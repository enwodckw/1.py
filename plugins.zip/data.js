var data_a1e2fb4a_e986_4524_b0da_9b7ba7c0874d = 
{
	"main": {
		"floorIds": [
			"ML1",
			"ML2",
			"ML3",
			"ML4",
			"ML5",
			"ML6",
			"ML7",
			"ML8",
			"ML9",
			"ML10",
			"ML11",
			"ML12",
			"ML13",
			"ML14",
			"ML15",
			"ML16",
			"ML17",
			"ML18",
			"ML19",
			"ML20",
			"ML21",
			"ML22",
			"ML23",
			"ML24",
			"ML25",
			"ML26",
			"ML27",
			"ML28",
			"ML29",
			"ML30",
			"MT0",
			"MT1",
			"MT2",
			"MT3",
			"MT4",
			"MT5",
			"MT6",
			"MT7",
			"MT8",
			"MT9",
			"MT10",
			"MT11",
			"MT12",
			"MT13",
			"MT14",
			"MT15",
			"MT16",
			"MT17",
			"MT18",
			"MT19",
			"MT20",
			"MT21",
			"MT22",
			"MT23",
			"MT24",
			"MT25",
			"MT26",
			"MT27",
			"MT28",
			"MT29",
			"MT30",
			"MT31",
			"MM1",
			"MT32",
			"MT33",
			"MT34",
			"MT35",
			"MT36",
			"MT37",
			"MT38",
			"MT39",
			"MT40",
			"MM2",
			"MM3",
			"MT41",
			"MT42",
			"MT43",
			"MT44",
			"MT45",
			"MT46",
			"MT47",
			"MT48",
			"MT49",
			"MT50",
			"MT51",
			"MT52",
			"MT53",
			"MT54",
			"MT55",
			"MT56",
			"MT57",
			"MT58",
			"MT59",
			"MT60",
			"MT61",
			"MT62",
			"MT63",
			"MT64",
			"MT65",
			"MT66",
			"MT67",
			"MT68",
			"MT69",
			"MT70",
			"MT71",
			"MT72",
			"MT73",
			"MT74",
			"MT75",
			"MT76",
			"MT77",
			"MT78",
			"MT79",
			"MT80",
			"MT81",
			"MT82",
			"MT83",
			"MT84",
			"MT85",
			"MT86",
			"MT87",
			"MT88",
			"MT89",
			"MT90",
			"MT91",
			"MT92",
			"MT93",
			"MT94",
			"MT95",
			"MT96",
			"MT97",
			"MT98",
			"MT99",
			"MT100",
			"MT101",
			"MT102",
			"MT103",
			"MT104",
			"MT105",
			"MT106",
			"MT107",
			"MT108",
			"MT109",
			"MT110",
			"MT111",
			"MT112",
			"MT113",
			"MT114",
			"MT115",
			"MT116",
			"MT117",
			"MT118",
			"MT119",
			"MT120",
			"MT121",
			"MT122",
			"MT123",
			"MT124",
			"MT125",
			"MT126",
			"MT127",
			"MT128",
			"MT129",
			"MT130",
			"MT131",
			"MT132",
			"MT133",
			"MT134",
			"MT135",
			"MT136",
			"MT137",
			"MT138",
			"MT139",
			"MT140",
			"MT141",
			"MT142",
			"MT143",
			"MT144",
			"MT145",
			"MT146",
			"MT147",
			"MT148",
			"MT149",
			"MT150",
			"MT151",
			"MT152",
			"MT153",
			"MT154",
			"MT155",
			"MT156",
			"MT157",
			"MT158",
			"MT159",
			"MT160",
			"MT161",
			"MT162",
			"MT163",
			"MT164",
			"MT165",
			"MT166",
			"MT167",
			"MT168",
			"MT169",
			"MT170",
			"MT171",
			"MT172",
			"MT173",
			"MT174",
			"MT175",
			"MT176",
			"MT177",
			"MT178",
			"MT179",
			"MT180",
			"MT181",
			"MT182",
			"MT183",
			"MT184",
			"MT185",
			"MT186",
			"MT187",
			"MT188",
			"MT189",
			"MT190",
			"MT191",
			"MT192",
			"MT193",
			"MT194",
			"MT195",
			"MT196",
			"MT197",
			"MT198",
			"MT199",
			"MT200",
			"MO1",
			"MT201",
			"MT202",
			"MT203",
			"MT204",
			"MT205",
			"MT206",
			"MT207",
			"MT208",
			"MT209",
			"MT210",
			"MT211",
			"MT212",
			"MT213",
			"MT214",
			"MT215",
			"MT216",
			"MT217",
			"MT218",
			"MT219",
			"MT220",
			"MT221",
			"MT222",
			"MT223",
			"MT224",
			"MT225",
			"MT226",
			"MT227",
			"MT228",
			"MT229",
			"MT230",
			"MT231",
			"MT232",
			"MT233",
			"MT234",
			"MT235",
			"MT236",
			"MT237",
			"MT238",
			"MT239",
			"MT240",
			"MT241",
			"MT242",
			"MT243",
			"MT244",
			"MT245",
			"MT246",
			"MT247",
			"MT248",
			"MT249",
			"MT250",
			"MT251",
			"MT252",
			"MT253",
			"MT254",
			"MT255",
			"MT256",
			"MT257",
			"MT258",
			"MT259",
			"MT260",
			"MT261",
			"MT262",
			"MT263",
			"MT264",
			"MT265",
			"MT266",
			"MT267",
			"MT268",
			"MT269",
			"MT270",
			"MT271",
			"MT272",
			"MT273",
			"MT274",
			"MT275",
			"MT276",
			"MT277",
			"MT278",
			"MT279",
			"MT280",
			"MT281",
			"MT282",
			"MT283",
			"MT284",
			"MT285",
			"MT286",
			"MT287",
			"MT288",
			"MT289",
			"MT290",
			"MT291",
			"MT292",
			"MT293",
			"MT294",
			"MT295",
			"MT296",
			"MT297",
			"MT298",
			"MT299",
			"MT300",
			"MT301",
			"MT302",
			"MT303",
			"MT304",
			"MT305",
			"MT306",
			"MT307",
			"MT308",
			"MT309",
			"MT310",
			"MT311",
			"MT312",
			"MT313",
			"MT314",
			"MT315",
			"MT316",
			"MT317",
			"MT318",
			"MT319",
			"MT320",
			"MT321",
			"MT322",
			"MT323",
			"MT324",
			"MT325",
			"MT326",
			"MT327",
			"MT328",
			"MT329",
			"MT330",
			"MT331",
			"MT332",
			"MT333",
			"MT334",
			"MT335",
			"MT336",
			"MT337",
			"MT338",
			"MT339",
			"MT340",
			"MT341",
			"MT342",
			"MT343",
			"MT344",
			"MT345",
			"MT346",
			"MT347",
			"MT348",
			"MT349",
			"MT350",
			"MT351",
			"MT352",
			"MT353",
			"MT354",
			"MT355",
			"MT356",
			"MT357",
			"MT358",
			"MT359",
			"MT360",
			"MT361",
			"MT362",
			"MT363",
			"MT364",
			"MT365",
			"MT366",
			"MT367",
			"MT368",
			"MT369",
			"MT370",
			"MT371",
			"MT372",
			"MT373",
			"MT374",
			"MT375",
			"MT376",
			"MT377",
			"MT378",
			"MT379",
			"MT380",
			"MT381",
			"MT382",
			"MT383",
			"MT384",
			"MT385",
			"MT386",
			"MT387",
			"MT388",
			"MT389",
			"MT390",
			"MT391",
			"MT392",
			"MT393",
			"MT394",
			"MT395",
			"MT396",
			"MT397",
			"MT398",
			"MT399",
			"MT400",
			"MN1",
			"MN2",
			"MN3",
			"MN4",
			"MN5",
			"MN6",
			"MN7",
			"MN8",
			"MN9",
			"MN10",
			"MN11",
			"MT401",
			"MT402",
			"MT403",
			"MT404",
			"MT405",
			"MT406",
			"MT407",
			"MT408",
			"MT409",
			"MT410",
			"MT411",
			"MT412",
			"MT413",
			"MT414",
			"MT415",
			"MT416",
			"MT417",
			"MT418",
			"MT419",
			"MT420",
			"MT421",
			"MT422",
			"MT423",
			"MT424",
			"MT425",
			"MT426",
			"MT427",
			"MT428",
			"MT429",
			"MT430",
			"MT431",
			"MT432",
			"MT433",
			"MT434",
			"MT435",
			"MT436",
			"MT437",
			"MT438",
			"MT439",
			"MT440",
			"MT441",
			"MT442",
			"MT443",
			"MT444",
			"MT445",
			"MT446",
			"MT447",
			"MT448",
			"MT449",
			"MT450",
			"MT451",
			"MT452",
			"MT453",
			"MT454",
			"MT455",
			"MN12",
			"MT456",
			"MT457",
			"MT458",
			"MT459",
			"MT460",
			"MT461",
			"MT462",
			"MT463",
			"MT464",
			"MT465",
			"MT466",
			"MT467",
			"MT468",
			"MT469",
			"MT470",
			"MT471",
			"MT472",
			"MT473",
			"MT474",
			"MT475",
			"MT476",
			"MT477",
			"MT478",
			"MT479",
			"MT480",
			"MT481",
			"MT482",
			"MT483",
			"MT484",
			"MT485",
			"MT486",
			"MT487",
			"MT488",
			"MT489",
			"MT490",
			"MT491",
			"MT492",
			"MT493",
			"MT494",
			"MT495",
			"MT496",
			"MT497",
			"MT498",
			"MT499",
			"MT500",
			"MT501",
			"MT502",
			"MT503",
			"MT504",
			"MT505",
			"MT506",
			"MT507",
			"MT508",
			"MT509",
			"MT510",
			"MT511",
			"MT512",
			"MT513",
			"MT514",
			"MT515",
			"MT516",
			"MT517",
			"MT518",
			"MT519",
			"MT520",
			"MT521",
			"MT522",
			"MT523",
			"MT524",
			"MT525",
			"MT526",
			"MT527",
			"MT528",
			"MT529",
			"MT530",
			"MT531",
			"MT532",
			"MT533",
			"MT534",
			"MT535",
			"MT536",
			"MT537",
			"MT538",
			"MT539",
			"MT540",
			"MT541",
			"MT542",
			"MT543",
			"MT544",
			"MT545",
			"MT546",
			"MT547",
			"MT548",
			"MT549",
			"MT550",
			"MT551",
			"MT552",
			"MT553",
			"MT554",
			"MT555",
			"MT556",
			"MT557",
			"MT558",
			"MT559",
			"MT560",
			"MT561",
			"MT562",
			"MT563",
			"MT564",
			"MT565",
			"MT566",
			"MT567",
			"MT568",
			"MT569",
			"MT570",
			"MT571",
			"MT572",
			"MT573",
			"MT574",
			"MT575",
			"MT576",
			"MT577",
			"MT578",
			"MT579",
			"MT580",
			"MT581",
			"MT582",
			"MT583",
			"MT584",
			"MT585",
			"MT586",
			"MT587",
			"MT588",
			"MT589",
			"MT590",
			"MT591",
			"MT592",
			"MT593",
			"MT594",
			"MT595",
			"MT596",
			"MT597",
			"MT598",
			"MT599",
			"MT600",
			"MP5",
			"MP6",
			"MT601",
			"MT602",
			"MT603",
			"MT604",
			"MT605",
			"MT606",
			"MT607",
			"MT608",
			"MT609",
			"MT610",
			"MT611",
			"MT612",
			"MT613",
			"MT614",
			"MT615",
			"MT616",
			"MT617",
			"MT618",
			"MT619",
			"MT620",
			"MT621",
			"MT622",
			"MT623",
			"MT624",
			"MT625",
			"MT626",
			"MT627",
			"MT628",
			"MT629",
			"MT630",
			"MT631",
			"MT632",
			"MT633",
			"MT634",
			"MT635",
			"MT636",
			"MT637",
			"MT638",
			"MT639",
			"MT640",
			"MT641",
			"MT642",
			"MT643",
			"MT644",
			"MT645",
			"MT646",
			"MT647",
			"MT648",
			"MT649",
			"MT650",
			"MT651",
			"MT652",
			"MT653",
			"MT654",
			"MT655",
			"MT656",
			"MT657",
			"MT658",
			"MT659",
			"MT660",
			"MT661",
			"MT662",
			"MT663",
			"MT664",
			"MT665",
			"MT666",
			"MT667",
			"MT668",
			"MT669",
			"MT670",
			"MT671",
			"MT672",
			"MT673",
			"MT674",
			"MT675",
			"MT676",
			"MT677",
			"MT678",
			"MT679",
			"MT680",
			"MT681",
			"MT682",
			"MT683",
			"MT684",
			"MT685",
			"MT686",
			"MT687",
			"MT688",
			"MT689",
			"MT690",
			"MT691",
			"MT692",
			"MT693",
			"MT694",
			"MT695",
			"MT696",
			"MT697",
			"MT698",
			"MT699",
			"MT700",
			"MT701",
			"MT702",
			"MT703",
			"MT704",
			"MT705",
			"MT706",
			"MT707",
			"MT708",
			"MT709",
			"MT710",
			"MT711",
			"MT712",
			"MT713",
			"MT714",
			"MT715",
			"MT716",
			"MT717",
			"MT718",
			"MT719",
			"MT720",
			"MT721",
			"MT722",
			"MT723",
			"MT724",
			"MT725",
			"MT726",
			"MT727",
			"MT728",
			"MT729",
			"MT730",
			"MT731",
			"MT732",
			"MT733",
			"MT734",
			"MT735",
			"MT736",
			"MT737",
			"MT738",
			"MT739",
			"MT740",
			"MT741",
			"MT742",
			"MT743",
			"MT744",
			"MT745",
			"MT746",
			"MT747",
			"MT748",
			"MT749",
			"MT750",
			"MT751",
			"MT752",
			"MT753",
			"MT754",
			"MT755",
			"MT756",
			"MT757",
			"MT758",
			"MT759",
			"MT760",
			"MT761",
			"MT762",
			"MT763",
			"MT764",
			"MT765",
			"MT766",
			"MT767",
			"MT768",
			"MT769",
			"MT770",
			"MT771",
			"MT772",
			"MT773",
			"MT774",
			"MT775",
			"MT776",
			"MT777",
			"MT778",
			"MT779",
			"MT780",
			"MT781",
			"MT782",
			"MT783",
			"MT784",
			"MT785",
			"MT786",
			"MT787",
			"MT788",
			"MT789",
			"MT790",
			"MT791",
			"MT792",
			"MT793",
			"MT794",
			"MT795",
			"MT796",
			"MT797",
			"MT798",
			"MT799",
			"MT800",
			"MS1",
			"MS2",
			"MS3",
			"MS4",
			"MS5",
			"MT801",
			"MT802",
			"MT803",
			"MT804",
			"MT805",
			"MT806",
			"MT807",
			"MT808",
			"MT809",
			"MT810",
			"MT811",
			"MT812",
			"MT813",
			"MT814",
			"MT815",
			"MT816",
			"MT817",
			"MT818",
			"MT819",
			"MT820",
			"MT821",
			"MT822",
			"MT823",
			"MT824",
			"MT825",
			"MT826",
			"MT827",
			"MT828",
			"MT829",
			"MT830",
			"MT831",
			"MT832",
			"MT833",
			"MT834",
			"MT835",
			"MT836",
			"MT837",
			"MT838",
			"MT839",
			"MT840",
			"MT841",
			"MT842",
			"MT843",
			"MT844",
			"MT845",
			"MT846",
			"MT847",
			"MT848",
			"MT849",
			"MT850",
			"MS6"
		],
		"floorPartitions": [],
		"images": [
			"bear.png",
			"bg.jpg",
			"dragon.png",
			"hero.png",
			"winskin.png"
		],
		"tilesets": [
			"magictower.png"
		],
		"animates": [
			"baozha",
			"double",
			"hand",
			"sword",
			"yongchang",
			"zone"
		],
		"bgms": [
			"601.mp3",
			"bgm.mp3",
			"bgm1.mp3",
			"boss.mp3",
			"ks.mp3",
			"luolan.mp3",
			"mj.mp3",
			"q.mp3",
			"qxzd.mp3",
			"shanmai.mp3",
			"waiwei.mp3",
			"wuqu.mp3",
			"yiji.mp3"
		],
		"sounds": [
			"attack.mp3",
			"bomb.mp3",
			"cancel.mp3",
			"centerFly.mp3",
			"confirm.mp3",
			"cursor.mp3",
			"door.mp3",
			"equip.mp3",
			"error.mp3",
			"floor.mp3",
			"gem.mp3",
			"hy.mp3",
			"icePickaxe.mp3",
			"item.mp3",
			"jump.mp3",
			"leiji.mp3",
			"load.mp3",
			"open_ui.mp3",
			"pickaxe.mp3",
			"recovery.mp3",
			"save.mp3",
			"shop.mp3",
			"zone.mp3"
		],
		"fonts": [],
		"nameMap": {
			"确定": "confirm.mp3",
			"取消": "cancel.mp3",
			"操作失败": "error.mp3",
			"光标移动": "cursor.mp3",
			"打开界面": "open_ui.mp3",
			"读档": "load.mp3",
			"存档": "save.mp3",
			"获得道具": "item.mp3",
			"回血": "recovery.mp3",
			"炸弹": "bomb.mp3",
			"飞行器": "centerFly.mp3",
			"开关门": "door.mp3",
			"上下楼": "floor.mp3",
			"跳跃": "jump.mp3",
			"破墙镐": "pickaxe.mp3",
			"破冰镐": "icePickaxe.mp3",
			"宝石": "gem.mp3",
			"阻激夹域": "zone.mp3",
			"穿脱装备": "equip.mp3",
			"背景音乐": "bgm.mp3",
			"攻击": "attack.mp3",
			"背景图": "bg.jpg",
			"商店": "shop.mp3",
			"领域": "zone"
		},
		"levelChoose": null,
		"equipName": [
			"功法",
			"神器",
			"阵法",
			"境界证明",
			"护甲",
			"护符"
		],
		"startBgm": "ks.mp3",
		"styles": {
			"startBackground": "project/images/bg.jpg",
			"startVerticalBackground": "project/images/bg.jpg",
			"startLogoStyle": "display:none",
			"startButtonsStyle": "background-color: #32369F; opacity: 0.85; color: #FFFFFF; border: #FFFFFF 2px solid; caret-color: #FFD700;",
			"statusLeftBackground": "url(project/materials/ground.png) repeat",
			"statusTopBackground": "url(project/materials/ground.png) repeat",
			"toolsBackground": "url(project/materials/ground.png) repeat",
			"floorChangingStyle": "background-color: black; color: white",
			"statusBarColor": [
				255,
				255,
				255,
				1
			],
			"borderColor": [
				204,
				204,
				204,
				1
			],
			"selectColor": [
				255,
				215,
				0,
				1
			],
			"font": "Verdana"
		},
		"splitImages": [
			{
				"name": "dragon.png",
				"width": 384,
				"height": 96,
				"prefix": "dragon_"
			}
		]
	},
	"firstData": {
		"title": "成仙之路",
		"name": "cxzl",
		"version": "Ver 2.9.1",
		"floorId": "MT0",
		"hero": {
			"image": "hero.png",
			"animate": false,
			"name": "影枫",
			"lv": 1,
			"hpmax": 9999,
			"hp": 1000,
			"manamax": -1,
			"mana": 0,
			"atk": 0,
			"def": 0,
			"mdef": 0,
			"money": 0,
			"exp": 0,
			"equipment": [],
			"items": {
				"constants": {},
				"tools": {},
				"equips": {}
			},
			"loc": {
				"direction": "up",
				"x": 6,
				"y": 2
			},
			"flags": {},
			"followers": [],
			"steps": 0
		},
		"startCanvas": [
			{
				"type": "comment",
				"text": "在这里可以用事件来自定义绘制标题界面的背景图等"
			},
			{
				"type": "comment",
				"text": "也可以直接切换到其他楼层（比如某个开始剧情楼层）进行操作。"
			},
			{
				"type": "previewUI",
				"action": [
					{
						"type": "fillRect",
						"x": 0,
						"y": 0,
						"width": "core.__PIXELS__",
						"height": "core.__PIXELS__",
						"style": [
							82,
							82,
							82,
							1
						]
					},
					{
						"type": "setAttribute",
						"align": "center"
					},
					{
						"type": "fillBoldText",
						"x": "core.__PIXELS__ / 2",
						"y": 80,
						"style": [
							255,
							255,
							255,
							1
						],
						"strokeStyle": [
							0,
							0,
							0,
							1
						],
						"font": "bold 40px Verdana",
						"text": "${core.firstData.title}"
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:selection",
				"value": "0"
			},
			{
				"type": "comment",
				"text": "在右下方自绘一个对话框进行显示选择项"
			},
			{
				"type": "previewUI",
				"action": [
					{
						"type": "fillRect",
						"x": 230,
						"y": 250,
						"width": 150,
						"height": 142,
						"radius": 10,
						"style": [
							8,
							180,
							233,
							0.85
						]
					},
					{
						"type": "strokeRect",
						"x": 230,
						"y": 250,
						"width": 150,
						"height": 142,
						"radius": 10,
						"style": [
							255,
							255,
							255,
							1
						],
						"lineWidth": 2
					},
					{
						"type": "fillBoldText",
						"x": 305,
						"y": 290,
						"style": [
							250,
							12,
							197,
							1
						],
						"strokeStyle": [
							212,
							13,
							241,
							1
						],
						"font": "bold 25px Verdana",
						"text": "开始征程"
					},
					{
						"type": "fillBoldText",
						"x": 305,
						"y": 330,
						"style": [
							247,
							211,
							22,
							1
						],
						"strokeStyle": [
							234,
							199,
							13,
							1
						],
						"font": "bold 25px Verdana",
						"text": "回忆过去"
					},
					{
						"type": "fillBoldText",
						"x": 305,
						"y": 370,
						"style": [
							13,
							231,
							85,
							1
						],
						"strokeStyle": [
							13,
							227,
							63,
							1
						],
						"font": "bold 25px Verdana",
						"text": "回放录像"
					}
				]
			},
			{
				"type": "while",
				"condition": "1",
				"data": [
					{
						"type": "drawSelector",
						"image": "winskin.png",
						"code": 1,
						"x": 245,
						"y": "261 + 40*flag:selection",
						"width": 120,
						"height": 40
					},
					{
						"type": "wait",
						"data": [
							{
								"case": "keyboard",
								"keycode": "13,32",
								"break": true,
								"action": [
									{
										"type": "switch",
										"condition": "flag:selection",
										"caseList": [
											{
												"case": "0",
												"action": [
													{
														"type": "comment",
														"text": "在“开始征程”确定"
													},
													{
														"type": "break",
														"n": 1
													}
												]
											},
											{
												"case": "1",
												"action": [
													{
														"type": "comment",
														"text": "在“回忆过去”确定"
													},
													{
														"type": "callLoad"
													}
												]
											},
											{
												"case": "2",
												"action": [
													{
														"type": "comment",
														"text": "在“回放录像”确定"
													},
													{
														"type": "if",
														"condition": "(!core.isReplaying())",
														"true": [
															{
																"type": "function",
																"function": "function(){\ncore.chooseReplayFile()\n}"
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": "38",
								"break": true,
								"action": [
									{
										"type": "comment",
										"text": "光标上键"
									},
									{
										"type": "setValue",
										"name": "flag:selection",
										"value": "(flag:selection + 2) % 3"
									}
								]
							},
							{
								"case": "keyboard",
								"keycode": "40",
								"break": true,
								"action": [
									{
										"type": "comment",
										"text": "光标下键"
									},
									{
										"type": "setValue",
										"name": "flag:selection",
										"value": "(flag:selection + 1) % 3"
									}
								]
							},
							{
								"case": "mouse",
								"px": [
									245,
									365
								],
								"py": [
									261,
									300
								],
								"break": true,
								"action": [
									{
										"type": "comment",
										"text": "点击“开始征程”"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"case": "mouse",
								"px": [
									245,
									365
								],
								"py": [
									301,
									340
								],
								"break": true,
								"action": [
									{
										"type": "comment",
										"text": "点击“回忆过去”"
									},
									{
										"type": "callLoad"
									}
								]
							},
							{
								"case": "mouse",
								"px": [
									245,
									365
								],
								"py": [
									341,
									380
								],
								"break": true,
								"action": [
									{
										"type": "comment",
										"text": "点击“播放录像”"
									},
									{
										"type": "if",
										"condition": "(!core.isReplaying())",
										"true": [
											{
												"type": "function",
												"function": "function(){\ncore.chooseReplayFile()\n}"
											}
										]
									}
								]
							}
						]
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:selection",
				"value": "null"
			},
			{
				"type": "drawSelector",
				"code": 1
			},
			{
				"type": "clearMap"
			},
			{
				"type": "function",
				"function": "function(){\ncore.control.checkBgm()\n}"
			},
			{
				"type": "if",
				"condition": "(main.levelChoose.length == 0)",
				"true": [
					{
						"type": "comment",
						"text": "没有难度选择：直接开始游戏"
					}
				],
				"false": [
					{
						"type": "comment",
						"text": "难度选择：作为样例，这里只提供了一个显示选择项。"
					},
					{
						"type": "function",
						"function": "function(){\nvar choices = [];\nmain.levelChoose.forEach(function (one) {\n\tchoices.push({\n\t\t\"text\": one.title || '',\n\t\t\"action\": [\n\t\t\t{ \"type\": \"function\", \"function\": \"function() { core.status.hard = '\" + (one.name || '') + \"'; }\" }\n\t\t]\n\t});\n})\ncore.insertAction({ \"type\": \"choices\", \"choices\": choices });\n}"
					},
					{
						"type": "comment",
						"text": "你也可以仿照上面的样例进行自己创建等待用户操作来处理不同的难度分歧。\n如需自己处理，请设置 core.status.hard \n（例如，自定义js脚本：core.status.hard = 'Easy' ）"
					}
				]
			},
			{
				"type": "clearMap"
			},
			{
				"type": "comment",
				"text": "接下来会执行startText中的事件"
			},
			{
				"type": "comment",
				"text": "状态栏默认处于隐藏状态；可以使用“显示状态栏”事件进行显示。"
			}
		],
		"startText": [
			{
				"type": "hide",
				"loc": [
					[
						6,
						1
					]
				],
				"floorId": "MT0"
			},
			"我叫影枫,乃是一名初入修炼者，因为没有任何背景，处处被人欺压，在走投无路时，偶然听到了一个可以成仙的秘密，相传在很久以前有一座从天而降的塔，此塔看不到高度，听别人说如果能爬到塔顶，就可以寻找到成仙之道，于是大量而来的散修或各门派弟子纷纷踏入此塔，而我也是其中一个，因为实力太弱又没有任何背景，只能排在了最后进入",
			"很多素材出自大神Material and art之手，多谢大神"
		],
		"shops": [
			{
				"id": "shop1",
				"text": "\t[贪婪之神,moneyShop]给我绿钥匙,换取你想要的强力道具",
				"textInList": "绿钥匙兑换商店",
				"mustEnable": false,
				"disablePreview": false,
				"choices": [
					{
						"text": "强力炸弹 +1  (20绿钥匙)",
						"need": "item:greenKey>=20",
						"action": [
							{
								"type": "setValue",
								"name": "item:greenKey",
								"operator": "-=",
								"value": "20"
							},
							{
								"type": "setValue",
								"name": "item:I618",
								"operator": "+=",
								"value": "1"
							}
						]
					},
					{
						"text": "地震卷轴 +1  (20绿钥匙)",
						"need": "item:greenKey>=20",
						"action": [
							{
								"type": "setValue",
								"name": "item:greenKey",
								"operator": "-=",
								"value": "20"
							},
							{
								"type": "setValue",
								"name": "item:earthquake",
								"operator": "+=",
								"value": "1"
							}
						]
					},
					{
						"text": "普通炸弹 +1  (20绿钥匙)",
						"need": "item:greenKey>=20",
						"action": [
							{
								"type": "setValue",
								"name": "item:greenKey",
								"operator": "-=",
								"value": "20"
							},
							{
								"type": "setValue",
								"name": "item:bomb",
								"operator": "+=",
								"value": "1"
							}
						]
					}
				]
			},
			{
				"id": "shop2",
				"text": "\t[贪婪之神,moneyShop]给我绿钥匙,换取你想要的强力道具",
				"textInList": "绿钥匙兑换商店",
				"mustEnable": false,
				"disablePreview": false,
				"choices": [
					{
						"text": "强力炸弹 +1  (50绿钥匙)",
						"need": "item:greenKey>=50",
						"action": [
							{
								"type": "setValue",
								"name": "item:greenKey",
								"operator": "-=",
								"value": "50"
							},
							{
								"type": "setValue",
								"name": "item:I618",
								"operator": "+=",
								"value": "1"
							}
						]
					},
					{
						"text": "全属性 + 1亿 (50绿钥匙)",
						"need": "item:greenKey>=50",
						"action": [
							{
								"type": "setValue",
								"name": "item:greenKey",
								"operator": "-=",
								"value": "50"
							},
							{
								"type": "setValue",
								"name": "status:atk",
								"operator": "+=",
								"value": "100000000"
							},
							{
								"type": "setValue",
								"name": "status:def",
								"operator": "+=",
								"value": "100000000"
							},
							{
								"type": "setValue",
								"name": "status:mdef",
								"operator": "+=",
								"value": "100000000"
							}
						]
					},
					{
						"text": "普通炸弹 +1  (50绿钥匙)",
						"need": "item:greenKey>=50",
						"action": [
							{
								"type": "setValue",
								"name": "item:greenKey",
								"operator": "-=",
								"value": "50"
							},
							{
								"type": "setValue",
								"name": "item:bomb",
								"operator": "+=",
								"value": "1"
							}
						]
					}
				]
			},
			{
				"id": "shop3",
				"text": "\t[贪婪之神,moneyShop]给我护盾值,换取你想要的道具",
				"textInList": "护盾值兑换商店",
				"mustEnable": false,
				"disablePreview": false,
				"choices": [
					{
						"text": "隐身魔法棒 +1  ( 500京 护盾)",
						"need": "status:mdef>=5000000000000000000",
						"color": [
							254,
							137,
							13,
							1
						],
						"action": [
							{
								"type": "setValue",
								"name": "status:mdef",
								"operator": "-=",
								"value": "5000000000000000000"
							},
							{
								"type": "setValue",
								"name": "item:I340",
								"operator": "+=",
								"value": "1"
							}
						]
					},
					{
						"text": "破墙镐 +1  ( 1000京 护盾)",
						"need": "status:mdef>=10000000000000000000",
						"color": [
							14,
							242,
							237,
							1
						],
						"action": [
							{
								"type": "setValue",
								"name": "status:mdef",
								"operator": "-=",
								"value": "10000000000000000000"
							},
							{
								"type": "setValue",
								"name": "item:pickaxe",
								"operator": "+=",
								"value": "1"
							}
						]
					},
					{
						"text": "攻击力 + 500兆 ( 500京 护盾)",
						"need": "status:mdef>=5000000000000000000",
						"color": [
							255,
							236,
							0,
							1
						],
						"action": [
							{
								"type": "setValue",
								"name": "status:mdef",
								"operator": "-=",
								"value": "5000000000000000000"
							},
							{
								"type": "setValue",
								"name": "status:atk",
								"operator": "+=",
								"value": "500000000000000"
							}
						]
					},
					{
						"text": "防御力 + 500兆 ( 500京 护盾)",
						"need": "status:mdef>=5000000000000000000",
						"color": [
							6,
							131,
							247,
							1
						],
						"action": [
							{
								"type": "setValue",
								"name": "status:mdef",
								"operator": "-=",
								"value": "5000000000000000000"
							},
							{
								"type": "setValue",
								"name": "status:def",
								"operator": "+=",
								"value": "500000000000000"
							}
						]
					},
					{
						"text": "红钥匙 + 1 ( 5京 护盾)",
						"need": "status:mdef>=50000000000000000",
						"color": [
							255,
							0,
							74,
							1
						],
						"action": [
							{
								"type": "setValue",
								"name": "status:mdef",
								"operator": "-=",
								"value": "50000000000000000"
							},
							{
								"type": "setValue",
								"name": "item:redKey",
								"operator": "+=",
								"value": "1"
							}
						]
					}
				]
			}
		],
		"levelUp": [
			{
				"need": "0",
				"title": "剑徒",
				"clear": true,
				"action": [
					{
						"type": "comment",
						"text": "此处是初始等级，只需填写称号"
					}
				]
			},
			{
				"need": "5",
				"title": "剑者",
				"clear": true,
				"action": [
					"恭喜升级,攻击+1",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1"
					}
				]
			},
			{
				"need": "20",
				"title": "剑师",
				"clear": true,
				"action": [
					"恭喜升级,攻击+2",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "2"
					}
				]
			},
			{
				"need": "40",
				"title": "剑灵",
				"clear": true,
				"action": [
					"恭喜升级,攻击+2,防御+3",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "2"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "3"
					}
				]
			},
			{
				"need": "60",
				"title": "剑尊",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "5"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "5"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "5"
					}
				]
			},
			{
				"need": "80",
				"title": "剑王",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "5"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "5"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "5"
					}
				]
			},
			{
				"need": "100",
				"title": "剑圣",
				"clear": true,
				"action": [
					"恭喜升级,全属性+15",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "15"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "15"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "15"
					}
				]
			},
			{
				"need": "120",
				"title": "剑神",
				"clear": true,
				"action": [
					"恭喜升级,全属性+15",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "15"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "15"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "15"
					}
				]
			},
			{
				"need": "150",
				"title": "炼魂境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+30",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "30"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "30"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "30"
					}
				]
			},
			{
				"need": "170",
				"title": "炼魄境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+80",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "80"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "80"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "80"
					}
				]
			},
			{
				"need": "200",
				"title": "斩灵境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+160",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "160"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "160"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "160"
					}
				]
			},
			{
				"need": "230",
				"title": "三灾境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+160",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "160"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "160"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "160"
					}
				]
			},
			{
				"need": "250",
				"title": "九难境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+320",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "320"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "320"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "320"
					}
				]
			},
			{
				"need": "270",
				"title": "神位境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+320",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "320"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "320"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "320"
					}
				]
			},
			{
				"need": "300",
				"title": "乾坤境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+650",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "650"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "650"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "650"
					}
				]
			},
			{
				"need": "400",
				"title": "灵君境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+650",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "650"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "650"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "650"
					}
				]
			},
			{
				"need": "500",
				"title": "皇君境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1000"
					}
				]
			},
			{
				"need": "600",
				"title": "帝君境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1000"
					}
				]
			},
			{
				"need": "800",
				"title": "造化九重",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1500",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1500"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1500"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1500"
					}
				]
			},
			{
				"need": "1000",
				"title": "封仙九重",
				"clear": true,
				"action": [
					"恭喜升级,全属性+10000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "10000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "10000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "10000"
					},
					"某种东西被激活，全属性增加10000",
					"\t[hero]这是什么东西？难道我的身体里面隐藏着什么，只能下次找器灵问问了",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "10000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "10000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "10000"
					}
				]
			},
			{
				"need": "1000",
				"title": "伪神格境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+20000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "20000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "20000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "20000"
					}
				]
			},
			{
				"need": "2000",
				"title": "神格境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+40000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "40000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "40000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "40000"
					}
				]
			},
			{
				"need": "5000",
				"title": "玄幽境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+100000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "100000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "100000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "100000"
					}
				]
			},
			{
				"need": "8000",
				"title": "转轮境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+300000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "300000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "300000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "300000"
					}
				]
			},
			{
				"need": "10000",
				"title": "轮回境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+500000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "500000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "500000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "500000"
					}
				]
			},
			{
				"need": "10000",
				"title": "生死境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+700000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "700000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "700000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "700000"
					}
				]
			},
			{
				"need": "14000",
				"title": "涅盘境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+900000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "900000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "900000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "900000"
					}
				]
			},
			{
				"need": "16000",
				"title": "羽化境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1100000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1100000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1100000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1100000"
					}
				]
			},
			{
				"need": "20000",
				"title": "虚神境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1300000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1300000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1300000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1300000"
					},
					"再次突破激活血脉,全属性增加100万",
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1000000"
					},
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1000000"
					}
				]
			},
			{
				"need": "24000",
				"title": "真仙境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1600000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1600000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1600000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1600000"
					}
				]
			},
			{
				"need": "28000",
				"title": "仙君境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "5000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "5000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "5000000"
					}
				]
			},
			{
				"need": "35000",
				"title": "金仙境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+15000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "15000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "15000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "15000000"
					}
				]
			},
			{
				"need": "40000",
				"title": "大罗金仙境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+30000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "30000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "30000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "30000000"
					}
				]
			},
			{
				"need": "50000",
				"title": "仙王境九变",
				"clear": true,
				"action": [
					"恭喜升级,全属性+45000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "45000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "45000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "45000000"
					}
				]
			},
			{
				"need": "75000",
				"title": "仙圣境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+60000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "60000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "60000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "60000000"
					}
				]
			},
			{
				"need": "90000",
				"title": "仙尊境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+90000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "90000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "90000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "90000000"
					}
				]
			},
			{
				"need": "110000",
				"title": "仙神境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+120000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "120000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "120000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "120000000"
					}
				]
			},
			{
				"need": "200000",
				"title": "不朽境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+200000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "200000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "200000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "200000000"
					},
					"再次激活血脉,全属性+100000000",
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "100000000"
					},
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "100000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "100000000"
					}
				]
			},
			{
				"need": "300000",
				"title": "地阶天尊境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+300000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "300000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "300000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "300000000"
					}
				]
			},
			{
				"need": "400000",
				"title": "天阶天尊境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+500000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "500000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "500000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "500000000"
					}
				]
			},
			{
				"need": "500000",
				"title": "神阶天尊境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+700000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "700000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "700000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "700000000"
					}
				]
			},
			{
				"need": "600000",
				"title": "大天尊境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1000000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1000000000"
					}
				]
			},
			{
				"need": "1000000",
				"title": "森罗万象境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+3000000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "3000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "3000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "3000000000"
					}
				]
			},
			{
				"need": "1200000",
				"title": "返虚炼元境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5000000000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "5000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "5000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "5000000000"
					}
				]
			},
			{
				"need": "1500000",
				"title": "万古不死境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+100亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "10000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "10000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "10000000000"
					}
				]
			},
			{
				"need": "1700000",
				"title": "圣人斩尸境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+300亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "30000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "30000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "30000000000"
					}
				]
			},
			{
				"need": "2000000",
				"title": "万劫不灭境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+600亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "60000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "60000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "60000000000"
					}
				]
			},
			{
				"need": "2500000",
				"title": "御天境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1000亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "100000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "100000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "100000000000"
					},
					"再次激活血脉,全属性+1000亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "100000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "100000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "100000000000"
					}
				]
			},
			{
				"need": "3000000",
				"title": "御仙境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+3兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "3000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "3000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "3000000000000"
					}
				]
			},
			{
				"need": "4000000",
				"title": "御神境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+6兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "6000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "6000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "6000000000000"
					}
				]
			},
			{
				"need": "5000000",
				"title": "御圣境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+15兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "15000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "15000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "15000000000000"
					}
				]
			},
			{
				"need": "6000000",
				"title": "下位踏天境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+25兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "25000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "25000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "25000000000000"
					}
				]
			},
			{
				"need": "8000000",
				"title": "上位踏天境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+50兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "50000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "50000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "50000000000000"
					}
				]
			},
			{
				"need": "10000000",
				"title": "天品踏天境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+90兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "90000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "90000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "90000000000000"
					}
				]
			},
			{
				"need": "15000000",
				"title": "圣品踏天境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+120兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "120000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "120000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "120000000000000"
					}
				]
			},
			{
				"need": "50000000",
				"title": "踏道境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+200兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "200000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "200000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "200000000000000"
					}
				]
			},
			{
				"need": "100000000",
				"title": "踏仙境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+500兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "500000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "500000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "500000000000000"
					}
				]
			},
			{
				"need": "150000000",
				"title": "下位破界境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1000兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1000000000000000"
					}
				]
			},
			{
				"need": "400000000",
				"title": "上位破界境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+2000兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "2000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "2000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "2000000000000000"
					}
				]
			},
			{
				"need": "600000000",
				"title": "神位破界境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1京",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "10000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "10000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "10000000000000000"
					}
				]
			},
			{
				"need": "1000000000",
				"title": "灵级界王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1京",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "10000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "10000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "10000000000000000"
					}
				]
			},
			{
				"need": "1000000000",
				"title": "王级界王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5京",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "50000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "50000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "50000000000000000"
					}
				]
			},
			{
				"need": "1500000000",
				"title": "天级界王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+10京",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "100000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "100000000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "100000000000000000"
					}
				]
			},
			{
				"need": "2000000000",
				"title": "圣级界王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+20",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "20"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "20"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "20"
					}
				]
			},
			{
				"need": "300",
				"title": "神级界王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+50",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "50"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "50"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "50"
					}
				]
			},
			{
				"need": "500",
				"title": "组级界王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1000"
					}
				]
			},
			{
				"need": "1000",
				"title": "混沌界王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "5000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "5000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "5000"
					},
					"再次激活血脉,全属性增加4000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "4000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "4000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "4000"
					}
				]
			},
			{
				"need": "1500",
				"title": "大界王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+15000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "15000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "15000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "15000"
					}
				]
			},
			{
				"need": "3000",
				"title": "超凡大界王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+4万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "40000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "40000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "40000"
					}
				]
			},
			{
				"need": "10000",
				"title": "真尊境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+10万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "100000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "100000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "100000"
					}
				]
			},
			{
				"need": "10000",
				"title": "真王境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+15万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "150000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "150000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "150000"
					}
				]
			},
			{
				"need": "20000",
				"title": "真圣境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+30万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "300000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "300000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "300000"
					}
				]
			},
			{
				"need": "20000",
				"title": "真域境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+50万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "500000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "500000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "500000"
					}
				]
			},
			{
				"need": "30000",
				"title": "真天境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+150万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1500000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1500000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1500000"
					}
				]
			},
			{
				"need": "40000",
				"title": "真皇境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+300万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "3000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "3000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "3000000"
					}
				]
			},
			{
				"need": "50000",
				"title": "真祖境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+600万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "6000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "6000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "6000000"
					}
				]
			},
			{
				"need": "50000",
				"title": "真沌境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1000万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "10000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "10000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "10000000"
					}
				]
			},
			{
				"need": "60000",
				"title": "下位王座境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+8000万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "80000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "80000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "80000000"
					}
				]
			},
			{
				"need": "80000",
				"title": "上位王座境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+2亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "200000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "200000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "200000000"
					}
				]
			},
			{
				"need": "110000",
				"title": "天位王座境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1"
					}
				]
			},
			{
				"need": "110000",
				"title": "仙位王座境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+200",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "300"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "300"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "300"
					}
				]
			},
			{
				"need": "110000",
				"title": "圣位王座境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1000"
					}
				]
			},
			{
				"need": "150000",
				"title": "神位王座境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+3000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "3000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "3000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "3000"
					}
				]
			},
			{
				"need": "150000",
				"title": "祖位王座境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+8000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "8000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "8000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "8000"
					}
				]
			},
			{
				"need": "200000",
				"title": "大王座境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+15000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "15000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "15000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "15000"
					}
				]
			},
			{
				"need": "300000",
				"title": "至高王座境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+40000",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "40000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "40000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "40000"
					}
				]
			},
			{
				"need": "500000",
				"title": "圣神之境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "50000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "50000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "50000"
					},
					"再次激活血脉,全属性+10万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "100000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "100000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "100000"
					}
				]
			},
			{
				"need": "750000",
				"title": "主神之境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+200万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "2000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "2000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "2000000"
					}
				]
			},
			{
				"need": "1000000",
				"title": "天神之境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+500万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "5000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "5000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "5000000"
					}
				]
			},
			{
				"need": "1300000",
				"title": "古神之境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1000万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "10000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "10000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "10000000"
					}
				]
			},
			{
				"need": "1500000",
				"title": "至高神境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+4000万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "40000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "40000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "40000000"
					}
				]
			},
			{
				"need": "1800000",
				"title": "神祖之境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+7000万",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "70000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "70000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "70000000"
					}
				]
			},
			{
				"need": "2000000",
				"title": "虚无神境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+1亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "100000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "100000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "100000000"
					}
				]
			},
			{
				"need": "2300000",
				"title": "周天神境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+2亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "250000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "250000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "250000000"
					}
				]
			},
			{
				"need": "2600000",
				"title": "昊天神境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+15亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "1500000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "1500000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "1500000000"
					}
				]
			},
			{
				"need": "4000000",
				"title": "造化神境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+45亿,再次激活血脉，敌人全属性降低5%",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "4500000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "4500000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "4500000000"
					}
				]
			},
			{
				"need": "6000000",
				"title": "涅神之境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5000亿",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "500000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "500000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "500000000000"
					},
					"激活全部血脉,全属性增加2千亿,获得血之结晶",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "200000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "200000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "200000000000"
					},
					{
						"type": "setValue",
						"name": "item:I1866",
						"operator": "+=",
						"value": "1"
					}
				]
			},
			{
				"need": "10000000",
				"title": "灵神之境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "5000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "5000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "5000000000000"
					}
				]
			},
			{
				"need": "15000000",
				"title": "乾神之境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+5兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "5000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "5000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "5000000000000"
					}
				]
			},
			{
				"need": "30000000",
				"title": "陀神之境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+15兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "15000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "15000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "15000000000000"
					}
				]
			},
			{
				"need": "50000000",
				"title": "鸿沟神境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+25兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "25000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "25000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "25000000000000"
					}
				]
			},
			{
				"need": "50000000",
				"title": "道天神境",
				"clear": true,
				"action": [
					"恭喜升级,全属性+50兆",
					{
						"type": "setValue",
						"name": "status:atk",
						"operator": "+=",
						"value": "50000000000000"
					},
					{
						"type": "setValue",
						"name": "status:mdef",
						"operator": "+=",
						"value": "50000000000000"
					},
					{
						"type": "setValue",
						"name": "status:def",
						"operator": "+=",
						"value": "50000000000000"
					}
				]
			}
		]
	},
	"values": {
		"lavaDamage": 100,
		"poisonDamage": 100000,
		"weakValue": 0.2,
		"redGem": 1,
		"blueGem": 1,
		"greenGem": 2,
		"redPotion": 300,
		"bluePotion": 600,
		"yellowPotion": 900,
		"greenPotion": 1200,
		"breakArmor": 0.9,
		"counterAttack": 0.1,
		"purify": 3,
		"hatred": 2,
		"animateSpeed": 300,
		"moveSpeed": 100,
		"statusCanvasRowsOnMobile": 3,
		"floorChangeTime": 500
	},
	"flags": {
		"statusBarItems": [
			"enableFloor",
			"enableName",
			"enableLv",
			"enableHP",
			"enableAtk",
			"enableDef",
			"enableMDef",
			"enableExp",
			"enableLevelUp",
			"levelUpLeftMode",
			"enableKeys",
			"enableGreenKey",
			"enablePZF",
			"enableDebuff"
		],
		"autoScale": true,
		"extendToolbar": false,
		"flyNearStair": true,
		"flyRecordPosition": false,
		"itemFirstText": true,
		"equipboxButton": false,
		"enableAddPoint": false,
		"enableNegativeDamage": false,
		"betweenAttackMax": true,
		"useLoop": false,
		"startUsingCanvas": false,
		"statusCanvas": false,
		"enableEnemyPoint": true,
		"enableGentleClick": true,
		"ignoreChangeFloor": true,
		"canGoDeadZone": true,
		"enableMoveDirectly": true,
		"enableRouteFolding": true,
		"disableShopOnDamage": false,
		"blurFg": false
	}
}