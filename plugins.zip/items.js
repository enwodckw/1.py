var items_296f5d02_12fd_4166_a7c1_b5e830c9ee3a = 
{
	"yellowKey": {
		"cls": "tools",
		"name": "黄钥匙",
		"text": "可以打开一扇黄门",
		"hideInToolbox": true
	},
	"blueKey": {
		"cls": "tools",
		"name": "蓝钥匙",
		"text": "可以打开一扇蓝门",
		"hideInToolbox": true
	},
	"redKey": {
		"cls": "tools",
		"name": "红钥匙",
		"text": "可以打开一扇红门",
		"hideInToolbox": true
	},
	"redGem": {
		"cls": "items",
		"name": "红宝石",
		"text": "攻击+${core.values.redGem}",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio",
		"itemEffectTip": null,
		"useItemEffect": "core.status.hero.atk += core.values.redGem",
		"canUseItemEffect": "true"
	},
	"blueGem": {
		"cls": "items",
		"name": "蓝宝石",
		"text": "，防御+${core.values.blueGem}",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio",
		"itemEffectTip": null,
		"useItemEffect": "core.status.hero.def += core.values.blueGem",
		"canUseItemEffect": "true"
	},
	"greenGem": {
		"cls": "items",
		"name": "绿宝石",
		"text": "，护盾+${core.values.greenGem}",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio",
		"itemEffectTip": null,
		"useItemEffect": "core.status.hero.mdef += core.values.greenGem",
		"canUseItemEffect": "true"
	},
	"yellowGem": {
		"cls": "items",
		"name": "黄宝石",
		"text": null,
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 1\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 1\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 1",
		"itemEffectTip": "，全属性提升",
		"useItemEvent": null,
		"canUseItemEffect": "true"
	},
	"redPotion": {
		"cls": "items",
		"name": "红血瓶",
		"text": "，生命+${core.values.redPotion}",
		"itemEffect": "core.status.hero.hp += core.values.redPotion * core.status.thisMap.ratio",
		"itemEffectTip": null,
		"useItemEffect": "core.status.hero.hp += core.values.redPotion",
		"canUseItemEffect": "true"
	},
	"bluePotion": {
		"cls": "items",
		"name": "蓝血瓶",
		"text": "，生命+${core.values.bluePotion}",
		"itemEffect": "core.status.hero.hp += core.values.bluePotion * core.status.thisMap.ratio",
		"itemEffectTip": null,
		"useItemEffect": "core.status.hero.hp += core.values.bluePotion",
		"canUseItemEffect": "true"
	},
	"yellowPotion": {
		"cls": "items",
		"name": "黄血瓶",
		"text": "，生命+${core.values.yellowPotion}",
		"itemEffect": "core.status.hero.hp += core.values.yellowPotion * core.status.thisMap.ratio",
		"itemEffectTip": null,
		"useItemEffect": "core.status.hero.hp += core.values.yellowPotion",
		"canUseItemEffect": "true"
	},
	"greenPotion": {
		"cls": "items",
		"name": "绿血瓶",
		"text": "，生命+${core.values.greenPotion}",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio",
		"itemEffectTip": null,
		"useItemEffect": "core.status.hero.hp += core.values.greenPotion",
		"canUseItemEffect": "true"
	},
	"sword0": {
		"cls": "items",
		"name": "破旧的剑",
		"text": "一把已经生锈的剑",
		"equip": {
			"type": 0,
			"animate": "sword",
			"value": {
				"atk": 0
			}
		},
		"itemEffect": "core.status.hero.atk += 3",
		"itemEffectTip": "，攻击+3",
		"useItemEffect": null
	},
	"sword1": {
		"cls": "items",
		"name": "铁剑",
		"text": "一把很普通的铁剑",
		"equip": {
			"type": 0,
			"animate": "sword",
			"value": {
				"atk": 10
			}
		},
		"itemEffect": "core.status.hero.atk += 10",
		"itemEffectTip": "，攻击+10"
	},
	"sword2": {
		"cls": "items",
		"name": "银剑",
		"text": "一把很普通的银剑",
		"equip": {
			"type": 0,
			"animate": "sword",
			"value": {
				"atk": 20
			}
		},
		"itemEffect": "core.status.hero.atk += 30",
		"itemEffectTip": "，攻击+30"
	},
	"sword3": {
		"cls": "items",
		"name": "骑士剑",
		"text": "一把很普通的骑士剑",
		"equip": {
			"type": 0,
			"animate": "sword",
			"value": {
				"atk": 40
			}
		},
		"itemEffect": "core.status.hero.atk += 100",
		"itemEffectTip": "，攻击+100"
	},
	"sword4": {
		"cls": "items",
		"name": "圣剑",
		"text": "一把很普通的圣剑",
		"equip": {
			"type": 0,
			"animate": "sword",
			"value": {
				"atk": 80
			}
		},
		"itemEffect": "core.status.hero.atk += 200",
		"itemEffectTip": "，攻击+200"
	},
	"sword5": {
		"cls": "items",
		"name": "神圣剑",
		"text": "一把很普通的神圣剑",
		"equip": {
			"type": 0,
			"animate": "sword",
			"value": {
				"atk": 160
			}
		},
		"itemEffect": "core.status.hero.atk += 2000",
		"itemEffectTip": "，攻击+2000"
	},
	"shield0": {
		"cls": "items",
		"name": "破旧的盾",
		"text": "一个很破旧的铁盾",
		"equip": {
			"type": 1,
			"value": {
				"def": 0
			}
		},
		"itemEffect": "core.status.hero.def += 3",
		"itemEffectTip": "，防御+3"
	},
	"shield1": {
		"cls": "items",
		"name": "铁盾",
		"text": "一个很普通的铁盾",
		"equip": {
			"type": 1,
			"value": {
				"def": 10
			}
		},
		"itemEffect": "core.status.hero.def += 10",
		"itemEffectTip": "，防御+10"
	},
	"shield2": {
		"cls": "items",
		"name": "银盾",
		"text": "一个很普通的银盾",
		"equip": {
			"type": 1,
			"value": {
				"def": 20
			}
		},
		"itemEffect": "core.status.hero.def += 30",
		"itemEffectTip": "，防御+30"
	},
	"shield3": {
		"cls": "items",
		"name": "骑士盾",
		"text": "一个很普通的骑士盾",
		"equip": {
			"type": 1,
			"value": {
				"def": 40
			}
		},
		"itemEffect": "core.status.hero.def += 100",
		"itemEffectTip": "，防御+100"
	},
	"shield4": {
		"cls": "items",
		"name": "圣盾",
		"text": "一个很普通的圣盾",
		"equip": {
			"type": 1,
			"value": {
				"def": 80
			}
		},
		"itemEffect": "core.status.hero.def += 200",
		"itemEffectTip": "，防御+200"
	},
	"shield5": {
		"cls": "items",
		"name": "神圣盾",
		"text": "一个很普通的神圣盾",
		"equip": {
			"type": 1,
			"value": {
				"def": 100,
				"mdef": 100
			}
		},
		"itemEffect": "core.status.hero.def += 2000;\ncore.status.hero.mdef += 4000",
		"itemEffectTip": "，防御+2000，护盾+4000"
	},
	"superPotion": {
		"cls": "items",
		"name": "圣水",
		"itemEffect": "core.status.hero.hp *= 2",
		"itemEffectTip": "，生命值翻倍",
		"useItemEffect": "core.status.hero.hp *= 2;core.playSound('回血');",
		"canUseItemEffect": "true",
		"text": "生命值翻倍"
	},
	"book": {
		"cls": "constants",
		"name": "怪物手册",
		"text": "可以查看当前楼层各怪物属性",
		"hideInToolbox": true,
		"useItemEffect": "core.ui.drawBook(0);",
		"canUseItemEffect": "true"
	},
	"fly": {
		"cls": "constants",
		"name": "楼层传送器",
		"text": "可以自由往来去过的楼层",
		"hideInReplay": true,
		"hideInToolbox": true,
		"useItemEffect": "core.ui.drawFly(core.floorIds.indexOf(core.status.floorId));",
		"canUseItemEffect": "(function () {\n\tif (core.flags.flyNearStair && !core.nearStair()) return false;\n\treturn core.status.maps[core.status.floorId].canFlyFrom && !core.hasEnemyLeft('E1583');\n})();"
	},
	"coin": {
		"cls": "constants",
		"name": "幸运金币",
		"text": "持有时打败怪物可得双倍金币"
	},
	"freezeBadge": {
		"cls": "constants",
		"name": "冰冻徽章",
		"text": "可以将面前的熔岩变成平地",
		"useItemEffect": "(function () {\n\tvar success = false;\n\n\tvar snowFourDirections = false; // 是否多方向雪花；如果是将其改成true\n\tif (snowFourDirections) {\n\t\t// 多方向雪花\n\t\tfor (var direction in core.utils.scan) { // 多方向雪花默认四方向，如需改为八方向请将这两个scan改为scan2\n\t\t\tvar delta = core.utils.scan[direction];\n\t\t\tvar nx = core.getHeroLoc('x') + delta.x,\n\t\t\t\tny = core.getHeroLoc('y') + delta.y;\n\t\t\tif (core.getBlockId(nx, ny) == 'lava') {\n\t\t\t\tcore.removeBlock(nx, ny);\n\t\t\t\tsuccess = true;\n\t\t\t}\n\t\t}\n\t} else {\n\t\tif (core.getBlockId(core.nextX(), core.nextY()) == 'lava') {\n\t\t\tcore.removeBlock(core.nextX(), core.nextY());\n\t\t\tsuccess = true;\n\t\t}\n\t}\n\n\tif (success) {\n\t\tcore.playSound('打开界面');\n\t\tcore.drawTip(core.material.items[itemId].name + '使用成功', itemId);\n\t} else {\n\t\tcore.playSound('操作失败');\n\t\tcore.drawTip(\"当前无法使用\" + core.material.items[itemId].name, itemId);\n\t\tcore.addItem(itemId, 1);\n\t\treturn;\n\t}\n})();",
		"canUseItemEffect": "true"
	},
	"cross": {
		"cls": "constants",
		"name": "十字架",
		"text": "持有后无视怪物的无敌属性"
	},
	"dagger": {
		"cls": "constants",
		"name": "屠龙匕首",
		"text": "该道具尚未被定义"
	},
	"amulet": {
		"cls": "constants",
		"name": "护符",
		"text": "持有时无视负面地形"
	},
	"bigKey": {
		"cls": "tools",
		"name": "大黄门钥匙",
		"text": "可以开启当前层所有黄门",
		"itemEffect": null,
		"itemEffectTip": null,
		"useItemEffect": "(function () {\n\tvar actions = core.searchBlock(\"A342\").map(function (block) {\n\t\treturn { \"type\": \"openDoor\", \"loc\": [block.x, block.y], \"async\": true };\n\t});\n\tactions.push({ \"type\": \"waitAsync\" });\n\tactions.push({ \"type\": \"tip\", \"text\": core.material.items[itemId].name + \"使用成功\" });\n\tcore.insertAction(actions);\n})();",
		"canUseItemEffect": "(function () {\n\treturn core.searchBlock('A342').length > 0;\n})();"
	},
	"greenKey": {
		"cls": "tools",
		"name": "绿钥匙",
		"text": "可以打开一扇绿门"
	},
	"steelKey": {
		"cls": "tools",
		"name": "铁门钥匙",
		"text": "可以打开一扇铁门"
	},
	"pickaxe": {
		"cls": "tools",
		"name": "破墙镐",
		"text": "可以破坏勇士面前的墙",
		"useItemEffect": "(function () {\n\tvar canBreak = function (x, y) {\n\t\tvar block = core.getBlock(x, y);\n\t\tif (block == null || block.disable) return false;\n\t\treturn block.event.canBreak;\n\t};\n\n\tvar success = false;\n\tvar pickaxeFourDirections = false; // 是否多方向破；如果是将其改成true\n\tif (pickaxeFourDirections) {\n\t\t// 多方向破\n\t\tfor (var direction in core.utils.scan) { // 多方向破默认四方向，如需改成八方向请将这两个scan改为scan2\n\t\t\tvar delta = core.utils.scan[direction];\n\t\t\tvar nx = core.getHeroLoc('x') + delta.x,\n\t\t\t\tny = core.getHeroLoc('y') + delta.y;\n\t\t\tif (canBreak(nx, ny)) {\n\t\t\t\tcore.removeBlock(nx, ny);\n\t\t\t\tsuccess = true;\n\t\t\t}\n\t\t}\n\t} else {\n\t\t// 仅破当前\n\t\tif (canBreak(core.nextX(), core.nextY())) {\n\t\t\tcore.removeBlock(core.nextX(), core.nextY());\n\t\t\tsuccess = true;\n\t\t}\n\t}\n\n\tif (success) {\n\t\tcore.playSound('破墙镐');\n\t\tcore.drawTip(core.material.items[itemId].name + '使用成功', itemId);\n\t} else {\n\t\t// 无法使用\n\t\tcore.playSound('操作失败');\n\t\tcore.drawTip(\"当前无法使用\" + core.material.items[itemId].name, itemId);\n\t\tcore.addItem(itemId, 1);\n\t\treturn;\n\t}\n})();",
		"canUseItemEffect": "true"
	},
	"icePickaxe": {
		"cls": "tools",
		"name": "破冰镐",
		"text": "可以破坏勇士面前的一堵冰墙",
		"useItemEffect": "(function () {\n\tcore.drawTip(core.material.items[itemId].name + '使用成功', itemId);\n\tcore.insertAction({ \"type\": \"openDoor\", \"loc\": [\"core.nextX()\", \"core.nextY()\"] });\n})();",
		"canUseItemEffect": "(function () {\n\treturn core.getBlockId(core.nextX(), core.nextY()) == 'ice';\n})();"
	},
	"bomb": {
		"cls": "tools",
		"name": "炸弹",
		"text": "可以炸掉勇士四周的怪物,可开启机关门",
		"useItemEffect": "(function () {\n\tvar bombList = []; // 炸掉的怪物坐标列表\n\tvar todo = []; // 炸弹后事件\n\tvar money = 0,\n\t\texp = 0; // 炸弹获得的金币和经验\n\n\tvar canBomb = function (x, y) {\n\t\tvar block = core.getBlock(x, y);\n\t\tif (block == null || block.disable || block.event.cls.indexOf('enemy') != 0) return false;\n\t\tvar enemy = core.material.enemys[block.event.id];\n\t\treturn enemy && !enemy.notBomb;\n\t};\n\n\tvar bomb = function (x, y) {\n\t\tif (!canBomb(x, y)) return;\n\t\tbombList.push([x, y]);\n\t\tvar id = core.getBlockId(x, y),\n\t\t\tenemy = core.material.enemys[id];\n\t\tmoney += core.getEnemyValue(enemy, 'money', x, y) || 0;\n\t\texp += core.getEnemyValue(enemy, 'exp', x, y) || 0;\n\t\tcore.push(todo, core.floors[core.status.floorId].afterBattle[x + \",\" + y]);\n\t\tcore.push(todo, enemy.afterBattle);\n\t\tcore.removeBlock(x, y);\n\t}\n\n\t// 如果要多方向可炸，把这里的false改成true\n\tif (true) {\n\t\tvar scan = core.utils.scan; // 多方向炸时默认四方向，如果要改成八方向炸可以改成 core.utils.scan2\n\t\tfor (var direction in scan) {\n\t\t\tvar delta = scan[direction];\n\t\t\tbomb(core.getHeroLoc('x') + delta.x, core.getHeroLoc('y') + delta.y);\n\t\t}\n\t} else {\n\t\t// 仅炸当前\n\t\tbomb(core.nextX(), core.nextY());\n\t}\n\n\tif (bombList.length == 0) {\n\t\tcore.playSound('操作失败');\n\t\tcore.drawTip('当前无法使用' + core.material.items[itemId].name, itemId);\n\t\tcore.addItem(itemId, 1);\n\t\treturn;\n\t}\n\n\tcore.playSound('炸弹');\n\tcore.drawTip(core.material.items[itemId].name + '使用成功', itemId);\n\n\t// 取消这里的注释可以炸弹后获得金币和经验\n\tcore.status.hero.money += money;\n\tcore.status.hero.exp += exp;\n\n\t// 取消这里的注释可以炸弹引发战后事件\n\tif (todo.length > 0) core.insertAction(todo);\n\n})();",
		"canUseItemEffect": "true"
	},
	"centerFly": {
		"cls": "tools",
		"name": "中心对称飞行器",
		"text": "可以飞向当前楼层中心对称的位置",
		"useItemEffect": "core.playSound('centerFly.mp3');\ncore.clearMap('hero');\ncore.setHeroLoc('x', core.bigmap.width - 1 - core.getHeroLoc('x'));\ncore.setHeroLoc('y', core.bigmap.height - 1 - core.getHeroLoc('y'));\ncore.drawHero();\ncore.drawTip(core.material.items[itemId].name + '使用成功');",
		"canUseItemEffect": "(function () {\n\tvar toX = core.bigmap.width - 1 - core.getHeroLoc('x'),\n\t\ttoY = core.bigmap.height - 1 - core.getHeroLoc('y');\n\tvar id = core.getBlockId(toX, toY);\n\treturn id == null;\n})();"
	},
	"upFly": {
		"cls": "tools",
		"name": "上楼器",
		"text": "可以飞往楼上的相同位置",
		"useItemEffect": "(function () {\n\tvar floorId = core.floorIds[core.floorIds.indexOf(core.status.floorId) + 1];\n\tif (core.status.event.id == 'action') {\n\t\tcore.insertAction([\n\t\t\t{ \"type\": \"changeFloor\", \"loc\": [core.getHeroLoc('x'), core.getHeroLoc('y')], \"floorId\": floorId },\n\t\t\t{ \"type\": \"tip\", \"text\": core.material.items[itemId].name + '使用成功' }\n\t\t]);\n\t} else {\n\t\tcore.changeFloor(floorId, null, core.status.hero.loc, null, function () {\n\t\t\tcore.drawTip(core.material.items[itemId].name + '使用成功');\n\t\t\tcore.replay();\n\t\t});\n\t}\n})();",
		"canUseItemEffect": "(function () {\n\tvar floorId = core.status.floorId,\n\t\tindex = core.floorIds.indexOf(floorId);\n\tif (index < core.floorIds.length - 1) {\n\t\tvar toId = core.floorIds[index + 1],\n\t\t\ttoX = core.getHeroLoc('x'),\n\t\t\ttoY = core.getHeroLoc('y');\n\t\tvar mw = core.floors[toId].width,\n\t\t\tmh = core.floors[toId].height;\n\t\tif (toX >= 0 && toX < mw && toY >= 0 && toY < mh && core.getBlock(toX, toY, toId) == null) {\n\t\t\treturn true;\n\t\t}\n\t}\n\treturn false;\n})();"
	},
	"downFly": {
		"cls": "tools",
		"name": "下楼器",
		"text": "可以飞往楼下的相同位置",
		"useItemEffect": "(function () {\n\tvar floorId = core.floorIds[core.floorIds.indexOf(core.status.floorId) - 1];\n\tif (core.status.event.id == 'action') {\n\t\tcore.insertAction([\n\t\t\t{ \"type\": \"changeFloor\", \"loc\": [core.getHeroLoc('x'), core.getHeroLoc('y')], \"floorId\": floorId },\n\t\t\t{ \"type\": \"tip\", \"text\": core.material.items[itemId].name + '使用成功' }\n\t\t]);\n\t} else {\n\t\tcore.changeFloor(floorId, null, core.status.hero.loc, null, function () {\n\t\t\tcore.drawTip(core.material.items[itemId].name + '使用成功');\n\t\t\tcore.replay();\n\t\t});\n\t}\n})();",
		"canUseItemEffect": "(function () {\n\tvar floorId = core.status.floorId,\n\t\tindex = core.floorIds.indexOf(floorId);\n\tif (index > 0) {\n\t\tvar toId = core.floorIds[index - 1],\n\t\t\ttoX = core.getHeroLoc('x'),\n\t\t\ttoY = core.getHeroLoc('y');\n\t\tvar mw = core.floors[toId].width,\n\t\t\tmh = core.floors[toId].height;\n\t\tif (toX >= 0 && toX < mw && toY >= 0 && toY < mh && core.getBlock(toX, toY, toId) == null) {\n\t\t\treturn true;\n\t\t}\n\t}\n\treturn false;\n})();"
	},
	"earthquake": {
		"cls": "tools",
		"name": "地震卷轴",
		"text": "可以破坏当前层的所有墙",
		"useItemEffect": "(function () {\n\tvar indexes = [];\n\tfor (var index in core.status.thisMap.blocks) {\n\t\tvar block = core.status.thisMap.blocks[index];\n\t\tif (!block.disable && block.event.canBreak) {\n\t\t\tindexes.push(index);\n\t\t}\n\t}\n\tcore.removeBlockByIndexes(indexes);\n\tcore.redrawMap();\n\tcore.playSound('炸弹');\n\tcore.drawTip(core.material.items[itemId].name + '使用成功');\n})();",
		"canUseItemEffect": "(function () {\n\treturn core.status.thisMap.blocks.filter(function (block) {\n\t\treturn !block.disable && block.event.canBreak;\n\t}).length > 0;\n})();"
	},
	"poisonWine": {
		"cls": "tools",
		"name": "解毒药水",
		"text": "可以解除中毒状态",
		"useItemEffect": "core.triggerDebuff('remove', 'poison');",
		"canUseItemEffect": "core.hasFlag('poison');"
	},
	"weakWine": {
		"cls": "tools",
		"name": "解衰药水",
		"text": "可以解除衰弱状态",
		"useItemEffect": "core.triggerDebuff('remove', 'weak');",
		"canUseItemEffect": "core.hasFlag('weak');"
	},
	"curseWine": {
		"cls": "tools",
		"name": "解咒药水",
		"text": "可以解除诅咒状态",
		"useItemEffect": "core.triggerDebuff('remove', 'curse');",
		"canUseItemEffect": "core.hasFlag('curse');"
	},
	"superWine": {
		"cls": "tools",
		"name": "万能药水",
		"text": "可以解除所有不良状态",
		"useItemEffect": "core.triggerDebuff('remove', ['poison', 'weak', 'curse']);",
		"canUseItemEffect": "(function() {\n\treturn core.hasFlag('poison') || core.hasFlag('weak') || core.hasFlag('curse');\n})();"
	},
	"hammer": {
		"cls": "items",
		"name": "升级丹",
		"text": null,
		"itemEffect": "core.status.hero.exp = core.calValue(core.firstData.levelUp[core.status.hero.lv].need);"
	},
	"lifeWand": {
		"cls": "tools",
		"name": "生命魔杖",
		"text": "可以恢复100点生命值",
		"useItemEvent": [
			{
				"type": "comment",
				"text": "先恢复一个魔杖（因为使用道具必须消耗一个）"
			},
			{
				"type": "function",
				"function": "function(){\ncore.addItem('lifeWand', 1);\n}"
			},
			{
				"type": "playSound",
				"name": "打开界面"
			},
			{
				"type": "input",
				"text": "请输入生命魔杖使用次数：(0-${item:lifeWand})"
			},
			{
				"type": "comment",
				"text": "【接受用户输入】弹窗输入的结果将会保存在“flag:input”中\n如果需要更多帮助，请查阅帮助文档"
			},
			{
				"type": "if",
				"condition": "flag:input<=item:lifeWand",
				"true": [
					{
						"type": "setValue",
						"name": "item:lifeWand",
						"operator": "-=",
						"value": "flag:input"
					},
					{
						"type": "setValue",
						"name": "status:hp",
						"operator": "+=",
						"value": "flag:input*100"
					},
					{
						"type": "playSound",
						"name": "回血"
					},
					"成功使用${flag:input}次生命魔杖，恢复${flag:input*100}点生命。"
				],
				"false": [
					{
						"type": "playSound",
						"name": "操作失败"
					},
					"输入不合法！"
				]
			}
		],
		"canUseItemEffect": "true"
	},
	"jumpShoes": {
		"cls": "tools",
		"name": "跳跃靴",
		"text": "能跳跃到前方两格处",
		"useItemEffect": "core.playSound(\"跳跃\");\ncore.insertAction({ \"type\": \"jumpHero\", \"loc\": [core.nextX(2), core.nextY(2)] });",
		"canUseItemEffect": "(function () {\n\tvar nx = core.nextX(2),\n\t\tny = core.nextY(2);\n\treturn nx >= 0 && nx < core.bigmap.width && ny >= 0 && ny < core.bigmap.height && core.getBlockId(nx, ny) == null;\n})();"
	},
	"skill1": {
		"cls": "constants",
		"name": "技能：二倍斩",
		"text": "可以打开或关闭主动技能二倍斩",
		"hideInReplay": true,
		"useItemEffect": "(function () {\n\tvar skillValue = 1; // 技能的flag:skill值，可用于当前开启技能的判定；对于新技能可以依次改成2，3等等\n\tvar skillNeed = 5; // 技能的需求\n\tvar skillName = '二倍斩'; // 技能的名称\n\n\tif (core.getFlag('skill', 0) != skillValue) { // 判断当前是否已经开了技能\n\t\tif (core.getStatus('mana') >= skillNeed) { // 这里要写当前能否开技能的条件判断，比如魔力值至少要多少\n\t\t\tcore.playSound('打开界面');\n\t\t\tcore.setFlag('skill', skillValue); // 开技能1\n\t\t\tcore.setFlag('skillName', skillName); // 设置技能名\n\t\t} else {\n\t\t\tcore.playSound('操作失败');\n\t\t\tcore.drawTip('魔力不足，无法开启技能');\n\t\t}\n\t} else { // 关闭技能\n\t\tcore.setFlag('skill', 0); // 关闭技能状态\n\t\tcore.setFlag('skillName', '无');\n\t}\n})();",
		"canUseItemEffect": "true"
	},
	"wand": {
		"cls": "items",
		"name": "新物品"
	},
	"pack": {
		"cls": "items",
		"name": "钱袋",
		"itemEffect": "core.status.hero.money += 500",
		"itemEffectTip": "，金币+500"
	},
	"I331": {
		"cls": "tools",
		"name": "大蓝门钥匙",
		"canUseItemEffect": "(function () {\n\treturn core.searchBlock('A343').length > 0;\n})();",
		"useItemEvent": null,
		"text": "可以开启当前层所有蓝门",
		"useItemEffect": "(function () {\n\tvar actions = core.searchBlock(\"A343\").map(function (block) {\n\t\treturn { \"type\": \"openDoor\", \"loc\": [block.x, block.y], \"async\": true };\n\t});\n\tactions.push({ \"type\": \"waitAsync\" });\n\tactions.push({ \"type\": \"tip\", \"text\": core.material.items[itemId].name + \"使用成功\" });\n\tcore.insertAction(actions);\n})();"
	},
	"I332": {
		"cls": "equips",
		"name": "超市梦云",
		"canUseItemEffect": "true",
		"useItemEvent": null,
		"text": "上古真神梦云遗留下来的功法,全属性增加10%,随主角实力等级而提升",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"atk": 10,
				"def": 10,
				"mdef": 10
			}
		}
	},
	"I333": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I334": {
		"cls": "equips",
		"name": "仙阶强者徽章",
		"canUseItemEffect": "true",
		"equip": {
			"type": "境界证明",
			"value": {},
			"percentage": {
				"mdef": 150,
				"def": 150,
				"atk": 150
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I335",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "仙阶至强者证明,全属性增加150%"
	},
	"I335": {
		"cls": "equips",
		"name": "天阶强者徽章",
		"canUseItemEffect": "true",
		"text": "天阶至强者证明,全属性增加90%",
		"equip": {
			"type": "境界证明",
			"value": {},
			"percentage": {
				"mdef": 90,
				"def": 90,
				"atk": 90
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I336",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I336": {
		"cls": "equips",
		"name": "地阶强者徽章",
		"canUseItemEffect": "true",
		"text": "地阶至强者证明,全属性增加55%",
		"equip": {
			"type": "境界证明",
			"value": {},
			"percentage": {
				"atk": 55,
				"def": 55,
				"mdef": 55
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I337",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"hideInToolbox": false
	},
	"I337": {
		"cls": "equips",
		"name": "凡阶强者徽章",
		"canUseItemEffect": "true",
		"text": "凡阶至强者证明,全属性增加25%",
		"equip": {
			"type": "境界证明",
			"value": {},
			"percentage": {
				"atk": 25,
				"def": 25,
				"mdef": 25
			}
		}
	},
	"I338": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I339": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I340": {
		"cls": "tools",
		"name": "隐身魔法棒",
		"canUseItemEffect": "true",
		"useItemEffect": "core.stealthOn()",
		"text": "使用后可隐身穿过本层所有怪物,上下楼或使用楼传后消失"
	},
	"I341": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I346": {
		"cls": "constants",
		"name": "血瓶数据显示开关",
		"canUseItemEffect": "true",
		"text": "开启或者关闭血瓶宝石数据显示",
		"useItemEvent": [
			{
				"type": "confirm",
				"text": "是否开启血瓶宝石显示数据(默认开启)",
				"yes": [
					{
						"type": "setValue",
						"name": "flag:itemDetail",
						"value": "true"
					}
				],
				"no": [
					{
						"type": "setValue",
						"name": "flag:itemDetail",
						"value": "false"
					}
				]
			}
		]
	},
	"I347": {
		"cls": "constants",
		"name": "魔法手套",
		"canUseItemEffect": "true",
		"useItemEvent": [
			{
				"type": "choices",
				"text": "这里是自动拾取开关！",
				"choices": [
					{
						"text": "开启自动拾取",
						"color": [
							105,
							231,
							153,
							1
						],
						"action": [
							"自动拾取已开启！",
							{
								"type": "setValue",
								"name": "flag:shiqu",
								"value": "true"
							}
						]
					},
					{
						"text": "关闭自动拾取",
						"color": [
							243,
							184,
							78,
							1
						],
						"action": [
							"自动拾取已关闭！",
							{
								"type": "setValue",
								"name": "flag:shiqu",
								"value": "false"
							}
						]
					}
				]
			}
		],
		"text": "开启或者关闭自动拾取周围物品"
	},
	"I348": {
		"cls": "items",
		"name": "红灵水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 2"
	},
	"I349": {
		"cls": "items",
		"name": "蓝灵水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 3"
	},
	"I350": {
		"cls": "items",
		"name": "黄灵水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 5"
	},
	"I351": {
		"cls": "items",
		"name": "绿灵水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 6"
	},
	"I352": {
		"cls": "items",
		"name": "蓝灵液",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 8"
	},
	"I353": {
		"cls": "items",
		"name": "紫灵液",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 9"
	},
	"I354": {
		"cls": "items",
		"name": "红灵液",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 11"
	},
	"I355": {
		"cls": "items",
		"name": "绿灵液",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 13"
	},
	"I356": {
		"cls": "items",
		"name": "二阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 2"
	},
	"I357": {
		"cls": "items",
		"name": "三阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 4"
	},
	"I358": {
		"cls": "items",
		"name": "四阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 6"
	},
	"I359": {
		"cls": "items",
		"name": "五阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 8"
	},
	"I360": {
		"cls": "items",
		"name": "六阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 10"
	},
	"I361": {
		"cls": "items",
		"name": "七阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 12"
	},
	"I362": {
		"cls": "items",
		"name": "八阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 14"
	},
	"I363": {
		"cls": "items",
		"name": "二阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 2"
	},
	"I364": {
		"cls": "items",
		"name": "三阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 4"
	},
	"I365": {
		"cls": "items",
		"name": "四阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 6"
	},
	"I366": {
		"cls": "items",
		"name": "五阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 8"
	},
	"I367": {
		"cls": "items",
		"name": "六阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 10"
	},
	"I368": {
		"cls": "items",
		"name": "七阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 12"
	},
	"I369": {
		"cls": "items",
		"name": "八阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 14"
	},
	"I370": {
		"cls": "items",
		"name": "二阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 2"
	},
	"I371": {
		"cls": "items",
		"name": "三阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 4"
	},
	"I372": {
		"cls": "items",
		"name": "四阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 6"
	},
	"I373": {
		"cls": "items",
		"name": "五阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 8"
	},
	"I374": {
		"cls": "items",
		"name": "六阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 10"
	},
	"I375": {
		"cls": "items",
		"name": "七阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 12"
	},
	"I376": {
		"cls": "items",
		"name": "八阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 14"
	},
	"I377": {
		"cls": "items",
		"name": "二阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 2\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 2\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 3"
	},
	"I378": {
		"cls": "items",
		"name": "三阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 4\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 4\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 6"
	},
	"I379": {
		"cls": "items",
		"name": "四阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 6\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 6\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 8"
	},
	"I380": {
		"cls": "items",
		"name": "五阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 8\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 8\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 10"
	},
	"I381": {
		"cls": "items",
		"name": "六阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 10\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 10\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 12"
	},
	"I382": {
		"cls": "items",
		"name": "七阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 12\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 12\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 14"
	},
	"I383": {
		"cls": "items",
		"name": "八阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 14\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 14\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 16"
	},
	"I384": {
		"cls": "items",
		"name": "九阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 16"
	},
	"I385": {
		"cls": "items",
		"name": "九阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 16"
	},
	"I386": {
		"cls": "items",
		"name": "九阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 16"
	},
	"I387": {
		"cls": "items",
		"name": "九阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 16\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 16\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 18"
	},
	"I388": {
		"cls": "items",
		"name": "十阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 18"
	},
	"I389": {
		"cls": "items",
		"name": "十阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 18"
	},
	"I390": {
		"cls": "items",
		"name": "十阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 18"
	},
	"I391": {
		"cls": "items",
		"name": "十阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 20\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 20\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 22"
	},
	"I396": {
		"cls": "tools",
		"name": "斩神剑碎Ⅰ",
		"canUseItemEffect": null,
		"text": "收集齐全后可以重铸斩神剑(器灵)"
	},
	"I397": {
		"cls": "tools",
		"name": "斩神剑碎片Ⅱ",
		"canUseItemEffect": null,
		"text": "收集齐全后可以重铸斩神剑(器灵)"
	},
	"I398": {
		"cls": "tools",
		"name": "斩神剑碎片Ⅲ",
		"canUseItemEffect": null,
		"text": "收集齐全后可以重铸斩神剑(器灵)"
	},
	"I399": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I400": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I401": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I402": {
		"cls": "equips",
		"name": "斩神剑",
		"canUseItemEffect": "true",
		"text": "圣器,具有毁天灭地之威，全属性增加1%,秒杀同阶及以下任何敌人",
		"equip": {
			"type": "神器",
			"value": {},
			"percentage": {
				"mdef": 1,
				"def": 1,
				"atk": 1
			}
		}
	},
	"I433": {
		"cls": "equips",
		"name": "初级刀意",
		"canUseItemEffect": "true",
		"text": "领悟初级刀意,全属性增加10%",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"atk": 10,
				"def": 10,
				"mdef": 10
			}
		}
	},
	"I434": {
		"cls": "equips",
		"name": "中级刀意",
		"canUseItemEffect": "true",
		"text": "中级刀意,全属性增加25%",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 25,
				"def": 25,
				"atk": 25
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I433",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I435": {
		"cls": "equips",
		"name": "高级刀意",
		"canUseItemEffect": "true",
		"text": "中级刀意,全属性增加40%",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 40,
				"def": 40,
				"atk": 40
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I434",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I436": {
		"cls": "equips",
		"name": "地阶剑意",
		"canUseItemEffect": "true",
		"text": "地阶顶级剑意,全属性增加65%",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 65,
				"def": 65,
				"atk": 65
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I435",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I437": {
		"cls": "equips",
		"name": "领域剑技",
		"canUseItemEffect": "true",
		"text": "天阶顶级剑技,全属性增加90%",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 90,
				"def": 90,
				"atk": 90
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I436",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I438": {
		"cls": "equips",
		"name": "超市梦云Ⅱ",
		"canUseItemEffect": "true",
		"text": "上古真神梦云遗留下来的功法,全属性增加20%,随主角实力等级而提升",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 20,
				"def": 20,
				"atk": 20
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I332",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I439": {
		"cls": "equips",
		"name": "超市梦云Ⅲ",
		"canUseItemEffect": "true",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 45,
				"def": 45,
				"atk": 45
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I438",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "上古真神梦云遗留下来的功法,全属性增加45%,随主角实力等级而提升"
	},
	"I440": {
		"cls": "equips",
		"name": "超市梦云Ⅳ",
		"canUseItemEffect": "true",
		"text": "上古真神梦云遗留下来的功法,全属性增加75%,随主角实力等级而提升",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 75,
				"def": 75,
				"atk": 75
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I439",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I441": {
		"cls": "equips",
		"name": "超市梦云Ⅴ",
		"canUseItemEffect": "true",
		"text": "上古真神梦云遗留下来的功法,全属性增加200%,随主角实力等级而提升，穿戴后,敌人攻击力降低20%",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 200,
				"def": 200,
				"atk": 200
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I440",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I442": {
		"cls": "equips",
		"name": "超市梦云Ⅵ",
		"canUseItemEffect": "true",
		"text": "上古真神梦云遗留下来的功法,全属性增加600%,随主角实力等级而提升，穿戴后,敌人攻防降低10%",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 600,
				"def": 600,
				"atk": 600
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I441",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I443": {
		"cls": "equips",
		"name": "青冈剑",
		"canUseItemEffect": "true",
		"text": "凡阶武器(五品),全属性增加10%",
		"equip": {
			"type": "神器",
			"value": {},
			"percentage": {
				"mdef": 10,
				"def": 10,
				"atk": 10
			}
		}
	},
	"I444": {
		"cls": "equips",
		"name": "清风剑",
		"canUseItemEffect": "true",
		"equip": {
			"type": "神器",
			"value": {},
			"percentage": {
				"mdef": 30,
				"def": 30,
				"atk": 30
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I443",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "凡阶武器(顶级),全属性增加30%"
	},
	"I445": {
		"cls": "equips",
		"name": "琉璃剑",
		"canUseItemEffect": "true",
		"equip": {
			"type": "神器",
			"value": {},
			"percentage": {
				"mdef": 50,
				"def": 50,
				"atk": 50
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I444",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "地阶武器(初级),全属性增加50%"
	},
	"I446": {
		"cls": "equips",
		"name": "火名剑",
		"canUseItemEffect": "true",
		"equip": {
			"type": "神器",
			"value": {},
			"percentage": {
				"mdef": 70,
				"def": 70,
				"atk": 70
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I445",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "地阶武器(高级),全属性增加70%"
	},
	"I447": {
		"cls": "equips",
		"name": "绝刀·红莲天舞",
		"canUseItemEffect": "true",
		"text": "仙阶级武器(初级),全属性增加95%,穿戴后敌人防御减少10%",
		"equip": {
			"type": "神器",
			"value": {},
			"percentage": {
				"mdef": 95,
				"def": 95,
				"atk": 95
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I446",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I448": {
		"cls": "equips",
		"name": "天选之剑-格朗",
		"canUseItemEffect": "true",
		"text": "仙阶级武器(初级),全属性增加150%,穿戴后敌人防御减少10%",
		"equip": {
			"type": "神器",
			"value": {},
			"percentage": {
				"mdef": 150,
				"def": 150,
				"atk": 150
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I447",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I449": {
		"cls": "equips",
		"name": "地灵绝魂剑",
		"canUseItemEffect": "true",
		"text": "仙阶级武器(高级),全属性增加300%,穿戴后敌人防御减少10%",
		"equip": {
			"type": "神器",
			"value": {},
			"percentage": {
				"mdef": 300,
				"def": 300,
				"atk": 300
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I448",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I450": {
		"cls": "equips",
		"name": "子午七星剑",
		"canUseItemEffect": "true",
		"text": "神阶级武器(初级),全属性增加600%,穿戴后敌人防御减少10%",
		"equip": {
			"type": "神器",
			"value": {},
			"percentage": {
				"mdef": 600,
				"def": 600,
				"atk": 600
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I449",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I451": {
		"cls": "equips",
		"name": "苍穹落日剑",
		"canUseItemEffect": "true",
		"text": "此装备以失效",
		"equip": null
	},
	"I452": {
		"cls": "equips",
		"name": "两仪剑阵",
		"canUseItemEffect": "true",
		"text": "凡阶阵法,全属性增加10%",
		"equip": {
			"type": "阵法",
			"value": {},
			"percentage": {
				"atk": 10,
				"def": 10,
				"mdef": 10
			}
		}
	},
	"I453": {
		"cls": "equips",
		"name": "四象剑阵",
		"canUseItemEffect": "true",
		"equip": {
			"type": "阵法",
			"value": {},
			"percentage": {
				"atk": 20,
				"def": 20,
				"mdef": 20
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I452",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "凡阶顶级阵法,全属性增加20%"
	},
	"I454": {
		"cls": "equips",
		"name": "九宫图",
		"canUseItemEffect": "true",
		"text": "地阶初级阵法,全属性增加40%",
		"equip": {
			"type": "阵法",
			"value": {},
			"percentage": {
				"mdef": 40,
				"def": 40,
				"atk": 40
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I453",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I455": {
		"cls": "equips",
		"name": "太阴奇门阵",
		"canUseItemEffect": "true",
		"equip": {
			"type": "阵法",
			"value": {},
			"percentage": {
				"mdef": 65,
				"def": 65,
				"atk": 65
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I454",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "地阶高级阵法,全属性增加65%"
	},
	"I456": {
		"cls": "equips",
		"name": "天魔玄阴阵",
		"canUseItemEffect": "true",
		"equip": {
			"type": "阵法",
			"value": {},
			"percentage": {
				"mdef": 90,
				"def": 90,
				"atk": 90
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I455",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "天阶初级阵法,全属性增加90%"
	},
	"I457": {
		"cls": "equips",
		"name": "都天烈火阵",
		"canUseItemEffect": "true",
		"text": "仙阶初级阵法,全属性增加150%",
		"equip": {
			"type": "阵法",
			"value": {},
			"percentage": {
				"mdef": 150,
				"def": 150,
				"atk": 150
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I456",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I458": {
		"cls": "equips",
		"name": "九真伏魔阵",
		"canUseItemEffect": "true",
		"equip": {
			"type": "阵法",
			"value": {},
			"percentage": {
				"mdef": 300,
				"def": 300,
				"atk": 300
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I457",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "仙阶高级阵法,全属性增加300%"
	},
	"I459": {
		"cls": "equips",
		"name": "十八天煞阵",
		"canUseItemEffect": "true",
		"text": "神阶初级阵法,全属性增加600%，额外增加5千点全属性",
		"equip": {
			"type": "阵法",
			"value": {
				"mdef": 5000,
				"def": 5000,
				"atk": 5000
			},
			"percentage": {
				"mdef": 600,
				"def": 600,
				"atk": 600
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I458",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I474": {
		"cls": "equips",
		"name": "凡阶铁甲",
		"canUseItemEffect": "true",
		"text": "特殊手法打造的铠甲，抵御大量的攻击,全属性增加10%",
		"equip": {
			"type": "护甲",
			"value": {},
			"percentage": {
				"mdef": 10,
				"def": 10,
				"atk": 10
			}
		}
	},
	"I476": {
		"cls": "equips",
		"name": "凡阶铠甲",
		"canUseItemEffect": "true",
		"equip": {
			"type": "护甲",
			"value": {},
			"percentage": {
				"atk": 20,
				"def": 20,
				"mdef": 20
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I474",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "特殊手法打造的凡阶顶级防具,全属性增加20%"
	},
	"I477": {
		"cls": "equips",
		"name": "初级地阶铠甲",
		"canUseItemEffect": "true",
		"equip": {
			"type": "护甲",
			"value": {},
			"percentage": {
				"mdef": 40,
				"def": 40,
				"atk": 40
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I476",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "特殊手法打造的地阶初级防具,全属性增加40%"
	},
	"I478": {
		"cls": "equips",
		"name": "顶级地阶铠甲",
		"canUseItemEffect": "true",
		"text": "特殊手法打造的地阶高级防具,全属性增加65%",
		"equip": {
			"type": "护甲",
			"value": {},
			"percentage": {
				"mdef": 65,
				"def": 65,
				"atk": 65
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I477",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I479": {
		"cls": "equips",
		"name": "白银铠",
		"canUseItemEffect": "true",
		"text": "特殊手法打造的天阶初级防具,全属性增加90%",
		"equip": {
			"type": "护甲",
			"value": {},
			"percentage": {
				"mdef": 90,
				"def": 90,
				"atk": 90
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I478",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I480": {
		"cls": "equips",
		"name": "烈龙甲",
		"canUseItemEffect": "true",
		"text": "特殊手法打造的仙阶初级防具,全属性增加150%",
		"equip": {
			"type": "护甲",
			"value": {},
			"percentage": {
				"mdef": 150,
				"def": 150,
				"atk": 150
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I479",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"hideInToolbox": false
	},
	"I481": {
		"cls": "equips",
		"name": "天魔圣甲",
		"canUseItemEffect": "true",
		"text": "特殊手法打造的仙阶高级防具,全属性增加300%",
		"equip": {
			"type": "护甲",
			"value": {},
			"percentage": {
				"mdef": 300,
				"def": 300,
				"atk": 300
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I480",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I482": {
		"cls": "equips",
		"name": "白龙铠",
		"canUseItemEffect": "true",
		"text": "特殊手法打造的神阶初级防具,全属性增加600%",
		"equip": {
			"type": "护甲",
			"value": {},
			"percentage": {
				"mdef": 600,
				"def": 600,
				"atk": 600
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I481",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I483": {
		"cls": "equips",
		"name": "幻泉",
		"canUseItemEffect": "true",
		"text": "特殊手法打造的神阶中级防具,全属性增加1000%,额外增加全属性5000万",
		"equip": {
			"type": "护甲",
			"value": {
				"mdef": 5000000,
				"def": 5000000,
				"atk": 5000000
			},
			"percentage": {
				"mdef": 1000,
				"def": 1000,
				"atk": 1000
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I482",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I484": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I485": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I328": {
		"cls": "items",
		"name": "进阶铁剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 5000"
	},
	"I329": {
		"cls": "items",
		"name": "进阶铁盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 5000;\ncore.status.hero.mdef += 8000"
	},
	"I330": {
		"cls": "items",
		"name": "断钢",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 30000"
	},
	"I502": {
		"cls": "items",
		"name": "钢盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 30000;\ncore.status.hero.mdef += 60000",
		"itemEffectTip": null
	},
	"I503": {
		"cls": "items",
		"name": "火焰剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 60000"
	},
	"I504": {
		"cls": "items",
		"name": "火焰盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 60000;\ncore.status.hero.mdef += 200000"
	},
	"I505": {
		"cls": "items",
		"name": "龙牙",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 500000"
	},
	"I506": {
		"cls": "items",
		"name": "龙鳞",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 500000;\ncore.status.hero.mdef += 1500000"
	},
	"I533": {
		"cls": "items",
		"name": "十一阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 24\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 24\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 30"
	},
	"I534": {
		"cls": "items",
		"name": "十二阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 28\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 28\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 35"
	},
	"I535": {
		"cls": "items",
		"name": "十三阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 32\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 32\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 40"
	},
	"I536": {
		"cls": "items",
		"name": "十四阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 36\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 36\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 52"
	},
	"I537": {
		"cls": "items",
		"name": "十五阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 42\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 42\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 65"
	},
	"I538": {
		"cls": "items",
		"name": "紫神水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 15"
	},
	"I539": {
		"cls": "items",
		"name": "红神水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 17"
	},
	"I540": {
		"cls": "items",
		"name": "金神水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 20"
	},
	"I564": {
		"cls": "items",
		"name": "红桦水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 23"
	},
	"I565": {
		"cls": "items",
		"name": "蓝桦水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 26"
	},
	"I566": {
		"cls": "items",
		"name": "绿桦水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 29"
	},
	"I567": {
		"cls": "items",
		"name": "金桦水",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 32"
	},
	"I568": {
		"cls": "items",
		"name": "神圣·红灵液",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 35"
	},
	"I569": {
		"cls": "items",
		"name": "神圣·蓝灵液",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 38"
	},
	"I570": {
		"cls": "items",
		"name": "神圣·绿灵液",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 41"
	},
	"I571": {
		"cls": "items",
		"name": "神圣·金灵液",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 44"
	},
	"I572": {
		"cls": "constants",
		"name": "穿透之石",
		"canUseItemEffect": null,
		"text": "持有后，所有敌人防御降低20%"
	},
	"I573": {
		"cls": "constants",
		"name": "力量之石",
		"canUseItemEffect": null,
		"text": "持有后,减少敌人10%的攻击力"
	},
	"I574": {
		"cls": "constants",
		"name": "防御宝石",
		"canUseItemEffect": null,
		"text": "战斗结束后,增加2%的防御力"
	},
	"I575": {
		"cls": "constants",
		"name": "护盾之石",
		"canUseItemEffect": null,
		"text": "战斗结束后，增加2%的护盾值"
	},
	"I602": {
		"cls": "items",
		"name": "大串黄钥匙",
		"canUseItemEffect": "true",
		"useItemEvent": [
			{
				"type": "setValue",
				"name": "item:yellowKey",
				"operator": "+=",
				"value": "5"
			}
		]
	},
	"I603": {
		"cls": "items",
		"name": "大串蓝钥匙",
		"canUseItemEffect": "true",
		"useItemEvent": [
			{
				"type": "setValue",
				"name": "item:blueKey",
				"operator": "+=",
				"value": "3"
			}
		]
	},
	"I618": {
		"cls": "tools",
		"name": "强力炸弹",
		"canUseItemEffect": "true",
		"text": "消灭本层所有怪物,无法开启机关门",
		"useItemEffect": "(function () {\n\tvar bombList = []; // 炸掉的怪物坐标列表\n\tvar bombXYList = []; // 炸掉的怪物xy坐标列表\n\tvar expSum = 0;\n\tvar coinSum = 0;\n\tfor (var index in core.status.thisMap.blocks) {\n\t\tvar block = core.status.thisMap.blocks[index];\n\t\t// \t\tvar nx = block.x;\n\t\t// \t\tvar ny = block.y;\n\t\tvar enemyCanBomb = false;\n\t\tif (block == null || block.disable || block.event.cls.indexOf('enemy') != 0) {} else {\n\t\t\tvar enemy = core.material.enemys[block.event.id];\n\t\t\tvar enemyCanBomb = enemy && !enemy.notBomb;\n\t\t\tif (enemyCanBomb) {\n\t\t\t\tbombList.push(index);\n\t\t\t\texpSum += enemy.exp;\n\t\t\t\tcoinSum += enemy.money;\n\t\t\t\tbombXYList.push(block)\n\t\t\t}\n\t\t}\n\t}\n\tcore.removeBlockByIndexes(bombList);\n\tcore.status.hero.exp += expSum;\n\tcore.status.hero.money += coinSum;\n\tcore.playSound('bomb.mp3');\n\tcore.drawTip(core.material.items[itemId].name + '使用成功');\n\tcore.drawMap();\n\tfor (var index in bombXYList) {\n\t\tcore.drawAnimate(\"zone\", bombXYList[index].x, bombXYList[index].y, false)\n\t}\n})();"
	},
	"I619": {
		"cls": "items",
		"name": "断魂",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 1000000"
	},
	"I620": {
		"cls": "items",
		"name": "断魂",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 1000000;\ncore.status.hero.mdef += 3000000"
	},
	"I621": {
		"cls": "items",
		"name": "琉炎剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 6000000"
	},
	"I622": {
		"cls": "items",
		"name": "犀银盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 6000000;\ncore.status.hero.mdef += 12000000"
	},
	"I623": {
		"cls": "items",
		"name": "蓝鳞",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 20000000"
	},
	"I624": {
		"cls": "items",
		"name": "星云",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 20000000;\ncore.status.hero.mdef += 80000000"
	},
	"I625": {
		"cls": "items",
		"name": "极光",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 100000000"
	},
	"I626": {
		"cls": "items",
		"name": "紫云盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 100000000;\ncore.status.hero.mdef += 250000000"
	},
	"I627": {
		"cls": "items",
		"name": "紫云剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 200000000"
	},
	"I628": {
		"cls": "items",
		"name": "青铜盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 200000000;\ncore.status.hero.mdef += 250000000"
	},
	"I629": {
		"cls": "items",
		"name": "火焰长剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 500000000"
	},
	"I630": {
		"cls": "items",
		"name": "蛛丝盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 500000000;\ncore.status.hero.mdef += 1000000000"
	},
	"I631": {
		"cls": "items",
		"name": "金絮剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 10000000000"
	},
	"I632": {
		"cls": "items",
		"name": "金絮盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 10000000000;\ncore.status.hero.mdef += 30000000000"
	},
	"I637": {
		"cls": "items",
		"name": "十六阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 50\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 50\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 80"
	},
	"I638": {
		"cls": "items",
		"name": "十七阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 60\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 60\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 100"
	},
	"I639": {
		"cls": "items",
		"name": "十八阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 75\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 75\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 150"
	},
	"I896": {
		"cls": "items",
		"name": "雨花剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 20000000000"
	},
	"I897": {
		"cls": "items",
		"name": "寒霜剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 150000000000",
		"itemEffectTip": null
	},
	"I898": {
		"cls": "items",
		"name": "紫云剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 700000000000"
	},
	"I899": {
		"cls": "items",
		"name": "天破剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 2500000000000"
	},
	"I900": {
		"cls": "items",
		"name": "残影剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 5500000000000"
	},
	"I901": {
		"cls": "items",
		"name": "黑龙骨剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 100000000000000"
	},
	"I902": {
		"cls": "items",
		"name": "乾坤剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 500000000000000"
	},
	"I903": {
		"cls": "items",
		"name": "玄机剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 1500000000000000"
	},
	"I904": {
		"cls": "items",
		"name": "炎黄剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 4000000000000000"
	},
	"I905": {
		"cls": "items",
		"name": "雨花盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 20000000000;\ncore.status.hero.mdef += 50000000000"
	},
	"I906": {
		"cls": "items",
		"name": "寒霜盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 150000000000;\ncore.status.hero.mdef += 250000000000"
	},
	"I907": {
		"cls": "items",
		"name": "紫云盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 700000000000;\ncore.status.hero.mdef += 1500000000000"
	},
	"I908": {
		"cls": "items",
		"name": "天破盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 2500000000000;\ncore.status.hero.mdef += 5000000000000"
	},
	"I909": {
		"cls": "items",
		"name": "猎魔盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 5500000000000;\ncore.status.hero.mdef += 9000000000000"
	},
	"I910": {
		"cls": "items",
		"name": "黑龙骨盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 100000000000000;\ncore.status.hero.mdef += 200000000000000"
	},
	"I911": {
		"cls": "items",
		"name": "乾坤盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 500000000000000;\ncore.status.hero.mdef += 2000000000000000"
	},
	"I912": {
		"cls": "items",
		"name": "玄机盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 1500000000000000;\ncore.status.hero.mdef += 5000000000000000"
	},
	"I913": {
		"cls": "items",
		"name": "炎黄盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 4000000000000000;\ncore.status.hero.mdef += 10000000000000000"
	},
	"I1151": {
		"cls": "constants",
		"name": "诛仙剑",
		"canUseItemEffect": null,
		"text": "诛仙四剑之一,获得后降低敌人10%的全属性,无视敌人魔攻"
	},
	"I1152": {
		"cls": "constants",
		"name": "绝仙剑",
		"canUseItemEffect": null,
		"text": "诛仙四剑之一,获得后敌人攻击降低10%"
	},
	"I1153": {
		"cls": "constants",
		"name": "戮仙剑",
		"canUseItemEffect": null,
		"text": "诛仙四剑之一,获得后降低敌人10%防御"
	},
	"I1154": {
		"cls": "constants",
		"name": "陷仙剑",
		"canUseItemEffect": null,
		"text": "诛仙四剑之一,获得后敌人生命值降低10%"
	},
	"I1207": {
		"cls": "items",
		"name": "十一阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 30"
	},
	"I1208": {
		"cls": "items",
		"name": "十二阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 40"
	},
	"I1209": {
		"cls": "items",
		"name": "十三阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 50"
	},
	"I1210": {
		"cls": "items",
		"name": "十一阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 30"
	},
	"I1211": {
		"cls": "items",
		"name": "十二阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 40"
	},
	"I1212": {
		"cls": "items",
		"name": "十三阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 50"
	},
	"I1213": {
		"cls": "items",
		"name": "十一阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 30"
	},
	"I1214": {
		"cls": "items",
		"name": "十二阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 40"
	},
	"I1215": {
		"cls": "items",
		"name": "十三阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 50"
	},
	"I1216": {
		"cls": "items",
		"name": "十一阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 30\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 30\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 60"
	},
	"I1217": {
		"cls": "items",
		"name": "十二阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 40\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 40\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 80"
	},
	"I1218": {
		"cls": "items",
		"name": "十三阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 55\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 55\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 110"
	},
	"I1219": {
		"cls": "items",
		"name": "十四阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 60"
	},
	"I1220": {
		"cls": "items",
		"name": "十四阶蓝灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 60"
	},
	"I1221": {
		"cls": "items",
		"name": "十四阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 60"
	},
	"I1222": {
		"cls": "items",
		"name": "十四阶黄灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 65\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 65\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 150"
	},
	"I1223": {
		"cls": "items",
		"name": "十九阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 85\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 85\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 200"
	},
	"I1224": {
		"cls": "items",
		"name": "二十阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 100\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 100\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 250"
	},
	"I1225": {
		"cls": "items",
		"name": "二十一阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 150\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 150\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 300"
	},
	"I1226": {
		"cls": "items",
		"name": "二十二阶灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 200\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 200\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 400"
	},
	"I1227": {
		"cls": "equips",
		"name": "不死不灭经",
		"canUseItemEffect": "true",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 150,
				"def": 150,
				"atk": 150
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I437",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "仙阶初级武技,全属性增加150%"
	},
	"I1228": {
		"cls": "equips",
		"name": "九转玄功",
		"canUseItemEffect": "true",
		"text": "仙阶高级武技,全属性增加300%",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 300,
				"def": 300,
				"atk": 300
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I1227",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1229": {
		"cls": "equips",
		"name": "混元玄功",
		"canUseItemEffect": "true",
		"equip": {
			"type": "功法",
			"value": {},
			"percentage": {
				"mdef": 600,
				"def": 600,
				"atk": 600
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I1228",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "神阶初级武技,全属性增加600%"
	},
	"I1230": {
		"cls": "equips",
		"name": "上清仙经",
		"canUseItemEffect": "true",
		"text": "神阶中级武技,全属性增加1000%，额外增加2万点全属性",
		"equip": {
			"type": "功法",
			"value": {
				"mdef": 20000,
				"def": 20000,
				"atk": 20000
			},
			"percentage": {
				"mdef": 1000,
				"def": 1000,
				"atk": 1000
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I1229",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1231": {
		"cls": "equips",
		"name": "度厄仙经",
		"canUseItemEffect": "true",
		"text": "神阶高级武技,全属性增加2000%，额外增加500万点全属性",
		"equip": {
			"type": "功法",
			"value": {
				"mdef": 5000000,
				"def": 5000000,
				"atk": 5000000
			},
			"percentage": {
				"mdef": 2000,
				"def": 2000,
				"atk": 2000
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I1230",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1232": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1233": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1234": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1245": {
		"cls": "constants",
		"name": "秘境图纸",
		"canUseItemEffect": null,
		"text": "王座级高手坐落之地的图纸"
	},
	"I1283": {
		"cls": "items",
		"name": "天虚剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 8000000000000000"
	},
	"I1284": {
		"cls": "items",
		"name": "天魔剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 15000000000000000"
	},
	"I1285": {
		"cls": "items",
		"name": "黑光",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 100"
	},
	"I1286": {
		"cls": "items",
		"name": "烈日裁决",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 500"
	},
	"I1287": {
		"cls": "items",
		"name": "青冈",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 5000"
	},
	"I1288": {
		"cls": "items",
		"name": "天虚盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 8000000000000000;\ncore.status.hero.mdef += 16000000000000000"
	},
	"I1289": {
		"cls": "items",
		"name": "天魔盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 15000000000000000;\ncore.status.hero.mdef += 30000000000000000"
	},
	"I1290": {
		"cls": "items",
		"name": "黑之光",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 100;\ncore.status.hero.mdef += 200"
	},
	"I1291": {
		"cls": "items",
		"name": "沁之盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 500;\ncore.status.hero.mdef += 1000"
	},
	"I1292": {
		"cls": "items",
		"name": "血鸿",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 5000;\ncore.status.hero.mdef += 10000"
	},
	"I1315": {
		"cls": "tools",
		"name": "钥匙礼袋",
		"canUseItemEffect": "true",
		"useItemEvent": [
			{
				"type": "setValue",
				"name": "item:blueKey",
				"operator": "+=",
				"value": "1"
			},
			{
				"type": "setValue",
				"name": "item:yellowKey",
				"operator": "+=",
				"value": "1"
			}
		],
		"text": "使用后,各增加一把黄钥匙和蓝钥匙"
	},
	"I1355": {
		"cls": "items",
		"name": "混沌液·残次品",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 47"
	},
	"I1356": {
		"cls": "items",
		"name": "混沌液·半成品",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 50"
	},
	"I1357": {
		"cls": "items",
		"name": "混沌液·初级成品",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 53"
	},
	"I1358": {
		"cls": "items",
		"name": "混沌液·高级成品",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 56"
	},
	"I1359": {
		"cls": "items",
		"name": "混沌液·下品",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 59"
	},
	"I1360": {
		"cls": "items",
		"name": "混沌液·中品",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 62"
	},
	"I1361": {
		"cls": "items",
		"name": "混沌液·上品",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 65"
	},
	"I1362": {
		"cls": "items",
		"name": "混沌液·极品",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 68"
	},
	"I1363": {
		"cls": "items",
		"name": "混沌液·仙品下",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 71"
	},
	"I1364": {
		"cls": "items",
		"name": "混沌液·仙品上",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 74"
	},
	"I1365": {
		"cls": "items",
		"name": "混沌液·神品下",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 77"
	},
	"I1366": {
		"cls": "items",
		"name": "混沌液·神品上",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 80"
	},
	"I1367": {
		"cls": "items",
		"name": "混沌液·圣品下",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 83"
	},
	"I1368": {
		"cls": "items",
		"name": "混沌液·圣品中",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 86"
	},
	"I1369": {
		"cls": "items",
		"name": "混沌液·圣品上",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 89"
	},
	"I1370": {
		"cls": "items",
		"name": "混沌液·混沌品",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.hp += core.values.greenPotion * core.status.thisMap.ratio * 92"
	},
	"I1397": {
		"cls": "tools",
		"name": "大红门钥匙",
		"canUseItemEffect": "(function () {\n\treturn core.searchBlock('A344').length > 0;\n})();",
		"useItemEffect": "(function () {\n\tvar actions = core.searchBlock(\"A344\").map(function (block) {\n\t\treturn { \"type\": \"openDoor\", \"loc\": [block.x, block.y], \"async\": true };\n\t});\n\tactions.push({ \"type\": \"waitAsync\" });\n\tactions.push({ \"type\": \"tip\", \"text\": core.material.items[itemId].name + \"使用成功\" });\n\tcore.insertAction(actions);\n})();",
		"text": "可以开启当前层所有红门"
	},
	"I1398": {
		"cls": "tools",
		"name": "万能钥匙",
		"canUseItemEffect": "(function () {\n\treturn core.searchBlockWithFilter(block => block.event.id === 'A342' || block.event.id === 'A343' || block.event.id === 'A344').length > 0;\n})();",
		"useItemEffect": "(function () {\n\tvar actions = core.searchBlockWithFilter(block => block.event.id === 'A342' || block.event.id === 'A343' || block.event.id === 'A344').map(function (block) {\n\t\treturn { \"type\": \"openDoor\", \"loc\": [block.x, block.y], \"async\": true };\n\t});\n\tactions.push({ \"type\": \"waitAsync\" });\n\tactions.push({ \"type\": \"tip\", \"text\": core.material.items[itemId].name + \"使用成功\" });\n\tcore.insertAction(actions);\n})();",
		"text": "可以开启当前层所有黄门蓝门红门"
	},
	"I1399": {
		"cls": "tools",
		"name": "大绿门钥匙",
		"canUseItemEffect": "(function () {\n\treturn core.searchBlock('A345').length > 0;\n})();",
		"useItemEffect": "(function () {\n\tvar actions = core.searchBlock(\"A345\").map(function (block) {\n\t\treturn { \"type\": \"openDoor\", \"loc\": [block.x, block.y], \"async\": true };\n\t});\n\tactions.push({ \"type\": \"waitAsync\" });\n\tactions.push({ \"type\": \"tip\", \"text\": core.material.items[itemId].name + \"使用成功\" });\n\tcore.insertAction(actions);\n})();",
		"text": "可以开启当前层所有绿门"
	},
	"I1439": {
		"cls": "equips",
		"name": "仙阶强者徽章-锻造Ⅰ",
		"canUseItemEffect": "true",
		"text": "仙阶至强者证明,经过特殊锻造，全属性增加300%",
		"equip": {
			"type": "境界证明",
			"value": {},
			"percentage": {
				"mdef": 300,
				"def": 300,
				"atk": 300
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I334",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1440": {
		"cls": "equips",
		"name": "仙阶强者徽章-锻造Ⅱ",
		"canUseItemEffect": "true",
		"equip": {
			"type": "境界证明",
			"value": {},
			"percentage": {
				"mdef": 600,
				"def": 600,
				"atk": 600
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I1439",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "仙阶至强者证明,经过特殊锻造，全属性增加600%"
	},
	"I1441": {
		"cls": "equips",
		"name": "神阶强者徽章-锻造Ⅰ",
		"canUseItemEffect": "true",
		"text": "神阶至强者证明,经过特殊锻造，全属性增加1000%,额外增加全属性5000万",
		"equip": {
			"type": "境界证明",
			"value": {
				"mdef": 50000000,
				"def": 50000000,
				"atk": 50000000
			},
			"percentage": {
				"mdef": 1000,
				"def": 1000,
				"atk": 1000
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I1440",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1442": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1443": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1452": {
		"cls": "items",
		"name": "变异铁剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 40000"
	},
	"I1453": {
		"cls": "items",
		"name": "变异银剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 1000000"
	},
	"I1454": {
		"cls": "items",
		"name": "紫光圣剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 30000000"
	},
	"I1455": {
		"cls": "items",
		"name": "白影剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 10"
	},
	"I1456": {
		"cls": "items",
		"name": "紫虹长剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 200"
	},
	"I1457": {
		"cls": "items",
		"name": "毒龙剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 3000"
	},
	"I1458": {
		"cls": "items",
		"name": "变异铁盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 40000\ncore.status.hero.mdef += 80000"
	},
	"I1459": {
		"cls": "items",
		"name": "变异银盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 1000000\ncore.status.hero.mdef += 2000000"
	},
	"I1460": {
		"cls": "items",
		"name": "紫光圣盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 30000000\ncore.status.hero.mdef += 60000000"
	},
	"I1461": {
		"cls": "items",
		"name": "沁心盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 10\ncore.status.hero.mdef += 30"
	},
	"I1462": {
		"cls": "items",
		"name": "青光天盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 200\ncore.status.hero.mdef += 400"
	},
	"I1463": {
		"cls": "items",
		"name": "毒龙盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 3000\ncore.status.hero.mdef += 6000"
	},
	"I1473": {
		"cls": "items",
		"name": "二十三阶变异灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 500\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 500\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 500"
	},
	"I1474": {
		"cls": "items",
		"name": "二十四阶变异灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 1000\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 1000\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 1000"
	},
	"I1475": {
		"cls": "items",
		"name": "二十五阶变异灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 1500\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 1500\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 1500"
	},
	"I1476": {
		"cls": "items",
		"name": "二十六阶变异灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 2000\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 2000\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 2000"
	},
	"I1477": {
		"cls": "items",
		"name": "二十七阶变异灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 3500\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 3500\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 3500"
	},
	"I1478": {
		"cls": "items",
		"name": "二十八阶变异灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 5000\ncore.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 5000\ncore.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 5000"
	},
	"I1486": {
		"cls": "items",
		"name": "十五阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 120"
	},
	"I1487": {
		"cls": "items",
		"name": "十五阶蓝晶石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 120"
	},
	"I1488": {
		"cls": "items",
		"name": "十五阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 120"
	},
	"I1489": {
		"cls": "items",
		"name": "十六阶红灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += core.values.redGem * core.status.thisMap.ratio * 240"
	},
	"I1490": {
		"cls": "items",
		"name": "十六阶蓝晶石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += core.values.blueGem * core.status.thisMap.ratio * 240"
	},
	"I1491": {
		"cls": "items",
		"name": "十六阶绿灵石",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.mdef += core.values.greenGem * core.status.thisMap.ratio * 240"
	},
	"I1557": {
		"cls": "tools",
		"name": "强化破墙镐",
		"canUseItemEffect": "true",
		"useItemEffect": "(function () {\n\tvar canBreak = function (x, y) {\n\t\tvar block = core.getBlock(x, y);\n\t\tif (block == null || block.disable) return true;\n\t\treturn block.event.canBreak;\n\t};\n\n\tvar success = true;\n\tvar pickaxeFourDirections = true; // 是否多方向破；如果是将其改成true\n\tif (pickaxeFourDirections) {\n\t\t// 多方向破\n\t\tfor (var direction in core.utils.scan2) { // 多方向破默认四方向，如需改成八方向请将这两个scan改为scan2\n\t\t\tvar delta = core.utils.scan2[direction];\n\t\t\tvar nx = core.getHeroLoc('x') + delta.x,\n\t\t\t\tny = core.getHeroLoc('y') + delta.y;\n\t\t\tif (canBreak(nx, ny)) {\n\t\t\t\tcore.removeBlock(nx, ny);\n\t\t\t\tsuccess = true;\n\t\t\t}\n\t\t}\n\t} else {\n\t\t// 仅破当前\n\t\tif (canBreak(core.nextX(), core.nextY())) {\n\t\t\tcore.removeBlock(core.nextX(), core.nextY());\n\t\t\tsuccess = true;\n\t\t}\n\t}\n\n\tif (success) {\n\t\tcore.playSound('破墙镐');\n\t\tcore.drawTip(core.material.items[itemId].name + '使用成功', itemId);\n\t} else {\n\t\t// 无法使用\n\t\tcore.playSound('操作失败');\n\t\tcore.drawTip(\"当前无法使用\" + core.material.items[itemId].name, itemId);\n\t\tcore.addItem(itemId, 1);\n\t\treturn;\n\t}\n})();",
		"text": "可以破坏勇士周围八个方向的墙壁"
	},
	"I1601": {
		"cls": "tools",
		"name": "普通香蕉",
		"canUseItemEffect": "true",
		"itemEffect": null,
		"text": "使用后,生命增加5千万",
		"useItemEffect": "core.status.hero.hp += 50000000;core.playSound('回血');"
	},
	"I1602": {
		"cls": "tools",
		"name": "变异香蕉",
		"canUseItemEffect": "true",
		"text": "吸收鲜血而变异的香蕉,使用后生命增加1亿",
		"itemEffect": null,
		"useItemEffect": "core.status.hero.hp += 100000000;\ncore.playSound('回血');"
	},
	"I1651": {
		"cls": "items",
		"name": "追星",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 200000"
	},
	"I1652": {
		"cls": "items",
		"name": "冷月",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 800000"
	},
	"I1653": {
		"cls": "items",
		"name": "揽月",
		"canUseItemEffect": "true",
		"itemEffectTip": null,
		"itemEffect": "core.status.hero.def += 200000\ncore.status.hero.mdef += 500000"
	},
	"I1654": {
		"cls": "items",
		"name": "天逐",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 800000\ncore.status.hero.mdef += 1600000"
	},
	"I1655": {
		"cls": "equips",
		"name": "超市梦云Ⅶ",
		"canUseItemEffect": "true",
		"text": "上古真神梦云遗留下来的功法,全属性增加1500%,随主角实力等级而提升，穿戴后,敌人攻防降低10%,且额外增加5万全属性",
		"equip": {
			"type": "功法",
			"value": {
				"mdef": 50000,
				"def": 50000,
				"atk": 50000
			},
			"percentage": {
				"mdef": 1500,
				"def": 1500,
				"atk": 1500
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I442",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1656": {
		"cls": "equips",
		"name": "超市梦云Ⅷ",
		"canUseItemEffect": "true",
		"text": "上古真神梦云遗留下来的功法,全属性增加3000%,随主角实力等级而提升，穿戴后,敌人攻防降低10%,且额外增加1亿全属性",
		"equip": {
			"type": "功法",
			"value": {
				"mdef": 100000000,
				"def": 100000000,
				"atk": 100000000
			},
			"percentage": {
				"mdef": 3000,
				"def": 3000,
				"atk": 3000
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I1655",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1657": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1658": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1659": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1660": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1698": {
		"cls": "equips",
		"name": "破碎之命运",
		"canUseItemEffect": "true",
		"text": "神阶级武器(中级),全属性增加1000%,额外增加全属性5000万,穿戴后敌人防御减少10%",
		"equip": {
			"type": "神器",
			"value": {
				"mdef": 50000000,
				"def": 50000000,
				"atk": 50000000
			},
			"percentage": {
				"mdef": 1000,
				"def": 1000,
				"atk": 1000
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I450",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1699": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1700": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1701": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1702": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1703": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1704": {
		"cls": "equips",
		"name": "清真琉光阵",
		"canUseItemEffect": "true",
		"text": "神阶初级阵法,全属性增加1000%，额外增加全属性1亿",
		"equip": {
			"type": "阵法",
			"value": {
				"mdef": 100000000,
				"def": 100000000,
				"atk": 100000000
			},
			"percentage": {
				"mdef": 1000,
				"def": 1000,
				"atk": 1000
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I459",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1705": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1706": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1707": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1708": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1709": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1710": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1711": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1712": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1733": {
		"cls": "items",
		"name": "白银剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 10000000"
	},
	"I1734": {
		"cls": "items",
		"name": "骑士剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 30000000"
	},
	"I1735": {
		"cls": "items",
		"name": "圣剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 400000000"
	},
	"I1736": {
		"cls": "items",
		"name": "龙骨剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 5000000000"
	},
	"I1737": {
		"cls": "items",
		"name": "魔剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk += 100000000000"
	},
	"I1738": {
		"cls": "items",
		"name": "白银盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 10000000\ncore.status.hero.mdef += 30000000"
	},
	"I1739": {
		"cls": "items",
		"name": "骑士盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 30000000\ncore.status.hero.mdef += 60000000"
	},
	"I1740": {
		"cls": "items",
		"name": "圣盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 400000000\ncore.status.hero.mdef += 800000000"
	},
	"I1741": {
		"cls": "items",
		"name": "龙骨盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 5000000000\ncore.status.hero.mdef += 10000000000"
	},
	"I1742": {
		"cls": "items",
		"name": "魔盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 100000000000\ncore.status.hero.mdef += 200000000000"
	},
	"I1806": {
		"cls": "items",
		"name": "初级经验灵药",
		"canUseItemEffect": "true",
		"text": null,
		"useItemEvent": null,
		"itemEffect": "core.status.hero.exp +=50000",
		"itemEffectTip": "经验增加5万"
	},
	"I1807": {
		"cls": "items",
		"name": "中级经验灵药",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.exp +=150000",
		"itemEffectTip": "经验增加15万"
	},
	"I1808": {
		"cls": "items",
		"name": "高级经验灵药",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.exp +=250000",
		"itemEffectTip": "经验增加25万"
	},
	"I1809": {
		"cls": "items",
		"name": "神级经验灵药",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.exp +=500000",
		"itemEffectTip": "经验增加50万"
	},
	"I1810": {
		"cls": "items",
		"name": "圣级经验灵药",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.exp +=800000",
		"itemEffectTip": "经验增加80万"
	},
	"I1812": {
		"cls": "equips",
		"name": "一阶护符",
		"canUseItemEffect": "true",
		"text": "全属性增加1000%",
		"equip": {
			"type": "护符",
			"value": {},
			"percentage": {
				"atk": 1000,
				"def": 1000
			}
		}
	},
	"I1814": {
		"cls": "equips",
		"name": "二阶护符",
		"canUseItemEffect": "true",
		"text": "全属性增加2000%,额外增加全属性1兆,受到的伤害降低5%",
		"equip": {
			"type": "护符",
			"value": {
				"mdef": 1000000000000,
				"def": 1000000000000,
				"atk": 1000000000000
			},
			"percentage": {
				"mdef": 2000,
				"def": 2000,
				"atk": 2000
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I1812",
					"operator": "-=",
					"value": "1"
				}
			]
		}
	},
	"I1815": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1816": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1817": {
		"cls": "equips",
		"name": "二阶护符",
		"canUseItemEffect": "true",
		"equip": {
			"type": "护符",
			"value": {
				"mdef": 1000000000000,
				"def": 1000000000000,
				"atk": 1000000000000
			},
			"percentage": {
				"mdef": 2000,
				"def": 2000,
				"atk": 2000
			},
			"equipEvent": [
				{
					"type": "setValue",
					"name": "item:I1813",
					"operator": "-=",
					"value": "1"
				}
			]
		},
		"text": "全属性增加2000%,额外增加全属性1兆"
	},
	"I1818": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1819": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1856": {
		"cls": "items",
		"name": "幻·铁剑",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.atk +=500000000000"
	},
	"I1857": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1858": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1859": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1860": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1861": {
		"cls": "items",
		"name": "幻·铁盾",
		"canUseItemEffect": "true",
		"itemEffect": "core.status.hero.def += 500000000000\ncore.status.hero.mdef += 1000000000000"
	},
	"I1862": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1863": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1864": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1865": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1866": {
		"cls": "constants",
		"name": "血之结晶",
		"canUseItemEffect": "true",
		"text": "血脉压制,敌人生命值降低10%"
	},
	"I1875": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1876": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1877": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1878": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	},
	"I1879": {
		"cls": "items",
		"name": "新物品",
		"canUseItemEffect": "true"
	}
}