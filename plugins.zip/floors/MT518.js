main.floors.MT518=
{
    "floorId": "MT518",
    "title": "通天塔 518 ",
    "name": "通天塔518",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  1,  1],
    [  4, 23,  4, 23,  4, 23,  4, 23,  4, 23,  4, 87,  1],
    [  4, 47,  4, 47,  4, 47,  4, 47,  4, 47,  4, 31,  1],
    [  4,343,  4,343,  4,343,  4,343,  4,343,  4, 31,  1],
    [  4,343,  4,343,  4,343,  4,343,  4,343,  4, 31,  1],
    [  4,343,  4,343,  4,343,  4,343,  4,343,  4,  0,  1],
    [  4,343,  4,343,  4,343,  4,343,  4,343,  4,1386,  1],
    [377,377,377,363,363,363,356,356,356,  0,1389, 31,  1],
    [  1,343,  1,343,  1,343,  1,343,  1,343,  1, 31,  1],
    [  1, 29,  1, 29,  1, 29,  1, 29,  1, 29,  1, 31,  1],
    [  1,343,  1,343,  1,343,  1,343,  1,343,  1,  0,  1],
    [  1,602,  1,602,  1,602,  1,602,  1,602,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}