main.floors.MT540=
{
    "floorId": "MT540",
    "title": "通天塔 540 ",
    "name": "通天塔540",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT540_7_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT540_7_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,3": {
            "0": {
                "condition": "flag:door_MT540_7_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT540_7_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16],
    [ 16, 88, 86, 86, 86, 86,  0,  0,  0, 16, 16, 16, 16],
    [ 16,  0, 16, 16, 16, 16,1419,  0,1419, 16, 16, 16, 16],
    [ 16,539, 16, 16, 16, 16, 16, 85, 16, 16, 16, 16, 16],
    [ 16,  0, 16,1209,1209,1209, 16,  0, 16,1209,1209,1209, 16],
    [ 16,539, 16,1209,1209, 47, 86,  0, 86, 47,1209,1209, 16],
    [ 16,  0, 16, 16, 16, 16, 16,  0, 16, 16, 16, 16, 16],
    [ 16,378, 16,1212,1212,1212, 16,  0, 16,1212,1212,1212, 16],
    [ 16,  0, 16,1212,1212, 47, 86,  0, 86, 47,1212,1212, 16],
    [ 16,378, 16, 16, 16, 16, 16,  0, 16, 16, 16, 16, 16],
    [ 16,  0, 16,1218,1218,1218, 16,  0, 16,1218,1218,1218, 16],
    [ 16, 87, 16,1218,1218, 47, 86,  0, 86, 47,1218,1218, 16],
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16]
],
    "bgmap": [

],
    "fgmap": [

]
}