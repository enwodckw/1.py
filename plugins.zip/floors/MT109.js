main.floors.MT109=
{
    "floorId": "MT109",
    "title": "通天塔 109 ",
    "name": "通天塔109",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,617,342, 29,  1, 21, 87, 21,344,535,603,535,  1],
    [  1,365,  1, 29,343,378, 23,378,  1,  0,609,  0,  1],
    [  1,365,  1, 29,  1, 21,617, 21,  1,  1,342,  1,  1],
    [  1,  1,  1,615,  1,  1,342,  1,  1,606,  0,365,  1],
    [  1,616,342,  0,615,  0, 30, 30, 30,  0,538,  0,  1],
    [  1,365,  1, 29,  1,  1,  1,344,  1,606,  1,365,  1],
    [  1,365,  1, 29,  1,378,378,378,  1,387,342,  0,  1],
    [  1,  1,  1, 29,  1,  1,  1,  1,  1,  1,  1,617,  1],
    [  1,602,  1,  0,  1,360,360,  1,367,367,  1,  0,  1],
    [  1,616,  1,613,  1,360,360,  1,367,367,  1, 23,  1],
    [  1, 88,343,  0,342,608,538,  1,538,608,342,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}