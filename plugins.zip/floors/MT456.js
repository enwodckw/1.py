main.floors.MT456=
{
    "floorId": "MT456",
    "title": "通天塔 456 ",
    "name": "通天塔456",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [
        {
            "type": "setValue",
            "name": "flag:__visited__",
            "value": "{}"
        },
        {
            "type": "function",
            "function": "function(){\ncore.visitFloor(\"MT456\")\n}"
        },
        {
            "type": "setGlobalValue",
            "name": "redGem",
            "value": 2
        },
        {
            "type": "setGlobalValue",
            "name": "blueGem",
            "value": 2
        },
        {
            "type": "setGlobalValue",
            "name": "greenGem",
            "value": 4
        },
        {
            "type": "setGlobalValue",
            "name": "redPotion",
            "value": 1000
        },
        {
            "type": "setGlobalValue",
            "name": "bluePotion",
            "value": 2000
        },
        {
            "type": "setGlobalValue",
            "name": "yellowPotion",
            "value": 4000
        },
        {
            "type": "setGlobalValue",
            "name": "greenPotion",
            "value": 6000
        },
        {
            "type": "setValue",
            "name": "item:greenKey",
            "value": "1000"
        },
        {
            "type": "setValue",
            "name": "item:yellowKey",
            "value": "10"
        },
        {
            "type": "setValue",
            "name": "item:blueKey",
            "value": "10"
        },
        {
            "type": "setValue",
            "name": "item:redKey",
            "value": "10"
        },
        {
            "type": "setValue",
            "name": "item:pickaxe",
            "value": "10"
        },
        {
            "type": "setValue",
            "name": "item:bomb",
            "value": "0"
        },
        {
            "type": "setValue",
            "name": "item:I618",
            "value": "0"
        },
        {
            "type": "setValue",
            "name": "status:hp",
            "value": "1"
        },
        {
            "type": "setValue",
            "name": "status:atk",
            "value": "100"
        },
        {
            "type": "setValue",
            "name": "status:def",
            "value": "100"
        },
        {
            "type": "setValue",
            "name": "status:mdef",
            "value": "100"
        },
        {
            "type": "disableShop",
            "id": "shop2"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,8": [
            "等级检测,到此等级需为 天级界王境  不足将被抹杀",
            {
                "type": "if",
                "condition": "(status:lv===63)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "floorId": "MT456"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "status:hp",
                        "value": "-1"
                    }
                ]
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        8
                    ]
                ],
                "floorId": "MT456",
                "remove": true
            }
        ],
        "6,6": [
            "苍穹落日剑测试结束，失去效果",
            "所有榜单生命都不计分",
            "快乐成仙:黄钥匙每把10万，蓝钥匙每把40万，红钥匙每把160万，破墙镐每把640万，炸弹每个2500万",
            "作弊成仙:绿钥匙每把500万，破墙镐每个100万"
        ]
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,602,  1,602,  1, 21, 88, 21,  1,602,  1,602,  1],
    [  1,344,  1,344,  1,  0,  0,  0,  1,344,  1,344,  1],
    [  1,603,  1,603,  1, 22,  0, 22,  1,603,  1,603,  1],
    [  1,344,  1,344,  1,  1,343,  1,  1,344,  1,344,  1],
    [  1, 23,  0, 23,  1, 47,  0, 47,  1, 23,  0, 23,  1],
    [  1,  0, 47,  0,343,  0,129,  0,343,  0, 47,  0,  1],
    [  1, 23,  0, 23,  1, 47,  0, 47,  1, 23,  0, 23,  1],
    [  1,343,  1,343,  4,  4,1320,  4,  4,343,  1,343,  1],
    [  1, 21,  1, 21,  4, 85, 85, 85,  4, 21,  1, 21,  1],
    [  1, 21,  1, 21,  4, 85, 65, 85,  4, 21,  1, 21,  1],
    [  1, 21,  1, 21,  4, 85, 87, 85,  4, 21,  1, 21,  1],
    [  1,  1,  1,  1,  4,  4,  4,  4,  4,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}