main.floors.MT91=
{
    "floorId": "MT91",
    "title": "通天塔 91 ",
    "name": "通天塔91",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  1, 30, 30, 30,  1, 27,  1, 27,  1, 27,  1],
    [  1,  0,  1,350,350,350,  1, 30,  1, 30,  1, 30,  1],
    [  1,535,  1,343,556,342,  1, 28,  1, 28,  1, 28,  1],
    [  1,  0,546,  0,  0,  0, 86,549, 86,552, 86,549,  1],
    [  1,343,  1,  1,  1,350,  1,  1,  1,  1,  1,  1,  1],
    [  1, 30, 30, 30,545,  0,342,547, 30, 30, 30,348,  1],
    [  1,  1,  1,  1,  1,546,  1,  1,  1,  1,  1,343,  1],
    [  1, 30,535, 30,  1,  0,  1, 30, 30,472, 30, 30,  1],
    [  1,348,348,348,  1,350,  1,548, 30,342,546, 30,  1],
    [  1,342,553,472,  1, 86,342,  0,  1,  1,  1,342,  1],
    [  1, 88,  0,  0,546,  0,  0,553,548, 30, 30, 30,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}