main.floors.MT138=
{
    "floorId": "MT138",
    "title": "通天塔 138 ",
    "name": "通天塔138",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "3,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21, 21, 21,  1, 47,533, 47,  1,  0,673,  0,  1],
    [  1,663,  1,663,  1, 23,  0, 23,  1,354,  1,354,  1],
    [  1,  0,342,  0,  1,  1,343,  1,  1,387,  1,391,  1],
    [  1,354,  1,354,  1,365,668,365,  1,  0,  1,390,  1],
    [  1,  0,  1,  0,  1,665,  0,665,  1,664,  1,390,  1],
    [  1,664,  1,664,  1,  1, 86,  1,  1,  0,  1,  0,  1],
    [  1,  0,343,  0,  1,358,667,358,  1,390,  1,670,  1],
    [  1,385,  1,385,  1,666,  0,666,  1,383,  1,390,  1],
    [  1,  0,  1,  0,  1,  1,343,  1,  1,390,  1,390,  1],
    [  1,665,  1,665,  1,  0,  0,382,  1,  0,  1,533,  1],
    [  1, 87,344, 88,342,664,  0,  0,342,669,  1,390,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}