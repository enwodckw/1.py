main.floors.ML14=
{
    "floorId": "ML14",
    "title": "通天塔 14 ",
    "name": "地下14",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "4,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML14_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,8": [
            {
                "type": "setValue",
                "name": "flag:door_ML14_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,8": [
            {
                "type": "setValue",
                "name": "flag:door_ML14_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML14_6_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,3": {
            "0": {
                "condition": "flag:door_ML14_6_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML14_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,2": {
            "0": {
                "condition": "flag:door_ML14_6_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML14_6_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,536,536,  1,  1,  1, 88,  1,  1,  1,536,536,  1],
    [  1,536,594,342,342,  1, 85,  1,342,342,594,536,  1],
    [  1,  1,  1,  1,342,  1, 85,  1,342,  1,  1,  1,  1],
    [  1,  1,  1,  1,541,  0,540,  0,541,  1,  1,  1,  1],
    [537,  1,  1,  1,  0,  1,344,  1,  0,  1,  1,  1,537],
    [593,343,343,343,  0,  1, 23,  1,  0,343,343,343,593],
    [537,  1,  1,  1,  0,  1,533,  1,  0,  1,  1,  1,537],
    [  1,  1,  1,  1,541,  1,540,  1,541,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,533,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 21,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,342,343,342,  0,  0,  0,344,352,352,352],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}