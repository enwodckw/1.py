main.floors.MN4=
{
    "floorId": "MN4",
    "title": "通天塔 M4 ",
    "name": "黑暗深渊M4",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000000000,
    "defaultGround": "ground",
    "bgm": "boss.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "9,9": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "3,9": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,5": [
            {
                "type": "setValue",
                "name": "flag:door_MN4_3_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,9": [
            {
                "type": "setValue",
                "name": "flag:door_MN4_3_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "3,4": {
            "0": {
                "condition": "flag:door_MN4_3_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MN4_3_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,  4,1150,1150,1150,1150,1150,1150,1150,1150,1150,  4,1150],
    [1150,  4,1150,  0,  0,  0,  0,  0,  0,  0,1150,  4,1150],
    [1150,  4,1150, 85,  4,  4, 86,  4,  4,  0,1150,  4,1150],
    [1150,  4,1150,1223,  4,  4,1242,  4,  4,  0,1150,  4,1150],
    [1150,  4,1150,1223,  4,  4,  0,  4,  4,  0,1150,  4,1150],
    [1150,  4,1150,1223,  4,  4,  0,  4,  4,  0,1150,  4,1150],
    [1150,  4,1150, 23,  4,  4,  0,  4,  4,  0,1150,  4,1150],
    [1150,  4,1150, 87,  4,  4,1242,  4,  4, 88,1150,  4,1150],
    [1150,  4,1150,1150,1150,1150,1150,1150,1150,1150,1150,  4,1150],
    [1150,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}