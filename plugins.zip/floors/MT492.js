main.floors.MT492=
{
    "floorId": "MT492",
    "title": "通天塔 492 ",
    "name": "通天塔492",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,342,1340, 34,  1,365,365,365,  0,1344,379,  1],
    [  1,  0,  1, 34, 34,  1,1334,  1,  1,  1,  1,349,  1],
    [  1,1338,  1,  1,  1,  1,343,  1, 34,602,  1,379,  1],
    [  1,  0, 34,  0,1334,  0,602,342,1345,536,  1,  1,  1],
    [  1,342,  1,1340,  1, 30,  0,  1, 34,602,  1,349,  1],
    [  1, 21,1332,  0,  1,  1,342,  1,  1,  1,  1,1342,  1],
    [  1,342,  1,1340,  1,352,1336,  0, 34,  0,343,  0,  1],
    [  1, 21, 34,  0,  1, 30,  1,  1,342,  1,  1,1342,  1],
    [  1,  1,  1,342,  1, 30,  1,1343,  0,1343,  1,358,  1],
    [  1, 21, 21,1338,  1, 30,  1,349,  1,349,  1,358,  1],
    [  1, 87, 30, 30,  1, 30,  1,379,  1,379,  1,358,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}