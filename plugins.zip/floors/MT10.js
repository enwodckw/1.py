main.floors.MT10=
{
    "floorId": "MT10",
    "title": "通天塔 10 ",
    "name": "通天塔10",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,3": [
            {
                "type": "setBlock",
                "number": "redKey"
            },
            {
                "type": "setBlock",
                "number": "redGem",
                "loc": [
                    [
                        1,
                        1
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "redGem",
                "loc": [
                    [
                        2,
                        1
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "redGem",
                "loc": [
                    [
                        3,
                        1
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "blueGem",
                "loc": [
                    [
                        11,
                        1
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "blueGem",
                "loc": [
                    [
                        10,
                        1
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "blueGem",
                "loc": [
                    [
                        9,
                        1
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "bluePotion",
                "loc": [
                    [
                        9,
                        5
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "bluePotion",
                "loc": [
                    [
                        10,
                        5
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "bluePotion",
                "loc": [
                    [
                        11,
                        5
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "yellowKey",
                "loc": [
                    [
                        1,
                        5
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "yellowKey",
                "loc": [
                    [
                        2,
                        5
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "yellowKey",
                "loc": [
                    [
                        3,
                        5
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "openDoor",
                "loc": [
                    10,
                    10
                ],
                "floorId": "MT10"
            },
            {
                "type": "openDoor",
                "loc": [
                    10,
                    12
                ],
                "floorId": "MT10"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,6": {
            "0": {
                "condition": "flag:door_MT10_6_6==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT10_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,325,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,214,  0,214,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,214,  0,214,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,344,  1,  1, 23, 85, 31,  1],
    [  1, 88,  0,210,  0,356,  0,342,213,377,345, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1, 21, 85,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "shanmai.mp3"
}