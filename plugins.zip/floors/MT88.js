main.floors.MT88=
{
    "floorId": "MT88",
    "title": "通天塔 88 ",
    "name": "通天塔88",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "1,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT88_2_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT88_2_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "2,9": {
            "0": {
                "condition": "flag:door_MT88_2_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT88_2_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,350,547,342, 30,  1,348,  0,551,  0,348,  1],
    [  1,545,343, 21,  1, 30,  1,348,  1,  1,  1,348,  1],
    [  1,342,343, 21,  1,545,  1,  0,  1, 27,  1,  0,  1],
    [  1, 31,356, 31,356,  0,  1,550,  1, 27,  1,552,  1],
    [  1,  1,  1,  1,  1, 27,  1,  0,  1, 27,  1,  0,  1],
    [  1,349,  0,349,  1, 27,  1,348,  1, 27,  1,348,  1],
    [  1,  0,503,  0,  1, 27,  1,348,  1, 28,  1,348,  1],
    [  1,349,  0,349,  1,  0,  1,348,  1, 28,  1,  0,  1],
    [  1,  1, 85,  1,  1,546,  1,  0,  1, 28,  1,556,  1],
    [  1,545,  0,545,  0,  0,  1,549,  1, 28,  1, 47,  1],
    [  1, 88,  0,  0,  0,351,342,  0,342,553,  1,535,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}