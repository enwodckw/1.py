main.floors.MT483=
{
    "floorId": "MT483",
    "title": "通天塔 483 ",
    "name": "通天塔483",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT483_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT483_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,8": [
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        6
                    ]
                ],
                "floorId": "MT483"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        7
                    ]
                ],
                "floorId": "MT483"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        8
                    ]
                ],
                "floorId": "MT483"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "MT483"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        7
                    ]
                ],
                "floorId": "MT483"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        7
                    ]
                ],
                "floorId": "MT483"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        6
                    ]
                ],
                "floorId": "MT483"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        8
                    ]
                ],
                "floorId": "MT483"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_MT483_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT483_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  0, 87,  0,  1,  1,  1,  1,  1],
    [  1, 34,342,  0,359,  0,348,  0,366,  0,342, 34,  1],
    [  1,  1,  1,  0,  4,  4,  4,  4,  4,  0,  1,  1,  1],
    [  1, 33,  1,1339,  4,568,  0,568,  4,1338,  1, 32,  1],
    [  1,363,  1,  0,  4,  0,1228,  0,  4,  0,342, 30,  1],
    [  1,1340,342, 21,  4,568,  0,568,  4, 21,  1, 32,  1],
    [  1,363,  1, 21,  4,1349,1351,1354,  4, 21,  1,  1,  1],
    [  1,  1,  1, 21,  4,1348,1350,1353,  4, 21,  1, 32,  1],
    [  1, 33,  1,  0,  4,1347,1346,1352,  4,  0,342, 30,  1],
    [  1,356,  1,1339,  4,  4, 85,  4,  4,343,  1, 32,  1],
    [  1,1340,342,  0,  4,1342,  0,1342,  4,  0,  1,  1,  1],
    [  1,356,  1, 22,  1,345,343,344,  1, 22,  0, 88,  1],
    [  1,  1,  1,  0,348,  0,638,  0,348,  0,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}