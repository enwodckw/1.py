main.floors.MT477=
{
    "floorId": "MT477",
    "title": "通天塔 477 ",
    "name": "通天塔477",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "1,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT477_2_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT477_2_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "2,9": {
            "0": {
                "condition": "flag:door_MT477_2_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT477_2_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,344,  0, 21, 21, 21,1321, 31, 31, 31, 87,  1],
    [  1,1323,  1, 31, 31, 31,  0,  1,  1,  1,  1,342,  1],
    [  1,  0,  1,  1,  1,  1,1328,  1, 30, 30,  1,1322,  1],
    [  1, 33,343,344,  1,  1,372,  1,372,372,  1,  0,  1],
    [  1,  1,  1,343,  1,  1,372,  1,372,1328,342, 34,  1],
    [  1, 32,  0, 32,  1, 30, 30,  1,  1,  1,  1,  0,  1],
    [  1,  0,387,  0,  1,  1,  1,  1, 32, 32,  1,1323,  1],
    [  1, 32,  0, 32,  1,  1,  1,  1,  1, 32,  1, 29,  1],
    [  1,  1, 85,  1,  1, 32,1326, 32,  1,1327,  1, 29,  1],
    [  1,1331,  0,1331,  1,1325,  1,1325,  1,343,  1, 29,  1],
    [  1,  0,  0,  0, 86,  0,343,  0, 86,  0,1326,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}