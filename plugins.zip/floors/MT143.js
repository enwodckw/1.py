main.floors.MT143=
{
    "floorId": "MT143",
    "title": "通天塔 143 ",
    "name": "通天塔143",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "12,3": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,384,384,384,  1,387,386,  1,352,  0,352,  0,  1],
    [  1,385,385,385,  1,386,673,342,672,  0,672,343,  1],
    [  1,344,  1,677,  1,  1,  1,  1,  1,342,  1,  0, 88],
    [  1,  0,676,  0,  1,602,342,  0,  0,668,  0,386,  1],
    [  1,352,  1,  1,  1,669,  1,670,  1,  1,  1,  1,  1],
    [  1,  0,  1,602,342,  0,352,  0,  1,  1,  1,  1,  1],
    [  1,675,  1,669,  1,670,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,342,  0,352,  0,  1,  1,  1,  1,  1,  1,  1],
    [  1,667,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}