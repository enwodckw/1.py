main.floors.MT11=
{
    "floorId": "MT11",
    "title": "通天塔 11 ",
    "name": "通天塔11",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "5,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 22,  1, 21,  0,  1,343,370, 34,370,219,  0,  1],
    [  1,216,342,  0,228,343,216,  1,  1,  1,  1,  0,  1],
    [  1, 22,  1, 21,  0,  1,  0,370,  0, 34,  1, 31,  1],
    [  1,  1,  1,  1, 30,  1,377,  0,228,  0,  1, 31,  1],
    [  1, 31, 22,  1,  1,  1,  1,  1,342,  1,  1, 31,  1],
    [  1,219, 31,  1,363,228,356,  1,217,342,218,  0,  1],
    [  1,342,  1,  1,  1,343,  1,  1,  0,  1,  1,  1,  1],
    [  1,  0,  0,214,  0,  0,  0,217,  0,  1, 32, 28,  1],
    [  1,342,  1,  1,  1,342,  1,  1,342,  1,215, 32,  1],
    [  1,215, 32,  1,  0,214,  0,  1,214,  1,342,  1,  1],
    [  1, 32, 27,  1, 28,  0, 27,  1,  0,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}