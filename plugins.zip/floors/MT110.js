main.floors.MT110=
{
    "floorId": "MT110",
    "title": "通天塔 110 ",
    "name": "通天塔110",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,354,  1,378,613,342, 88,342,348,614,380, 21,  1],
    [  1,611,354,  1,613,378,617,378,  1,354,  1,342,  1],
    [  1,378,606,354,  1,342,378,613,342,614,379, 21,  1],
    [  1,342,378,  1,354,611,  1,343,  1,354,  1,342,  1],
    [  1,374,613,606,  0,  1,  1,614,  1,615,380,615,  1],
    [  1,  1,378,343,374, 21,  1,564,  1,354,  1,342,  1],
    [  1,374,  1,615,377,  1,  1,  1,  1,615,379,615,  1],
    [  1,342,613,377,343, 21,  1,380,617,354,  1,342,  1],
    [  1,374, 21,  1, 21,606,342,617,379,343,380,616,  1],
    [  1,611,377,  1,348,  1,613,  1,616,  1,616,611,  1],
    [  1,377,  1,348,348,  1,379,  1,380,  1,379, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}