main.floors.MT38=
{
    "floorId": "MT38",
    "title": "通天塔 38 ",
    "name": "通天塔38",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  1,  0, 30,  0,255,  0, 30,  0,255,  0,  1],
    [  1,  0,  1,412,  1,  1,  1,  1,  1,  1,  1,254,  1],
    [  1,  0,343,  0,  1, 47,351,382,270,  0, 86,  0,  1],
    [  1,253,  1,411,  1,  1,  1,  1,  1,343,  1,254,  1],
    [  1,  0,  1,  0, 28, 28, 28,  1,386,386,  1, 30,  1],
    [  1, 21,  1,  1,  1,  1,343,  1,  1,  1,  1,  1,  1],
    [  1,  0,409,  0, 21,  1,380,408,  0,  0,408,  0,  1],
    [  1,  1,  1,  1,390,  1,  1,  1,  1,  1,342,  1,  1],
    [  1, 27, 27,  1,  0,412,  0,351,  0,410,  0,250,  1],
    [  1, 28, 28,  1,253,  1,  1,  1,  1,  1,344,  0,  1],
    [  1, 30,254,342,  0,343, 21, 21, 21,  1,383, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}