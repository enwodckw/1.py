main.floors.MT551=
{
    "floorId": "MT551",
    "title": "通天塔 551 ",
    "name": "通天塔551",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "4,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT551_5_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT551_5_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "11,1": [
            "吸取斩神剑的剑意，全属性增加5万",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "50000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "50000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "50000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {
        "5,4": {
            "0": {
                "condition": "flag:door_MT551_5_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT551_5_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,537,355,  1, 21, 23, 21,  1, 21,1408,355,396,  1],
    [  1,355,  0,  1, 22,537, 22,  1,  1,343,  1,  1,  1],
    [  1,  1,1417,  1, 21, 47, 21,  1,367,367,  1, 22,  1],
    [  1, 21, 21,  1,  1, 85,  1,  1,1408,367,  1, 22,  1],
    [  1,348,  1,  1,1416,  0,1416,  1,342,  1,  1, 22,  1],
    [  1, 21,  1,1408,  0,  0,  0,  0,1407,  0,  1,348,  1],
    [  1,1407,  1,342,  1,  1,  1,1407,  1,1407,  1,1408,  1],
    [  1,342,  0, 21,  0,343,350,  0,344,  0, 86,  0,  1],
    [  1,  1,1409,  1,1406,  1,343,  1,  1,  1,  1,1407,  1],
    [  1, 21,  0,  1,348,  1, 21,  1,355, 22,  1,  0,  1],
    [  1, 87,350,344,348,  1, 21,  1, 22,1407,342, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}