main.floors.MT1=
{
    "floorId": "MT1",
    "title": "通天塔 1 ",
    "name": "通天塔1",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,12": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT1_10_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT1_10_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT1_2_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT1_2_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT1_9_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,9": {
            "0": {
                "condition": "flag:door_MT1_10_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT1_10_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,9": {
            "0": {
                "condition": "flag:door_MT1_2_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT1_2_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "9,6": {
            "0": {
                "condition": "flag:door_MT1_9_6==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT1_9_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,201,202,201,  0, 21, 34, 28,  0,202,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 81,  0,  1],
    [  1,  0,209,342, 32,  1,205,  1, 27, 28,  1, 21,  1],
    [  1, 21, 32,  1, 32,  1,205,  1, 29, 29,  1, 34,  1],
    [  1, 30, 22,  1,203,  1,205,  1, 22, 31,  1, 29,  1],
    [  1,  1,  1,  1,342,  1,343,  1,  1, 85,  1,201,  1],
    [  1,  0,  0,  0,  0,  0, 30,  0,201,  0,  0,  0,  1],
    [  1,206,  0,206,  1,  1,344,  1,  1,206,  0,206,  1],
    [  1,  1, 85,  1,  1, 33,  0, 23,  1,  1, 85,  1,  1],
    [  1, 31, 31, 31,  1,  0, 27,  0,  1, 31, 31, 31,  1],
    [  1, 29, 21, 29,  1,347,  0,346,  1, 29, 21, 29,  1],
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "shanmai.mp3"
}