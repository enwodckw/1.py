main.floors.MT107=
{
    "floorId": "MT107",
    "title": "通天塔 107 ",
    "name": "通天塔107",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "9,12": {
            "floorId": "MT108",
            "loc": [
                9,
                12
            ]
        },
        "11,12": {
            "floorId": "MT108",
            "loc": [
                11,
                12
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 23,382,610,379,611,355,612,352,613,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,342,611,  1],
    [  1, 47,382,616,379,615,355,614,352,613,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,343,613,  1],
    [  1, 47,382,616,379,615,355,614,352,613,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,342,611,  1],
    [  1,375,  1,616,342,615,  1,614,342,613,  0,  0,  1],
    [  1,375,  1, 21,  1, 21,  1, 21,  1,  1,  1, 33,  1],
    [  1,387,  1,386,  1,386,  1,386,  1,615,342,  0,  1],
    [  1,375,  1, 21,  1, 21,  1, 21,  1,  0,  1,342,  1],
    [  1,375,617,  0,  1,  0,617,  0,  1,351,  1,615,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1, 87,  1, 87,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}