main.floors.MT365=
{
    "floorId": "MT365",
    "title": "通天塔 365 ",
    "name": "黑暗深渊365",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,380,380,380,380,344, 87,344,380,380,380,380,  4],
    [  4,  4,  4,  4,  4,  4,348,  4,  4,  4,  4,  4,  4],
    [  4,639,639,639,639,1193,  0,1192,639,639,639,639,  4],
    [  4,  4,  4,  4,  4,  4,348,  4,  4,  4,  4,  4,  4],
    [  4,639,639,639,639,1194,  0,1196,639,639,639,639,  4],
    [  4,  4,  4,  4,  4,  4,348,  4,  4,  4,  4,  4,  4],
    [  4,639,639,639,639,1197,  0,1195,639,639,639,639,  4],
    [  4,  4,  4,  4,  4,  4,348,  4,  4,  4,  4,  4,  4],
    [  4,639,639,639,639,1199,  0,1198,639,639,639,639,  4],
    [  4,  4,  4,  4,  4,  4,348,  4,  4,  4,  4,  4,  4],
    [  4,639,639,639,639,1205, 88,1206,639,639,639,639,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}