main.floors.MT112=
{
    "floorId": "MT112",
    "title": "通天塔 112 ",
    "name": "通天塔112",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "0,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  1, 87,  1],
    [  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  1,  0,  1],
    [  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  1,571,  1],
    [  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  1,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,606,  1],
    [ 88,  0, 22,537, 22,  0,607,  0, 22,537, 22,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  1],
    [  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  1],
    [  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  1],
    [  1,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}