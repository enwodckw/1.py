main.floors.MT166=
{
    "floorId": "MT166",
    "title": "通天塔 166 ",
    "name": "通天塔166",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150000,
    "defaultGround": "grass",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "3,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT166_10_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT166_10_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT166_10_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT166_10_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT166_9_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT166_9_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT166_8_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT166_8_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,7": {
            "0": {
                "condition": "flag:door_MT166_10_7==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT166_10_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "9,7": {
            "0": {
                "condition": "flag:door_MT166_9_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT166_9_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,2": {
            "0": {
                "condition": "flag:door_MT166_8_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT166_8_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20, 88, 20,690,349, 20,  0,679, 20,391,  0,391, 20],
    [ 20,  0,342,  0,  0,342,  0,  0, 85,  0,391,  0, 20],
    [ 20,678, 20,690,  0, 20,  0,679, 20,391,  0,391, 20],
    [ 20,352, 20,  0,342, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20, 47, 20,691,  0, 20,680,680,343,536,  0,536, 20],
    [ 20, 20, 20, 20,533, 20,680, 20,344, 20, 20,570, 20],
    [ 20, 47, 20,691,  0,342,  0, 86,  0, 85, 85,570, 20],
    [ 20,352, 20,  0,342, 20,681, 20,344, 20, 20,570, 20],
    [ 20,352, 20,  0,349, 20,681,681,343,536,  0,536, 20],
    [ 20,682,342,691, 20, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20,352, 20,  0,343,682, 47, 47, 23, 23,538,538, 20],
    [ 20, 20, 20, 87, 20, 20, 20, 20, 20, 20, 20, 20, 20]
],
    "bgmap": [

],
    "fgmap": [

]
}