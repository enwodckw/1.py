main.floors.MT370=
{
    "floorId": "MT370",
    "title": "通天塔 370 ",
    "name": "黑暗深渊370",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT370_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT370_10_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,8": {
            "0": {
                "condition": "flag:door_MT370_10_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT370_10_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 87,1150,1150,1150,1150,1150,1150,911,1221,1180,  0,1150],
    [1150,1161,1150,1150,1150,1150,1150,1150,1150,1150,1150,366,1150],
    [1150,  0,349,  0,1178,569,1150,1150,1150,1150,1150,  0,1150],
    [1150,  0,1150,342,1150,637,1150,1150,1150,1150,1150,1163,1150],
    [1150,1172,1150,366,1150,1150,1150,360,  0,360,342,  0,1150],
    [1150,  0,1161,  0,349,  0,1173,  0,569,  0,1150,564,1150],
    [1150,  0,1150,1150,1150,342,1150,343,1150,1174,  0,1174,1150],
    [1150,1162,342,366,1150,349,1150,366,1150,1150, 85,1150,1150],
    [1150,  0,1167,366,1150,  0,1173,366,1150,1221,  0,1221,1150],
    [1150,  0,1150,1150,1150, 86,1150,1150,1150,  0,1223,  0,1150],
    [1150, 88,1150,1222,1222,1177,1222,1222,1150,1221,  0,1221,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}