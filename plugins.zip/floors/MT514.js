main.floors.MT514=
{
    "floorId": "MT514",
    "title": "通天塔 514 ",
    "name": "通天塔514",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_2_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_2_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT514_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,11": [
            {
                "type": "if",
                "condition": "blockId:3,11",
                "true": [],
                "false": [
                    {
                        "type": "setBlock",
                        "number": "I1397",
                        "loc": [
                            [
                                2,
                                12
                            ]
                        ],
                        "floorId": "MT514"
                    }
                ]
            }
        ],
        "3,11": [
            {
                "type": "if",
                "condition": "blockId:1,11",
                "true": [],
                "false": [
                    {
                        "type": "setBlock",
                        "number": "I1397",
                        "loc": [
                            [
                                2,
                                12
                            ]
                        ],
                        "floorId": "MT514"
                    }
                ]
            }
        ],
        "9,11": [
            {
                "type": "if",
                "condition": "blockId:11,11",
                "true": [],
                "false": [
                    {
                        "type": "setBlock",
                        "number": "I1359",
                        "loc": [
                            [
                                10,
                                12
                            ]
                        ],
                        "floorId": "MT514"
                    }
                ]
            }
        ],
        "11,11": [
            {
                "type": "if",
                "condition": "blockId:9,11",
                "true": [],
                "false": [
                    {
                        "type": "setBlock",
                        "number": "I1359",
                        "loc": [
                            [
                                10,
                                12
                            ]
                        ],
                        "floorId": "MT514"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,8": {
            "0": {
                "condition": "flag:door_MT514_10_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT514_10_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,4": {
            "0": {
                "condition": "flag:door_MT514_10_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT514_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,4": {
            "0": {
                "condition": "flag:door_MT514_2_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT514_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,8": {
            "0": {
                "condition": "flag:door_MT514_2_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT514_2_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        },
        "6,4": {
            "0": {
                "condition": "flag:door_MT514_6_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT514_6_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,8": {
            "0": {
                "condition": "flag:door_MT514_6_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT514_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,536,  0,  1,  0, 87,  0,  1,  0,536,  0,  1],
    [  1,348,  0,348,  1,349,  0,349,  1,348,  0,348,  1],
    [  1,  0,1385,  0,  1,  0,537,  0,  1,  0,1385,  0,  1],
    [  1,  1, 85,  1,  1,  1, 85,  1,  1,  1, 85,  1,  1],
    [  1,1384,  0,1384,  1,1378,  0,1378,  1,1383,  0,1383,  1],
    [  1,  0,  0,  0,342,  0,  0,  0,342,  0,  0,  0,  1],
    [  1,1383,  0,1383,  1,349,  0,349,  1,1384,  0,1384,  1],
    [  1,  1, 85,  1,  1,  1, 85,  1,  1,  1, 85,  1,  1],
    [  1,348,1387,348,  1,1377,  0,1377,  1,348,1387,348,  1],
    [  1,  0,536,  0,  1,  0,  0,  0,  1,  0,536,  0,  1],
    [  1,1392,  0,1392,  1,  0, 88,  0,  1,1392,  0,1392,  1],
    [  1,  1, 29,  1,  1,  1,  1,  1,  1,  1, 29,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}