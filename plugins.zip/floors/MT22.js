main.floors.MT22=
{
    "floorId": "MT22",
    "title": "通天塔 22 ",
    "name": "通天塔22",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,0": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1, 87,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1],
    [  1,  0,236,  0, 32,342,  0,344, 21,356,356,356,  1],
    [  1,  1,  1,  1,  1,  1, 30,  1,363,363,363, 21,  1],
    [  1, 21, 21, 21,  0,235,  0,342,247,  0,353,377,  1],
    [  1,350,  1,  1,  1,  1,342,  1,  1,  1,  1,343,  1],
    [  1,  1,  1, 30, 22,237,  0,237,  0,349,  0,240,  1],
    [  1,377,  1,  1,  1,  1, 86,  1,343,  1,342,  1,  1],
    [  1, 22,238,  0, 32,  0,235,  0, 21,  1,349,  0,  1],
    [  1,  1,  1,237,  1,  1,  1,  1,342,  1,  0,379,  1],
    [  1,  0, 32, 86,  0,236,  0, 86,  0,238,  0,  0,  1],
    [  1,342,  1,  1,343,  1,238,  1,236,  1,  1,342,  1],
    [  1,239,358,  1, 30,  1,377,  1, 22,  1,365,239,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}