main.floors.MT135=
{
    "floorId": "MT135",
    "title": "通天塔 135 ",
    "name": "通天塔135",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT135_7_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT135_7_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,8": {
            "0": {
                "condition": "flag:door_MT135_7_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT135_7_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,357,  1,357,  1,350, 87,350,  1,357,  1,357,  1],
    [  1,364,  1,364,  1,  0,663,  0,  1,364,  1,364,  1],
    [  1,667,  1,666,  1,  1, 86,  1,  1,665,  1,667,  1],
    [  1,  0,539,  0, 86,664,  0,342,  0,  0,343,  0,  1],
    [  1,  1,  1,  1,  1,  1,538,  1,672,  0,672,354,  1],
    [  1,354,358,  1,364,665,  0,  1,  1, 86,  1,  1,  1],
    [  1,358,666,342,364,  1,343,387,  1, 33, 33, 33,  1],
    [  1,  1,  1,  1,  1,  1,  1, 85,  1,  1, 86,  1,  1],
    [  1,623,  0,358,  1,663,  0,663,  1, 33, 33, 33,  1],
    [  1,  0,358,  0,  1,  0,564,  0,  1,663,  1,342,  1],
    [  1,358,  0,664,342,  0,  0,  0, 86,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}