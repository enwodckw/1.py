main.floors.MT207=
{
    "floorId": "MT207",
    "title": "通天塔 207 ",
    "name": "通天塔207",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 5000000,
    "defaultGround": "grass",
    "bgm": "waiwei.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,2": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT207_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT207_6_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,6": {
            "0": {
                "condition": "flag:door_MT207_6_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT207_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142, 87,148,148,148,384,  0,384,148,148,148,142,142],
    [142,  0,148,148,148,  0,630,  0,148,148,148,142,142],
    [142,348,148,148,148,385,  0,385,148,148,148,142,142],
    [142,  0,148,148,148,148,538,148,148,148,148,142,142],
    [142,780,148,148,148,148, 85,148,148,148,148,142,142],
    [142,  0,148,148,148,778,  0,778,148,148,148,142,142],
    [142, 30,148,148,148,  0,777,  0,148,148,148,142,142],
    [142, 22,148,148,148,148,343,148,148,148,148,142,142],
    [142,  0,342,775,  0, 30,  0, 22,342,348, 31,142,142],
    [142, 88,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142,142,142,142,142,142,142,142]
],
    "bgmap": [

],
    "fgmap": [

]
}