main.floors.ML3=
{
    "floorId": "ML3",
    "title": "通天塔 3 ",
    "name": "地下3",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,12": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_ML3_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_ML3_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_ML3_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_ML3_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML3_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML3_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML3_10_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML3_10_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_ML3_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML3_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,6": {
            "0": {
                "condition": "flag:door_ML3_6_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML3_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,3": {
            "0": {
                "condition": "flag:door_ML3_6_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML3_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,3": {
            "0": {
                "condition": "flag:door_ML3_10_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML3_10_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,535, 47,535,  1,534, 21,534,  1,534, 21,534,  1],
    [  1,  1,  1, 47,  1, 21, 23, 21,  1, 21, 23, 21,  1],
    [  1, 21,  1,596,  1,  1, 85,  1,  1,  1, 85,  1,  1],
    [  1,536,  1,343,  1,592,  0,592,  1,594,  0,594,  1],
    [  1, 21,593,  0,351,  0, 21,  0,351,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1, 85,  1,  1,344,  1,595,  1],
    [  1,368,368,368,  1,578,  0,578,  1, 22,536, 22,  1],
    [  1,375,368,375,343, 21,355, 21,  1,  1,  1,  1,  1],
    [  1,375,591,375,  1,  1, 85,  1,  1,361,361,361,  1],
    [  1,  1,342,  1,  1,589,  0,589,  1,577,  1,361,  1],
    [  1, 87,  0,  0,577,  0,  0,  0,578,  0,342,342,  1],
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}