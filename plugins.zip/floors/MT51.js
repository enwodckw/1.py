main.floors.MT51=
{
    "floorId": "MT51",
    "title": "通天塔 51 ",
    "name": "通天塔51",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT51_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT51_8_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "11,1": [
            "吸收斩神剑剑意,全属性增加300",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "300"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "300"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "300"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {
        "8,6": {
            "0": {
                "condition": "flag:door_MT51_8_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT51_8_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,349,  1,348,  1,265,373,391,373,  1,397,  1],
    [  1,  0, 22,  1,348,  1,342,  1,  1,  1,  1,373,  1],
    [  1,425,342,  1,342, 22,  0,266,373,352,342,265,  1],
    [  1,  0,379,  0,343,427,  1,  1,  1,  1,  1,  1,  1],
    [  1,342,  1,428,  1,  0,  1,271,  1,391,  0,391,  1],
    [  1,  0,423,  0,430,  0,342,  0, 85,  0,391,  0,  1],
    [  1,349,  1,342,  1,342,  1,271,  1,391,  0,391,  1],
    [  1,  0,  1,265,  1,265,  1,  1,  1,  1,  1,  1,  1],
    [  1,431,  1,  0,  1,365,365,365,  0,266, 23,343,  1],
    [  1,  0,  1,358,  1,  1,  1,  1,  1,  1,  1,343,  1],
    [  1, 87,  1,358,358,  0,267,349,391,349, 23,343,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}