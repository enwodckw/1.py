main.floors.MT66=
{
    "floorId": "MT66",
    "title": "通天塔 66 ",
    "name": "通天塔66",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 24,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,359,359,359,  1, 27, 27, 27,  1,366,366,366,  1],
    [  1,350,246,350,  1, 30,  1,467,  1,350,246,350,  1],
    [  1,  1,342,  1,  1,343,  1,342,  1,  1,342,  1,  1],
    [  1,469, 86,462,  0,461,468,461,  0,  0,  0, 21,  1],
    [  1, 30,  1,  0,  1,  1,  1,  1,  1,463, 21, 21,  1],
    [  1, 30,  1, 21,  1,384,246,385,  1,343,  1,  1,  1],
    [  1,  1,  1,  0,  1,  1,342,  1,  1,386,  1, 30,  1],
    [  1,469,342,  0,463,  0,349,  0,462,  0,  1, 30,  1],
    [  1, 30,  1,467,  1,  1,343,  1,  1,  0,342,465,  1],
    [  1, 30,  1,  0,  1,  0,466,  0,  1,463,  1,  1,  1],
    [  1, 30,  1,386,342, 30, 87, 30,  1,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}