main.floors.MT364=
{
    "floorId": "MT364",
    "title": "通天塔 364 ",
    "name": "黑暗深渊364",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,639,639,639,639,  4, 88,  4,639,639,639,639,  4],
    [  4,639,639,639,639,  4,  0,  4,639,639,639,639,  4],
    [  4,639,639,639,639,  4,348,  4,639,639,639,639,  4],
    [  4,1201, 22, 22, 22,  4,348,  4, 23, 23, 23,1204,  4],
    [  4,344,  4,  4,  4,  4,348,  4,  4,  4,  4,344,  4],
    [  4,  0,350,350,350,1171,  0,1171,350,350,350,  0,  4],
    [  4,344,  4,  4,  4,  4,348,  4,  4,  4,  4,344,  4],
    [  4,1203, 21, 21, 21,  4,348,  4, 47, 47, 47,1202,  4],
    [  4,639,639,639,639,  4,348,  4,639,639,639,639,  4],
    [  4,639,639,639,639,  4,  0,  4,639,639,639,639,  4],
    [  4,639,639,639,639,  4, 87,  4,639,639,639,639,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}