main.floors.ML21=
{
    "floorId": "ML21",
    "title": "通天塔 21 ",
    "name": "地下21",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "4,5": {
            "floorId": "ML22",
            "loc": [
                4,
                5
            ]
        },
        "4,7": {
            "floorId": "ML22",
            "loc": [
                4,
                7
            ]
        },
        "12,6": {
            "floorId": "ML22",
            "loc": [
                12,
                6
            ]
        },
        "1,1": {
            "floorId": "ML20",
            "loc": [
                1,
                1
            ]
        },
        "1,11": {
            "floorId": "ML19",
            "loc": [
                1,
                11
            ]
        },
        "6,11": {
            "floorId": "ML20",
            "loc": [
                6,
                11
            ]
        },
        "6,1": {
            "floorId": "ML20",
            "loc": [
                6,
                1
            ]
        },
        "11,1": {
            "floorId": "ML19",
            "loc": [
                11,
                1
            ]
        },
        "11,11": {
            "floorId": "ML19",
            "loc": [
                11,
                11
            ]
        },
        "10,6": {
            "floorId": "ML20",
            "loc": [
                10,
                6
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  1, 21,379, 21, 88,  1,  0,522,  0, 88,  1],
    [  1,350,  1,519,  1,  1,  1,  1,357,  1,  1,  1,  1],
    [  1,379,  1,  0,342,525,  0,357,357,  1,352,352,  1],
    [  1,  0,  1,516,  1,  1,  1,  1,  1,  1,352,515,  1],
    [  1,522,342,  0, 87,348,  1,538, 21,  1,  1,342,  1],
    [  1,  1,  1,  1,  1,  1,  1,535,526,342, 88,  0, 87],
    [  1,  0,523,  0, 87,348,  1,538, 21,  1,  1,342,  1],
    [  1, 21,  1,  1,  1,  1,  1,  1,  1,  1,350,516,  1],
    [  1,379,  1, 21, 21, 21,  0,350,  0,516,  0,  0,  1],
    [  1,350,  1,  1,  1,  1,525,  1,342,  1,343,515,  1],
    [  1, 88,519,  0,379,  1, 88,  1,352,  1,352, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}