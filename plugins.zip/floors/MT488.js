main.floors.MT488=
{
    "floorId": "MT488",
    "title": "通天塔 488 ",
    "name": "通天塔488",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,377,  0,377,  1,  0,342,1338,1339,1338,  1, 87,  1],
    [  1,  0,1340,  0,  1, 21,  1,  1,  1,342,  1, 32,  1],
    [  1,  1,342,  1,  1, 21,  1, 30, 30, 31,  1, 32,  1],
    [  1,377,  0,377,  1, 21,  1, 30, 30, 31,  1, 32,  1],
    [  1,  0,1338,  0,  1,1327,  1,  1,  1,  1,  1,  0,  1],
    [  1,  1,342,  1,  1,342,  1,  1,  1,  1,  1,1327,  1],
    [  1,377,  0, 33,1332,  0,  0, 31, 31, 31,  0,  0,  1],
    [  1,  1,342,  1,  1,1332,  0,  1,  1,  1,  0,1332,  1],
    [  1,  0,1374,  0,  1,  1,343,  1,  1,  1,343,  1,  1],
    [  1,349,  0,349,344,  0,  0,  0,  1,  0,1334,  0,  1],
    [  1,  0,533,  0,345, 33, 88, 33,  1,348,348,348,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}