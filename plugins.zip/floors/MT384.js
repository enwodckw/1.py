main.floors.MT384=
{
    "floorId": "MT384",
    "title": "通天塔 384 ",
    "name": "黑暗深渊384",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT384_5_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT384_5_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT384_5_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT384_5_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "5,8": {
            "0": {
                "condition": "flag:door_MT384_5_8==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT384_5_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,  0,  0,  0,  0,  0,1150,  0,  0,  0,  0,  0,1150],
    [1150,  0,1217,  0,  0,  0,1150,  0,  0,  0,1217,  0,1150],
    [1150,  0,  0,  0,  0,  0,1150,  0,  0,  0,  0,  0,1150],
    [1150,  0,  0,  0,1150,1150,1150,1150,1150,  0,  0,  0,1150],
    [1150,  0,  0,  0,1150,1179,  0,1179,1150,  0,  0,  0,1150],
    [1150,1150,1150,1150,1150,  0, 88,  0,1150,1150,1150,1150,1150],
    [1150,1184,1216,1216,1150,1179,  0,1179,1150,  0,  0,  0,1150],
    [1150,342,1150,1150,1150, 85,1150,1150,1150,  0,  0,  0,1150],
    [1150,564,  0,  0,1176,  0,1150,  0,  0,  0,  0,  0,1150],
    [1150,  0,380,1150,1150,342,1150,  0,  0,  0,1217,  0,1150],
    [1150, 87,1150,1216,1216,1184,1150,  0,  0,  0,  0,  0,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}