main.floors.MT521=
{
    "floorId": "MT521",
    "title": "通天塔 521 ",
    "name": "通天塔521",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,359,359,  1,342,348,342,348,342, 31,1384, 87,  1],
    [  1, 22,359,  1,377,  1,  1,  1,  1,342,  1,350,  1],
    [  1,1388,349,  1,342,  1,  0,1380,  0,  0,1386,  0,  1],
    [  1,342,  1,  1,348,  1, 31,  1,  1,  1,  1,  1,  1],
    [  1,350,350,  1,342,  1, 21,  1,366,366,  1,349,  1],
    [  1,350,1388,  1,348,  1,1379,  1,366,1387,  1,379,  1],
    [  1,  1,342,  1,342,  1, 86,  1,  1,343,  1,1385,  1],
    [  1,1377,  0, 31,  0,1378,  0, 86, 21, 31, 86,  0,  1],
    [  1,  0,  1,  1,343,  1,  1,  1,343,  1,  1,1385,  1],
    [  1,  0,  1,1382,  0,1382,  1,1382,  0,1382,  1,379,  1],
    [  1, 88,  1,  0,1392,  0,  1,  0,1392,  0,  1,349,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}