main.floors.MT212=
{
    "floorId": "MT212",
    "title": "通天塔 212 ",
    "name": "通天塔212",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 5000000,
    "defaultGround": "grass",
    "bgm": "waiwei.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,3": [
            {
                "type": "openShop",
                "id": "shop2",
                "open": true
            }
        ]
    },
    "changeFloor": {
        "9,9": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "3,9": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT212_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT212_6_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,7": {
            "0": {
                "condition": "flag:door_MT212_6_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT212_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [141,141,141,141,141,141,141,141,141,141,141,141,141],
    [141,141,141,141,141,141,141,141,141,141,141,141,141],
    [141,141,141,141,141,141,141,141,141,141,141,141,141],
    [141,141,141,538,141,  7,131,  8,141,538,141,141,141],
    [141,141,141,533,141,141,343,141,141,533,141,141,141],
    [141,141,141,783,343,  0,380,  0,343,783,141,141,141],
    [141,141,141,533,141,380,  0,380,141,533,141,141,141],
    [141,141,141,538,141,141, 85,141,141,538,141,141,141],
    [353,141,141,141,141,779,  0,779,141,141,141,141,353],
    [343,351,343, 87,  0,  0,  0,  0,  0, 88,343,351,343],
    [141,141,141,141,342,141,639,141,342,141,141,141,141],
    [141,141,141, 31,348, 31,141, 31,348, 31,141,141,141],
    [141,141,141,141,141,141,141,141,141,141,141,141,141]
],
    "bgmap": [

],
    "fgmap": [

]
}