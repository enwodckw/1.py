main.floors.MT482=
{
    "floorId": "MT482",
    "title": "通天塔 482 ",
    "name": "通天塔482",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 32,  0, 32,  1,  0, 88,  0,  1, 32,  0, 32,  1],
    [  1,  0,378,  0,1341,  0,349,  0,1338,  0,378,  0,  1],
    [  1, 32,  0, 32,  1,  0,  0,  0,  1, 32,  0, 32,  1],
    [  1,  1,  1,  1,  1,343,  1,1341,  1,  1,  1,  1,  1],
    [  1,363, 33,1338,  0, 27, 27, 27,  0,342,1341, 33,  1],
    [  1,  1,343,  1,344,  1,342,  1,342,  1, 33, 33,  1],
    [  1, 33,1339,  1,377,  1,342,  1,1339,  1,  1,  1,  1],
    [  1,373,373,  1,377,  1,342,  1, 21, 21, 33,  0,  1],
    [  1,373,  1,  1,  1,  1,343,  1,  1,  1,  1,1327,  1],
    [  1,1339,342,1340,356,  1,343,  1,363,1340,342,  0,  1],
    [  1, 47,  1,356,356,  1,380,  1,363,363,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}