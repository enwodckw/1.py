main.floors.MT17=
{
    "floorId": "MT17",
    "title": "通天塔 17 ",
    "name": "通天塔17",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "5,4": [
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        5,
                        5
                    ]
                ],
                "floorId": "MT17"
            },
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "12,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "4,4": [
            {
                "type": "if",
                "condition": "(flag:17>=1)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            5
                        ],
                        "floorId": "MT17"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:17",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "6,4": [
            {
                "type": "if",
                "condition": "(flag:17>=1)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            5
                        ],
                        "floorId": "MT17"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:17",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,224,  0,220,  0,218,  0,216,  0,  1, 30,  1],
    [  1,225,  1,  1,  1,  1,  1,  1,  1, 30,  1,350,  1],
    [  1,  0,  1,379, 21,  0, 21,379,  1,  0,  1, 30,  1],
    [  1,226,  1,348,222,  0,222,348,  1,221,  1,221,  1],
    [  1,  0,  1,  1,  1,342,  1,  1,  1,342,  1,342,  1],
    [  1,227,  1,  0,217,  0,  0,217,342,  0,343,  0, 88],
    [  1,  0,  1,  0,  1,  1,  1,  0,  1,220,  1,219,  1],
    [  1,228,  1,219,  1,356,  1, 31,  1,  0,  1,  0,  1],
    [  1,381,344,  0,227,363,343,  0,  1, 28,  1, 27,  1],
    [  1,345,  1, 31,  1,  1,  1,215,  1,  0,  1,  0,  1],
    [  1,  0,219,  0,342,342,342,  0,  1,217,342,217,  1],
    [  1, 87,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}