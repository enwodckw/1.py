main.floors.ML26=
{
    "floorId": "ML26",
    "title": "通天塔 26 ",
    "name": "地下26",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": "ML28",
            "loc": [
                1,
                1
            ]
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  1,373,373,373,  1,373,373,373,  1,533,  1],
    [  1,  0,342,515,373,380,343,520,373,383,  1, 21,  1],
    [  1,  0,  1,373,373,373,  1,373,373,373,  1, 21,  1],
    [  1,512,  1,  1,  1,  1,  1,  1,  1,  1,  1, 21,  1],
    [  1,  0,  1,351,513,  0,513,351,  1,355,538,355,  1],
    [  1,351,  1,360,  1,  0,  1,367,  1,518,  0,518,  1],
    [  1,  0,  1,  1,  1,343,  1,  1,  1,  1,342,  1,  1],
    [  1, 27, 27, 27,387,  0,512,  0, 27, 27, 27,  0,  1],
    [  1,  1,  1,  1,  1,343,  1,  1,  1,  1,  1,512,  1],
    [  1, 21, 22, 21,518,  0,518, 21, 22, 21,344,  0,  1],
    [  1,383,383,383,  0,  1,  0,383,383,383,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}