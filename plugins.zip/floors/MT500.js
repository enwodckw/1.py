main.floors.MT500=
{
    "floorId": "MT500",
    "title": "通天塔 500 ",
    "name": "通天塔500",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,4": [
            {
                "type": "openDoor",
                "loc": [
                    4,
                    2
                ]
            },
            {
                "type": "openDoor",
                "loc": [
                    8,
                    2
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,262, 87,261,  4,  4,  4,  4,  4],
    [  4,348,  0,348, 85,  0,  0,  0, 85,348,  0,348,  4],
    [  4,  0,1223,  0,  4,345,  0,345,  4,  0,1223,  0,  4],
    [  4,348,  0,348,345,  0,1375,  0,345,348,  0,348,  4],
    [  4,  4,  4,  4,  4,345,  0,345,  4,  4,  4,  4,  4],
    [  1,350,344,349,  1,  1,344,  1,  1,349,344,350,  1],
    [  1,  1,  1,344,348,344,352,344,348,344,  1,  1,  1],
    [  1,348,  1,  1,  1,  1,536,  1,  1,  1,  1,348,  1],
    [  1,343,348,343, 33,343,1374,343, 33,343,348,343,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1, 33, 34,342, 34,342, 88,342, 34,342, 34, 33,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}