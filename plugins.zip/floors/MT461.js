main.floors.MT461=
{
    "floorId": "MT461",
    "title": "通天塔 461 ",
    "name": "通天塔461",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "5,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT461_8_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT461_8_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "8,4": {
            "0": {
                "condition": "flag:door_MT461_8_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT461_8_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1319, 32,359,  1, 87,  0,344,377,377, 33, 33,  1],
    [  1,342,  1,  1,  1,  1, 32,  1,  1,  1,  1,  1,  1],
    [  1,  0,344, 33,  0,  1,  0,1317,  1, 33,  1, 32,  1],
    [  1, 32,  1,379,1322,342,  0,1317, 85,377,  1, 27,  1],
    [  1, 30,  1, 33,  0,  1,1316,  1,  1,  1,  1, 27,  1],
    [  1,1318,  1,  1,  1,  1, 86,  1, 27,  0,1318,  0,  1],
    [  1,  0, 32, 30,  0,1316,  0,1316, 27, 27,  1, 27,  1],
    [  1,345,  1,  1,  1,  1, 32,  1,  1,  1,  1,345,  1],
    [  1,377,343,  0,1321,343,  0,343,1321,  0,343,377,  1],
    [  1,348,1319,342,  0, 86,  0, 86,  0,342,1319,348,  1],
    [  1,377,343,  0,1321,  1, 88,  1,1321,  0,343,377,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}