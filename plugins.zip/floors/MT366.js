main.floors.MT366=
{
    "floorId": "MT366",
    "title": "通天塔 366 ",
    "name": "黑暗深渊366",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT366_4_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT366_4_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,8": {
            "0": {
                "condition": "flag:door_MT366_4_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT366_4_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,  0,1160, 33, 33, 33, 88, 33, 33, 33,1160,  0,1150],
    [1150,356,1150,1150,1150,1150,342,1150,1150,1150,1150,356,1150],
    [1150,356,1150,388,349,1162,  0,1162,349,388,1150,356,1150],
    [1150,356,1150,1150,1150,1150,342,1150,1150,1150,1150,356,1150],
    [1150,  0,1150,  0,1163,  0, 30,  0,1163,349,1150,  0,1150],
    [1150,1161,1150,349,1150,342,1150,342,1150,389,1150,1161,1150],
    [1150,363,1150,1164,  0,1164,1150,349,1150,1150,1150,363,1150],
    [1150,363,1150,1150, 85,1150,1150,  0,1168,  0,1150,363,1150],
    [1150,363,1150,  0,  0,  0,1150,1150,342,1150,1150,363,1150],
    [1150,  0,1150,  0,902,  0,1150,1172,  0,1172,1150,1167,1150],
    [1150, 87,1150,  0,  0,  0,1150,639,1150,639,1150,340,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}