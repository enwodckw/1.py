main.floors.MT103=
{
    "floorId": "MT103",
    "title": "通天塔 103 ",
    "name": "通天塔103",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "2,1": [
            {
                "type": "openShop",
                "id": "shop1",
                "open": true
            }
        ]
    },
    "changeFloor": {
        "1,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  7,131,  8,  1,359,359,564,366,366,  1,349,  1],
    [  1, 30, 30, 30,  1,359,373,607,373,366,  1,348,  1],
    [  1,  1,344,  1,  1,  1,  1,342,  1,  1,  1,342,  1],
    [  1, 21, 30,610,  1,606,  1,  0,  1,606,  0,377,  1],
    [  1,342,  1, 86,342,  0, 86,617,342,  0,538,  0,  1],
    [  1, 88,  0,  0,  1,606,  1,  0,  1,606,  0,377,  1],
    [  1,342,  1,610,  1,361,  1,342,  1,  1,  1,608,  1],
    [  1, 21, 30,  0,  1,  1,  1,609,  0,609,  1,373,  1],
    [  1,343,  1, 86,  1,361,  1,536,  1,536,  1,534,  1],
    [  1,378,  1,610,  1,353,  1,569,  1,569,  1,373,  1],
    [  1, 87,342, 21,342,613,  1,536,344,536,  1,373,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}