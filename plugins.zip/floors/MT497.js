main.floors.MT497=
{
    "floorId": "MT497",
    "title": "通天塔 497 ",
    "name": "通天塔497",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,350,  4,  1,  1,  1,  1,  1,  1,  1,  4,350,  1],
    [  1,1216,  4,  1,377,1342, 87,1342,377,  1,  4,1222,  1],
    [  1,342,  4,  1,  1,  1, 32,  1,  1,  1,  4,343,  1],
    [  1,342,  4,  1,363,  1,  0,  1,356,  1,  4,343,  1],
    [  1,342,  4,  1,363,  1,1332,  1,356,  1,  4,343,  1],
    [  1,342,  4,  1,363,1342,  0,1342,356,  1,  4,343,  1],
    [  1,342,  4,  1,  1,  1, 32,  1,  1,  1,  4,343,  1],
    [  1,342,  4,  1,356,  1,  0,  1,363,  1,  4,343,  1],
    [  1,342,  4,  1,356,  1,1332,  1,363,  1,  4,343,  1],
    [  1,342,  4,  1,356,1342,  0,1342,363,  1,  4,343,  1],
    [  1,342,  4,  1,  1,  1, 86,  1,  1,  1,  4,343,  1],
    [  1, 32, 32, 32,1343, 86, 88, 86,1343, 32, 32, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}