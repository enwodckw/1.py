main.floors.MT101=
{
    "floorId": "MT101",
    "title": "通天塔101",
    "name": "通天塔101",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1200,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [
        "抵制不良游戏，拒绝盗版游戏。\n注意自我保护，谨防受骗上当。\n适度游戏益脑，沉迷游戏伤身。\n合理安排时间，享受健康生活。\n                     快乐的作者——最咸的咸鱼",
        {
            "type": "hide",
            "loc": [
                [
                    6,
                    4
                ]
            ],
            "floorId": "ML2"
        },
        {
            "type": "if",
            "condition": "(item:greenKey<1000)",
            "true": [
                {
                    "type": "setValue",
                    "name": "status:hp",
                    "operator": "+=",
                    "value": "888888888"
                },
                {
                    "type": "setValue",
                    "name": "status:atk",
                    "operator": "+=",
                    "value": "1000000"
                },
                {
                    "type": "setValue",
                    "name": "status:def",
                    "operator": "+=",
                    "value": "1000000"
                },
                {
                    "type": "setValue",
                    "name": "status:mdef",
                    "operator": "+=",
                    "value": "1000000"
                }
            ],
            "false": [
                {
                    "type": "setValue",
                    "name": "status:hp",
                    "value": "888888888"
                },
                {
                    "type": "setValue",
                    "name": "status:atk",
                    "value": "9000000"
                },
                {
                    "type": "setValue",
                    "name": "status:def",
                    "value": "9000000"
                },
                {
                    "type": "setValue",
                    "name": "status:mdef",
                    "value": "20000000"
                }
            ]
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,10": [
            "开启红门后不可返回之前楼层，请注意",
            {
                "type": "hide"
            }
        ],
        "8,12": [
            "咸绿计分:每把绿钥匙计分1千亿，破墙镐每把计分1百亿，所得总分乘以0.005得最后得分",
            "全绿计分:每把黄钥匙计分500亿，每把蓝钥匙计分二千亿，每把红钥匙计分八千亿，每把破墙镐计分一万亿，所得总分乘以0.005得最后得分"
        ]
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {
        "6,9": [
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        11
                    ]
                ],
                "floorId": "MT101"
            },
            {
                "type": "setValue",
                "name": "flag:__visited__",
                "value": "{}"
            },
            {
                "type": "function",
                "function": "function(){\ncore.visitFloor(\"MT101\")\n}"
            }
        ]
    },
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,348,  0,348,  4,  4,  4,  4,  4],
    [  4,570,  4,570,  4,  0, 87,  0,  4,570,  4,570,  4],
    [  4,534,  4,534,  4,348, 65,348,  4,534,  4,534,  4],
    [  4,345,  4,345,  4,  4,344,  4,  4,345,  4,345,  4],
    [  1, 27, 27, 27,  0, 32,  0, 32,  0, 28, 28, 28,  1],
    [  1,  1,  1,  1, 22,  4,  4,  4, 21,  1,  1,  1,  1],
    [  1,539,391,344, 22,  4,537,  4, 21,344,391,539,  1],
    [  1,  1,  1,  1, 22,  4,606,  4, 21,  1,  1,  1,  1],
    [  1, 28, 28, 28,  0, 33,  0, 33,  0, 27, 27, 27,  1],
    [  4,345,  4,345,  4,  4,344,  4,  4,345,  4,345,  4],
    [  4,534,  4,534,  4,348,  0,348,  4,534,  4,534,  4],
    [  4,570,  4,570,  4,  0, 88,  0,  4,570,  4,570,  4],
    [  4,  4,  4,  4,  4,348,  0,348,129,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}