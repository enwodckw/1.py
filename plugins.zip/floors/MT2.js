main.floors.MT2=
{
    "floorId": "MT2",
    "title": "通天塔 2 ",
    "name": "通天塔2",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT2_7_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT2_7_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,4": {
            "0": {
                "condition": "flag:door_MT2_7_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT2_7_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88, 22,  1, 29, 29, 22,  1, 30,  0, 34,207,  1],
    [  1,  0, 31,  1,205,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,342,  1,  1,342,  1,202,  1, 21,  0,  1, 34,  1],
    [  1, 32,  0,201,  0,342,  0, 85,  0, 22,  1, 22,  1],
    [  1, 27,  1,  1, 21,  1,202,  1, 21,  0,  1,  0,  1],
    [  1,343, 30,203,  0,  1,  1,  1,  1,  1,  1,204,  1],
    [  1,  0,  1,  1,201,  1,  0,203,  0,  1, 29,  0,  1],
    [  1,202,342, 31,  0,202,  0,342, 28,  1,205, 21,  1],
    [  1,  0,  1,343,  1,  1,206,  1, 31,  1,342,  1,  1],
    [  1, 28,  1, 31, 31,  1, 29,  1, 31,  1, 27,  0,  1],
    [  1,  0,  1, 32, 32,  1, 21,  1, 29,342,206, 21,  1],
    [  1, 87,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "shanmai.mp3"
}