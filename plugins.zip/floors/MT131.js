main.floors.MT131=
{
    "floorId": "MT131",
    "title": "通天塔 131 ",
    "name": "通天塔131",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [
        {
            "type": "setGlobalValue",
            "name": "greenGem",
            "value": 4
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,0": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1],
    [  1,348,  0,349,  1,348,  0,349,  1,348,  0,349,  1],
    [  1,  0,381,  0,  1,  0,381,  0,  1,  0,381,  0,  1],
    [  1, 21,  0, 21,  1, 21,  0, 21,  1, 21,  0, 21,  1],
    [  1,  1, 86,  1,  1,  1, 86,  1,  1,  1, 86,  1,  1],
    [  1,348,  0,349,  1,348,  0,349,  1,348,  0,349,  1],
    [  1,  0, 23,  0, 86,  0, 23,  0, 86,  0, 23,  0,  1],
    [  1, 22,  0,390,  1, 22,  0,390,  1, 22,  0,390,  1],
    [  1,  1, 86,  1,  1,  1, 86,  1,  1,  1, 86,  1,  1],
    [  1,348,  0,349,  1,348,  0,349,  1,348,  0,349,  1],
    [  1,  0,381,  0,  1,  0,381,  0,  1,  0,381,  0,  1],
    [  1, 21,  0, 21,  1, 21,  0, 21,  1, 21,  0, 21,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}