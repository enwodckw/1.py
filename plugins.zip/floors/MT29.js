main.floors.MT29=
{
    "floorId": "MT29",
    "title": "通天塔 29 ",
    "name": "通天塔29",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "12,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,234, 21, 30, 30, 21,  1, 21,  1, 21,  1, 21,  1],
    [  1,343,  1,  1,  1,  1,  1,382,  1,382,  1,382,  1],
    [  1, 21, 30, 30, 21,222,  1, 22,  1, 21,  1, 22,  1],
    [  1,  1,  1,  1,  1,343,  1,352,  1,352,  1,352,  1],
    [  1,223, 21, 30, 30, 21,  1,253,  1,253,  1,253,  1],
    [  1,343,  1,  1,  1,  1,  1,  0,349,  0,  0,  0, 88],
    [  1, 21,  0,244,  0, 30,  0,232,  0,  1,343,  1,  1],
    [  1,  1,  1,  1,244,  1,343,  1,342,  1, 21, 21,  1],
    [  1,378,  0,  1,  0,  1, 33,  1, 27,  1,  1, 21,  1],
    [  1, 21,348,  1,349,  1,378,  1,  0,342,  1,247,  1],
    [  1,348,  0,223,  0,223, 33,  1,232,  0, 33, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}