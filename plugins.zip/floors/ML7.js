main.floors.ML7=
{
    "floorId": "ML7",
    "title": "通天塔 7 ",
    "name": "地下7",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "12,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,538,  1,387,387,589,  0,589,387,387,  1,538,  1],
    [  1,391,  1,385,540,  1, 86,  1,540,384,  1,391,  1],
    [  1,590,  1,  1,  1,  1, 86,  1,  1,  1,  1,590,  1],
    [  1,  0,354,  0,587,  0,587,  0,587,  0,354,  0,  1],
    [  1,  1,  1,  1,  1,578,  1,342,  1,  1,  1,578,  1],
    [  1,360,360,360,  1,  0,380,352,  1,380,380,380,  1],
    [  1,  1,  1,367,  1,390,  1,  1,  1,  1,  1,342,  1],
    [  1,380,  1,367,  1,  0,  1,390,391,390,  1,342,  1],
    [  1,352,  1,591,  1,576,  1,352,588,352,  1,342,  1],
    [  1,585,  1,342,  1,342,  1,  1,342,  1,  1,342,  1],
    [  1, 87,  0,580, 59, 58,581, 58, 59,580,  0,  0, 88],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}