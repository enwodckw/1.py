main.floors.MT203=
{
    "floorId": "MT203",
    "title": "通天塔 203 ",
    "name": "通天塔203",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 5000000,
    "defaultGround": "grass",
    "bgm": "waiwei.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,10": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "2,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT203_4_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT203_4_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT203_8_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT203_8_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,9": {
            "0": {
                "condition": "flag:door_MT203_4_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT203_4_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,9": {
            "0": {
                "condition": "flag:door_MT203_8_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT203_8_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,148,148,148,148,148,148,148,148,148,148,148,142],
    [142,148,366,366,366,777,  0,777,359,359,359,148,142],
    [142,148,148,148,148,148,390,148,148,148,148,148,142],
    [142,148,365,365,365,344,  0,344,358,358,358,148,142],
    [142,148,148,148,148,148,390,148,148,148,148,148,142],
    [142,148, 87,  0,  0,772,  0,779,380,355,380,148,142],
    [142,148,148,148,148,148,774,148,148,148,148,148,142],
    [142,148,  0,364,148,772,  0,772,148,357,  0,148,142],
    [142,148,364,  0, 85,  0,  0,  0, 85,  0,357,148,142],
    [142,148,  0,364,148,772, 88,772,148,357,  0,148,142],
    [142,148,148,148,148,148,148,148,148,148,148,148,142],
    [142,142,142,142,142,142,142,142,142,142,142,142,142]
],
    "bgmap": [

],
    "fgmap": [

]
}