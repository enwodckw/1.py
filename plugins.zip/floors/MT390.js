main.floors.MT390=
{
    "floorId": "MT390",
    "title": "通天塔 390 ",
    "name": "黑暗深渊390",
    "width": 13,
    "height": 13,
    "canFlyTo": false,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": "MT389",
            "loc": [
                6,
                1
            ]
        },
        "11,11": {
            "floorId": "MT391",
            "loc": [
                11,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT390_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT390_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT390_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT390_6_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,10": {
            "0": {
                "condition": "flag:door_MT390_6_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT390_6_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,7": {
            "0": {
                "condition": "flag:door_MT390_6_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT390_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  0,1209,1209,1209,1205, 93,1205,1209,1209,1209,  0,  4],
    [  4,1206,  4,  4,  4,  4,  0,  4,  4,  4,  4,1206,  4],
    [  4,1212,  4,539,637,1199,  0,1199,637,539,  4,1212,  4],
    [  4,1212,  4,637,  4,  4,342,  4,  4,637,  4,1212,  4],
    [  4,1212,  4,  0,  4,  0,352,  0,  4,  0,  4,1212,  4],
    [  4,1212,  4,1205,  4,1197,  0,1197,  4,1205,  4,1212,  4],
    [  4,1198,  4,637,  4,  4, 85,  4,  4,637,  4,1203,  4],
    [  4,1222,  4,539,  4,  0,352,  0,  4,539,  4,1226,  4],
    [  4,1222,  4,539,  4,1195,  0,1195,  4,637,  4,1226,  4],
    [  4,1222,  4,539,  4,  4, 85,  4,  4,  4,  4,  4,  4],
    [  4,1222,  4,637,  4,352,1198,  0, 47,  0,1201, 94,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}