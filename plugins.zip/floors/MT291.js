main.floors.MT291=
{
    "floorId": "MT291",
    "title": "通天塔 291 ",
    "name": "通天塔291",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000,
    "defaultGround": "ground",
    "bgm": "yiji.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT291_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT291_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT291_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT291_6_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,4": {
            "0": {
                "condition": "flag:door_MT291_10_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT291_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        },
        "6,6": {
            "0": {
                "condition": "flag:door_MT291_6_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT291_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [155,155,155,155,155,155,155,155,  4,155,155,155,155],
    [155, 87,  0,952,  0,  0, 88,350,  4,537,  0,537,155],
    [155,965,155,155,155,951,  0,  0,969,  0,639,  0,155],
    [155,384,384,384,155,155,965,155,  4,537,  0,537,155],
    [155,155,155,965,155,964,  0,964,  4,  4, 85,  4,  4],
    [155,385,385,385,155,  0,350,  0,155,970,  0,970,155],
    [155,155,155,155,155,155, 85,155,155,155,343,155,155],
    [155,  0,378,378,378,  0,960,  0,378,378,378,  0,155],
    [155,961,155,155,155,155,155,155,155,155,155,155,155],
    [155,350,155,387,155,564,968, 22,155,564,966, 22,155],
    [155,539,155,387,155,638,155,638,155,638,155,638,155],
    [155,350,970,387,969, 22,155,564,967, 22,155,564,155],
    [155,155,155,155,155,155,155,155,155,155,155,155,155]
],
    "bgmap": [

],
    "fgmap": [

]
}