main.floors.MT63=
{
    "floorId": "MT63",
    "title": "通天塔 63 ",
    "name": "通天塔63",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 24,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,2": [
            {
                "type": "if",
                "condition": "(flag:63>=1)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ],
                        "floorId": "MT63"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            4
                        ],
                        "floorId": "MT63"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            4
                        ],
                        "floorId": "MT63"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            11
                        ],
                        "floorId": "MT63"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            11
                        ],
                        "floorId": "MT63"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:63",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,2": [
            {
                "type": "if",
                "condition": "(flag:63>=1)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ],
                        "floorId": "MT63"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            4
                        ],
                        "floorId": "MT63"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            4
                        ],
                        "floorId": "MT63"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            11
                        ],
                        "floorId": "MT63"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            11
                        ],
                        "floorId": "MT63"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:63",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,378,352,378,  0,  0,  0,  0,  0,343,  0, 87],
    [  1,279,  1,  1,  1,275,  0,275,  1,472,472,  0,  1],
    [  1,  0,  1,  1,  1,  1, 85,  1,  1,  1,  1,461,  1],
    [  1,352,  1, 29, 29, 85,  0, 85, 29, 29,  1,  0,  1],
    [  1,362,  1, 29, 29,  1,  0,  1, 29, 29,  1,  0,  1],
    [  1,  0,  1, 29, 29,  1,  0,  1, 29, 29,  1,464,  1],
    [  1,279,  1,377,377,  1,  0,  1,377,377,  1,  0,  1],
    [  1,  0,  1,  1,  1,  1,  0,  1,  1,  1,  1,  0,  1],
    [  1,352,  1,370,370,  1,  0,  1,370,370,  1,461,  1],
    [  1,383,  1,370,370,  1,  0,  1,370,370,  1,  0,  1],
    [  1, 47,  1,377,377, 85,  0, 85,377,377,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}