main.floors.MT470=
{
    "floorId": "MT470",
    "title": "通天塔 470 ",
    "name": "通天塔470",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1321,  0,370, 21,  0, 88,344, 32, 32, 32,380,  1],
    [  1,  0,  1,472,  1,  1,  1,  1,  1,  1,  1,1321,  1],
    [  1,  0,472,472,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,1321,  1,  1,  1,  1,  1,  1,  1,  1,  1,356,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1, 21,  1],
    [  1,350,  1,  1,  1,  1, 49,  1,  1,  1,  1, 32,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,1316,  1,  1,  1,  1,  1,  1,  1,  1,  1,1322,  1],
    [  1,1317,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,1316,  1,  1,  1,  1,  1,  1,  1,  1,  1,372,  1],
    [  1, 87,343, 32,372,356,  0,1323,  0, 32,372,372,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}