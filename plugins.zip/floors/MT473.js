main.floors.MT473=
{
    "floorId": "MT473",
    "title": "通天塔 473 ",
    "name": "通天塔473",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87, 32, 21,  1,372, 30,372,  1,380,344,380,  1],
    [  1,344,  1,343,  1,  1,  1,343,  1,1329,  0,1329,  1],
    [  1,377,  1,363,1321,  0,1321,363,  1,  1,343,  1,  1],
    [  1,1322,  1,  1,  1, 86,  1,  1,  1,1322,  0, 47,  1],
    [  1,  0, 32,  0,1321,  0,1321,  0, 32,  0,  1,  1,  1],
    [  1,  1,  1,  1,  1, 31,  1,  1,  1,  1,  1,377,  1],
    [  1, 30,1324, 30,  1, 21,  1,364,1329,364,  1,377,  1],
    [  1,  1,342,  1,  1, 31,  1,  1,342,  1,  1,344,  1],
    [  1, 30, 22,  0,1323,  0,1323, 21,  0,  0, 22,  0,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1,343,  1,  1,343,  1],
    [  1, 88,342, 32,342, 34,  1, 31, 30, 31,  1, 34,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}