main.floors.MT505=
{
    "floorId": "MT505",
    "title": "通天塔 505 ",
    "name": "通天塔505",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,350,  1,350,  1,353,  1,353,  1,351,  1,351,  1],
    [  1,342,  1,342,  1,344,  1,344,  1,343,  1,343,  1],
    [  1,349,  1,349,  1,352,  1,352,  1,350,  1,350,  1],
    [  1,342,  1,342,  1,344,  1,344,  1,343,  1,343,  1],
    [  1,349,  1,349,  1,351,  1,351,  1,350,  1,350,  1],
    [  1,342,  1,342,  1,344,  1,344,  1,343,  1,343,  1],
    [  1,377,  1,377,  1,378,  1,378,  1,377,  1,377,  1],
    [  1,342,  1,342,  1,344,  1,344,  1,343,  1,343,  1],
    [  1, 30,  1, 30,  1,378,  1,378,  1,377,  1,377,  1],
    [  1,342,  1,342,  1,344,  1,344,  1,343,  1,343,  1],
    [  1, 88,  0, 21,363,  0,1378,  0,356, 21,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}