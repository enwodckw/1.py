main.floors.MT455=
{
    "floorId": "MT455",
    "title": "通天塔 455 ",
    "name": "黑暗深渊深处455",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 700000000000,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [
        "请清理所有怪物后在进入下一层,进入下一层后无法返回之前楼层"
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": "MN12",
            "loc": [
                6,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT455_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT455_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT455_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT455_6_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,3": {
            "0": {
                "condition": "flag:door_MT455_6_3==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT455_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,  4, 85, 89, 85,  4,1150,1150,1150,1150],
    [1150,564,1150,564,  4,571,1313,571,  4,1150,1150,1150,1150],
    [1150,564,1150,564,  4,1226,  0,1226,  4,564,564,564,1150],
    [1150,342,1150,342,  4,  4, 85,  4,  4,1150,1150,343,1150],
    [1150,564,1150,564,  4,1312,  0,1312,  4,564,564,564,1150],
    [1150,342,1150,342,  4,  0,571,  0,  4,343,1150,1150,1150],
    [1150,564,1150,564,  4,1312,  0,1312,  4,564,564,564,1150],
    [1150,342,1150,342,  4,  4,344,  4,  4,1150,1150,343,1150],
    [1150,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,1150],
    [1150,  0,1150,1311,  4,  4,1304,  4,  4,1310,1150,1311,1150],
    [1150,  0,1150,1223,  4,1224,  0,1224,  4,1223,1150,1223,1150],
    [1150, 88,1150,569,  4,  0,1224,  0,  4,569,1150,569,1150],
    [1150,1150,1150,1150,  4,  4,  4,  4,  4,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}