main.floors.MT56=
{
    "floorId": "MT56",
    "title": "通天塔 56 ",
    "name": "通天塔56",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 24,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT56_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT56_10_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,6": {
            "0": {
                "condition": "flag:door_MT56_10_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT56_10_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,350,349,350,344,  0,  0,460, 30,353, 21, 87,  1],
    [  1,  1,  1,  1,  1,351,  1,  1,  1,  1,  4,345,  4],
    [  1, 22,349, 22,344, 22,  1,360,360,360,  4,350,  4],
    [  1,  1,  1,  1,  1,379,  1,  0,  1,  1,  4,380,  4],
    [  1, 21, 21, 21,343,  0,  1,277,  1,275,  4,  4,  4],
    [  1,  1,  1,  1,  1,460,342,  0,342,  0, 85,391,  4],
    [  1, 33,348, 33,342,  0,  1,277,  1,275,  4,  4,  4],
    [  1,  1,  1,  1,  1,379,  1,  0,  1,  1,  4,380,  4],
    [  1,348,349,348,343, 22,  1,367,367,367,  4,350,  4],
    [  1,  1,  1,  1,  1,351,  1,  1,  1,  1,  4,345,  4],
    [  1, 33,348, 33,342,  0,  0,460, 30,353, 21, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}