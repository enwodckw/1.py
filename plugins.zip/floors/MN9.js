main.floors.MN9=
{
    "floorId": "MN9",
    "title": "通天塔 M9 ",
    "name": "黑暗深渊M9",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000000000,
    "defaultGround": "ground",
    "bgm": "boss.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "4,8": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,1225,1225,571,1225,1225,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4, 86,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4, 88,  0,1239,343,570,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,571,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,571,  4, 23,  4,571,  4,  4,  4,  4],
    [  4,  4,  4,  4,571,344, 87,344,571,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}