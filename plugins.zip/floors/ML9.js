main.floors.ML9=
{
    "floorId": "ML9",
    "title": "通天塔 9 ",
    "name": "地下9",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,11": {
            "floorId": "MM3",
            "loc": [
                1,
                11
            ]
        },
        "0,6": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,579,369,  1,350,350,350,  1,350,350,350,  1],
    [  1, 59,  1,362,  1,  1,342,  1,  1,  1,342,  1,  1],
    [  1,  0,342,350,  1,390,  0,581,390, 21,390,  0,  1],
    [  1,580,  1,350,580,  0,  1,  1,  1,  1,  1,342,  1],
    [  1,  0,  1,  1,  1, 21,342,580,352,  1,352,582,  1],
    [ 88,348,  0,579,  0,390,  1,352,380,  1,380,352,  1],
    [  1,342,  1,  1,580,  1,  1,  1,  1,  1,  1,  1,  1],
    [587,  0,587,  1,  0,  0,579,  0,  1,379,  1,379,  1],
    [  1,380,  1,  1,342,  1,  1,349,  1,379,  1,379,  1],
    [  1,  0,  1, 58,582, 59,  1, 21,  1,379,  1,379,  1],
    [  1, 89,  1,381,381,381,  1,  0,581,354,581,354,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}