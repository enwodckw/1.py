main.floors.ML17=
{
    "floorId": "ML17",
    "title": "通天塔 17 ",
    "name": "地下17",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 33,342,526, 21,352,  1,352, 21,526,342, 87,  1],
    [  1,  0,  1,391, 21,352,  1,352, 21,391,  1,  0,  1],
    [  1,524,  1,  1,  1,  1,  1,  1,  1,  1,  1,523,  1],
    [  1,  0,521,  0,  0, 27, 27, 27,  0,521,  0, 33,  1],
    [  1,343,  1,  1,519,  1,343,  1,528,  1,521,  0,  1],
    [  1,  0,520,  0, 33,  1,353,353,353,  1,342,  1,  1],
    [  1, 33,  1,  1,  1,  1,  1,  1,  1,  1,524,343,  1],
    [  1,  0,519,  0,342,528, 23,  0,  1,525,  0,525,  1],
    [  1,  0,  1, 33,  1,355,  0,387,  1,388,  1,389,  1],
    [  1,343,  1, 33,  1,  1,  1,  1,  1, 33,  1, 33,  1],
    [  1, 88,  0,520,  1,387, 47,355,528,388,  1,389,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}