main.floors.MT7=
{
    "floorId": "MT7",
    "title": "通天塔 7 ",
    "name": "通天塔7",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "12,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  4, 32, 32, 32,  4,  1,  1],
    [  1, 31, 34,  1, 34, 31,  4, 22, 23, 22,  4,  0, 88],
    [  1,342,  1,  1,  1,342,  4,  4,345,  4,  4,  0,  1],
    [  1,  0,203,  0, 86,  0,203,  0,  0,  0,202,  0,  1],
    [  1,342,  1,205,  1,  1,343,  1,  1,202,  1,209,  1],
    [  1,  0, 31,  0,  1,  0,211,  0,  1,  0,342,370,  1],
    [  1,203,  1,  1,  1, 34,  0, 27,  1, 29,  1, 27,  1],
    [  1,  0, 29,  0,  1,  1,342,  1,  1, 29,  1,  1,  1],
    [  1,205,  1,342,  1, 27,207, 34,  1,  0,342,206,  1],
    [  1,  0, 31,  0,  1,  1,342,  1,  1,210,  1, 21,  1],
    [  1,  1,  1,204,  1,  0,212,  0,  1, 21,  1,370,  1],
    [  1, 87, 21,  0,  1, 28,  0, 28,  1, 30,  1, 27,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "shanmai.mp3"
}