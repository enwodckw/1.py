main.floors.MT35=
{
    "floorId": "MT35",
    "title": "通天塔 35 ",
    "name": "通天塔35",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT35_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT35_4_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,10": {
            "0": {
                "condition": "flag:door_MT35_4_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT35_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,344,364,381,415,342,348,  1, 30, 30, 30,  1],
    [  1, 28,  1,364,357,357,  1,  0,344, 30, 30, 30,  1],
    [  1, 21,  1,  1,  1,  1,  1,253,  1,  1,  1,  1,  1],
    [  1,407, 86,  0, 28, 21, 27,  0,  1,364,  1,364,  1],
    [  1,  1,  1,405,  1,342,  1,405,  1, 34,  1, 34,  1],
    [  1,359,  1,  0, 86,348, 86,  0,  1,253,  0,253,  1],
    [  1,255,  1,342,  1,406,  1,343,  1,  1,255,  1,  1],
    [  1, 21, 86,  0,  0,  0,407,  0,352, 86,  0,407,  1],
    [  1,343,  1,416,  0,416,  1,343,  1,  1,  1,  0,  1],
    [  1,342,  1,  1, 85,  1,  1,342,  1, 30,  1,  0,  1],
    [  1, 34, 34, 34,383, 34, 34, 34,  1, 30,248, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}