main.floors.MT372=
{
    "floorId": "MT372",
    "title": "通天塔 372 ",
    "name": "黑暗深渊372",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT372_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT372_2_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "2,4": {
            "0": {
                "condition": "flag:door_MT372_2_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT372_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 87,  0, 21,1150,352,  0,533,1150,354, 47,535,1150],
    [1150,1221,  0,  0,342,1169,352,  0,342,1171,  0,535,1150],
    [1150,  0,1170,  0,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,1150, 85,1150,1150,387,1150,387,1150,387,1150,387,1150],
    [1150,1163,  0,1163,1150,1164,1150,1165,1150,1166,1150,1167,1150],
    [1150,  0,358,  0, 86,  0, 86,  0, 86,  0, 86,  0,1150],
    [1150, 21,  0, 21,1150,1164,1150,1165,1150,1166,1150,1167,1150],
    [1150,1150,342,1150,1150,387,1150,387,1150,387,1150,387,1150],
    [1150,1172,  0,1173,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 21,343, 21,342,1162,365,  0,342,1163,  0,  0,1150],
    [1150,349,342,349,1150,365,  0,365,1150,  0,  0, 88,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}