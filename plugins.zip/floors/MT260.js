main.floors.MT260=
{
    "floorId": "MT260",
    "title": "通天塔 260 ",
    "name": "通天塔260",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 100000000,
    "defaultGround": "T836",
    "bgm": "q.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "2,9": [
            {
                "type": "if",
                "condition": "(flag:260>=5)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            5
                        ],
                        "floorId": "MT260"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:260",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "4,9": [
            {
                "type": "if",
                "condition": "(flag:260>=5)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            5
                        ],
                        "floorId": "MT260"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:260",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "8,9": [
            {
                "type": "if",
                "condition": "(flag:260>=5)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            5
                        ],
                        "floorId": "MT260"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:260",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "10,9": [
            {
                "type": "if",
                "condition": "(flag:260>=5)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            5
                        ],
                        "floorId": "MT260"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:260",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "3,10": [
            {
                "type": "if",
                "condition": "(flag:260>=5)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            5
                        ],
                        "floorId": "MT260"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:260",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "9,10": [
            {
                "type": "if",
                "condition": "(flag:260>=5)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            5
                        ],
                        "floorId": "MT260"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:260",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "6,2": [
            {
                "type": "openDoor",
                "loc": [
                    5,
                    4
                ]
            },
            {
                "type": "openDoor",
                "loc": [
                    7,
                    4
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [879,879,879,879,879,879,879,879,879,879,879,879,879],
    [879, 30, 30,564,879,568, 87,568,879,564, 30, 30,879],
    [879,879,879, 28,879,  0,924,  0,879, 27,879,879,879],
    [149,571,879, 28,879,879,344,879,879, 27,879,571,149],
    [149,344,879, 28, 28, 85,915, 85, 27, 27,879,344,149],
    [149,355,879,879,879,879, 85,879,879,879,879,355,149],
    [149,353,343,348,350,342,  0,342,350,348,343,353,149],
    [149,879,879,879,879,879,  0,879,879,879,879,879,149],
    [149,879,352,916,352,879,  0,879,352,916,352,879,149],
    [149,879,  0,  0,  0,879,  0,879,  0,  0,  0,879,149],
    [149,879,879,342,879,879,  0,879,879,342,879,879,149],
    [149,378,378,378,882, 86, 88, 86,882,378,378,378,149],
    [149,149,149,149,149,149,149,149,149,149,149,149,149]
],
    "bgmap": [

],
    "fgmap": [

]
}