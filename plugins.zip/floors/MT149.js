main.floors.MT149=
{
    "floorId": "MT149",
    "title": "通天塔 149 ",
    "name": "通天塔149",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150000,
    "defaultGround": "grass",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "7,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT149_8_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT149_8_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT149_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT149_4_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "8,2": {
            "0": {
                "condition": "flag:door_MT149_8_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT149_8_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "4,2": {
            "0": {
                "condition": "flag:door_MT149_4_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT149_4_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20, 21,  0,654, 20, 22,  0,680, 20, 47,  0, 47, 20],
    [ 20,  0,  0,  0, 85,  0,  0,  0, 85,  0,638,  0, 20],
    [ 20, 21,  0,654, 20, 22,  0,680, 20, 23,  0, 23, 20],
    [ 20,386, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20,386, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20,386, 20,367,569,360, 20,383, 20,353,693, 21, 20],
    [ 20,  0, 20,367, 22,360, 20,353, 20, 20, 20, 21, 20],
    [ 20,695, 20,367,654,360, 20,691,342, 21, 20, 21, 20],
    [ 20,342, 20, 20,342, 20, 20, 20, 20,348, 20,683, 20],
    [ 20,  0,342, 21,  0,342,  0, 21, 20,684, 20,342, 20],
    [ 20, 87,693,  0,348,689,348,  0,683,  0,  0, 88, 20],
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20]
],
    "bgmap": [
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0]
],
    "fgmap": [

]
}