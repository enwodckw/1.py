main.floors.MT240=
{
    "floorId": "MT240",
    "title": "通天塔 240 ",
    "name": "通天塔240",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000,
    "defaultGround": "ski",
    "bgm": "q.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,5": [
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        6,
                        11
                    ]
                ],
                "floorId": "MT240"
            },
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,5": [
            {
                "type": "if",
                "condition": "(flag:240>=1)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "E878",
                        "loc": [
                            [
                                6,
                                2
                            ]
                        ],
                        "floorId": "MT240"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:240",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,5": [
            {
                "type": "if",
                "condition": "(flag:240>=1)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "E878",
                        "loc": [
                            [
                                6,
                                2
                            ]
                        ],
                        "floorId": "MT240"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:240",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [788,788,788,788,788,788,788,788,788,788,788,788,788],
    [788,788,788,  0,  0,  0,  0,  0,  0,  0,788,788,788],
    [788,788,788,  0,  0,  0,  0,  0,  0,  0,788,788,788],
    [788,788,788,  0,  0,  0,  0,  0,  0,  0,788,788,788],
    [788,788,788,788,262,  0,  0,  0,262,788,788,788,788],
    [788,788,788,788,788,835,  0,835,788,788,788,788,788],
    [788,788,788,788,788,788,571,788,788,788,788,788,788],
    [788,788,788,788,788,788,639,788,788,788,788,788,788],
    [788,788,788,788,788,788,571,788,788,788,788,788,788],
    [788,788,788,788,788,788,344,788,788,788,788,788,788],
    [788,  0,  0,788,788,788,344,788,788,788,  0,  0,788],
    [788, 87,  0, 85,  0,384,  0,385,  0,566,  0, 88,788],
    [788,788,788,788,788,788,788,788,788,788,788,788,788]
],
    "bgmap": [

],
    "fgmap": [

]
}