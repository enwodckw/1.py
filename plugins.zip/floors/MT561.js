main.floors.MT561=
{
    "floorId": "MT561",
    "title": "通天塔 561 ",
    "name": "通天塔561",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0,344, 30, 30,  1,359,  1,1219,  1,1220,  1],
    [  1,  0,  0,  1, 30, 30,  1,359,  1,637,  1,637,  1],
    [  1,  1,1420,  1,  1,  1,  1,359,  1,1219,  1,1220,  1],
    [  1,353,  0,  0,343,1427,359,359,  1,571,1434,571,  1],
    [  1,342,  1,1420,  1,  1,  1,  1,  1,  1,343,  1,  1],
    [  1,  0,353,  0,1426,  0,564,  0,1427,  0,353,  0,  1],
    [  1,1426,  1,  0,  1,1420,  1,1420,  1,  1,  1,1428,  1],
    [  1,571,  1, 21,  1,1226,  1,1226,  1,637,  1,351,  1],
    [  1,571,  1,  0,  1,571,  1,571,  1,351,  1,351,  1],
    [  1,  1,  1,1426,  1,  1,  1,  1,  1,1428,  1,351,  1],
    [  1, 87,353,  0,343,1427,379,379,379,379,344,637,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}