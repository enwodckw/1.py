main.floors.MT87=
{
    "floorId": "MT87",
    "title": "通天塔 87 ",
    "name": "通天塔87",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,3": [
            "请注意死亡之眼",
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,2": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,359,380, 21,  1,537,  0,537,  1, 21,380,366,  1],
    [  1,359, 21,550,342,  0, 88,  0,342,550, 21,366,  1],
    [  1,359,380, 21,  1,387,  0,387,  1, 21,380,366,  1],
    [  1,  1,  1,  1,  1,  1,540,  1,  1,  1,  1,  1,  1],
    [  1,348, 30,348, 86,  0, 30,  0,342,546,  0,547,  1],
    [  1,343,  1,545,  1,342,  1,342,  1,372,  1,379,  1],
    [  1,348, 30,348,  1,547,  1,548,  1,379,  1,372,  1],
    [  1,545,  1,  1,  1, 33,  1, 21,  1,  1,  1,  1,  1],
    [  1,  0,  1,  0, 33,379,  1, 21,342,551, 30, 30,  1],
    [  1,564,  1,549,  1,  1,  1,343,  1,  1, 30, 30,  1],
    [  1, 87,  1,379, 21,555, 33,379, 33,  1, 30, 30,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}