main.floors.MT541=
{
    "floorId": "MT541",
    "title": "通天塔 541 ",
    "name": "通天塔541",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT541_7_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT541_7_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,3": {
            "0": {
                "condition": "flag:door_MT541_7_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT541_7_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4, 87, 86, 86, 86, 86,  0,  0,  0,  4,  4,  4,  4],
    [  4,  0,  4,  4,  4,  4,1420,  0,1420,  4,  4,  4,  4],
    [  4,564,  4,  4,  4,  4,  4, 85,  4,  4,  4,  4,  4],
    [  4,  0,  4,1219,1219,1219,  4,  0,  4,1219,1219,1219,  4],
    [  4,564,  4,1219,1219, 23, 86,  0, 86, 23,1219,1219,  4],
    [  4,  0,  4,  4,  4,  4,  4,  0,  4,  4,  4,  4,  4],
    [  4,378,  4,1220,1220,1220,  4,  0,  4,1220,1220,1220,  4],
    [  4,  0,  4,1220,1220, 23, 86,  0, 86, 23,1220,1220,  4],
    [  4,378,  4,  4,  4,  4,  4,  0,  4,  4,  4,  4,  4],
    [  4,  0,  4,1222,1222,1222,  4,  0,  4,1222,1222,1222,  4],
    [  4, 88,  4,1222,1222, 23, 86,  0, 86, 23,1222,1222,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}