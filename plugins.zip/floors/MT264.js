main.floors.MT264=
{
    "floorId": "MT264",
    "title": "通天塔 264 ",
    "name": "通天塔264",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000,
    "defaultGround": "ground",
    "bgm": "yiji.mp3",
    "firstArrive": [
        "\t[hero]好久没碰到器灵了,到底发生了什么,怪物越来越强大,还要不要继续和塔灵干下去呢？"
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT264_7_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT264_7_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT264_7_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT264_7_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,3": {
            "0": {
                "condition": "flag:door_MT264_7_3==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT264_7_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [154,154,154,154,154,154,349,  0,349,154,154,154,154],
    [154, 88,154,154,154,154,  0,906,  0,154,154,154,154],
    [154, 30,154,348,154,154,349,  0,349,154,154,348,154],
    [154, 30,154,349,154,154,  4, 85,  4,154,154,349,154],
    [154, 30,154,343,154,154,935,  0,935,154,154,343,154],
    [154,  0,154,348,154,154,  0,  0,  0,154,154,348,154],
    [154,916,154,348,154,154,935,  0,935,154,154,348,154],
    [154,  0,154,342,154,154,  4,344,  4,154,154,342,154],
    [154, 30,343,  0,  0,  0,  0,  0,  0,  0,391,  0,915],
    [154, 30,  4,345,  4,345,  4,344,  4,344,  4,343,  4],
    [154, 30,  4,381,  4,381,  4, 22,  4, 22,  4, 21,  4],
    [154, 87,  4,381,  4,381,  4, 22,  4, 22,  4, 21,  4],
    [154,154,  4,381,  4,381,  4, 22,  4, 21,  4, 21,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}