main.floors.MT129=
{
    "floorId": "MT129",
    "title": "通天塔 129 ",
    "name": "通天塔129",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,0": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1],
    [  1,  0,653,360,381,  1,  0,643,360,568,  1,650,  1],
    [  1,568,  1,  1,  1,  1,342,  1,  1,  1,  1,381,  1],
    [  1,602,  1, 27, 27,  0,646,  0,643,  0,342,653,  1],
    [  1,649,  1,343,  1,644,  1,343,  1,367,  1,  1,  1],
    [  1,  0, 86,642, 28, 28,  1,342,  1,602,  1,360,  1],
    [  1,  1,  1,342,  1,  1,  1,650, 86,643,343,653,  1],
    [  1,650,  1,  0, 27, 27,  1,  1,  1,342,  1,381,  1],
    [  1,602,  1,644,  1,343,  1,567,  1,358,  1,  1,  1],
    [  1,643,342,  0, 28, 28,343,568,  1,568,358,  0,  1],
    [  1,  1,  1,342,  1,  1,  1,  1,  1,  1,  1,653,  1],
    [  1,358,568,644,  0,358,642,  1,367,367,367,571,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}