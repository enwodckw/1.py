main.floors.MT137=
{
    "floorId": "MT137",
    "title": "通天塔 137 ",
    "name": "通天塔137",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": "MT136",
            "loc": [
                1,
                11
            ]
        },
        "11,11": {
            "floorId": "MT136",
            "loc": [
                11,
                11
            ]
        },
        "3,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  0,675,  0,361,567,368,  0,676,  0,361,567,  4],
    [  4,361,  4,  4,  4,  4,  4,  4,  4,  4,  4,368,  4],
    [  4,567,  4,384,  1,391,  1,349,349,349,  4,  0,  4],
    [  4,368,  4,384,  1,540,  1,  1,  1, 21,  4,677,  4],
    [  4,  0,  4,385,  1,672,  0,672,  1, 21,  4,537,  4],
    [  4,674,  4,385,  1,  1,342,  1,  1,664,  4,537,  4],
    [  4,  0,  4,670,342,  0,664,  0, 22,  0,  4,445,  4],
    [  4,382,  4,349,  1,  1,342,  1,  1,  1,  4,345,  4],
    [  4,  0,  4,349,  1,  0,375,  0,375,  0,  4,345,  4],
    [  4,672,  4,  1,  1,663,  1,663,  1,663,  4,345,  4],
    [  4, 88,  4, 87,378,  0,343,378,472,  0,  0, 88,  4],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}