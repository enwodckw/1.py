main.floors.MT466=
{
    "floorId": "MT466",
    "title": "通天塔 466 ",
    "name": "通天塔466",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT466_10_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT466_10_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,9": {
            "0": {
                "condition": "flag:door_MT466_10_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT466_10_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,1316,  1],
    [  1,  1,  1,  1,  1,357,1322,357,  1,1317,342,  0,  1],
    [  1,  1,  1,  1,  1,  1,342,  1,  1,  0,  1,1319,  1],
    [  1,  1,  1,  1,  1, 32,  0,1318,  0, 32,  1, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,1316,  1,  1, 32,  1],
    [  1,  1,  1,  1,  1,  0,1322,342,  0,1318,  1,  1,  1],
    [  1,  1,  1,  1,  1,364,364,  1,  0,1318, 85,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1, 86,  1, 27, 28,  1],
    [  1,  1,  1,  1,  1, 30, 87,  0,1317,  1, 27, 28,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}