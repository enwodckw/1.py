main.floors.MT120=
{
    "floorId": "MT120",
    "title": "通天塔 120 ",
    "name": "通天塔120",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [
        "左上角去往地下30层，只有一次机会",
        {
            "type": "hide",
            "loc": [
                [
                    1,
                    11
                ]
            ],
            "floorId": "ML30"
        },
        {
            "type": "hide",
            "loc": [
                [
                    1,
                    1
                ]
            ],
            "floorId": "ML30"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,1": {
            "floorId": "ML30",
            "loc": [
                12,
                1
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 89,  1,381,646,381,  1,650,348,378,348, 87,  1],
    [  1,374,  1,  1,342,  1,  1,343,  1,  1,  1,640,  1],
    [  1,569,  1,378,641,378,  1,  0,348, 21,348,  0,  1],
    [  1,648,  1,  1,342,  1,  1,342,  1,  1,  1,609,  1],
    [  1,  0, 21,360,  0,647,  0,647,  0,360, 21,  0,  1],
    [  1,342,  1,  1,  1,  1,342,  1,  1,  1,  1,343,  1],
    [  1,641,348, 21,348,  1,  0,342,640,  1,374,642,  1],
    [  1,  1,  1,  1,342,  1,569,  1, 21,  1,381,374,  1],
    [  1,380, 21,642,  0,  1, 22,  1, 21,  1, 86,  1,  1],
    [  1,343,  1,  1,342,  1,  0,343,650,  1,642,374,  1],
    [  1,378,374,378,641,  1, 88,  1,379,  1,374,381,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}