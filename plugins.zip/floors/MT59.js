main.floors.MT59=
{
    "floorId": "MT59",
    "title": "通天塔 59 ",
    "name": "通天塔59",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 24,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "4,9": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,350,  1,350,364,  1,  0,470,348,348,348,387,  1],
    [  1,364,  1,364,467,342, 21,  1,  1,  1,  1,  1,  1],
    [  1,465,  1,  1,  1,  1,342,  1,382,  0,352, 21,  1],
    [  1,  0,356,350,  1,371,371,  1,343,  1,  1,  0,  1],
    [  1,356,  1,  1,  1, 21,  1,  1,380,371,  1,360,  1],
    [  1,467,  1,465, 21, 22,  1,371,371,371,  1,470,  1],
    [  1,342,  1,342,  1,  1,  1,464,  1,343,  1,342,  1],
    [  1,461, 29,  0,464,  0,348,  0,462,  0,348,  0,  1],
    [  1,  0,  1,342, 87,343,  1,460,  1,342,  1,468,  1],
    [  1, 86,  1,  1,344,472,  1,  0,  1,342,  1,380,  1],
    [  1, 88,  0,348,  0,460,  0, 21,472,371,371,371,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}