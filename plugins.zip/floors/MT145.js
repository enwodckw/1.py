main.floors.MT145=
{
    "floorId": "MT145",
    "title": "通天塔 145 ",
    "name": "通天塔145",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "12,9": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT145_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT145_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT145_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT145_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT145_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT145_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT145_6_11",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,2": {
            "0": {
                "condition": "flag:door_MT145_6_2==6",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT145_6_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,11": {
            "0": {
                "condition": "flag:door_MT145_6_11==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT145_6_11",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,602,535,535,535, 86,671, 86,535,535,535,603,  4],
    [  4,  4,  4,  4,  4,  4, 85,  4,  4,  4,  4,  4,  4],
    [  4,536,  4,387,  0,659,  0,659,  0,387,  4,536,  4],
    [  4,353,  4,659,  0,567,  0,567,  0,659,  4,353,  4],
    [  4,674,  4,387,  0,659,  0,659,  0,387,  4,674,  4],
    [  4,538,  4,  4,  4,  4,344,  4,  4,  4,  4,538,  4],
    [  4,676,539,675,355, 86,677, 86,355,675,539,676,  4],
    [  4,  4,  4,  4,  4,  4,672,  4,  4,  4,  4,  4,  4],
    [344,379,379,379,677, 86,  0,350,350,350,677,  0, 88],
    [ 21,  4,345,  4,343,  4,672,  4,  4,  4,  4,342,  4],
    [566,  4, 23,  4, 21,  4, 85,  4,568,536,568,680,  4],
    [ 22,  4,535,  4,569,  4, 87,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}