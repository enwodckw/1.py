main.floors.MT320=
{
    "floorId": "MT320",
    "title": "通天塔 320 ",
    "name": "沼泽林320",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1500000000,
    "defaultGround": "grass",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "9,9": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,3": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,6": [
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        4
                    ]
                ],
                "floorId": "MT320"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        5
                    ]
                ],
                "floorId": "MT320"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        6
                    ]
                ],
                "floorId": "MT320"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        4
                    ]
                ],
                "floorId": "MT320"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        5
                    ]
                ],
                "floorId": "MT320"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        4
                    ]
                ],
                "floorId": "MT320"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        5
                    ]
                ],
                "floorId": "MT320"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        6
                    ]
                ],
                "floorId": "MT320"
            },
            {
                "type": "openDoor",
                "loc": [
                    4,
                    6
                ],
                "floorId": "MT320"
            },
            {
                "type": "openDoor",
                "loc": [
                    8,
                    6
                ],
                "floorId": "MT320"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142, 87,142,142,142,142,142,142],
    [142,142,142,639,142,1062,1067,1065,142,639,142,142,142],
    [142,142,142,639,142,1061,1066,1064,142,639,142,142,142],
    [142,142,142,639, 85,1060,1059,1063, 85,639,142,142,142],
    [142,142,142,142,142,142,  0,142,142,142,142,142,142],
    [142,142,142,142,142,142,  0,142,142,142,142,142,142],
    [142,142,142,639,639,345,  0,  0,  0, 88,142,142,142],
    [142,142,142,142,142,142,142,142,344,142,142,142,142],
    [142,142,142,142,142,142,142,142,344,142,142,142,142],
    [142,142,142,447,344,344,344,344,344,142,142,142,142]
],
    "bgmap": [

],
    "fgmap": [

]
}