main.floors.MT246=
{
    "floorId": "MT246",
    "title": "通天塔 246 ",
    "name": "通天塔246",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 100000000,
    "defaultGround": "T836",
    "bgm": "q.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "10,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT246_7_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT246_7_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,9": {
            "0": {
                "condition": "flag:door_MT246_7_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT246_7_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [150,150,150,150,150,150,150,150,150,150,150,150,150],
    [150,150,150,150,150,150,150,150,150,150,150,150,150],
    [150,150,150,150,150,150,150,150,150,150,150,150,150],
    [150,150,150,150,150,150,150,150,150,150,150,150,150],
    [879,879,879,879,  0,889,348,348,348,149,379,150,150],
    [380,353,380,345,  0,149,149,149,149,149,149,150,150],
    [879,879,879,879,889,149,348,  0,348,149, 21,150,150],
    [380,353,380,345,  0,149,  0,533,  0,149,379,150,150],
    [879,879,879,879, 22,149,348,  0,348,149, 21,150,150],
    [380,353,380,345,  0,149,149, 85,149,149,886,150,150],
    [879,879,879,879,886,149,891,  0,891,149, 86,150,150],
    [149, 88,  0,  0,  0,888,  0,  0,  0,355, 87,150,150],
    [149,149,149,149,149,149,149,149,149,149,149,150,150]
],
    "bgmap": [

],
    "fgmap": [

]
}