main.floors.MT100=
{
    "floorId": "MT100",
    "title": "通天塔 100 ",
    "name": "通天塔100",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,0": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT100_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT100_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT100_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT100_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT100_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT100_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "if",
                "condition": "blockId:7,9",
                "true": [],
                "false": [
                    {
                        "type": "setBlock",
                        "number": "E560",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT100"
                    }
                ]
            }
        ],
        "7,9": [
            {
                "type": "if",
                "condition": "blockId:5,9",
                "true": [],
                "false": [
                    {
                        "type": "setBlock",
                        "number": "E560",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT100"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_MT100_6_8==6",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT100_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  4, 88,  4,  1,  1,  1,  1,  1],
    [  1,355,353,342,353,342,  0,342,353,342,353,355,  1],
    [  1,  1,  1,  1,  1,  1,538,  1,  1,  1,  1,  1,  1],
    [  1,355,353,342,353,342,  0,342,353,342,353,355,  1],
    [  1,  1,  1,  1,  1,  1,537,  1,  1,  1,  1,  1,  1],
    [  1,355,353,342,353,342,  0,342,353,342,353,355,  1],
    [  1,343,  1,  1,  1,  1,344,  1,  1,  1,  1,343,  1],
    [  1,355,  1,543,543,543,  0,543,543,543,  1,355,  1],
    [  1,538, 85, 85, 85, 85, 85, 85, 85, 85, 85,538,  1],
    [  1,343, 85,536, 85,563,  0,563, 85,536, 85,343,  1],
    [  1,538, 85,536, 85,  0,  0,  0, 85,536, 85,538,  1],
    [  1,540, 85,536, 85, 85, 85, 85, 85,536, 85,540,  1],
    [  1,  1, 85, 85, 85, 85, 87, 85, 85, 85, 85,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}