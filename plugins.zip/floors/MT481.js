main.floors.MT481=
{
    "floorId": "MT481",
    "title": "通天塔 481 ",
    "name": "通天塔481",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [
        {
            "type": "setGlobalValue",
            "name": "redPotion",
            "value": 10000
        },
        {
            "type": "setGlobalValue",
            "name": "bluePotion",
            "value": 15000
        },
        {
            "type": "setGlobalValue",
            "name": "yellowPotion",
            "value": 20000
        },
        {
            "type": "setGlobalValue",
            "name": "greenPotion",
            "value": 25000
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4, 87,  4,  4,  4,  4,  4,  4],
    [  4,382, 33, 33, 33,345,  0,345, 33, 33, 33,382,  4],
    [  4,  4,  4,  4,  4,  4, 31,  4,  4,  4,  4,  4,  4],
    [  1, 32, 32, 22, 22,344,  0,344, 22, 22, 32, 32,  1],
    [  1,  1,  1,  1,  1,  1, 31,  1,  1,  1,  1,  1,  1],
    [  1, 34, 34, 21, 21,344,  0,344, 21, 21, 34, 34,  1],
    [  1,  1,  1,  1,  1,  1, 31,  1,  1,  1,  1,  1,  1],
    [  1, 32, 32, 32, 21,343,  0,343, 21, 32, 32, 32,  1],
    [  1,  1,  1,  1,  1,  1, 31,  1,  1,  1,  1,  1,  1],
    [  1, 32, 32, 32, 30,343,  0,343, 30, 32, 32, 32,  1],
    [  1,  1,  1,  1,  1,  1, 31,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0, 31,  0, 31,  0,342, 29, 29, 29, 30,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}