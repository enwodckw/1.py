main.floors.ML8=
{
    "floorId": "ML8",
    "title": "通天塔 8 ",
    "name": "地下8",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "0,6": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "0,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,580, 33,364, 33,  0,585,  1, 30,588, 30,  1],
    [  1, 33,  1,  1,  1,  1,  1, 33,  1,586,  1,586,  1],
    [  1,364,344,582,349,585,  1,357,  1, 27,  1,348,  1],
    [  1, 33,  1,349,585,348,  1, 33,  1, 27,  1,348,  1],
    [  1,580,  1,585,348,586,  1,579,  1,348,  1,348,  1],
    [ 87,  0,  1,348,586,444,  1, 33,  1,348,  1, 28,  1],
    [  1,356,  1,  1,  1,  1,  1,357,  1,348,  1, 28,  1],
    [  1,  0,342,  1,391,388,  1, 33,  1,586,  1,586,  1],
    [  1,581,  0,344,389,390,343,581,342,  0,  1, 58,  1],
    [  1,472,343,  1,  1,  1,  1,  1,  1,  1,  1,351,  1],
    [ 88, 33, 33, 33,  1,537,571,577,342,342,342, 59,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}