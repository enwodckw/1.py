main.floors.MT21=
{
    "floorId": "MT21",
    "title": "通天塔 21 ",
    "name": "通天塔21",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,8": [
            "\t[器灵,thief]是不是发现境界比你低还能对你造成恐怖伤害，千万别忽略了他们的阶位，有时候阶位才能代表他们真正的战力，切记。现在增强的机会来了,来吧换取实力的机会来了",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我5绿,增加10万生命值，换吗？",
                "choices": [
                    {
                        "text": "换了",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "5"
                            },
                            {
                                "type": "setValue",
                                "name": "status:hp",
                                "operator": "+=",
                                "value": "100000"
                            },
                            "\t[器灵,thief]我很欣赏你,本区域就有一个碎片，你可以尽快的取到手，吸收碎片上的剑意，能够增加你的实力",
                            "\t[hero]好",
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不换",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[器灵,thief]我很欣赏你,本区域就有一个碎片，你可以尽快的取到手，吸收碎片上的剑意，能够增加你的实力",
                            "\t[hero]好",
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "6,12": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT21_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT21_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT21_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT21_10_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "2,4": {
            "0": {
                "condition": "flag:door_MT21_2_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT21_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,4": {
            "0": {
                "condition": "flag:door_MT21_10_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT21_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1],
    [  1,373,  0,373,  1, 27,  0, 27,  1,373,  0,373,  1],
    [  1,  0,381,  0,  1,  0, 33,  0,  1,  0,381,  0,  1],
    [  1,373,  0,373,  1,  0,233,  0,  1,373,  0,373,  1],
    [  1,  1, 85,  1,  1,  1,342,  1,  1,  1, 85,  1,  1],
    [  1,234,  0,234,  1, 21,  0, 21,  1,234,  0,234,  1],
    [  1,  0,252,  0,  1,  0, 22,  0,  1,  0,252,  0,  1],
    [  1,  0,  0,  0,  1, 33,  0, 33,  1,  0,  0,  0,  1],
    [  1,  0, 29,  0, 86,  0,123,  0, 86,  0, 29,  0,  1],
    [  1,345,  1,345,  1,236,  1,344,  1,345,  1,345,  1],
    [  1,348,  1,348,  1,  0,348,  0,  1,348,  1,348,  1],
    [  1,350,  1,350,  1,  0,  0,  0,  1,350,  1,350,  1],
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}