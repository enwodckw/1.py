main.floors.ML22=
{
    "floorId": "ML22",
    "title": "通天塔 22 ",
    "name": "地下22",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": "ML23",
            "loc": [
                1,
                1
            ]
        },
        "1,6": {
            "floorId": "ML23",
            "loc": [
                1,
                6
            ]
        },
        "1,11": {
            "floorId": "ML23",
            "loc": [
                1,
                11
            ]
        },
        "11,11": {
            "floorId": "ML23",
            "loc": [
                11,
                11
            ]
        },
        "12,6": {
            "floorId": "ML21",
            "loc": [
                12,
                6
            ]
        },
        "4,5": {
            "floorId": "ML21",
            "loc": [
                4,
                5
            ]
        },
        "4,7": {
            "floorId": "ML21",
            "loc": [
                4,
                7
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  1,385,385,385,386,524,  0,518, 23, 47,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1, 30,  1,  1,  1,  1],
    [  1,519,353,356,356,356, 30,  1,  0,518, 23, 47,  1],
    [  1,  1,  1,  1,  1,  1, 30,  1, 30,  1,  1,  1,  1],
    [  1,  0,520,382, 88,  1, 30,  1,349,  0,517,  0,  1],
    [  1, 87,  1,  1,  1,  1,  1,  1,  1,  1,  1,539, 88],
    [  1,  0,520,382, 88,  1, 30,  1, 21,  0,517,  0,  1],
    [  1,  1,  1,  1,  1,  1, 30,  1,349,  1,  1,342,  1],
    [  1,519,353,363,363,363, 30,  1,349,  1,386,513,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1,349,  1,386,386,  1],
    [  1, 87,  1,384,384,384,386,524,  0,  1,386, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}