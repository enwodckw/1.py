main.floors.MT221=
{
    "floorId": "MT221",
    "title": "通天塔 221 ",
    "name": "通天塔221",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000,
    "defaultGround": "ski",
    "bgm": "q.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT221_4_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT221_4_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT221_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT221_8_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,6": {
            "0": {
                "condition": "flag:door_MT221_4_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT221_4_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,6": {
            "0": {
                "condition": "flag:door_MT221_8_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT221_8_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [788,788,788,788,788,788,788,788,788,788,788,788,788],
    [788,378,352,378,345,  0, 88,  0,345,378,352,378,788],
    [788,788,788,788,788,  0,  0,  0,788,788,788,788,788],
    [788,378,352,378,345,  0,564,  0,345,378,352,378,788],
    [788,788,788,788,788,  0,  0,  0,788,788,788,788,788],
    [788, 30,  0, 30,788,788,344,788,788, 30,  0, 30,788],
    [788, 30,  0, 30, 85,792,  0,792, 85, 30,  0, 30,788],
    [788,788,788,788,788,792,  0,792,788,788,788,788,788],
    [788,  0,792,  0,359,  0,  0,  0,  0,  0,  0,  0,788],
    [788, 31,788,342,788,343,788,343,788,342,788,344,788],
    [788,  0,788, 33,788, 21,788, 21,788, 33,788, 22,788],
    [788, 87,788, 33,788, 21,788, 21,788, 33,788, 21,788],
    [788,788,788, 33,788,348,788,348,788, 33,788,788,788]
],
    "bgmap": [

],
    "fgmap": [

]
}