main.floors.MT454=
{
    "floorId": "MT454",
    "title": "通天塔 454 ",
    "name": "黑暗深渊深处454",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 700000000000,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT454_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT454_6_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_MT454_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT454_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,387,1150, 22,1302,  0,1150, 22,1150,387,1150,571,1150],
    [1150,387,1150,1226,1150,566,1150,1226,1150,387,1150,1311,1150],
    [1150,387,1150, 22,1150,  0,1150, 22,1150,387,1310,  0,1150],
    [1150,1310,1150,1150,1150,1311,1150,1302,1150,1150,1150, 86,1150],
    [1150,566,1226,566,1301,  0,  0,  0,1301,566,1226,566,1150],
    [1150,1150,1150,1150,1150,387,  0,387,1150,1150,1150,1150,1150],
    [1150, 21,  0, 21,1150,  0,387,  0,1150, 22,  0, 22,1150],
    [1150,  0,1226,  0,1150,387,  0,387,1150,  0,1226,  0,1150],
    [1150, 21,  0, 21,1150,1150, 85,1150,1150, 22,  0, 22,1150],
    [1150,1150,1304,1150,1150,1311,  0,1311,1150,1150,1304,1150,1150],
    [1150, 87,  0,  0,1310,  0,  0,  0,1310,  0,  0, 88,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}