main.floors.MT39=
{
    "floorId": "MT39",
    "title": "通天塔 39 ",
    "name": "通天塔39",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,11": {
            "floorId": "MM2",
            "loc": [
                6,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21,  1,378,378,378,  1,342, 21, 21,381,351,  1],
    [  1, 21,  1,  0,270,  0,  1,343,  1,  1,  1,360,  1],
    [  1, 22,  1,  1,342,  1,  1,342,  1,  1,  1,367,  1],
    [  1,351,414,342,  0,  0,342,  0,415,376,376,351,  1],
    [  1,  1,  1,  1, 21,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,363,363,  1, 32,  1,387,  1,376, 32,  0, 32,  1],
    [  1,356,356,  1,  0,  1, 32,  1, 21,  1,411,  1,  1],
    [  1,378,248,342,415,  1,270,  1,411,  1,371,371,  1],
    [  1,371,371,  1,  0, 86,  0, 86,  0,  1,371,248,  1],
    [  1,  1,  1,  1, 21,  1,416,  1,343,  1,  1,342,  1],
    [  1, 87,  0, 32,414,  1, 89,  1, 32, 32,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}