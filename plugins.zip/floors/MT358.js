main.floors.MT358=
{
    "floorId": "MT358",
    "title": "通天塔 358 ",
    "name": "黑暗深渊358",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 10000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT358_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT358_6_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_MT358_6_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT358_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,353,1156,  0,387,  0,947,  0,387,  0,1150,533,1150],
    [1150,639,1150,1150,1150,342,1158,342,1150,  0,342,947,1150],
    [1150,353,1150,533,1150,342,639,342,1150, 22,1150,533,1150],
    [1150,  0,1150,539,  4,  4,  4,  4,  4,  0,1150,533,1150],
    [1150,1147,1150,1148, 86, 23,538, 23,  4,1158,1150,1150,1150],
    [1150,  0,1150,539,  4,538,457,538,  4,  0,566,  0,1150],
    [1150,350,1156,533,  4, 23,538, 23,  4,535,  0,1148,1150],
    [1150,1150,1150,1150,  4,  4, 85,  4,  4,1150,1150,342,1150],
    [1150, 21, 21,1150,  0,1149,  0,1149,  0,344,1146,  0,1150],
    [1150, 21, 21,1150,  0,  0,  0,  0,  0,1150,  0,  0,1150],
    [1150, 88,  0,1156,  0,1150,1150,342,1150,1150,570, 87,1150],
    [1150,1150,1150,1150,1150,1150,351,351,351,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}