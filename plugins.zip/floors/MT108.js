main.floors.MT108=
{
    "floorId": "MT108",
    "title": "通天塔 108 ",
    "name": "通天塔108",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,12": [
            "\t[器灵,thief]我现在可以让梦云功法再次进行升级，是否需要升级？",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我30绿,升级梦云功法",
                "choices": [
                    {
                        "text": "升级",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "30"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I439",
                                "operator": "+=",
                                "value": "1"
                            },
                            "\t[器灵,thief]升级完成,祝你好运！",
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不升级",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[器灵,thief]只有一次机会哦",
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ],
        "7,11": [
            {
                "type": "if",
                "condition": "(item:greenKey<=999)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            12
                        ],
                        "floorId": "MT108"
                    }
                ],
                "false": []
            }
        ]
    },
    "changeFloor": {
        "9,12": {
            "floorId": "MT107",
            "loc": [
                9,
                12
            ]
        },
        "11,12": {
            "floorId": "MT107",
            "loc": [
                11,
                12
            ]
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  4,435,  4],
    [  1,378,  1, 22,378,  1,615, 22,538,378,  4,344,  4],
    [  1, 22,  1,378,607,342,  0,  1,  1,  1,  4,344,  4],
    [  1,378,  1,  1,  1,  1,  0,615, 22,378,  4,344,  4],
    [  1,607,  1, 22,378,  1,612,  1,  1,  1,  4,344,  4],
    [  1,  0,343,378,606,342,  0,606, 22,378,  4,344,  4],
    [  1,  1,  1,  1,  1,  1,  1,342,  1,  1,  4,344,  4],
    [  1,378, 22,567,378,616, 22,  0,  1,378,  4,342,  4],
    [  1,  1,  1,  1,  1,  1,  0,614,  1,565,  4,342,  4],
    [  1,372,377,342,372,  1,  1,342,  1,616,  4,343,  4],
    [  1,613,342,  1,  0,  0,612,  0,613,  0,  4,343,  4],
    [  1, 87,372,377,613,  4,  4,  0,  4,  0,  4,609,  4],
    [  1,  1,  1,  1,  1,  4,123, 85,  4, 88,  4, 88,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}