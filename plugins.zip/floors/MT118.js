main.floors.MT118=
{
    "floorId": "MT118",
    "title": "通天塔 118 ",
    "name": "通天塔118",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,12": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,7": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,382,  1,379,650,379,  1,374,374,374,642,  0,  1],
    [  1, 21,  1,  1,343,  1,  1,380,  1,  1,  1,342,  1],
    [  1,642,  0,374,564,380,344,355,  1,365,472,647,  1],
    [  1,  0,  1,  1,  1,  1,343,  1,  1,365,  1,358,  1],
    [  1, 21,651, 21,380,  1,535,  1,352,365,  1,358,  1],
    [  1,647,  1,  1,  1,  1,643,  1,641,  1,  1,358,  1],
    [  1,  0,374, 21,647,  1, 87,  1,  0,343,650,352,  1],
    [  1,  1,  1,  1,  0,  1,564,  1,378,  1,  1,  1,  1],
    [  1,378,378,  1,538,  1,374,  1,  0,  1,352,379,  1],
    [  1,378,343,  1,  0,342, 21,  1,609,  1,  1,641,  1],
    [  1,641,352,342,609,  1,  0,342,  0,640,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}