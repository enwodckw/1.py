main.floors.MT142=
{
    "floorId": "MT142",
    "title": "通天塔 142 ",
    "name": "通天塔142",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,3": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,379,379,379,675,342, 88,342,675,369,369,369,  1],
    [  1,343,  1,  1,  1,  1,342,  1,  1,  1,  1,  1,  1],
    [  1,679,  1,361,361,  1,  0,351,  0,669,  0,  0, 87],
    [  1,381,  1,536,681,342,673,  1,342,  1,  1,669,  1],
    [  1,381,  1,368,368,  1,379,  1,343,360,360,360,  1],
    [  1,  1,  1,  1,  1,  1,342,  1,  1,  1,  1,  1,  1],
    [  1,  0,351,351,351,672,  0,672,351,351,351,  0,  1],
    [  1,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,663,  1],
    [  1,680,681,682,344,639,639,436,639,639,  4,664,  1],
    [  1,679,  4,  4,  4,  4,  4,  4,  4,  4,  4,665,  1],
    [  1,678,677,676,675,674,673,670,669,668,667,666,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}