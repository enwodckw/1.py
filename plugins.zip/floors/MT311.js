main.floors.MT311=
{
    "floorId": "MT311",
    "title": "通天塔 311 ",
    "name": "沼泽林311",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1500000000,
    "defaultGround": "grass",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "0,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT311_7_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT311_7_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,8": {
            "0": {
                "condition": "flag:door_MT311_7_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT311_7_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [151,151,151,151,151,151,151,151,151,151,151,151,151],
    [151,151,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,151],
    [151,151,  4, 21,  4, 21,  4,381,  4, 21,  4, 21,151],
    [151,151,  4, 21,  4,374,  4,381,  4,374,  4, 21,151],
    [151,151,  4, 21,  4,374,  4,381,  4,374,  4, 21,151],
    [151,151,  4,344,  4,343,  4,345,  4,343,  4,344,151],
    [ 88,  0,  0, 21,  0,1033,  0,  0,  0,342,1030,  0,151],
    [151,151,342,152,342,152,1036,  0,1036,152,  0, 30,151],
    [151,151,1045,152,1043,152,152, 85,152,152, 30,  0,151],
    [151,151,364,152,364,152,357,  0,357,152,152,342,151],
    [151,151,364,152,364,152,  0,565,  0,152,353,1030,151],
    [151,151,364,344,364,152,357,  0,357,152, 21, 87,151],
    [151,151,151,151,151,151,151,151,151,151,151,151,151]
],
    "bgmap": [

],
    "fgmap": [

]
}