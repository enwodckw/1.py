main.floors.MN3=
{
    "floorId": "MN3",
    "title": "通天塔 M3 ",
    "name": "黑暗深渊M3",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000000000,
    "defaultGround": "ground",
    "bgm": "boss.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "2,10": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "10,10": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,6": [
            {
                "type": "setValue",
                "name": "flag:door_MN3_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,6": [
            {
                "type": "setValue",
                "name": "flag:door_MN3_6_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,7": {
            "0": {
                "condition": "flag:door_MN3_6_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MN3_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,  4,  4,  4,  4,  4,568,  4,  4,  4,  4,  4,1150],
    [1150,  4,  4,  4,  4,  4,568,  4,  4,  4,  4,  4,1150],
    [1150,  4,  4,  4,  4,  4,568,  4,  4,  4,  4,  4,1150],
    [1150,  4,  4,  4,  4,  4,342,  4,  4,  4,  4,  4,1150],
    [1150,  4,  0,1241,  0,  0,  0,  0,  0,1241,  0,  4,1150],
    [1150,  4,  0,  4,  4,  4, 85,  4,  4,  4,  0,  4,1150],
    [1150,  4,  0,  4,  4,  4,1223,  4,  4,  4,  0,  4,1150],
    [1150,  4,  0,  4,  4,  4,1223,  4,  4,  4, 23,  4,1150],
    [1150,  4, 88,  4,  4,  4,1223,  4,  4,  4, 87,  4,1150],
    [1150,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}