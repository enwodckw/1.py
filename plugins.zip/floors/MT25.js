main.floors.MT25=
{
    "floorId": "MT25",
    "title": "通天塔 25 ",
    "name": "通天塔25",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [
        "\t[hero]那就是器灵碎片吗？这么远都感受到了剑意，看来这个器灵完整时必然超越了塔灵"
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {
        "2,1": [
            "吸收斩神剑剑意,全属性增加20",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "20"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "20"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "20"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,364,396,364,  1, 30,  0, 30,  1,233,  0, 88,  1],
    [  1,357,  0,357,  1,  0,348,  0,  1,  0,233,  0,  1],
    [  1,  0,  0,223,  1,  0,222,  0,  1,349,  0,233,  1],
    [  1,  1,  1,342,  1,  1,342,  1,  1,342,  1,  1,  1],
    [  1,  0, 86,  0,237,  0,  0, 29,  0,233,  0, 29,  1],
    [  1,238,  1,  1,  1,235,  1,342,  1,  1,  1,  1,  1],
    [  1, 30,  1,  0,342,  0,237,  0,238,  0, 30,  0,  1],
    [  1,348,  1,348,  1,241,  1,241,  1,  1,  1,  1,  1],
    [  1,  1,  1,  0,  1, 30,  1, 30,  1,342,348,377,  1],
    [  1,  0,239, 29,  1,  0,  1,  0,  1,  0,  1,348,  1],
    [  1, 87,342,  0,343, 29,  1, 29,342,232,  0,235,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}