main.floors.MT14=
{
    "floorId": "MT14",
    "title": "通天塔 14 ",
    "name": "通天塔14",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 23,  1,  1,  1,  1,  1,  1],
    [  1, 34,225, 34,  1, 33,227, 33,  1, 34,225, 34,  1],
    [  1,  1,342,  1,  1,  1,343,  1,  1,  1,342,  1,  1],
    [  1,  0, 21,  0,215,  0, 21,  0,215,  0, 21,  0,  1],
    [  1,342,  1,342,  1,  1,  1,  1,  1,220,  1,  1,  1],
    [  1, 30,  1, 30,  1, 32,377, 32,  1, 30,  1, 30,  1],
    [  1,370,  1,370,  1,  0,227,  0,  1,370,  1,370,  1],
    [  1,218,  1,225,  1,  1,343,  1,  1,  1,  1,220,  1],
    [  1,  0, 86,  0,217,  0,342,  0,217,  0, 86,  0,  1],
    [  1,214,  1,  1,  1,  1,228,  1,  1,  1,  1,214,  1],
    [  1,  0,342,226,  0, 32,343, 32,  0,226,342,  0,  1],
    [  1, 88,  1,  0, 32,357,  1,364, 32,  0,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}