main.floors.MT173=
{
    "floorId": "MT173",
    "title": "通天塔 173 ",
    "name": "临时教会住所173",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT173_7_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT173_7_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,9": {
            "0": {
                "condition": "flag:door_MT173_7_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT173_7_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144, 88,741,741,361,361,741,262,741,361,361,741,144],
    [144,  0,741,741,361,361,741,262,741,361,361,741,144],
    [144,  0,741,741,741, 86,741,387,741, 86,741,741,144],
    [144,  0,741,741,368,368,741,387,741,368,368,741,144],
    [144,  0,741,741,368,368,741,387,741,368,368,741,144],
    [144,  0,741,741,741, 86,741,749,741, 86,741,741,144],
    [144,  0,741,741,375,382,741, 86,741,382,375,741,144],
    [144,  0,741,741,375,375, 86,564, 86,375,375,741,144],
    [144,  0,741,741,741,741,741, 85,741,741,741,741,144],
    [144,  0,741,741,741,741,662,  0,662,741,741,741,144],
    [144, 87,343,746,  0,  0,  0,  0,  0,344,379,379,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}