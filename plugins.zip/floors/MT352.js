main.floors.MT352=
{
    "floorId": "MT352",
    "title": "通天塔 352 ",
    "name": "黑暗深渊352",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 10000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT352_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT352_6_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_MT352_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT352_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 87, 21,1150,365,365,365,1150,1158,639, 47,639,1150],
    [1150, 86,1150,1150,1150,1156,1150,1150,343,1150,1150,1150,1150],
    [1150,1140, 86,1141,379,  0,364,353,  0,1156,1150, 47,1150],
    [1150,  0,1150,1150, 86,1150,1150,  0,1150,357,357,357,1150],
    [1150,344,1150,1155,  0,1155,1150,1155,1150,1150,1150,1150,1150],
    [1150,364,1150,1150, 86,1150,1150,  0, 86,1140,364,353,1150],
    [1150,  0, 86,1141,  0,  0, 21,  0,1150,1150,343,1150,1150],
    [1150,1142,1150,1150,1150,1157,  0,1157,1150,1147,  0,1147,1150],
    [1150, 21,1150,379,1150,1150, 85,1150,1150,637,1150,637,1150],
    [1150,  0,1150,379,1150,  0,387,  0,1150,637,1150,637,1150],
    [1150, 88,344,379,1150,387,  0,387,1150,637,1150,637,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}