main.floors.MT144=
{
    "floorId": "MT144",
    "title": "通天塔 144 ",
    "name": "通天塔144",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,9": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "1,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT144_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT144_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT144_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT144_2_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "2,4": {
            "0": {
                "condition": "flag:door_MT144_2_4==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT144_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,677,  0,672,  1,353,  1,391,  0,675,342,  0,  1],
    [  1,  0,  0,  0,342, 22,  1,  0,639,  0,  1,388,  1],
    [  1,677,  0,672,  1, 22,  1,570,  0,391,  1,  0,  1],
    [  1,  1, 85,  1,  1, 21,  1,  1,  1,  1,  1,676,  1],
    [  1,537,  0,537,  1, 21,  1,675,  0,388,390,  0,  1],
    [  1,  0,637,  0,  1,353,  1,  0,  1,  1,  1,  1,  1],
    [  1,537,  0,537,  1,674,  1,  0,344,377,377,377,  1],
    [  1,  1,  1,  1,  1,342,  1,673,  1,  1,  1,  1,  1],
    [  1,  0,674,  0,350,  0,675,  0,  0,672,  0,  0, 87],
    [  1,343,  1,676,  1,343,  1,677,  1,  1,  1,  1,  1],
    [  1, 88,  0,  0,670,  0,353,  0,677, 23,534, 47,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}