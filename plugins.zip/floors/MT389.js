main.floors.MT389=
{
    "floorId": "MT389",
    "title": "通天塔 389 ",
    "name": "黑暗深渊389",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": "MT392",
            "loc": [
                11,
                11
            ]
        },
        "6,1": {
            "floorId": "MT390",
            "loc": [
                6,
                1
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT389_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT389_6_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,4": {
            "0": {
                "condition": "flag:door_MT389_6_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT389_6_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,  5,  5,  5,1150,1150,1150,1150,1150],
    [1150,568,  0,568,1150,  5, 91,  5,1150,568,  0,568,1150],
    [1150,  0,1225,  0,1150,  5,570,  5,1150,  0,1225,  0,1150],
    [1150, 21,  0,568,1150,  5,639,  5,1150,568,  0, 21,1150],
    [1150,1187,  0,1150,  5,  5, 85,  5,  5,1150,  0,1187,1150],
    [1150,342,1150,1150,  5,1195,  0,1195,  5,1150,1150,342,1150],
    [1150,564,1150,1150,  5,  0,  0,  0,  5,1150,1150,564,1150],
    [1150,  0,1223,1150,  5,  5,344,  5,  5,1150,1223,  0,1150],
    [1150,1188,  0,564,1150,1150,344,1150,1150,564,  0,1188,1150],
    [1150,342,1150,1150,1150,1150,344,1150,1150,1150,1150,342,1150],
    [1150,  0, 33,342,359,359,  0,366,366,342, 33,  0,1150],
    [1150, 88,  0,1180,359,359,  0,366,366,1180,  0, 87,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}