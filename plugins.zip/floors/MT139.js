main.floors.MT139=
{
    "floorId": "MT139",
    "title": "通天塔 139 ",
    "name": "通天塔139",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "8,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT139_9_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "10,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT139_9_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "9,3": {
            "0": {
                "condition": "flag:door_MT139_9_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT139_9_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,665,  0,380,355,  0,344,  0,  0,  0,650,  1],
    [  1,  0,  1,  1,  1,  1,  4,  4,679,  0,679,  4,  4],
    [  1,  0,343,540,565,  1,  4,  4,  4, 85,  4,  4,  4],
    [  1,663,  1,  1,  1,  1,  4,536,  4,  0,  4,536,  4],
    [  1,  0,  1,539,539,539,  4,566,  4,566,  4,566,  4],
    [  1,355,  1, 21,  1,  1,  4,536, 86,  0, 86,536,  4],
    [  1,  0,342,673,  1, 22,  4,  4,  4,678,  4,  4,  4],
    [  1,663,  1,  1,  1, 22,  4, 47,  4,567,  4, 47,  4],
    [  1,  0,  1,672,  1, 22,  4,638, 86, 23, 86,638,  4],
    [  1,  0,342,  0,  1,667,  4,  4,  4,  4,  4,  4,  4],
    [  1, 88,  1,672, 86,  0,669,  0,533,539,  0,670,534],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}