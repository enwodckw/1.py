main.floors.ML28=
{
    "floorId": "ML28",
    "title": "通天塔 28 ",
    "name": "地下28",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [
        "有个怪卡在墙里请注意"
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "2,11": [
            {
                "type": "openDoor"
            }
        ],
        "1,10": [
            {
                "type": "openDoor"
            }
        ],
        "7,1": [
            {
                "type": "openDoor"
            }
        ],
        "7,0": [
            {
                "type": "openDoor"
            },
            {
                "type": "setBlock",
                "number": "E529"
            }
        ],
        "10,11": [
            "本层墙壁里面有只怪，撞出来即可，无需破墙镐"
        ]
    },
    "changeFloor": {
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,1": {
            "floorId": "ML26",
            "loc": [
                1,
                1
            ]
        },
        "1,11": {
            "floorId": "ML27",
            "loc": [
                1,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,372,  1,472,472,472,472,472,472,472,472,472,  1],
    [  1,372,  1,472,  1,  1,  1,472,  1,  1,  1,472,  1],
    [  1,372,  1,472,472,383,  1,472,  1,383,472,472,  1],
    [  1, 34,  1,472,  1,  1,  1,472,  1,  1,  1,472,  1],
    [  1,372,  1,472,472,383,  1,472,  1,383,472,472,  1],
    [  1,372,  1,  1,528,  1,  1,472,  1,  1,528,  1,  1],
    [  1,372,  1,  1,387,353,  1,472,  1,  1,387,353,  1],
    [  1,  0,512,  1,  1,  1,  1,524,  1,  1,  1,  1,  1],
    [  1,  1,  0,372,372,372,381,  0,372,372,372,  0,  1],
    [  1, 88,  1,  1,  1,  1,  1,  1,  1,  1,129, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}