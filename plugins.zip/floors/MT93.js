main.floors.MT93=
{
    "floorId": "MT93",
    "title": "通天塔 93 ",
    "name": "通天塔93",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "9,5": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,360,349,360,  0,  1,351,556,  0,351, 21,362,  1],
    [  1,342,  1,  1,550,  1,504,  1,  1,  1,556, 21,  1],
    [  1,367,349,367,  0,  1,  1,  1,351,  1,342,  1,  1],
    [  1,342,  1,  1,549,  0,  1,351,  0,548,  0,  0,  1],
    [  1,349,349,550,  0,348,342,380,  1, 87,  1,547,  1],
    [  4,  4,  4,  1,  1,  0,342,  1,  1,344,  1,  0,  1],
    [  4,534,  4,355,  1,555,  0,353,  0,546,  0,348,  1],
    [  4,534,  4,538,  1,  1,  1,  1,343,  1,  1,  1,  1],
    [  4,534,  4,355,  1,545,  0,545,  0,556, 21, 23,  1],
    [  4,345,  4,344,  1,  0,  1,343,  1, 21,369, 21,  1],
    [  1, 88,  0,  0,  0,545,  0,349,  1, 23, 21,362,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}