main.floors.MT141=
{
    "floorId": "MT141",
    "title": "通天塔 141 ",
    "name": "通天塔141",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4, 87,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  0,  4,  4,384,384,384,  4],
    [  4,  4,  4,  4,  4,  4,669,342,674,564,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  0,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,637,342,669,354,354,  4,  4],
    [  4,  4,  4,  4,  4,  4,354,  4,  4,  4,675,533,  4],
    [385,385,385,677,342,672,  0,672,380,343,564,345,  4],
    [  4,  4,  4,  4,  4,342,  0,  4,  4,  4,387,  4,  4],
    [  4,  4,  4,  4,  4,  4,667,343,342,  4,345,  4,  4],
    [  4,  4,  4,  4,  4,  4, 21,  4,  0,668,348,348,  4],
    [  4,  4,  4,  4,  4,  4,380,  4,380,  4,348,348,  4],
    [  4,  4,  4,  4,  4,  4, 21,673,  0,  4,  0, 88,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}