main.floors.MT102=
{
    "floorId": "MT102",
    "title": "通天塔 102 ",
    "name": "通天塔102",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,2": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,348,378,348,  1,391,  0,391,  1,  0,533,  0,  1],
    [  1,343,  1,611,  1,  0, 88,  0,  1, 21,  0, 21,  1],
    [  1,348,378,362,  1,391,  0,391,  1,  0,613,  0,  1],
    [  1,348,  1,343,  1,  1,342,  1,  1,  1,342,  1,  1],
    [  1,611,  1,  0,342,356,  0,356,  1,  0,350,  0,  1],
    [  1, 87,  0,350,610,  0,612,  0,342,614,  1,615,  1],
    [  1,  1,  1,  1,  1,356,  0,356,  1,375,  1,375,  1],
    [  1,619, 21, 21,  1,  1,610,  1,  1,380,  1,380,  1],
    [  1,342,  1, 21,  1,363,  0,363,  1,  1,  1,  1,  1],
    [  1,342,  1,613,  1,  0,612,  0,  1,375,350,380,  1],
    [  1,350,363,  0,611,363,  0,363,342,614,375,350,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}