main.floors.MT467=
{
    "floorId": "MT467",
    "title": "通天塔 467 ",
    "name": "通天塔467",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,342,342,342,342, 31, 87, 31,342,342,342,342,  1],
    [  1,342,  4,  4,  4,  4,343,  4,  4,  4,  4,342,  1],
    [  1,342,  4, 27, 28,1321,  0,1321, 28, 27,  4,342,  1],
    [  1,342,  4,  1,  1,342,  0,  1,  1,  1,  4,342,  1],
    [  1,381,  4, 27, 28,1321,  0,1321, 28, 27,  4,381,  1],
    [  1,  4,  4,  1,  1,342,  0,  1,  1,  1,  4,  4,  1],
    [  1,381,  4, 27, 28,1321,  0,1321, 28, 27,  4,381,  1],
    [  1,342,  4,  1,  1,342,  0,  1,  1,  1,  4,342,  1],
    [  1,342,  4, 31, 29, 31,  0, 31, 29, 31,  4,342,  1],
    [  1,342,  4,  4,  4,  4,  0,  4,  4,  4,  4,342,  1],
    [  1,342,342,342,342, 31, 88, 31,342,342,342,342,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}