main.floors.MT479=
{
    "floorId": "MT479",
    "title": "通天塔 479 ",
    "name": "通天塔479",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,357,  1,357,  1,357,  1,357,  1,357,  1,357,  1],
    [  1,364,  1,364,  1,364,  1,364,  1,364,  1,364,  1],
    [  1,345,  1,345,  1,345,  1,345,  1,345,  1,345,  1],
    [  1,  0,1325, 21,1326, 21,1327, 21,1325, 21,1326, 21,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,1331,1331,  0,  1,  1,  0,1329,1329,  0,  0,  1],
    [  1,  0,  1,  1,383,  1,  1,383,  1,  1,344,1331,  1],
    [  1,1330,  1,  1,  0,  1,  1,  0,  1,  1,348,  0,  1],
    [  1,  0,  1,  1,349,  1,  1,349,  1,  1,  0,535,  1],
    [  1, 87,  1,  1,  0,1330,1330,  0,  1,  1,348,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}