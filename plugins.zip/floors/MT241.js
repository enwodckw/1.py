main.floors.MT241=
{
    "floorId": "MT241",
    "title": "通天塔 241 ",
    "name": "通天塔241",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 100000000,
    "defaultGround": "T836",
    "bgm": "q.mp3",
    "firstArrive": [
        {
            "type": "setGlobalValue",
            "name": "redPotion",
            "value": 50000
        },
        {
            "type": "setGlobalValue",
            "name": "bluePotion",
            "value": 100000
        },
        {
            "type": "setGlobalValue",
            "name": "yellowPotion",
            "value": 200000
        },
        {
            "type": "setGlobalValue",
            "name": "greenPotion",
            "value": 300000
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [879,879,879,879,879,879,879,879,879,879,879,879,879],
    [879,383,345,381,602,345, 87,345,603,381,345,383,879],
    [879,879,879,879,879,879,  0,879,879,879,879,879,879],
    [840,355,355,344,602,344, 21,344,603,344,355,355,840],
    [840,877,877,877,877,877,  0,877,877,877,877,877,840],
    [840,352,353,343,353,343, 21,343,353,343,353,352,840],
    [840,877,877,877,877,877,  0,877,877,877,877,877,840],
    [840,351,354,343,354,343, 21,343,354,343,354,351,840],
    [840,877,877,877,877,877,  0,877,877,877,877,877,840],
    [840,352,350,342,351,342, 21,342,351,342,350,352,840],
    [840,877,877,877,877,877,  0,877,877,877,877,877,840],
    [840, 88,  0,  0,  0,571,  0,342,351,342,350,352,840],
    [840,840,840,840,840,840,840,840,840,840,840,840,840]
],
    "bgmap": [

],
    "fgmap": [

]
}