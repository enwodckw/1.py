main.floors.MT116=
{
    "floorId": "MT116",
    "title": "通天塔 116 ",
    "name": "通天塔116",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [
        {
            "type": "setValue",
            "name": "item:poisonWine",
            "value": "0"
        },
        {
            "type": "setValue",
            "name": "item:weakWine",
            "value": "0"
        },
        {
            "type": "setValue",
            "name": "item:superWine",
            "value": "0"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,0": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1],
    [  1, 22,  1, 21,  1, 21,  0, 21,  1, 21,  1, 22,  1],
    [  1, 22,  1, 21,  1,  0,391,  0,  1, 21,  1, 22,  1],
    [  1, 22,  1, 21,  1, 21,  0, 21,  1, 21,  1, 22,  1],
    [  1,344,  1,343,  1,  1,344,  1,  1,343,  1,344,  1],
    [  4,353,609,350,350,608,  0,608,350,350,609,353,  4],
    [  4,  4,  4,  4,  4,  4, 87,  4,  4,  4,  4,  4,  4],
    [  4,567,342,540,564,342, 23,342,564,540,342,567,  4],
    [  4,  4,  4,  4,  4,  4,345,  4,  4,  4,  4,  4,  4],
    [  4, 21,345, 21,345, 21,345, 21,345, 21,345, 21,  4],
    [  4, 22,  4, 22,  4, 22,  4, 22,  4, 22,  4, 22,  4],
    [  4,383,  4,383,  4,383,  4,383,  4,383,  4,383,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}