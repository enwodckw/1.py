main.floors.MT123=
{
    "floorId": "MT123",
    "title": "通天塔 123 ",
    "name": "通天塔123",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "0,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,353,609,  0,359,  0,641,353,  1,353,652,353,  1],
    [  1,609,  4,  4,  4,  4,  4,641,  1,650,  1,650,  1],
    [  1,  0,344,  0,643,645,  4,  0,  1,  0,  1,  0,  1],
    [  1,  0,  4,643,344,644,  4,359,  1,387,  1,387,  1],
    [  1,640,  4,  4,644,477,  4,  0,  1, 21,  1, 21,  1],
    [ 87,  0,  4,  4,  4,  4,  4,646,  1,  0,  1,  0,  1],
    [  1,351,  4,  4,380,  1,  4,  0,  1,651,  1,651,  1],
    [  1,  0,640,  4,  1,381,  4,367,  1,  0,  1,  0,  1],
    [  1,344,342,344,381,569,642,  0,648,  0,  1,367,  1],
    [  1,351,640,  1,  1,  1,  1,  1,  1,  1,  1, 21,  1],
    [  1, 88,  0,649,361,361,  1,388,391,389,649,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}