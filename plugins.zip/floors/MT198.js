main.floors.MT198=
{
    "floorId": "MT198",
    "title": "通天塔 198 ",
    "name": "临时教会住所198",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "5,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "7,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "8,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT198_9_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT198_9_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT198_3_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT198_3_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "9,6": {
            "0": {
                "condition": "flag:door_MT198_9_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT198_9_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "3,6": {
            "0": {
                "condition": "flag:door_MT198_3_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT198_3_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,262],
    [144,539,764,539,535,535,535,741,741,539, 47, 47,144],
    [144,741,342,741,741,741,741,741,602,759,539, 47,144],
    [144,  0,571,  0,757,342,  0,760,  0,741,741,741,144],
    [144,741,741,741,741,741,766,741,741,741,352,352,144],
    [144,  0,352,741,763,741,  0,741,762,741,352,352,144],
    [144,639,  0, 85,  0, 88,  0, 87,  0, 85,  0,639,144],
    [144,  0,352,741,763,741,  0,741,762,741,352,352,144],
    [144,741,741,741,741,741,766,741,741,741,352,352,144],
    [144,382,741,382,741,380,  0,343,539,741,741,741,144],
    [144,760,342,761,342,  0,741,741,741,741,382,382,144],
    [144,382,741,382,741,602,761,  0,571,  0,765,382,144],
    [262,144,144,144,144,144,144,144,144,144,144,144,262]
],
    "bgmap": [

],
    "fgmap": [

]
}