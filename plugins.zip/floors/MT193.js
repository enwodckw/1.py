main.floors.MT193=
{
    "floorId": "MT193",
    "title": "通天塔 193 ",
    "name": "临时教会住所193",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "10,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "2,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT193_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT193_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT193_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT193_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT193_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT193_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT193_2_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT193_2_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,8": {
            "0": {
                "condition": "flag:door_MT193_10_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT193_10_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,4": {
            "0": {
                "condition": "flag:door_MT193_10_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT193_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,4": {
            "0": {
                "condition": "flag:door_MT193_2_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT193_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,8": {
            "0": {
                "condition": "flag:door_MT193_2_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT193_2_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144,348,  0,348,741,741,741,741,741,348,  0,348,144],
    [144,  0,537,  0,741,741,261,741,741,  0,537,  0,144],
    [144,348,  0,348,741,741,741,741,741,348,  0,348,144],
    [144,741, 85,741,741,741,741,741,741,741, 85,741,144],
    [144,751,  0,751,741,766,741,766,741,751,  0,751,144],
    [144,  0, 87,  0,  0,  0,750,  0,  0,  0, 88,  0,144],
    [144,751,  0,751,741,766,741,766,741,751,  0,751,144],
    [144,741, 85,741,741,741,741,741,741,741, 85,741,144],
    [144,348,  0,348,741,741,261,741,741,348,  0,348,144],
    [144,  0,537,  0,741,741,741,741,741,  0,537,  0,144],
    [144,348,  0,348,741,741,741,741,741,348,  0,348,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}