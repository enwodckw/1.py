main.floors.MT162=
{
    "floorId": "MT162",
    "title": "通天塔 162 ",
    "name": "通天塔162",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150000,
    "defaultGround": "grass",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT162_4_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,10": {
            "0": {
                "condition": "flag:door_MT162_4_10==14",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT162_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20, 87,691,  0,378,  0,686,  0,684,  0, 20,538, 20],
    [  4,  4,  4,  4,343,  4,  4,  4,  4,  0, 20,538, 20],
    [  4,384,  4,690,  0,690,  4,384,  4,683, 20,342, 20],
    [  4,384,  4,691,342,691,  4,384,  4,  0,687,  0, 20],
    [  4,384,  4,692,342,692,  4,384,  4, 21, 20,354, 20],
    [  4,385,  4,689,342,689,  4,385,  4, 21, 20,342, 20],
    [  4,385,  4,654,342,654,  4,385,  4,  0,688,  0, 20],
    [  4,385,  4,695,342,695,  4,385,  4, 20, 20,378, 20],
    [  4,386,  4,680,  0,680,  4,386,  4,538, 20,354, 20],
    [  4,386,  4,  4, 85,  4,  4,386,  4,540, 20,  0, 20],
    [  4,386,387,387,639,387,387,386,  4,538,343, 88, 20],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4, 20, 20, 20, 20]
],
    "bgmap": [

],
    "fgmap": [

]
}