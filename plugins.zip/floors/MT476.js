main.floors.MT476=
{
    "floorId": "MT476",
    "title": "通天塔 476 ",
    "name": "通天塔476",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  1, 34,  1, 47,  0, 47,  1, 34,  1, 34,  1],
    [  1,348,  1,377,  1,  0,351,  0,  1,378,  1, 30,  1],
    [  1,  0,  1, 34,  1,377,  0,377,  1, 34,  1, 34,  1],
    [  1,1324,  1,1328,  1,1329,  1,1330,  1,1330,  1,1326,  1],
    [  1,342,  1,342,  1,343,  1,342,  1,342,  1,342,  1],
    [  1,  0,1328,  0,  0,  0,  0,  0,1318,  0,  0,  0,  1],
    [  1,342,  1,342,  1,342,  1,342,  1,342,  1,1317,  1],
    [  1,1323,  1,1323,  1,1331,  1,1325,  1,1331,  1,1316,  1],
    [  1,1324,  1, 33,  1, 34,  1, 34,  1, 34,  1,1317,  1],
    [  1,1323,  1, 33,  1,378,  1, 30,  1,378,  1,  0,  1],
    [  1, 33,342, 33,  1, 34,  1, 34,  1, 34,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}