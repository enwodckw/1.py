main.floors.MT13=
{
    "floorId": "MT13",
    "title": "通天塔 13 ",
    "name": "通天塔13",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "12,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "0,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 28, 28, 28,  1,  0,379,  0,  1, 21,342, 33,  1],
    [  1,  0,349,  0,  1,373,  0, 23,  1, 21,  1, 31,  1],
    [  1,227,  0, 21,  1,  0,222,  0,  1, 21,  1,  1,  1],
    [  1,342,  1,  1,  1,  1,343,  1,  1,224,  1, 21,  1],
    [  1,  0, 31,  0,219,  0,  0,  0,216,  0,  1, 27,  1],
    [  1,342,  1, 33,342,  0, 31,  0,342,  0,342,216,  1],
    [  1,226,  0,  1,  1,  1, 86,  1,  1, 31,  1,  1,  1],
    [  1,  0,348,  0,  1,  0,219,  0,  1, 21,  1, 32,  1],
    [  1, 27, 27, 27,  1, 34,  0, 34,  1,  0,342, 34,  1],
    [  1,  1,  1,  1,  1,  1, 86,  1,  1,217,  1,  1,  1],
    [ 87,  0, 30,  0,214,  0, 30,  0,343,  0,  0,  0, 88],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}