main.floors.MT163=
{
    "floorId": "MT163",
    "title": "通天塔 163 ",
    "name": "通天塔163",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150000,
    "defaultGround": "grass",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "11,1": [
            "我是装饰品"
        ],
        "11,11": [
            "我是装饰品"
        ]
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT163_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT163_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT163_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT163_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT163_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT163_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT163_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT163_6_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_MT163_6_8==8",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT163_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20, 88,371,371,371,371,371,371,371,371,371, 88, 20],
    [ 20,371,371,353,  0,353,359,353,  0,353,371,371, 20],
    [ 20,371,358,  0,366,  0,  0,  0,366,  0,365,371, 20],
    [ 20,371,358, 21,  0,680, 85,680,  0, 21,365,371, 20],
    [ 20,371,  0,  0,679, 85,638, 85,679,  0,  0,371, 20],
    [ 20,371,359, 47, 85,638,639,638, 85, 23,359,371, 20],
    [ 20,371,  0,  0,679, 85,638, 85,679,  0,  0,371, 20],
    [ 20,371,358, 22,  0,680, 85,680,  0, 22,365,371, 20],
    [ 20,371,358,  0,366,  0,  0,  0,366,  0,365,371, 20],
    [ 20,371,371,353,  0,353,359,353,  0,353,371,371, 20],
    [ 20, 87,371,371,371,371,371,371,371,371,371, 87, 20],
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20]
],
    "bgmap": [

],
    "fgmap": [

]
}