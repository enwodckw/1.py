main.floors.MT519=
{
    "floorId": "MT519",
    "title": "通天塔 519 ",
    "name": "通天塔519",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,381,343,1392,  1,344,  0, 21, 86,1386, 86, 88,  1],
    [  1,360,  1,  0,342,  0,  1,  0,  1,  1,  1,  0,  1],
    [  1,360,  1,1392,344,352,  0,1388,  1, 21,  1,  0,  1],
    [  1,360,  1,  1,  1,  1,342,  1,  1,387,  1,1381,  1],
    [  1,367,367,367,  1,355,1391,381,  1,1388,342,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 86,  1],
    [  1,1390,342,  0,1385,  0, 21,  0,1386,  0,343,  0,  1],
    [  1,360,  1,342,  1,  1,342,  1,  1,342,  1,1381,  1],
    [  1,360,  1,1394,  1,355,1391,381,  1,348,  1,  0,  1],
    [  1,360,  1,367,  1,  1,  1,  1,  1,  1,  1,348,  1],
    [  1,360,  1,367,367,367,  1,387, 21,1390,343, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}