main.floors.MT531=
{
    "floorId": "MT531",
    "title": "通天塔 531 ",
    "name": "通天塔531",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [
        {
            "type": "setGlobalValue",
            "name": "redPotion",
            "value": 30000
        },
        {
            "type": "setGlobalValue",
            "name": "bluePotion",
            "value": 40000
        },
        {
            "type": "setGlobalValue",
            "name": "yellowPotion",
            "value": 50000
        },
        {
            "type": "setGlobalValue",
            "name": "greenPotion",
            "value": 60000
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,377,377,377,348,345, 88,345,348,377,377,377,  4],
    [  4,363,363,363,348,  4,  0,  4,348,356,356,356,  4],
    [  4,  4,  4,  4,  4,  4, 86,  4,  4,  4,  4,  4,  4],
    [  4,377, 47,344,540,344,  0,344,540,344, 47,377,  4],
    [  4,  4,  4,  4,  4,  4,1369,  4,  4,  4,  4,  4,  4],
    [  4,377, 47,344,540,344,  0,344,540,344, 47,377,  4],
    [  4,  4,  4,  4,  4,  4, 86,  4,  4,  4,  4,  4,  4],
    [  1,  0,1490,  0,1489, 86,  0, 86,1489,  0,1490,  0,  1],
    [  1,342,  1,343,  1,  1,344,  1,  1,343,  1,342,  1],
    [  1, 30,  1, 30,  1, 21,  0, 21,  1, 30,  1, 30,  1],
    [  1,348,  1,349,  1,  0, 87,  0,  1,349,  1,348,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}