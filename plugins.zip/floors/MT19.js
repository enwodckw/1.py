main.floors.MT19=
{
    "floorId": "MT19",
    "title": "通天塔 19 ",
    "name": "通天塔19",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,12": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT19_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT19_6_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_MT19_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT19_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1],
    [  1,363,363,363,  1, 21,377, 21,  1,356,356,356,  1],
    [  1, 21,  1,  1,  1,372,  0,372,  1, 21,  1,  1,  1],
    [  1,222,  1, 33,  1,  0,221,  0,  1,222,  1, 32,  1],
    [  1,342,  1,342,  1,  1,343,  1,  1,342,  1, 32,  1],
    [  1, 27,  0, 29,342,  0, 33,  0,342,  0,342, 32,  1],
    [  1,  1,225,  1,  1,  1,343,  1,  1,226,  1,  1,  1],
    [  1, 29,  0, 27,342,  0, 21,  0,342, 29,  0, 29,  1],
    [  1,228,  1,  1,  1, 30,  0, 30,  1,343,  1,  1,  1],
    [  1, 21,  1, 22,  1,  1, 85,  1,  1, 29,  0, 29,  1],
    [  1, 33,  1, 30,  1,227,  0,227,  1,342,  1,226,  1],
    [  1, 21,342,221,  1,  0,  0,  0,342,  0, 32,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 88,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}