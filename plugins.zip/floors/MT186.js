main.floors.MT186=
{
    "floorId": "MT186",
    "title": "通天塔 186 ",
    "name": "临时教会住所186",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT186_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT186_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT186_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT186_10_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "10,2": [
            "吸收斩神剑剑意,全属性增加1亿",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "100000000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "100000000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "100000000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {
        "10,4": {
            "0": {
                "condition": "flag:door_MT186_10_4==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT186_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  0,  0,  0,  0,144,144,144,144,144,144,144,144,144],
    [  0,  0,  0,  0,741,535,741,535,741,390,  0,390,144],
    [  0,  0,  0,  0,741,535,741,535,741,  0,398,  0,144],
    [  0,  0,  0,  0,741,535,741,535,741,390,  0,390,144],
    [  0,  0,  0,  0,741,538,764,538,741,741, 85,741,144],
    [  0,  0,  0,  0,741,741,343,741,741,762,  0,762,144],
    [  0,  0,  0,  0,741,  0,538,  0,741,  0,  0,  0,144],
    [  0,  0,  0,  0,741,754,741,754,741,762,  0,762,144],
    [144,741,741,741,741,391,741,391,741,741,342,741,144],
    [144,753,  0,  0,342,  0,757,  0,353,  0,747,  0,144],
    [144,353,753,  0,741,741,741,741,741,741,741,  0,144],
    [144, 87,353,753,741,391,391,391,540,759,342, 88,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [
    [145,145,145,145,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [145,145,145,145,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [145,145,145,145,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [145,145,145,145,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [145,145,145,145,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [145,145,145,145,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [145,145,145,145,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [145,145,145,145,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0]
],
    "fgmap": [

]
}