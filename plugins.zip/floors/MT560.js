main.floors.MT560=
{
    "floorId": "MT560",
    "title": "通天塔 560 ",
    "name": "通天塔560",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  1, 21,534, 21,  1, 22,1414,  0,1414, 23,  1],
    [  1, 30,  1, 21,  1,  1,  1, 22,  1,342,  1,  1,  1],
    [  1, 30,  1,1414,  1, 21,  1, 22,  1, 21,342,1416,  1],
    [  1,1412,342,  0,  1,534,  1, 22,  1,  0,  1,352,  1],
    [  1, 30,  1,1414,  1, 21,  1, 22,  1,352,  1,534,  1],
    [  1, 30,  1,344,  1,1415,  1,  1,  1,1413,  1,  1,  1],
    [  1,  0, 86,  0,1412,  0, 86,  0,1412,  0,348,376,  1],
    [  1,343,  1,344,  1,344,  1,343,  1,342,  1,  1,  1],
    [  1,377,  1,602,  1,602,  1, 21,  1,1413,  0,348,  1],
    [  1,343,  1,344,  1,344,  1, 21,  1,  0,348,  0,  1],
    [  1,377,  1,603,  1,603,  1, 21,  1,348,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}