main.floors.MT53=
{
    "floorId": "MT53",
    "title": "通天塔 53 ",
    "name": "通天塔53",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "12,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "0,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,358,  1,358,  1, 23,391, 23,  1,351,358,363,  1],
    [  1,363,  1,363,  1,353,272,353,  1, 27,  1,267,  1],
    [  1,271,  1,267,  1,  1,342,  1,  1,271,  1,358,  1],
    [  1,  0,382,  0,  0,266,  0,266,  0,  0,  1,363,  1],
    [  1,  1,  1,  1,  1,343,431,342,  1,  1,  1,  1,  1],
    [ 87,  0,  0,265,381, 21,351, 21,381,265,  0,  0, 88],
    [  1,  1,  1,  1,  1,342,431,343,  1,  1,  1,  1,  1],
    [  1,342,  0,265,  0,266,  0,266,  1,271,342,267,  1],
    [  1,267, 86,  0,  1,  1,344,  1,  1,  0,  1,  0,  1],
    [  1,391,  1,265,  1,387,387,387,272,354,  1, 27,  1],
    [  1,350,343,  0,  1,  1,  1,  1,343,  1,  1,  0,  1],
    [  1,  1,  1,354,266,  0,  0,266,  0, 27,  0,267,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}