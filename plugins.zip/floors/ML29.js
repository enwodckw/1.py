main.floors.ML29=
{
    "floorId": "ML29",
    "title": "通天塔 29 ",
    "name": "地下29",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [
        {
            "type": "changePos",
            "loc": [
                1,
                1
            ],
            "direction": "down"
        },
        "\t[冥武士,E512]还真有人不怕死，这个功劳是我的了",
        {
            "type": "jump",
            "from": [
                6,
                6
            ],
            "to": [
                1,
                2
            ],
            "time": 300,
            "keep": true
        },
        {
            "type": "battle",
            "id": "E512"
        },
        {
            "type": "hide",
            "loc": [
                [
                    1,
                    2
                ]
            ]
        },
        "\t[hero]果然有埋伏，还好当初没有下来",
        {
            "type": "hide",
            "loc": [
                [
                    1,
                    11
                ]
            ],
            "floorId": "ML28"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  1,361,382,361,  1,380,  1,368,382,368,  1],
    [  1,  0,  1,521,  1,343,  1,517,  1,343,  1,521,  1],
    [  1, 31,  1,379,372,520, 86,  0, 86,520,372,379,  1],
    [  1, 31,  1,351,372,372,  1,516,  1,372,372,351,  1],
    [  1, 31,  1,  1,  1,  1,  1,342,  1,  1,  1,  1,  1],
    [  1,  0, 21, 21, 21,  0,512,  0, 22, 22, 22,  0,  1],
    [  1,  1,  1,  1,  1,343,  1,  1,  1,  1,  1, 31,  1],
    [  1,  0,351,  0,516,  0,516,  0,351,  0,  1, 31,  1],
    [  1,342,  1,  1,  1,517,  1,  1,  1,518,  1, 31,  1],
    [  1,518, 21, 21,  1,  0,  1,382,  1, 21,  1,  0,  1],
    [  1, 21, 21,380,  1,381,  1, 47,519,  0,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}