main.floors.MT80=
{
    "floorId": "MT80",
    "title": "通天塔 80 ",
    "name": "通天塔80",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 48,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT80_7_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT80_7_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,9": {
            "0": {
                "condition": "flag:door_MT80_7_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT80_7_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  4,  1,  1,  1,  1,  1,  4,  1,  1,  1,  1],
    [  1, 87,  4,384,387,387,387,385,  4,380, 21, 21,  1],
    [  1,  0,  4,384,384,395,385,385,  4, 21, 21,497,  1],
    [  1,489,  4,  4,  4,343,  4,  4,  4,  1,  1,342,  1],
    [  1,  0, 33, 33, 33,487,  0,  0,  0, 86, 21,  0,  1],
    [  1,  1,  1,  1,  1,  1, 33,492, 33,  1,  0,488,  1],
    [  1,363,363,363,363,  1,  1,342,  1,  1,472,342,  1],
    [  1,  1,  1,  1,363,  1,358,358,358,  1, 30, 33,  1],
    [  1,363,363,  1,363,  1,358,358,358,  1, 30, 30,  1],
    [  1,492,363,  1,497,  1,  1, 85,  1,  1,488, 30,  1],
    [  1,342,  1,  1,342,  1,490,  0,490,  1,343,  1,  1],
    [  1, 88,  0,486,  0,  0,  0,  0,  0,487, 33, 33,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}