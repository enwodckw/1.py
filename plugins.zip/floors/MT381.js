main.floors.MT381=
{
    "floorId": "MT381",
    "title": "通天塔 381 ",
    "name": "黑暗深渊381",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT381_8_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT381_8_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT381_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT381_4_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "8,10": {
            "0": {
                "condition": "flag:door_MT381_8_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT381_8_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "4,10": {
            "0": {
                "condition": "flag:door_MT381_4_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT381_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 87,  0,1174,  0, 21,  0, 21,  0,1174,  0, 88,1150],
    [1150,1150,1150,1150,1150,1150,1192,1150,1150,1150,1150,1150,1150],
    [1150,639,639,639,1181,1150,  0,1150,1182,639,639,639,1150],
    [1150,1150,1150,1150,  0,342,353,342,  0,1150,1150,1150,1150],
    [1150,639,639,639,1181,1150,353,1150,1182,639,639,639,1150],
    [1150,1150,1150,1150,1150,1150,353,1150,1150,1150,1150,1150,1150],
    [1150,639,639,639,1183,342,  0,342,1183,639,639,639,1150],
    [1150,1150,1150,1150,1150,1150,342,1150,1150,1150,1150,1150,1150],
    [1150,538,  0,538,1150,1180,  0,1180,1150,538,  0,538,1150],
    [1150,  0,1225,  0, 85,  0,  0,  0, 85,  0,1225,  0,1150],
    [1150,538,  0,538,1150,1180,  0,1180,1150,538,  0,538,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}