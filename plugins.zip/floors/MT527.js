main.floors.MT527=
{
    "floorId": "MT527",
    "title": "通天塔 527 ",
    "name": "通天塔527",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  4,  4,  4,  4,  4,  4,  4],
    [  1, 88,  1,1223,1395,349,  4, 21, 22, 23,538,1226,  4],
    [  1,  0,  1,349,  1,1215,  4, 21, 22, 23,538, 47,  4],
    [  1,1389,  1,349,  1,1215,  4, 21, 22, 23,538,1396,  4],
    [  1,  0,  1,349,  1,1215,  4,  4,  4,  4,  4,343,  4],
    [  1,348,  1,344,  1,1215,1392,  0,1392,  0,  0,1396,  1],
    [  1,  0,344,1393,  1,  1,  1,342,  1,  1,343,  1,  1],
    [  1,348,  1,  0,1215,1215,1215,  0,  1,1389,  0,1389,  1],
    [  1,  0,  1,343,  1,  1,344,  1,  1, 21,  1, 21,  1],
    [  1,1389,  1, 32, 32,  1, 33, 33,  1,564,  0,564,  1],
    [  1,  0,  1, 32, 32,  1, 33, 33,  1,343,351,343,  1],
    [  1, 87,  1, 32,262,262,262, 33,  1,1392,  0,1392,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,1225,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}