main.floors.MT489=
{
    "floorId": "MT489",
    "title": "通天塔 489 ",
    "name": "通天塔489",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,377,343,  0, 27, 29,  0, 30, 28,  0,343, 88,  1],
    [  1,1338,  1,472,  1,  1,  1,  1,  1,472,  1,  0,  1],
    [  1,  0,472,472,  1,  1,  1,  1,  1,472,472,1338,  1],
    [  1, 27,  1,  1,  1,  1,  1,  1,  1,  1,  1, 27,  1],
    [  1, 29,  1,  1,  1,  1,  1,  1,  1,  1,  1, 29,  1],
    [  1,  0,  1,  1,  1,  1,535,  1,  1,  1,  1,  0,  1],
    [  1, 30,  1,  1,  1,  1,  1,  1,  1,  1,  1, 30,  1],
    [  1, 28,  1,  1,  1,  1,  1,  1,  1,  1,  1, 28,  1],
    [  1,  0,472,472,  1,  1,  1,  1,  1,472,472,  0,  1],
    [  1,1340,  1,472,  1,  1,  1,  1,  1,472,  1,343,  1],
    [  1, 87,343,  0, 28, 29,  0, 27, 30,  0,1340,377,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}