main.floors.MT50=
{
    "floorId": "MT50",
    "title": "通天塔 50 ",
    "name": "通天塔50",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,352,  0,  1,  0,372,372,372,  0,430,349,  1],
    [  1, 30,  1, 30,  1,430,  1,  1,  1,  1,342,  1,  1],
    [  1,342,  1,425,  1,342,  1,372,379,  1,432,372,  1],
    [  1,  0,427,  0, 21,  0,342,432, 21,  1, 21,379,  1],
    [  1,  1,  1,  1,  1,377,  1,  1,  1,  1,  1,  1,  1],
    [  1, 30, 30, 30,  1,  0,  1,360,343,367,  1, 21,  1],
    [  1, 21,427, 21,  1,428,  1,  0,428,  0,  1, 21,  1],
    [  1,  1,342,  1,  1,  0,  1,431,  1,349,429, 21,  1],
    [  1,349,  0,426,  0, 21,342,  0,351,  1,  1,343,  1],
    [  1,  0,  1,  1,  1,  1,  1,431,  1,  1,349,429,  1],
    [  1, 88,427, 21, 21,  1,348,348,348,  1,349,349,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}