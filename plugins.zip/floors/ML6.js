main.floors.ML6=
{
    "floorId": "ML6",
    "title": "通天塔 6 ",
    "name": "地下6",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,6": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,353,  1, 21,535, 21, 22,  1,351,  1,588,533,  1],
    [  1,535,  1,  1,  1,  1,539,  1,533,  1,342,  1,  1],
    [  1,353,  1,534,351,  1, 22,  1,351,  1,534,351,  1],
    [  1,592,  1,351,590,  1,592,  1,589,  1,351,591,  1],
    [  1,342,  1,  1,342,  1,343,  1,343,  1,  1,342,  1],
    [  1, 88,  0,585,  0, 30,  0,582,  0,350, 30,  0,  1],
    [  1,342,  1,  1,  1,  1,342,  1,  1,  1,  1,586,  1],
    [  1,593,  1,537,569,  1,594,  1,569,537,  1,  0,  1],
    [  1,536,  1,569,537,  1,353,  1,537,569,  1, 30,  1],
    [  1,353,  1,595,  1,  1,536,  1,  1,596,  1,  0,  1],
    [  1,536,  1,342,342,342,353,342,342,342,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}