main.floors.MT114=
{
    "floorId": "MT114",
    "title": "通天塔 114 ",
    "name": "通天塔114",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,540,387,540,  4,540,387,540,  4,540,387,540,  4],
    [  4,387,391,387,  4,387,391,387,  4,387,391,387,  4],
    [  4,540,387,540,  4,540,387,540,  4,540,387,540,  4],
    [  4, 23,568, 23,  4, 23,568, 23,  4, 23,568, 23,  4],
    [  4,535,257,535,  4,535,257,535,  4,535,257,535,  4],
    [  4,  4,344,  4,  4,  4,344,  4,  4,  4,344,  4,  4],
    [  4, 30, 30, 30, 30,606,  0,606, 30, 30, 30, 30,  4],
    [  1,  1,  1,  1,  1,  1,344,  1,  1,  1,  1,  1,  1],
    [  1,  1,  0,617,381,617,  0,608,348,348,348,533,  1],
    [  1,  1,617,  1,343,  1,615,  1,  1,  1,  1,344,  1],
    [  1, 88,  0,615,381,  1,  0,608,348,348,348,533,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}