main.floors.MT225=
{
    "floorId": "MT225",
    "title": "通天塔 225 ",
    "name": "通天塔225",
    "width": 13,
    "height": 13,
    "canFlyTo": false,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000,
    "defaultGround": "ski",
    "bgm": "q.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": "MT224",
            "loc": [
                1,
                1
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,7": [
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        5
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        6
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        7
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        5
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        5
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        6
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        7
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "setBlock",
                "number": "I639",
                "loc": [
                    [
                        1,
                        11
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "setBlock",
                "number": "I639",
                "loc": [
                    [
                        6,
                        11
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "setBlock",
                "number": "I639",
                "loc": [
                    [
                        11,
                        11
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "setBlock",
                "number": "I639",
                "loc": [
                    [
                        11,
                        6
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "setBlock",
                "number": "I639",
                "loc": [
                    [
                        11,
                        1
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "setBlock",
                "number": "I456",
                "loc": [
                    [
                        6,
                        1
                    ]
                ],
                "floorId": "MT225"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        1,
                        6
                    ]
                ],
                "floorId": "MT225"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [824,824,824,824,824,824,824,824,824,824,824,824,824],
    [824, 88,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,824],
    [824,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,824],
    [824,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,824],
    [824,  0,  0,  0, 33, 33, 33, 33, 33,  0,  0,  0,824],
    [824,  0,  0,  0, 33,799,801,804, 33,  0,  0,  0,824],
    [824,  0,  0,  0, 33,798,800,803, 33,  0,  0,  0,824],
    [824,  0,  0,  0, 33,797,796,802, 33,  0,  0,  0,824],
    [824,  0,  0,  0, 33, 33, 33, 33, 33,  0,  0,  0,824],
    [824,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,824],
    [824,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,824],
    [824,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,824],
    [824,824,824,824,824,824,824,824,824,824,824,824,824]
],
    "bgmap": [

],
    "fgmap": [

]
}