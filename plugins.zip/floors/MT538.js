main.floors.MT538=
{
    "floorId": "MT538",
    "title": "通天塔 538 ",
    "name": "通天塔538",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT538_7_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT538_7_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,3": {
            "0": {
                "condition": "flag:door_MT538_7_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT538_7_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5],
    [  5, 88, 86, 86, 86, 86,  0,  0,  0,  5,  5,  5,  5],
    [  5,  0,  5,  5,  5,  5,1417,  0,1417,  5,  5,  5,  5],
    [  5,350,  5,  5,  5,  5,  5, 85,  5,  5,  5,  5,  5],
    [  5,  0,  5,1207,1207,1207,  5,  0,  5,1207,1207,1207,  5],
    [  5,350,  5,1207,1207,1363, 86,  0, 86,1363,1207,1207,  5],
    [  5,  0,  5,  5,  5,  5,  5,  0,  5,  5,  5,  5,  5],
    [  5,377,  5,1210,1210,1210,  5,  0,  5,1210,1210,1210,  5],
    [  5,  0,  5,1210,1210,1363, 86,  0, 86,1363,1210,1210,  5],
    [  5,377,  5,  5,  5,  5,  5,  0,  5,  5,  5,  5,  5],
    [  5,  0,  5,1216,1216,1216,  5,  0,  5,1216,1216,1216,  5],
    [  5, 87,  5,1216,1216,1363, 86,  0, 86,1363,1216,1216,  5],
    [  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5,  5]
],
    "bgmap": [

],
    "fgmap": [

]
}