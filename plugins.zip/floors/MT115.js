main.floors.MT115=
{
    "floorId": "MT115",
    "title": "通天塔 115 ",
    "name": "通天塔115",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,12": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT115_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT115_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT115_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT115_6_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,4": {
            "0": {
                "condition": "flag:door_MT115_6_4==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT115_6_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4, 87,  4,  4,  4,  4,  4,  4],
    [  4,540,535,540,  4,345,  0,345,  4,540,535,540,  4],
    [  4,535,537,535,  4,  0,636,  0,  4,535,537,535,  4],
    [  4,540,535,540,  4,345,  0,345,  4,540,535,540,  4],
    [  4,  0,257,  0,  4,  4, 85,  4,  4,  0,257,  0,  4],
    [  4,  4,343,  4,  4,607,  0,607,  4,  4,343,  4,  4],
    [  4,352,533,352,607,  0,639,  0,607,352,533,352,  4],
    [  1,  4,  4,  4,  4,607,  0,607,  4,  4,  4,  4,  1],
    [  1,564,608,564,  4,  4,344,  4,  4,564,608,564,  1],
    [  1,  4,  4,608,564,608,  0,608,564,608,  4,  4,  1],
    [  1,571,  4,  4,  4,  4,607,  4,  4,  4,  4,571,  1],
    [  1,344,538,565,539,343,  0,343,539,565,538,344,  1],
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}