main.floors.ML19=
{
    "floorId": "ML19",
    "title": "通天塔 19 ",
    "name": "地下19",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": "ML21",
            "loc": [
                1,
                11
            ]
        },
        "11,11": {
            "floorId": "ML21",
            "loc": [
                11,
                11
            ]
        },
        "11,1": {
            "floorId": "ML21",
            "loc": [
                11,
                1
            ]
        },
        "0,6": {
            "floorId": "ML20",
            "loc": [
                0,
                6
            ]
        },
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  1,385,385,384,384,387,526,  0,  0, 87,  1],
    [  1,  0,  1,  1,  1,  1,  1,342,  1,342,  1,342,  1],
    [  1,352,  1, 23,534, 23,  1,350,  1,348,  1,348,  1],
    [  1,514,  1,354,  1,  1,  1,  1,  1,349,  1,349,  1],
    [  1,352,  1,354,  1,  0,526,  0,  1,  1,  1,  1,  1],
    [ 87,  0,  1,527,342,350,  1,374,374,  0,514,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,374,  1],
    [  1,357,  1,387,354,387,  1,380,  1,364,  1,374,  1],
    [  1,357,  1,  0,527,  0,  1,374,  1,364,  1,  0,  1],
    [  1,520,  1,  1,342,  1,  1,521,  1,364,  1,516,  1],
    [  1, 87,  0,520,  0,364,364,364,  1,521,342, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}