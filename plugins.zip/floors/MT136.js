main.floors.MT136=
{
    "floorId": "MT136",
    "title": "通天塔 136 ",
    "name": "通天塔136",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": "MT137",
            "loc": [
                11,
                11
            ]
        },
        "1,11": {
            "floorId": "MT137",
            "loc": [
                1,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT136_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT136_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT136_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT136_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT136_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT136_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT136_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT136_6_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "6,8": [
            {
                "type": "setBlock",
                "number": "E667",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "MT136"
            },
            {
                "type": "setBlock",
                "number": "E667",
                "loc": [
                    [
                        6,
                        4
                    ]
                ],
                "floorId": "MT136"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_MT136_6_9==8",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT136_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,664,  0,  0,663,  0, 88,  0,663,  0,  0,663,639],
    [  1,  0,342,  1,  1,  1,342,  1,  1,  1,342,  0,  1],
    [  1,354,  1,567,566,672,  0,672,566,567,  1,353,  1],
    [  1,380,  4,  4,  4,  4,342,  4,  4,  4,  4,380,  1],
    [  1,354,  4,381,343,  0,571,  0,343,381,  4,353,  1],
    [  1,  0,  4,667,  0,663,  1,663,  0,667,  4,  0,  1],
    [  1,376,  4,  0,665,  4,  1,  4,665,  0,  4,376,  1],
    [  1,376,  4, 86,  4,  4,624,  4,  4, 86,  4,376,  1],
    [  1,376,  4,  0,664,  1, 85,  1,664,  0,  4,376,  1],
    [  1,663,  4,667,  0,666,  0,666,  0,667,  4,663,  1],
    [  1, 87,  4,381,343,  0,536,  0,343,381,  4, 87,  1],
    [  1,  1,  4,  4,  4,  4,  4,  4,  4,  4,  4,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}