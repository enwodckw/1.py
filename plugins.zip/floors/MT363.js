main.floors.MT363=
{
    "floorId": "MT363",
    "title": "通天塔 363 ",
    "name": "黑暗深渊363",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,639,639,639,1181, 86, 87,  4,1180,639,639,639,  4],
    [  4,  4,  4,  4,  4,  4,1160,  4, 86,  4,  4,  4,  4],
    [  4,  4,639,639,639,1186,  0,349,1183,639,639,639,  4],
    [639,639,  4,  4,  4,  4,  4,349,  4,  4,  4,  4,  4],
    [  4,639,  4,639,639,639,1185,  0,  4,639,  4,639,  4],
    [  4,1182,  4,  4,  4,  4,  4,1161,  4,639,  4,639,  4],
    [  4,  0, 86,570,  0,1187, 86,  0,  4,639,  4,639,  4],
    [  4,1184,  4,  0,639,  0,  4,349,  4,1190,  4,1191,  4],
    [  4,639,  4,639,  0,639,  4,349,  0,  0,1160,  0,  4],
    [  4,639,  4,  4,1188,  4,  4,  4,1189,  4,  4,  0,  4],
    [  4,639,  4,639,639,639,  4,639,639,639,  4, 88,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}