main.floors.MT245=
{
    "floorId": "MT245",
    "title": "通天塔 245 ",
    "name": "通天塔245",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 100000000,
    "defaultGround": "T836",
    "bgm": "q.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT245_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT245_6_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,4": {
            "0": {
                "condition": "flag:door_MT245_6_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT245_6_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [149,149,149,149,149,149,149,149,149,149,149,149,149],
    [149,348,348,149,149,  0,  0,  0,149,149,348,348,149],
    [149, 30, 30,149,149,  0,896,  0,149,149, 30, 30,149],
    [149, 30, 30,149,149,  0,  0,  0,149,149, 30, 30,149],
    [149,886, 30,149,149,149, 85,149,149,149, 30,886,149],
    [149,342,149,149,149,880,  0,880,149,149,149,342,149],
    [149,  0,  0,888, 33,  0,  0,  0, 33,888,  0,  0,149],
    [149,390,149,149,149,149,888,149,149,149,149,342,149],
    [149,390,343,366,366,885,  0,149,366,348,149, 33,149],
    [149,390,149,149,149,149,391,149,149,889,149, 33,149],
    [149,  0,885,359,359,343,  0,888,  0,  0,149, 33,149],
    [149, 87,149,149,149,149, 88,149,149,149,149,149,149],
    [149,149,149,149,149,149,149,149,149,149,149,149,149]
],
    "bgmap": [

],
    "fgmap": [

]
}