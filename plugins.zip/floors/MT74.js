main.floors.MT74=
{
    "floorId": "MT74",
    "title": "通天塔 74 ",
    "name": "通天塔74",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 48,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "5,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 28, 28,486,342,  0, 88,  0,342,486,  0, 21,  1],
    [  1,  0, 28, 28,  1, 21,  0, 21,  1, 21, 21,  0,  1],
    [  1,487,  1,  1,  1,  1,343,  1,  1,  1,  1,487,  1],
    [  1,  0, 30,  0,342, 27,  0, 27,472, 28, 30,  0,  1],
    [  1,  1,472,  1,  1,  0, 30,  0,342,486,  0, 28,  1],
    [  1,488, 33, 33,  1,486,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  1,328,  1,  0,472, 21, 21,342, 21, 21,  1],
    [  1, 21,  1,  1,  1,349,  1,488, 21,  1, 21,488,  1],
    [  1,360,  0,486,  1,  0,  1,342,  1,  1,  1,342,  1],
    [  1,  0,487,  0,  1,487,  1, 33, 33,  1, 33, 33,  1],
    [  1,342,  0,367,343,  0,342,487,  0,342,487, 21,  1],
    [  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}