main.floors.ML15=
{
    "floorId": "ML15",
    "title": "通天塔 15 ",
    "name": "地下15",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML15_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_ML15_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML15_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_ML15_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,0": [
            {
                "type": "setBlock",
                "number": "E530"
            },
            "\t[绿魔王,E530]本座在这个位置呆的太久了，抓住了你，我就能够升职，去往更高的区域，小子我会好好感谢你的，来年我会给你烧点好酒，哈哈哈",
            "\t[hero]高兴的太早了,我…",
            {
                "type": "animate",
                "name": "zone"
            },
            "\t[绿魔王,E530]怎么可能,你竟然有防备！",
            "\t[hero]对付我还需要偷袭,都是这么废物的吗",
            "\t[绿魔王,E530]可恶,我不信",
            {
                "type": "battle",
                "id": "E530"
            },
            "\t[绿魔王,E530]怎么会这样………主人看到了吗？当初你的不在意让他成长到这个地步,我不甘心啊,现在不除掉他，后患无穷…啊",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        0
                    ]
                ],
                "floorId": "ML15"
            },
            {
                "type": "changePos",
                "loc": [
                    6,
                    1
                ],
                "direction": "down"
            },
            "\t[hero]好险啊，这是？",
            {
                "type": "jumpHero",
                "loc": [
                    0,
                    0
                ],
                "time": 500
            },
            {
                "type": "setHeroOpacity",
                "opacity": 0
            },
            {
                "type": "setBlock",
                "number": "E403",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "ML15"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[塔灵卫,E403]嗯？不见了？这小子难道能够提前预料？这绿魔王看气息刚死不久，不能让他跑了",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "ML15"
            },
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "setHeroOpacity",
                "opacity": 1
            },
            {
                "type": "jumpHero",
                "loc": [
                    6,
                    2
                ],
                "time": 500
            },
            "\t[hero]看样子应该是塔灵派人来抓我了，时间紧迫，赶快走吧"
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,3": {
            "0": {
                "condition": "flag:door_ML15_6_3==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML15_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,531,  1,  1,  1,  1,  1,  1],
    [  1,387,  1,  1,  0,  0,  0,  0,  0,  1,  1,387,  1],
    [  1,387, 85, 85,  0,  0,  0,  0,  0, 85, 85,387,  1],
    [  1,386,  1,  1,  1,  1, 85,  1,  1,  1,  1,386,  1],
    [  1,386,  1,  1,  1,532,  0,532,  1,  1,  1,386,  1],
    [  1,385,  1,  1,  1,  0,  0,  0,  1,  1,  1,384,  1],
    [  1,385,  1,  1,  1,532,  0,532,  1,  1,  1,384,  1],
    [  1,  1,  1,  1,  1,  1,344,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,344,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,344,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,344,  1,  1,  1,  1,  1,  1],
    [  1, 88, 85, 85, 85, 85,390,390,537,390,390, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}