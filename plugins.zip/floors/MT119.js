main.floors.MT119=
{
    "floorId": "MT119",
    "title": "通天塔 119 ",
    "name": "通天塔119",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,7": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,652,358,358,358,  1,637,  1,652, 22, 47, 22,  1],
    [  1,342,  1,  1,  1,  1,571,344,342,  1,  1,390,  1],
    [  1,365,365,365,650,  1,645,  1,343,  1,  1,387,  1],
    [  1,  1,  1,  1,342,  1,343,  1,342,  1,  1,390,  1],
    [  1,368,361,646,  0,647,  0,647,  0,648, 23,538,  1],
    [  1,  1,  1,  1,  1,  1,641,  1,  1,  1,  1,  1,  1],
    [  1,641,361,368,375,  1, 88,  1,640,354, 47,621,  1],
    [  1,342,  1,  1,  1,  1,  0,  1,342,  1,  1,  1,  1],
    [  1,  0,381,  0,640,342,  0,342,  0,650,  0,350,  1],
    [  1,342,  1,  1,  1,  1,608,  1,  1,472,  1,343,  1],
    [  1,641,361,368,375,  1, 87,  1,375,375,382,640,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}