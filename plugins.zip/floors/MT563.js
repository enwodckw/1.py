main.floors.MT563=
{
    "floorId": "MT563",
    "title": "通天塔 563 ",
    "name": "通天塔563",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "2,10": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,536,  1, 21, 21,389,389,389,  1,391,  1],
    [  1,  0,1427,  0,  1, 21,1428,388,388,388,  1,538,  1],
    [  1,  1,343,  1,  1,  1,342,  1,  1,  1,  1,1429,  1],
    [  1,351,351,343,  0,  1,  0,342,1428,  0,391,  0,  1],
    [  1,351,351,1427,  0,  1,1420,  1,  1,  1,  1,1429,  1],
    [  1,  1,  1,  1,1420,  0,  0,1422,  0,1360,  1,538,  1],
    [  1,351,351,  1,342,1426,343,  1,536,  0,  1,391,  1],
    [  1,351,351,  1,342,1426,343,  1,  1,  1,  1,  1,  1],
    [  1,1426,  1,  1,351,351,351,351,  1,1422,1360,536,  1],
    [  1,  0, 88,  0,  0,  1,  1,  1,  1,342,  1,  1,  1],
    [  1, 30, 30, 30, 30,342,1427,  0,538,  0,1430,537,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}