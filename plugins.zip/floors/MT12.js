main.floors.MT12=
{
    "floorId": "MT12",
    "title": "通天塔 12 ",
    "name": "通天塔12",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 31, 30, 31,  1,357,348,364,  1, 30, 31,  0,  1],
    [  1,342,  1, 21,  1, 21,221, 21,  1, 31,  0,225,  1],
    [  1,343,  1,224,  1,  1,343,  1,  1,  1,  1,342,  1],
    [  1,  0,215,  0,  0,  0,214,  0,  0,342,218,  0,  1],
    [  1,342,  1,  1, 31,  1,344,  1, 31,  1, 22, 33,  1],
    [  1,220, 27,  1,  0,  1, 35,  1,  0,  1,343,  1,  1],
    [  1, 27, 33,  1,214,  1,343,  1,214,  1, 29, 22,  1],
    [  1,343,  1,  1,  0,  1,343,  1,  0,342,215, 29,  1],
    [  1,  0, 28,  1, 31,  1,343,  1, 31,  1,  1,  1,  1],
    [  1, 28,  0,  1,  0,217, 33,217,  0,  1,  0, 33,  1],
    [  1,  0,215,343,  0,  1, 88,  1,  0,342,217,  0, 87],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}