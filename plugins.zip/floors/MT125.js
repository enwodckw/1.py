main.floors.MT125=
{
    "floorId": "MT125",
    "title": "通天塔 125 ",
    "name": "通天塔125",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,379,355,379,  1,349,652,359,349,359,649,637,  1],
    [  1,374,642,374,  1, 21,  1,343,  1,  1,  1,  1,  1],
    [  1,  1,342,  1,  1, 21,  1, 21, 21,349,359,652,  1],
    [  1,379,355,379,  1, 21,  1, 21,  1,  1,  1,343,  1],
    [  1,374,643,374,  1,648,  1,648,  1,374,374,374,  1],
    [  1,  1,342,  1,  1,342,  1,342,  1,641,343,647,  1],
    [  1,641,  0,  0,647,  0,354,  0,647,  0,354,  0,  1],
    [  1, 21,  1,  1,  1,642,  1,  1,  1,  1,  1,647,  1],
    [  1,354,342,643,  1,379,  1,381,  1,381,343,  0,  1],
    [  1,  0,  1,379,  1,  1,  1,355,  1,355,  1, 22,  1],
    [  1, 88,  1,379,342, 33,603,649,342,649,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}