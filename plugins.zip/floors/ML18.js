main.floors.ML18=
{
    "floorId": "ML18",
    "title": "通天塔 18 ",
    "name": "地下18",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,2": [
            {
                "type": "setValue",
                "name": "flag:door_ML18_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,2": [
            {
                "type": "setValue",
                "name": "flag:door_ML18_6_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,3": {
            "0": {
                "condition": "flag:door_ML18_6_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML18_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,  0,519,  0,  0,  0,519,  0,  0, 88,  1],
    [  1,342,  1,342,  1,527,  0,527,  1,  1,  1,519,  1],
    [  1,524,  1,525,  1,  1, 85,  1,  1,353,  1,  0,  1],
    [  1,359,  1,  0,  1,539,  0,539,  1,343,  1,  0,  1],
    [  1,359,343,365,  1,  0,536,  0,  1,  0,342,524,  1],
    [  1,  1,  1,365,  1,539,  0,539,  1,525,  1,379,  1],
    [  1,523,  0,365,  1,  1,  1,  1,  1,365,  1,379,  1],
    [  1,  0,  1,343,344, 22,  1,351,  1,365,  1,  1,  1],
    [  1,359,  1,353,  1,537,  1,522,342,365,342,523,  1],
    [  1,353,  1,  1,  1, 22,  1,343,  1,  1,  1, 47,  1],
    [  1,  0,529,540, 21, 21,  1,349,350,349,  1,353,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}