main.floors.MT463=
{
    "floorId": "MT463",
    "title": "通天塔 463 ",
    "name": "通天塔463",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT463_8_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT463_8_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "8,8": {
            "0": {
                "condition": "flag:door_MT463_8_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT463_8_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,342, 30,342, 30,  1, 31, 86,1323, 29,377,  1],
    [  1,  0,  1,343,  1,343,  1, 31,  1,  1,  1,  1,  1],
    [  1,1316,  1,365,  1,365,  1, 31,  1,343,343,358,  1],
    [  1,  0,  1,  1,  1,  1,  1,1323,  1,343,  1,358,  1],
    [  1, 32, 86,  0,1319,  0, 86,  0,342, 27,  1, 33,  1],
    [  1,  0,  1,1321,  1,343,  1,  0,  1,  0,344,365,  1],
    [  1,1316,342,363,  1, 33,  1,1319,  0,1319,  1,365,  1],
    [  1, 86,  1,  1,  1,  1,  1,  1, 85,  1,  1,1327,  1],
    [  1, 27,  0,1318,  0,  1, 33,1324,  0, 22, 27,  0,  1],
    [  1,343,  1,  1, 22,344,380,  1,  1,  1,  1,342,  1],
    [  1, 87,377,1318,  0,  1, 33,  1, 30, 30, 30,1325,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}