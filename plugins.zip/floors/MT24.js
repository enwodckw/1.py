main.floors.MT24=
{
    "floorId": "MT24",
    "title": "通天塔 24 ",
    "name": "通天塔24",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,4": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "0,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT24_1_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT24_1_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "1,10": {
            "0": {
                "condition": "flag:door_MT24_1_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT24_1_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 87,  1],
    [  1,383,  0, 23,  0,222,  0,222,349,390,164,  0,  1],
    [  1,  0,  1,  1,  1,  1,342,  1,  1,  1,  1,233,  1],
    [  1,344,  1,233,  0,349,  0, 28,  0, 21,342,  0,  1],
    [  1, 88,  0,  0,  1,342,  1,  1,237,  1,  1,239,  1],
    [  1, 86,  1,237,  0, 27,  0,233,  0, 28, 32,  0,  1],
    [  1, 86,  1,  1,  1,342,  1,  1,  1,  1,  1,342,  1],
    [222,  0,222,  1,  0,240,  0,  1,359,  0,348,234,  1],
    [  1,  0,  0,  1,348,  0,348,  1,  0,366,  0,  0,  1],
    [ 27, 27, 27,  1,342,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 85,  1,  1,247,  0,366,  1, 34,  1, 33, 33,  1],
    [ 34,378, 34,  1,  0,348,  0,235, 34,342,240, 33,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}