main.floors.MT515=
{
    "floorId": "MT515",
    "title": "通天塔 515 ",
    "name": "通天塔515",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,11": {
            "floorId": "MT516",
            "loc": [
                11,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 34,  0,377,1380,  0, 88,  0,1380,377,  0, 34,  1],
    [  1,342,  1,  1,  1,  1, 34,  1,  1,  1,  1,342,  1],
    [  1,1381,363,363,363,  1,  0,  1,356,356,356,1381,  1],
    [  1,  1,  1,  1,  1,  1,1380,  1,  1,  1,  1,  1,  1],
    [  1,  0, 32, 21,  0,1379,  0,1379,  0,351, 21,  0,  1],
    [  1,1377,  1,  1,  1,  1,343,  1,  1,  1,  1,1381,  1],
    [  1,  0,  1,379, 22,1382,  0,1382, 22,379,  1,  0,  1],
    [  1, 30,  1, 31,  1,  1,  1,  1,  1, 31,  1, 32,  1],
    [  1, 30,  1, 31,  1,383,  1,383,  1, 31,  1, 32,  1],
    [  1, 30,  1, 31,  1,472,  1,472,  1, 31,  1, 32,  1],
    [  1, 87,  1,1388, 23,382,  1,382, 23,1388,  1, 93,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}