main.floors.MN12=
{
    "floorId": "MN12",
    "title": "通天塔 MN12 ",
    "name": "黑暗深渊深处MN12",
    "width": 13,
    "height": 13,
    "canFlyTo": false,
    "canFlyFrom": false,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 700000000000,
    "defaultGround": "ground",
    "bgm": "boss.mp3",
    "firstArrive": [
        {
            "type": "setEnemy",
            "id": "E1312",
            "name": "special",
            "value": "2"
        },
        {
            "type": "setEnemy",
            "id": "E1312",
            "name": "exp",
            "value": "3500000"
        },
        "\t[hero]好强大的压迫感,这里应该是黑暗深渊的尽头了吧！"
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,5": [
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "move",
                "loc": [
                    6,
                    1
                ],
                "time": 50,
                "keep": true,
                "steps": [
                    "down:1"
                ]
            },
            "\t[深渊之主,E1314]就是你小子把我的地盘闹的天翻地覆,就是不知道你能不能拿得出赔偿的东西",
            "\t[hero]杀人者,人恒杀之,凡是阻挡我的脚步者,格杀勿论",
            "\t[深渊之主,E1314]好大的口气，给你一个活命的机会，交出王座境宝藏图纸，我就饶了你，怎么样，杀了我这么多手下，一张图纸不介意吧？",
            "\t[hero]想要图纸就直说，用不着拐弯抹角",
            "\t[深渊之主,E1314]好，够爽快,今天你有两个选择,要么留下图纸,放你离去，反之埋骨于此，选一个吧？",
            "\t[hero]我选第三个",
            "\t[深渊之主,E1314]第三个？",
            "\t[hero]那就是要你命",
            {
                "type": "moveHero",
                "time": 100,
                "steps": [
                    "up:2"
                ]
            },
            {
                "type": "battle",
                "id": "E1314"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[深渊之主,E1314]好不要脸,竟然偷袭,我…我…做鬼都不会放过你的",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "MN12"
            },
            "\t[hero]好险啊",
            "\t[hero]该死又有危险",
            {
                "type": "moveHero",
                "time": 100,
                "steps": [
                    "down:1"
                ]
            },
            {
                "type": "changePos",
                "loc": [
                    6,
                    4
                ],
                "direction": "up"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[塔灵卫,E403]果然都是一群废物",
            {
                "type": "setBlock",
                "number": "E403",
                "loc": [
                    [
                        6,
                        3
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "setBlock",
                "number": "E404",
                "loc": [
                    [
                        5,
                        3
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "setBlock",
                "number": "E404",
                "loc": [
                    [
                        7,
                        3
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "setBlock",
                "number": "E404",
                "loc": [
                    [
                        7,
                        5
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "setBlock",
                "number": "E404",
                "loc": [
                    [
                        5,
                        5
                    ]
                ],
                "floorId": "MN12"
            },
            "\t[hero]又是你们,还真是阴魂不散",
            "\t[塔灵卫,E403]让你活的太久了,一而再再而三的从我手里逃走,这次你就留下吧",
            "\t[梦云,E605]此人我保了",
            {
                "type": "setBlock",
                "number": "E605",
                "loc": [
                    [
                        7,
                        2
                    ]
                ],
                "floorId": "MN12"
            },
            "\t[塔灵卫,E403]该死,此处怎么会出现真主境高手",
            "\t[塔灵卫,E403]前辈,我等奉命行事,还望前辈行个方便",
            "\t[梦云,E605]我说此人我保了，听不懂吗？",
            "\t[塔灵卫,E403]这…前辈我等并不想与你为敌,希望前辈不要插手此事,否则我家主人定会追杀尔等",
            "\t[梦云,E605]呵呵,你在拿塔灵压我？一个叛徒而已，真以为我会怕他？",
            "\t[塔灵卫,E403]这…",
            "\t[任永似,E975]你们退下吧",
            {
                "type": "setBlock",
                "number": "E975",
                "loc": [
                    [
                        5,
                        2
                    ]
                ]
            },
            "\t[塔灵卫,E403]参见队长",
            "\t[任永似,E975]你们走吧,这里不是你们可以插手的了",
            "\t[塔灵卫,E403]遵命",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        3
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        3
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        3
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        5
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        5
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[任永似,E975]梦云,好久不见，想不到你还活着，并且实力未减当年",
            "\t[梦云,E605]我当是谁？原来是你",
            "\t[梦云,E605]当初主人对你不薄,我原以为你在当年那一战战死了，想不到你也做了叛徒，成了塔灵的走狗",
            "\t[任永似,E975]当初当我发现塔灵的意图时，为时已晚，我是第一个被塔灵控制的人，迫不得已,只能背叛主人",
            "\t[梦云,E605]别以为三言两语就可以打消欺师灭祖之事,紫薇圣宫当时何等的强大，如果不是你们关键时刻反水，圣宫怎么会被灭掉",
            "\t[任永似,E975]今天不想与你为敌，既然你决定保下他,塔灵日后绝对会找上你",
            "\t[梦云,E605]你就是不说，我也会灭掉塔灵这个叛徒",
            "\t[任永似,E975]言尽于此,另外告诉你一句,塔灵远比你想象的要强大，咱们作为多年的老朋友，我并不希望你将来会陨落，还是在我面前，我能说的就是这么多,告辞",
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        2
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[hero]前辈，又见到你了",
            "\t[梦云,E605]是啊，上次一别已有数月，你都已经成长起来了",
            "\t[hero]前辈过奖了，前辈为何不杀了他们，也好斩断塔灵的左膀右臂",
            "\t[梦云,E605]我不是他的对手，如果今天不是我和他是旧识，你我今天都得交代与此了",
            "\t[hero]这…",
            "\t[梦云,E605]你不用灰心,你的成长空间还很充足，相信以我的面子，他暂时不会对你动手，我的能量不多了，如果器灵能帮我找到重铸肉身的东西，我或许还能真身降临，届时我也不怕他了",
            "\t[hero]器灵一定会找到的，塔灵狼子野心，注定会失败",
            "\t[梦云,E605]走了",
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        2
                    ]
                ],
                "floorId": "MN12"
            },
            "\t[hero]送前辈",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        5
                    ]
                ],
                "floorId": "MN12"
            },
            {
                "type": "openDoor",
                "loc": [
                    5,
                    1
                ],
                "floorId": "MN12"
            },
            {
                "type": "openDoor",
                "loc": [
                    7,
                    1
                ],
                "floorId": "MN12"
            }
        ],
        "6,0": [
            {
                "type": "if",
                "condition": "(item:greenKey===1000)",
                "true": [
                    {
                        "type": "setValue",
                        "name": "status:hp",
                        "value": "1"
                    },
                    {
                        "type": "setValue",
                        "name": "status:hp",
                        "operator": "+=",
                        "value": "item:yellowKey*10000+item:pickaxe*640000+item:blueKey*40000+item:redKey*160000"
                    },
                    {
                        "type": "win",
                        "reason": "快乐成仙(450F)"
                    }
                ],
                "false": [
                    {
                        "type": "if",
                        "condition": "(item:greenKey===0)",
                        "true": [
                            {
                                "type": "setValue",
                                "name": "status:hp",
                                "value": "1"
                            },
                            {
                                "type": "win",
                                "reason": "没有榜单"
                            }
                        ],
                        "false": [
                            {
                                "type": "setValue",
                                "name": "status:hp",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "status:hp",
                                "operator": "+=",
                                "value": "item:greenKey*500000+item:pickaxe*200000"
                            },
                            {
                                "type": "win",
                                "reason": "作弊成仙(450F)"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "7,0": {
            "floorId": "MT456",
            "loc": [
                6,
                1
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MN12_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MN12_6_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,6": {
            "0": {
                "condition": "flag:door_MN12_6_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MN12_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,568,342, 56,  4,  4, 89, 87,  4, 56,342,568,  4],
    [  4,342,  4,  4,602, 85,1314, 85,602,  4,  4,342,  4],
    [  4,567,  4,  4, 85,  0,  0,  0, 85,  4,  4,567,  4],
    [  4,342,566,342,  4,  0,  0,  0,  4,342,566,342,  4],
    [  4,  4,  4,565,  4,  0,  0,  0,  4,565,  4,  4,  4],
    [  4,569,  4,342,  4,  0,  0,  0,  4,342,  4,569,  4],
    [  4,569,  4,564,  4,  4, 85,  4,  4,564,  4,569,  4],
    [  4,343,  4,342,  4,1312,  0,1312,  4,342,  4,343,  4],
    [  4,  0,570,  0,570,  0,  0,  0,570,  0,570,  0,  4],
    [  4,343,  4,344,  4,  4,344,  4,  4,344,  4,343,  4],
    [  4,571,  4,571,  4,602,1226,602,  4,571,  4,571,  4],
    [  4,343,  4,571,  4, 23,  0, 23,  4,571,  4,343,  4],
    [  4,571,  4,571,  4,603,571,603,  4,571,  4,571,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}