main.floors.MT165=
{
    "floorId": "MT165",
    "title": "通天塔 165 ",
    "name": "通天塔165",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150000,
    "defaultGround": "grass",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,8": [
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        6
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        7
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        8
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        7
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        6
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        7
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        8
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "openDoor",
                "loc": [
                    6,
                    5
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        9,
                        1
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        9,
                        3
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        9,
                        5
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        9,
                        7
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        9,
                        9
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        11,
                        9
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        11,
                        7
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        11,
                        5
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        11,
                        3
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "I571",
                "loc": [
                    [
                        11,
                        1
                    ]
                ],
                "floorId": "MT165"
            },
            {
                "type": "setBlock",
                "number": "superPotion",
                "loc": [
                    [
                        6,
                        7
                    ]
                ],
                "floorId": "MT200"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20, 87,342,355,  4,  4,  4,  4,  4,391, 20,391, 20],
    [ 20,691, 20,342,  4,639,  0,639,  4,566, 20,566, 20],
    [ 20,568, 20,355,  4,  0,478,  0,  4,391, 20,391, 20],
    [ 20,372, 20,342,  4,639,  0,639,  4,679, 20,679, 20],
    [ 20,382,691,  0,  4,  4, 85,  4,  4,382, 20,382, 20],
    [ 20, 20, 20,356,  4,735,740,738,  4,566, 20,566, 20],
    [ 20,388, 20,356,  4,734,739,737,  4,382, 20,382, 20],
    [ 20,388, 20,356,  4,733,732,736,  4,681, 20,681, 20],
    [ 20,389, 20,  0,  4,  4,344,  4,  4,342, 20,342, 20],
    [ 20,389, 20,688,342,  0,692,  0,342,688,  0,  0, 20],
    [ 20,678,342,  0, 20,379,343,379, 20,  0,  0, 88, 20],
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20]
],
    "bgmap": [

],
    "fgmap": [

]
}