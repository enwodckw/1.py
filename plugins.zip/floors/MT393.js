main.floors.MT393=
{
    "floorId": "MT393",
    "title": "通天塔 393 ",
    "name": "黑暗深渊393",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT393_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT393_6_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_MT393_6_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT393_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,1226,1150,1226,1150,1224, 87,1224,1150,  0,539,  0,1150],
    [1150, 22,1150, 22,1150,  0,1189,  0,1150, 22,1226, 22,1150],
    [1150,539,1150,539,1150,1190,  0,1190,1150,  0,1186,  0,1150],
    [1150,1186,1186,1186,1150,1150,343,1150,1150,1150,343,1150,1150],
    [1150,1150,342,1150,1150,571,  0,571,1150,1222,  0,1222,1150],
    [1150,354,354,354,1188,  0,1217,  0,1150,342,1187,342,1150],
    [1150,1150,1150,1150,1150,1190,  0,1190,344,  0,  0,  0,1150],
    [1150,354,391,391,1150,1150, 85,1150,1150,1209,1150,1187,1150],
    [1150,1188,391,391,1150,1185,  0,1185,1150,  0,1150,538,1150],
    [1150,342,1150,1150,1150,  0,1150,  0,1150,1183,1150,538,1150],
    [1150, 88,  0,  0,342,391,  0,391,343,  0,1150,538,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}