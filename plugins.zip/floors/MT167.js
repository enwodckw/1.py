main.floors.MT167=
{
    "floorId": "MT167",
    "title": "通天塔 167 ",
    "name": "通天塔167",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150000,
    "defaultGround": "grass",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "3,12": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [685, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20,685],
    [ 20,  0,380,  0, 20,  0,655,  0,  0,654,  0,  0, 20],
    [ 20,686, 20,686, 20,  0,  4,  4,  4,  4, 20,691, 20],
    [ 20, 30, 20, 30, 20,688,  4,564,342,  0, 20,  0, 20],
    [ 20,  0, 20,  0, 20,  0,  4,639,  4,656, 20,  0, 20],
    [ 20, 30, 20, 30, 20,  0,  4,639,  4,  0, 20,690, 20],
    [ 20,684, 20,684, 20,678,  4,639,  4,  0, 20,  0, 20],
    [ 20, 30, 20, 30, 20,  0,  4,564,  4,681, 20,  0, 20],
    [ 20,  0, 20,  0, 20,  0,  4,  4,  4,  0, 20,692, 20],
    [ 20, 30, 20, 30, 20,679,  0,  0,680,  0, 20,  0, 20],
    [ 20,683, 20,683, 20, 20, 20, 20, 20, 20, 20,  0, 20],
    [ 20,  0,343,  0,  0,693,  0,  0,694,  0,  0,695, 20],
    [ 20, 87, 20, 88, 20, 20, 20, 20, 20, 20, 20, 20,685]
],
    "bgmap": [

],
    "fgmap": [

]
}