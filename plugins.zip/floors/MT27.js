main.floors.MT27=
{
    "floorId": "MT27",
    "title": "通天塔 27 ",
    "name": "通天塔27",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "8,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT27_7_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT27_7_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT27_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT27_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT27_2_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT27_2_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT27_8_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT27_8_5",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,10": {
            "0": {
                "condition": "flag:door_MT27_7_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT27_7_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "4,10": {
            "0": {
                "condition": "flag:door_MT27_4_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT27_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,5": {
            "0": {
                "condition": "flag:door_MT27_2_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT27_2_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,5": {
            "0": {
                "condition": "flag:door_MT27_8_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT27_8_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 22,349, 22,223,  0,223,  0,349, 47,  0,342,  1],
    [  1,  1,  1,  1,  1, 33,  1,  1,  1,  1,  1,343,  1],
    [  1,  0,349,  0,  1, 33,  1,  0,349,  0,  1, 33,  1],
    [  1,359, 21,373,  1, 33,  1,373, 21,366,  1, 33,  1],
    [  1,  1, 85,  1,  1,247,  1,  1, 85,  1,  1,247,  1],
    [  1,234,  0,234,  1,342,  1,232,  0,232,  1,342,  1],
    [  1,  0,  0,  0, 86,235, 86,  0,  0,  0, 86,  0,  1],
    [  1,  1,343,  1,  1,  1,  1,  1,  1,  1,  1,237,  1],
    [  1, 27,  0, 28,  1,233,  0,  1,233,  0,  1,  0,  1],
    [  1,  0,252,  0, 85,  0,  0, 85,  0,348,342,  0,  1],
    [  1, 87,  0, 30,  1,233,  0,  1,233,  0,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}