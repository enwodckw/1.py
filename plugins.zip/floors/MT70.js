main.floors.MT70=
{
    "floorId": "MT70",
    "title": "通天塔 70 ",
    "name": "通天塔70",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 24,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,5": [
            {
                "type": "if",
                "condition": "(flag:70>=3)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ],
                        "floorId": "MT70"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:70",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,5": [
            {
                "type": "if",
                "condition": "(flag:70>=3)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ],
                        "floorId": "MT70"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:70",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "5,7": [
            {
                "type": "if",
                "condition": "(flag:70>=3)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ],
                        "floorId": "MT70"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:70",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,7": [
            {
                "type": "if",
                "condition": "(flag:70>=3)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ],
                        "floorId": "MT70"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:70",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {
        "6,8": [
            "\t[redKing]哈哈还真被大人猜中了，果然还有一条漏网之鱼，这次看你往哪里跑",
            "\t[hero]塔灵的走狗，今天就让我送你下地狱去吧",
            "\t[redKing]那就去死吧，杀了他",
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "move",
                "loc": [
                    6,
                    6
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "up:5"
                ]
            },
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        6,
                        10
                    ]
                ],
                "floorId": "MT70"
            },
            {
                "type": "setBlock",
                "number": "E394",
                "loc": [
                    [
                        5,
                        5
                    ]
                ],
                "floorId": "MT70"
            },
            {
                "type": "setBlock",
                "number": "E394",
                "loc": [
                    [
                        5,
                        7
                    ]
                ],
                "floorId": "MT70"
            },
            {
                "type": "setBlock",
                "number": "E394",
                "loc": [
                    [
                        7,
                        7
                    ]
                ],
                "floorId": "MT70"
            },
            {
                "type": "setBlock",
                "number": "E394",
                "loc": [
                    [
                        7,
                        5
                    ]
                ],
                "floorId": "MT70"
            }
        ],
        "6,2": [
            "\t[redKing]小看你了,死",
            {
                "type": "battle",
                "id": "redKing"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        1
                    ]
                ],
                "remove": true
            }
        ]
    },
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1],
    [  1,374,377,377,377, 86,  0, 86,377,377,377,374,  1],
    [  1,  1,  1,  1,  1,  1, 86,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1,  1],
    [  1, 31, 31,  1,  1,  1, 86,  1,  1,  1, 31, 31,  1],
    [  1, 31, 30,  1,  1,  0,  0,  0,  1,  1, 30, 31,  1],
    [  1,  1,342,  1,  1,  0,245,  0,  1,  1,342,  1,  1],
    [  1, 32, 32,  1,  1,  0,  0,  0,  1,  1, 32, 32,  1],
    [  1,377, 32,  1,  1,  1, 86,  1,  1,  1, 32,377,  1],
    [  1,343,  1,  1,  1,  1,344,  1,  1,  1,  1,343,  1],
    [  1, 30, 21, 21,  1,  0,  0,  0,  1, 21, 21, 30,  1],
    [  1, 30, 30,471, 86,  0, 88,  0, 86,471, 30, 30,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}