main.floors.MT539=
{
    "floorId": "MT539",
    "title": "通天塔 539 ",
    "name": "通天塔539",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT539_7_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT539_7_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,3": {
            "0": {
                "condition": "flag:door_MT539_7_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT539_7_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
    [ 15, 87, 86, 86, 86, 86,  0,  0,  0, 15, 15, 15, 15],
    [ 15,  0, 15, 15, 15, 15,1418,  0,1418, 15, 15, 15, 15],
    [ 15,353, 15, 15, 15, 15, 15, 85, 15, 15, 15, 15, 15],
    [ 15,  0, 15,1208,1208,1208, 15,  0, 15,1208,1208,1208, 15],
    [ 15,353, 15,1208,1208,1364, 86,  0, 86,1364,1208,1208, 15],
    [ 15,  0, 15, 15, 15, 15, 15,  0, 15, 15, 15, 15, 15],
    [ 15,377, 15,1211,1211,1211, 15,  0, 15,1211,1211,1211, 15],
    [ 15,  0, 15,1211,1211,1364, 86,  0, 86,1364,1211,1211, 15],
    [ 15,377, 15, 15, 15, 15, 15,  0, 15, 15, 15, 15, 15],
    [ 15,  0, 15,1217,1217,1217, 15,  0, 15,1217,1217,1217, 15],
    [ 15, 88, 15,1217,1217,1364, 86,  0, 86,1364,1217,1217, 15],
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15]
],
    "bgmap": [

],
    "fgmap": [

]
}