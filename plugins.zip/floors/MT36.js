main.floors.MT36=
{
    "floorId": "MT36",
    "title": "通天塔 36 ",
    "name": "通天塔36",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "0,2": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  1, 88,345,381,354,  4, 21, 22, 21,  4, 21, 22, 21],
    [ 87,  0,343,  4,  4,  4,  4,345,  4,  4,  4,345,  4],
    [  1,  0,260,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,344,  1,  1,  1,  1,  1,  1],
    [  1,  0, 28,  0, 28,  0,415,  0, 27,  0, 27,  0,  1],
    [  1, 28,  1,  1,  1,  1, 86,  1,  1,  1,  1, 27,  1],
    [  1,  0,  1,  1,  1,  1,415,  1,  1,  1,  1,  0,  1],
    [  1, 30,348,  1,348,378, 86,378,348,  1,348, 30,  1],
    [  1,  1,  1,  1,  1,  1,415,  1,  1,  1,  1,  1,  1],
    [  1,348,  0,  0,348,  0,349,  0,348,  0,  0,348,  1],
    [  1,  1,344,  1,  1,  1,344,  1,  1,  1,344,  1,  1],
    [  1, 21,379, 22,  1, 21,379, 22,  1, 21,379, 22,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}