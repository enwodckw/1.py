main.floors.MT513=
{
    "floorId": "MT513",
    "title": "通天塔 513 ",
    "name": "通天塔513",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT513_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT513_6_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,7": {
            "0": {
                "condition": "flag:door_MT513_6_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT513_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88, 30, 30,342,1377, 31, 31,343,1378, 31, 31,  1],
    [  1,  0, 30, 30,  1, 31, 31, 31,  1, 31, 31, 31,  1],
    [  1,1377,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0, 32,  0,  1, 31,  0, 31,  1,  0,1384,  0,  1],
    [  1,  1,  1,1378,  1,  0,1226,  0,  1,357,  1,358,  1],
    [  1,  0, 30,  0,  1, 31,  0, 31,  1,  0,  1,  0,  1],
    [  1, 30,  0, 30,  1,  1, 85,  1,  1,1381,  1,1381,  1],
    [  1,  1,1377,  1,  1,  0,1379,  0,  1,  0,  1,372,  1],
    [  1, 30,  0, 34,  1,1378,  0,1378,  1,357,  1,379,  1],
    [  1, 30,  1,1380,  1,  1,342,  1,  1,  0,  1,372,  1],
    [  1, 30,343,  0, 33,  0, 87,  0,343,1383,  1,603,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}