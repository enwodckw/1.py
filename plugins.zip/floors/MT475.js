main.floors.MT475=
{
    "floorId": "MT475",
    "title": "通天塔 475 ",
    "name": "通天塔475",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT475_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT475_6_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,4": {
            "0": {
                "condition": "flag:door_MT475_6_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT475_6_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 32, 23, 32,  0,1329,  0,1329,  0, 32, 23, 32,  1],
    [  1, 47,  1,  1,  1,  1,342,  1,  1,  1,  1,343,  1],
    [  1,391,  1, 30, 31,1326,  0,1326, 31, 31,  1, 31,  1],
    [  1,344,  1,378,  1,  1, 85,  1,  1,  1,  1, 31,  1],
    [  1, 34,344, 30,  1,1327,  0,1327,  1,349,  1, 31,  1],
    [  1,1324,  1,  1,  1,  1, 86,  1,  1,1325,  1,1324,  1],
    [  1,  0,  0,1318,  0,  0,1319,  0, 27,  0, 21,  0,  1],
    [  1,1322,  1,  1,  1,  1,  1,  1,  1,  1,  1,1323,  1],
    [  1, 21,  1,  1,  1,358,  1,  1,365,  1,  1, 21,  1],
    [  1,  0,  1,  1,  1,1325,  1,  1,1325,  1,  1,  0,  1],
    [  1, 88,1323, 31, 31,  0,342,342,  0, 31,1322, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}