main.floors.MT373=
{
    "floorId": "MT373",
    "title": "通天塔 373 ",
    "name": "黑暗深渊373",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT373_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT373_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT373_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT373_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT373_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT373_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT373_2_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT373_2_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,4": {
            "0": {
                "condition": "flag:door_MT373_10_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT373_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        },
        "10,8": {
            "0": {
                "condition": "flag:door_MT373_10_8==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT373_10_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,8": {
            "0": {
                "condition": "flag:door_MT373_2_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT373_2_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 88,  0,344,381, 33,  0, 21,1161,  0,  0, 87,1150],
    [1150, 21,  0,1150,381, 33,1168,  0,1150,1150,343,1150,1150],
    [1150,  0,1166,1150,1150,1150,343,1150,1150,1175,  0,1175,1150],
    [1150,1150,342,1150,1165,384,384,384,1150,1150, 85,1150,1150],
    [1150,355,  0,1150,342,1150,1150,1150,1150,1173,  0,1173,1150],
    [1150,  0,  0,  0,1166,385,385,385,1150,  0,1223,  0,1150],
    [1150,1171,  0,1171,1150,1150,1150,1150,1150,1173,  0,1173,1150],
    [1150,1150, 85,1150,1150,350,342,1173,1150,1150, 85,1150,1150],
    [1150,  0,352,  0,1150,350,1150,352,1150,637, 47,637,1150],
    [1150,352,381,352,1150,350,1150,352,1150, 23,564, 23,1150],
    [1150,  0,352,  0,342,1172,1150,352,1150,637, 47,637,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}