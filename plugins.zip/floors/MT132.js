main.floors.MT132=
{
    "floorId": "MT132",
    "title": "通天塔 132 ",
    "name": "通天塔132",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 22, 22, 22,344,390,  1,390,344,540,380,540,  1],
    [  1,  1,  1,  1,  1, 86,  1, 86,  1,  1,  1,  1,  1],
    [  1, 22, 21, 22,344,390,  1,390,344,379,379,379,  1],
    [  1,  1,  1,  1,  1, 86,  1, 86,  1,  1,  1,  1,  1],
    [  1, 21, 21, 21,343,390,  1,390,343,538,355,538,  1],
    [  1,  1,  1,  1,  1, 86,  1, 86,  1,  1,  1,  1,  1],
    [  1,354,538,354,343,390,  1,390,342,354,355,354,  1],
    [  1,  1,  1,  1,  1, 86,  1, 86,  1,  1,  1,  1,  1],
    [  1,351,353,351,342,348,  1,348,  1,390,  1,390,  1],
    [  1,  1,  1,  1,  1, 86, 86, 86,342,348,342,348,  1],
    [  1,351,353,351,342,  0, 88,  0,663,  0,663, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}