main.floors.MT508=
{
    "floorId": "MT508",
    "title": "通天塔 508 ",
    "name": "通天塔508",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "0,7": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1377,  0,  0, 32,  0,1377,  0, 32,  0,  0, 88,  1],
    [  1,  0,  1,1378,  1,1379,  1,1378,  1,1380,  1,1379,  1],
    [  1, 32,  1,377,  1,377,  1,377,  1,377,  1,377,  1],
    [  1,372,  1, 21,  1, 21,  1, 22,  1, 23,  1, 22,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1377,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [ 87,  0,1377,  0,1377,  0,1377,  0,1385,  0,387,  0,  1],
    [  4,345,  4,345,  4,345,  4,345,  4,345,  4,345,  4],
    [  4, 30,  4, 30,  4, 30,  4, 30,  4, 30,  4, 30,  4],
    [  4,345,  4,345,  4,345,  4,345,  4,345,  4,345,  4],
    [  4, 23,  4, 47,  4, 23,  4,377,  4, 26,  4,331,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}