main.floors.MT491=
{
    "floorId": "MT491",
    "title": "通天塔 491 ",
    "name": "通天塔491",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT491_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT491_4_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,10": {
            "0": {
                "condition": "flag:door_MT491_4_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT491_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87, 86,1339,  1,363,  1,377,  1,370,370,370,  1],
    [  1,1340,  1,  0,  1,363,  1,370,  1, 30,  1, 30,  1],
    [  1,356,  1, 33,  1,1340,  1,343,  1,343,  1,342,  1],
    [  1,356,  1,  0,  1,  0,1332,  0, 33,  0,  1,1338,  1],
    [  1,  1,  1,1341,  0,1341,  1,  1,  1,343,  1,1339,  1],
    [  1,350,  1,  1, 86,  1,  1,1341,  1,342,  1,1338,  1],
    [  1,1341,  1, 22,350, 22, 86,  0, 33,  0,1338,  0,  1],
    [  1,  0, 86,  0,  0,  0,  1,1341,  1,  1,  1,  0,  1],
    [  1,1341,  1,1371,  0,1371,  1,  1,  1, 31,  1,343,  1],
    [  1,344,  1,  1, 85,  1,  1,  1,  1, 32,  1,  0,  1],
    [  1, 31, 31, 31,391, 31, 31, 31,  1, 31,342, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}