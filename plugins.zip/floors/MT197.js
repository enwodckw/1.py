main.floors.MT197=
{
    "floorId": "MT197",
    "title": "通天塔 197 ",
    "name": "临时教会住所197",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "5,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT197_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT197_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT197_3_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT197_3_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "8,6": {
            "0": {
                "condition": "flag:door_MT197_8_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT197_8_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "3,6": {
            "0": {
                "condition": "flag:door_MT197_3_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT197_3_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144,385,384,741,566,741,352,741,566,741,377,377,144],
    [144,385,384,741,637,741,766,741,637,741,377,377,144],
    [144,761,384,741,566,763,  0,763,566,741,350,350,144],
    [144,342,741,262,741,741,342,741,741,741,741,741,144],
    [144,  0,751,741,751,741,  0,758,741,  0,637,  0,144],
    [262,  0,  0, 85,  0, 87, 88,  0, 85,765,  0,568,144],
    [144,  0,751,741,751,741,  0,758,741,  0,637,  0,144],
    [144,342,741,261,741,741,760,741,741,741,741,342,144],
    [144,761,384,741,568,741,  0,741,568,741,  0,764,144],
    [144,385,384,741,637,741,568,741,637,741,638,  0,144],
    [144,385,384,741,568,762,  0,762,568,741,  0,638,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}