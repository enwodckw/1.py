main.floors.MT86=
{
    "floorId": "MT86",
    "title": "通天塔86",
    "name": "通天塔86",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,7": [
            "\t[器灵,thief]想不到你这么简单的就突破了金魔王的领域，以你现在的实力往上就困难了，是时候去地下了，塔灵现在不知去向，正好你可以去摧毁他的老巢了",
            "\t[hero]多谢前辈的帮助，不过我有一件事想要请教你",
            "\t[器灵,thief]是关于你突破造化境九重到封仙境九重的力量增强问题吧",
            "\t[hero]前辈真是慧眼如珠，这是怎么回事？",
            "\t[器灵,thief]我之所以救下你，就是因为你的血脉，说实话你的血脉我也有点看不懂，至少血脉超过了圣级，虽然我不知道你的来历，但是单看你的血脉力量，就能发现你的父母远远超过了圣人，至于你突破增强，就和你的血脉有关",
            "\t[器灵,thief]你的血脉应该是被你父母封印了，每突破一定的实力后，激活一部分血脉，激活的血脉跟你融合后，就会大幅的增强你的实力",
            "\t[hero]这么说我如果源源不断的突破，就能激活大量的血脉，对付塔灵就更有把握了",
            "\t[器灵,thief]突破哪有那么简单，都是日积月累，你看看你现在突破下个境界都慢很多，越往后突破越难，除非有大的机遇，听说塔灵老巢有一颗进阶丹，拿到他服用后可以让你直接升级，趁现在塔灵不在，你就抓紧时间去他老巢看看吧",
            "\t[hero]好，那我去了",
            "\t[器灵,thief]地下常年昏暗，里面怪物都比较暴躁强大，我就在给你增强一次吧",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我20把绿钥匙,全属性提升20000，要换吗？",
                "choices": [
                    {
                        "text": "换了",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "20"
                            },
                            {
                                "type": "setValue",
                                "name": "status:atk",
                                "operator": "+=",
                                "value": "20000"
                            },
                            {
                                "type": "setValue",
                                "name": "status:def",
                                "operator": "+=",
                                "value": "20000"
                            },
                            {
                                "type": "setValue",
                                "name": "status:mdef",
                                "operator": "+=",
                                "value": "20000"
                            },
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不换",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[hero]我还是凭自己的实力去战斗吧",
                            "\t[器灵,thief]有主人当年的风范，哈哈哈",
                            {
                                "type": "setValue",
                                "name": "status:hp",
                                "value": "6666666"
                            },
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT86_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT86_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT86_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT86_6_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,3": {
            "0": {
                "condition": "flag:door_MT86_6_3==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT86_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,391,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  0,510,  0,510,  0,  1,  1,  1,  1],
    [  1,  1,  1,  1,  0,  0,354,  0,  0,  1,  1,  1,  1],
    [  1,  1,  1,  1,511,  1,344,  1,511,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,123,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [535,535,535,345,345,345,  0,  0,  0,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}