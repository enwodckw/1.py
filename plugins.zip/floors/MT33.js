main.floors.MT33=
{
    "floorId": "MT33",
    "title": "通天塔 33 ",
    "name": "通天塔33",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,2": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,380,374,413,  1, 21,  0, 21,  1,  0,254,380,  1],
    [  1,  1,  1,342,  1,  0, 88,  0,  1,374,  1,  1,  1],
    [  1, 33,374, 33,  1,350,  0,377,  1,365,  1,379,  1],
    [  1,342,  1,  1,  1,  1,405,  1,  1,410,  1, 33,  1],
    [  1,409,  0,352,  0,342,  0,  0,342,  0,343, 33,  1],
    [  1,  1,  1,  1,407, 22,  0,351,  1,410,408, 33,  1],
    [  1,358, 33,  1,  1,  1,342,  1,  1,  1,  1,  1,  1],
    [  1, 33,411,342,409,  0,  0,  0,342,411,342,413,  1],
    [  1,  1,  1,342,  1,343,406,342,  1,363,  1,356,  1],
    [  1,349,  1,349,  1, 21,  0, 21,  1,363,  1,356,  1],
    [  1,348,343,348,  1,348, 87,348,  1,363,  1,356,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}