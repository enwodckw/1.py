main.floors.MT52=
{
    "floorId": "MT52",
    "title": "通天塔 52 ",
    "name": "通天塔52",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,353,371,387, 21,272,  0,272, 21,387,371,353,  1],
    [  1,  1,  1,  1,  1,  1, 86,  1,  1,  1,  1,  1,  1],
    [  1, 21, 21,348,354,  1,  0,  1, 22,342, 33, 33,  1],
    [  1, 22,  1,  1,  1,  1,271,  1,  0,265, 33, 33,  1],
    [  1, 22,  1,265,  0, 33,  0,  1, 33,  1,266,342,  1],
    [  1,267,342,  0,342,  1,432,  1,  0, 86,  0,  0, 87],
    [  1,  1,  1,  1,  0,342,  0,  0,429,  1,266,391,  1],
    [363,353,363,  1, 33,  1,  1,  1,  1,  1,  1,343,  1],
    [432,  0,432,  1,  0,265,266,265,366,  1,348,271,  1],
    [  1,342,  1,  1,425,  1,  1,  1,366,  1,348,354,  1],
    [  1, 88,  0, 33,  0,342,342,342,366,  1,348,391,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}