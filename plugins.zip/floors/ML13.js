main.floors.ML13=
{
    "floorId": "ML13",
    "title": "通天塔 13 ",
    "name": "地下13",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [367,  1,381,  1,360,  1, 87,  1,391,  1,391,  1,391],
    [381,  1,374,  1,381,  1,  0,  1,389,  1,388,  1,390],
    [367,  1,381,  1,360,  1,538,  1,389,  1,388,  1,390],
    [583,  1,578,  1,584,  1,538,  1,391,  1,391,  1,391],
    [  0, 86,  0, 86,  0,343,536,  1,577,  1,577,  1,576],
    [342,  1,342,  1,342,  1,537,  1,342,  1,342,  1,342],
    [577,  1,577,  1,576,  1,538,343,  0, 86,  0, 86,  0],
    [391,  1,391,  1,391,  1,538,  1,584,  1,578,  1,583],
    [388,  1,389,  1,390,  1,  0,  1,360,  1,381,  1,367],
    [388,  1,389,  1,390,  1,542,  1,381,  1,374,  1,381],
    [391,  1,391,  1,391,  1, 88,  1,360,  1,381,  1,367],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}