main.floors.MT130=
{
    "floorId": "MT130",
    "title": "通天塔 130 ",
    "name": "通天塔130",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [
        "请携带超级炸弹后在和boss决斗"
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,4": [
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        6,
                        10
                    ]
                ],
                "floorId": "MT130"
            },
            "\t[血魔王,E633]这次跑不了吧,等你多时了",
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "E633",
                "loc": [
                    [
                        6,
                        3
                    ]
                ],
                "floorId": "MT130"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[hero]要不是这该死的光环压制，不然你以为你是我的对手",
            "\t[血魔王,E633]这次我绝对不会与你说那么多的废话，以免夜长梦多，怪不得我使用这种卑鄙手段",
            "\t[hero]此处也许是我的又一劫难，拼了",
            "\t[血魔王,E633]哈哈哈，此处就是你的埋骨之地",
            {
                "type": "animate",
                "name": "baozha"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[血魔王,E633]？？？",
            "\t[血魔王,E633]你怎么没事？",
            "\t[雪月国大长老,E658]有我在,他当然没事",
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "E473",
                "loc": [
                    [
                        7,
                        6
                    ]
                ],
                "floorId": "MT130"
            },
            {
                "type": "setBlock",
                "number": "E658",
                "loc": [
                    [
                        5,
                        6
                    ]
                ],
                "floorId": "MT130"
            },
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "moveHero",
                "steps": [
                    "down:2"
                ]
            },
            {
                "type": "changePos",
                "loc": [
                    6,
                    6
                ],
                "direction": "right"
            },
            "\t[hero]？",
            "\t[hero]是你？",
            "\t[雪月圣女,E473]又见面了,我这次来就是带人消灭塔灵的",
            "\t[hero]多谢圣女了",
            {
                "type": "changePos",
                "loc": [
                    6,
                    6
                ],
                "direction": "up"
            },
            "\t[hero]血魔没想到吧，今天还不知道鹿死谁手",
            "\t[血魔王,E633]小人得志，你以为就靠他就能对抗主人，太异想天开了",
            "\t[雪月圣女,E473]能不能消灭塔灵你也看不到了，大长老请你出手灭了他",
            "\t[雪月国大长老,E658]没问题，圣女殿下",
            "\t[雪月国大长老,E658]你该去死了，灭了你就轮到塔灵了",
            "\t[血魔王,E633]灵卫大人速来救我……啊…",
            {
                "type": "animate",
                "name": "baozha",
                "loc": [
                    6,
                    3
                ]
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        3
                    ]
                ],
                "floorId": "MT130"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[雪月圣女,E473]终于死了，还去找塔灵算账了",
            "\t[hero]是该结束了",
            "\t[塔灵卫,E403]确实该结束了",
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "E403",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "MT130"
            },
            {
                "type": "setBlock",
                "number": "E404",
                "loc": [
                    [
                        5,
                        3
                    ]
                ],
                "floorId": "MT130"
            },
            {
                "type": "setBlock",
                "number": "E404",
                "loc": [
                    [
                        7,
                        3
                    ]
                ],
                "floorId": "MT130"
            },
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "callBook"
            },
            "\t[hero]塔灵卫？",
            "\t[雪月国大长老,E658]该死，圣女你先走，我拖住他们",
            "\t[塔灵卫,E403]你太天真了，你以为你们能逃出我的手掌心",
            "\t[hero]怎么会这样？塔灵放出的信息有误",
            "\t[雪月国大长老,E658]可恶啊，这塔灵卫修为已经超出了我们的国主，那么塔灵修为更加深不可测，今日怕不是都该埋骨于此了，圣女对不起，我没能保护好你",
            "\t[雪月圣女,E473]是我连累了长老你，如果今天没有奇迹发生，我们都要葬身此地了",
            "\t[hero]奇迹？有了",
            "\t[hero]你以为我会怕，今日让你看看我的厉害",
            "\t[塔灵卫,E403]？",
            "\t[塔灵卫,E403]你…",
            "\t[hero]死吧",
            {
                "type": "useItem",
                "id": "I618"
            },
            "\t[塔灵卫,E403]不",
            {
                "type": "sleep",
                "time": 500
            },
            "\t[hero]好险啊",
            "\t[雪月圣女,E473]多谢公子了，想不到公子还有这种宝物",
            "\t[hero]这也是无意间得到的，想不到塔灵卫都这么厉害了，那么塔灵又该怎么对付",
            "\t[雪月国大长老,E658]圣女，此事远远超过了我们的预算，我们只能回去和国主商量了",
            "\t[雪月圣女,E473]也是，既然如此，公子我们就先走了",
            "\t[hero]嗯，好，再见",
            "\t[雪月国大长老,E658]年轻人勇气可嘉，期待你的成长，哈哈哈，再见",
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        6
                    ]
                ],
                "floorId": "MT130"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        6
                    ]
                ],
                "floorId": "MT130"
            },
            "\t[hero]继续前进吧",
            {
                "type": "openDoor",
                "loc": [
                    6,
                    1
                ],
                "floorId": "MT130"
            },
            {
                "type": "openDoor",
                "loc": [
                    6,
                    10
                ],
                "floorId": "MT130"
            },
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "6,12": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT130_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT130_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT130_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT130_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "10,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT130_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT130_6_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_MT130_6_8==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT130_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,5": {
            "0": {
                "condition": "flag:door_MT130_6_5==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT130_6_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,10": {
            "0": {
                "condition": "flag:door_MT130_6_10==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT130_6_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4, 87,  4,  4,  4,  4,  4,  4],
    [  4,650,  4,650,  4,571, 85,571,  4,650,  4,650,  4],
    [  4,  4,  4,  4,  4, 85,  0, 85,  4,  4,  4,  4,  4],
    [  4,650,  4,650,  4,  0,  0,  0,  4,650,  4,650,  4],
    [  4,  4,  4,  4,  4,571,  0,571,  4,  4,  4,  4,  4],
    [  4,651,  4,651,  4,  4, 85,  4,  4,651,  4,651,  4],
    [  4,  4,  4,  4,  4,  0,635,  0,  4,  4,  4,  4,  4],
    [  4,652,  4,652,  4,570,  0,570,  4,652,  4,652,  4],
    [  4,  4,  4,  4,  4,  4, 85,  4,  4,  4,  4,  4,  4],
    [  4,652,  4,652,  4,569,634,569,  4,652,  4,652,  4],
    [  4,  4,  4,  4,  4,  4, 85,  4,  4,  4,  4,  4,  4],
    [  1,657,657,  0,637,571,  0,571,637,  0,657,657,  1],
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}