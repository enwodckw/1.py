main.floors.ML2=
{
    "floorId": "ML2",
    "title": "通天塔 2 ",
    "name": "地下2",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,12": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,595,533,  1,384,384,  1,385,385,  1,593,391,  1],
    [  1,342,  1,  1,596,387,  1,387,594,  1,342,  1,  1],
    [  1, 59,594,  0,343,  1,  1,  1,343,593,391, 59,  1],
    [  1,  1,  1,592,  1,  1, 56,  1,  1,342,  1,  1,  1],
    [  1,534,591,  0,602,  1,544,  1,  1,  0,592,533,  1],
    [  1, 58,  1,380, 59,  1,544,  1,603,565,  1, 58,  1],
    [  1,  1,  1,591,343,  1,596,  1,589,  1,  1,  1,  1],
    [  1,534,  1,602,540,343,  0,343,380,  1,383,383,  1],
    [  1, 58,589,565,  0,590,  0,590,  0,343,591,383,  1],
    [  1,  1,  1,  1,  1,  1,344,  1,  1,  1,  1,  1,  1],
    [  1,536,536,345,345,345,  0,  0,589,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}