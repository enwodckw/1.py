main.floors.MT558=
{
    "floorId": "MT558",
    "title": "通天塔 558 ",
    "name": "通天塔558",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,384,384,  1,385,385,  1,386,  1,  0,1414, 87,  1],
    [  1,384,384,  1,385,385,  1,387,  1,351,  1,  1,  1],
    [  1,1419,384,  1,385,1420,  1,386,  1, 21,  1,378,  1],
    [  1, 86,  1,  1,  1,342,  1,1418,  1, 21,  1,378,  1],
    [  1,386,  1,351,351,351,  1,  0,342, 21,  1,378,  1],
    [  1,386,  1,  1,1415,351,  1,344,  1,1412,  1,378,  1],
    [  1,387,386,1413, 86,  1,  1,  0,  1,  0,342,1419,  1],
    [  1,  1,  1,  1,342,344,358, 22,1412,350,  1,  1,  1],
    [  1, 22,350,  0,1412,  1,358,  1,  1,  1,  1,387,  1],
    [  1,  0,  1,  1,  0,  1,358,  1,  0,1417,386,386,  1],
    [  1, 88,  1,  1,  0,1414,  0,342,1412,344,386,386,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}