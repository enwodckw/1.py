main.floors.MT349=
{
    "floorId": "MT349",
    "title": "通天塔 349 ",
    "name": "黑暗深渊349",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 10000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT349_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT349_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT349_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT349_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT349_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT349_6_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "6,10": [
            "吸收斩神剑剑意,全属性增加20兆",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "20000000000000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "20000000000000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "20000000000000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {
        "6,4": {
            "0": {
                "condition": "flag:door_MT349_6_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT349_6_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,8": {
            "0": {
                "condition": "flag:door_MT349_6_8==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT349_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,  0,390,390,390,  0,1141,  0,390,390,  0, 88,1150],
    [1150,1142,1150,342,1150,1150,342,1150,1150,342,1150,1142,1150],
    [1150,  0,342,342,1150,1155,  0,1155,1150,342,342,  0,1150],
    [1150,390,1150,1150,1150,1150, 85,1150,1150,1150,1150,342,1150],
    [1150,390,1150,1150,1150,1158,  0,1158,1150,1150,1150,1106,1150],
    [1150,  0,1150,1150,1150,  0,  0,  0,1150,1150,1150,1140,1150],
    [1150,1141,1150,1150,1150,1158,  0,1158,1150,1150,1150,1106,1150],
    [1150,  0,1150,1150,1150,1150, 85,1150,1150,1150,1150,1140,1150],
    [1150,390,1150,1150,1150,533,  0,533,1150,1150,1150,349,1150],
    [1150,390,1150,1150,1150,  0,397,  0,1150,1150,1150,349,1150],
    [1150, 87,1150,1150,1150,533,  0,533,1150,1150,1150,901,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}