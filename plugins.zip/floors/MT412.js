main.floors.MT412=
{
    "floorId": "MT412",
    "title": "通天塔 412 ",
    "name": "黑暗深渊深处412",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 200000000000,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT412_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT412_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT412_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT412_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT412_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT412_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT412_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT412_2_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,7": {
            "0": {
                "condition": "flag:door_MT412_6_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT412_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        },
        "6,9": {
            "0": {
                "condition": "flag:door_MT412_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT412_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,2": {
            "0": {
                "condition": "flag:door_MT412_6_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT412_6_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,4": {
            "0": {
                "condition": "flag:door_MT412_2_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT412_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 87,349,  0,1150,391,391,391,1150,386,387,386,1150],
    [1150,343,1150,1259,1150,1150, 85,1150,1150,1254,1150,1150,1150],
    [1150,349,  0,349,1150,1258,  0,1258,1150,386,387,386,1150],
    [1150,1150, 85,1150,1150,1209,1258,1212,1150,1260,1150,1150,1150],
    [1150,1246,  0,1246,1150,1150,342,1150,1150,  0,343,386,1150],
    [1150,  0,  0,  0, 86,  0,1257,  0, 86,  0,1259,387,1150],
    [1150,1150,342,1150,1150,1150, 85,1150,1150,  0,342,386,1150],
    [1150,  0,1260,  0,1150,1248,  0,1248,1150,1260,1150,1150,1150],
    [1150,387,387,387,1150,1150, 85,1150,1150,385,385,385,1150],
    [1150,1150,1150,1150,1150,1247,  0,1247,1150,1150,1150,1254,1150],
    [1150,384,384,384,1257,  0, 88,  0,1150,385,385,385,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}