main.floors.MT121=
{
    "floorId": "MT121",
    "title": "通天塔 121 ",
    "name": "通天塔121",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  4,  4,  4,  4,  4,  4,343,538],
    [  1,359,359,359,644,  0,645,622,344,344,344, 88,  1],
    [  4,  4,  4,  4,  4,652,  4,  4,  4,  4,  4,  0,  1],
    [  4,377,377,377,344,  0,342, 30,640, 30,342,533,  1],
    [  4,  4,  4,  4,  4,342,  1,  1,  1,  1,  1,640,  1],
    [  4,380,380,380,345,  0,342,359,641,359, 86,  0,  1],
    [  4,  4,  4,  4,  4,342,  1,  1,  1,  1,  1,609,  1],
    [  4, 22, 21, 22,344,651,342,366,642,366,342,  0,  1],
    [  4,  4,  4,  4,  4,342,  1,  1,  1,  1,  1,640,  1],
    [  4,539,540,539,343,  0,342,380,646,380, 86,  0,  1],
    [  4,  4,  4,  4,  4,342,  1,  1,  1,  1,  1,609,  1],
    [  4,538,539,538,342,650,342, 30,640, 30,342, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}