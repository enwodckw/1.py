main.floors.MT338=
{
    "floorId": "MT338",
    "title": "通天塔 338 ",
    "name": "沼泽林深处338",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 3000000000,
    "defaultGround": "grass",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "0,0": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT338_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT338_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT338_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT338_6_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,7": {
            "0": {
                "condition": "flag:door_MT338_6_7==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT338_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 88,  0,568,  0,  0,1068,  0,  0,568,  0,390,  0, 87],
    [  0, 85, 85,1075, 85, 85,343, 85, 85,1079, 85, 85,  0],
    [1068, 85,361,  0,361, 85,1078, 85,368,  0,368, 85,1069],
    [390, 85,  0,540,  0, 85,1077, 85,  0,540,  0, 85,  0],
    [362, 85,361,  0,361, 85,1081, 85,368,  0,368, 85,362],
    [390, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85,390],
    [  0,343,1078,1077,1080, 85,437, 85,1082,1077,1079,343,  0],
    [343, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85,1069],
    [1079, 85,381,  0,381, 85,1083, 85,381,  0,381, 85,  0],
    [378, 85,  0,540,  0, 85,1077, 85,  0,540,  0, 85,362],
    [378, 85,381,  0,381, 85,1078, 85,381,  0,381, 85,390],
    [378, 85, 85,1078, 85, 85,343, 85, 85,1076, 85, 85,390],
    [378, 85,390,  0,362,  0,1070,  0,362,  0,  0,1070,  0]
],
    "bgmap": [

],
    "fgmap": [

]
}