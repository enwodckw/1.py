main.floors.MT200=
{
    "floorId": "MT200",
    "title": "通天塔 200 ",
    "name": "临时教会住所200",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,2": [
            {
                "type": "openDoor",
                "loc": [
                    4,
                    1
                ],
                "floorId": "MT200"
            },
            {
                "type": "openDoor",
                "loc": [
                    8,
                    1
                ],
                "floorId": "MT200"
            },
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        1
                    ]
                ],
                "floorId": "MT200"
            }
        ],
        "4,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT200_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT200_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT200_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT200_6_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,6": {
            "0": {
                "condition": "flag:door_MT200_6_6==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT200_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144, 22,639, 22, 85,639, 87,639, 85, 21,639, 21,144],
    [144,144,144,144,144,  0,767,  0,144,144,144,144,144],
    [144,354,354,144,144,639,  0,639,144,144,354,354,144],
    [144,354,379,144,144,144,571,144,144,144,379,354,144],
    [144,144,343,144,768,144,571,144,768,144,343,144,144],
    [144,348,348,144,  0,144, 85,144,  0,144,348,348,144],
    [144,377,348,144,768, 86,639, 86,768,144,348,377,144],
    [144,342,144,144,144,144,344,144,144,144,144,342,144],
    [144,639,639,639,570,764,  0,764,570,639,639,639,144],
    [144,741,741,741,741,741,  0,741,741,741,741,741,144],
    [144,538,343,354,352,342, 88,342,352,354,343,538,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}