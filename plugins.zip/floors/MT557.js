main.floors.MT557=
{
    "floorId": "MT557",
    "title": "通天塔 557 ",
    "name": "通天塔557",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {
        "6,7": [
            "吸取斩神剑的剑意，全属性增加5万",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "50000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "50000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "50000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21,  4],
    [  4, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21,  4],
    [  4, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21,  4],
    [  4, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,  4],
    [  4, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22,  4],
    [  4, 22, 23, 23,  4,  4,  4,  4,  4, 23, 23, 22,  4],
    [  4, 22, 23, 23,  4,1369,397,1369,  4, 23, 23, 22,  4],
    [  4, 22, 23, 23,  4,  4, 86,  4,  4, 23, 23, 22,  4],
    [  4, 22, 22, 22, 22,  4,1425,  4, 22, 22, 22, 22,  4],
    [  4,  4,  4,  4,  4,  4,344,  4,  4,  4,  4,  4,  4],
    [  1, 87,  0,348,348,348,  0,348,348,348,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}