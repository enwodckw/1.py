main.floors.MT177=
{
    "floorId": "MT177",
    "title": "通天塔 177 ",
    "name": "临时教会住所177",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT177_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT177_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT177_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT177_6_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,3": {
            "0": {
                "condition": "flag:door_MT177_6_3==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT177_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144,748,379,379,741,  0,380,  0,741,743,342, 87,144],
    [144,342,741,741,741,380,  0,380,741,  0,741,342,144],
    [144,379,379,746,741,741, 85,741,741, 30,741,750,144],
    [144,741,741,342,741,749,  0,749,741, 30,741,  0,144],
    [144,744,342,746,741,  0,  0,  0,741, 30,741,359,144],
    [144,365,741,355,741,749,  0,749,741,  0,741,359,144],
    [144,365,741,378,741,741,343,741,741,743,741,359,144],
    [144,365,741,741,  0,  0,744,  0,639,  0,741,359,144],
    [144,365,744,342,742,741,343,741,741,741,741,538,144],
    [144,741,741,741,  0,743,  0,741,356,356,741,343,144],
    [144,539,351,343, 22,342, 88,748,363,363,343,343,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}