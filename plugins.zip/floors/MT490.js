main.floors.MT490=
{
    "floorId": "MT490",
    "title": "通天塔 490 ",
    "name": "通天塔490",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,9": [
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        6,
                        10
                    ]
                ],
                "floorId": "MT490"
            },
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "if",
                "condition": "blockId:7,9",
                "true": [],
                "false": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            10
                        ],
                        "floorId": "MT490"
                    }
                ]
            }
        ],
        "7,9": [
            {
                "type": "if",
                "condition": "blockId:5,9",
                "true": [],
                "false": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            10
                        ],
                        "floorId": "MT490"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1370,  1,  1,  1,  1,  1,  1,  1,  1,  1,1370,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,344,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,344,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,344,  1],
    [  1,  1,  1,  1,  1,  1,1217,  1,  1,  1,  1,344,  1],
    [  1,  1,  1,  1,  1,  1,1369,  1,  1,  1,  1,344,  1],
    [  1,  1,  1,  4,  4,  4,  4,  4,  4,  4,  1,344,  1],
    [  1,  1,  1,  4,1218,  0,355,  0,1218,  4,  1,344,  1],
    [  1,  1,  1,  4, 23,1345,  0,1345, 23,  4,  1,344,  1],
    [  1,  1,  1,  4,  4,  4,342,  4,  4,  4,  1,344,  1],
    [  1, 88,  0,  0,1341,  0, 33,  0,1341,  0,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}