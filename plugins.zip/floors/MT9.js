main.floors.MT9=
{
    "floorId": "MT9",
    "title": "通天塔 9 ",
    "name": "通天塔9",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "0,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,371, 30,  1,  0,342,214, 29,  1, 21, 21, 21,  1],
    [  1,212,371,  1, 31,  1, 29,356,  1,343,  1,  1,  1],
    [  1,342,  1,  1,370,  1,  1,  1,  1, 31,  1, 23,  1],
    [  1,348,  0, 86,  0,  1,356, 29,  1, 31,  1,343,  1],
    [  1,  1,211,  1,209,  1, 29,214,  1,  0,343,343,  1],
    [  1, 30, 33,  1,  0,  1,  1,342,  1,208,  1,  1,  1],
    [  1,343,  1,  1, 31,  1, 33,210,342,  0,  1, 22,  1],
    [  1, 21, 21,  1,370,  1,  1,  1,  1, 34,  1, 22,  1],
    [  1, 21, 21,  1,  0,  1,377,371,212,  0,344, 22,  1],
    [  1,210,  1,  1,213,  1,343,  1,  1,208,  1,  1,  1],
    [ 87,  0, 30,  0,  0,209,  0, 34, 21,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "shanmai.mp3"
}