main.floors.MT58=
{
    "floorId": "MT58",
    "title": "通天塔 58 ",
    "name": "通天塔58",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 24,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "0,6": [
            "\t[器灵,thief]我现在已经有能力让梦云功法进行升级，是否需要升级？",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我20绿,升级梦云功法",
                "choices": [
                    {
                        "text": "升级",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "20"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I438",
                                "operator": "+=",
                                "value": "1"
                            },
                            "\t[器灵,thief]升级完成,祝你好运！",
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不升级",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[器灵,thief]只有一次机会哦",
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ],
        "0,4": [
            {
                "type": "if",
                "condition": "(item:greenKey<1000)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            0,
                            5
                        ],
                        "floorId": "MT58"
                    },
                    {
                        "type": "hide"
                    }
                ],
                "false": []
            },
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT58_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT58_4_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,2": {
            "0": {
                "condition": "flag:door_MT58_4_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT58_4_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  1,373,443,373,  1,463,342,468, 27, 27,  1],
    [  1,  0,  1,  1, 85,  1,  1,  0,  1, 30, 28, 28,  1],
    [  1,  0,  1,467,  0,467,  1, 33,  1,472,  1,  1,  1],
    [  0,  0,  0,  0,  0,  0,  1, 33,  1, 33,  1, 33,  1],
    [ 85,  4,342,  1,343,  1,  1, 33,  1, 33,  1, 33,  1],
    [123,  4,  0, 30,  0,  1,465,  0,  1, 33,  1, 33,  1],
    [  4,  4,460,  1,343,  1,342,  1,  1,465,  1,463,  1],
    [  1,  0,  0,  0,  0,461,  0, 21,463,  0,  0,  0,  1],
    [  1,461,  1,460,  1,  1,342,  1,  1,  1,342,  1,  1],
    [  1,348,  1, 21,  1,367,468,367,  1,360,467,360,  1],
    [  1, 87,342, 30,  1,348,348,348,  1,348,348,348,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}