main.floors.MT104=
{
    "floorId": "MT104",
    "title": "通天塔 104 ",
    "name": "通天塔104",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,381,  1,  1,  1,  1,620,  1,  1,  1,  1,381,  1],
    [  1, 21,  1,  1,  1,  1,351,  1,  1,  1,  1, 21,  1],
    [  1, 22,  1,  1,  1,  1,351,  1,  1,  1,  1, 22,  1],
    [  1, 21,  1,  1,  1,  1,608,  1,  1,  1,  1, 21,  1],
    [  1,607,  1,  1,  1,  1,343,  1,  1,  1,  1,607,  1],
    [  1,  0, 33,611, 21, 21, 21,342,342,342,342,  0,  1],
    [  1,  1,  1,  1, 30, 30, 30,  1,  1,  1,  1,351,  1],
    [  1,377,351,  1, 30,568, 30,  1,351,377,  1,611,  1],
    [  1,613,377,  1,606,  0,606,  1,614,377,  1, 27,  1],
    [  1,342,  1,  1,  1,342,  1,  1,342,  1,  1, 27,  1],
    [  1, 88,  0,571,  0, 86,  0, 33,  0,611,  0, 27,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}