main.floors.MT18=
{
    "floorId": "MT18",
    "title": "通天塔 18 ",
    "name": "通天塔18",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 23,  1,  0,364,  0,221,  0,221,  0,  1, 30,  1],
    [  1, 31,  1,364,  1,  1,  1,342,  1, 21,  1, 31,  1],
    [  1, 31,  1,  1,  1,  0,342,  0,  1,227,342,228,  1],
    [  1,228,  0,  0,226,  0,227,  0,  1, 21,  1, 21,  1],
    [  1,  1,  1,  1,  1,  1,  1, 31,  1,  1,  1,  1,  1],
    [  1, 33,343, 29, 29, 29,  1, 29,  1,357,  0,357,  1],
    [  1, 33,  1,  0,220,  0,  1,  0,  1,  0,222,  0,  1],
    [  1,  1,  1,  1,342,  1,  1,215,  1,  1,342,  1,  1],
    [  1,  0,220,  0,  0, 27,  0,  0,  0,225,  0, 29,  1],
    [  1, 31,  0,  1,228,  1,  1,  1,343,  1,342,  1,  1],
    [  1, 88, 31,  1, 27, 32, 21, 32, 27,  1, 29,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 87,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}