main.floors.MT592=
{
    "floorId": "MT592",
    "title": "通天塔 592 ",
    "name": "通天塔592",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 72,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,1487,  1,1359,1486,602,  1,1488,1226,1488,  1,  1],
    [  1,  1,1487,  1,1480,1486,1486,  1,1470,  1,1470,  1,  1],
    [  1,  1,1487,  1,342,  1,  1,  1,1488,  1,1488,  1,  1],
    [  1,  1,1487,  1,602,566,1481,  1,1226,  1,1226,  1,  1],
    [  1,  1,1482,  1,  1,  1,342,  1,1488,  1,1488,  1,  1],
    [  1,  1,  0,602,566,1472,  0,  1,565,  1,565,  1,  1],
    [  1,  1,1482,  1,  1,  1,342,  1,1469,  1,1469,  1,  1],
    [  1,  1,1226,  0,566,344,  0,343,  0,1472,  0,  1,  1],
    [  1,  1,  1,  1,  1,  1,342,  1,  1,  1,342,  1,  1],
    [  1, 88,  0,  0,  0,1466,  0,565,344,566,1465, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}