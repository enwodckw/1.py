main.floors.MT113=
{
    "floorId": "MT113",
    "title": "通天塔 113 ",
    "name": "通天塔113",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0, 33,  0, 21, 30,  0,612,  0, 30,  0, 88,  1],
    [  1,342,  1,610,  4,  4,  4,  4,  4,  4,  4,614,  1],
    [  1,  0, 33,  0,  4,  0,607,387,616,391,  4,  0,  1],
    [  1,610,  1,342,  4,615,  4,  4,  4,608,  4,615,  1],
    [  1,  0, 33,  0,  4,  0,  4,261,  4,533,  4,  0,  1],
    [  1,342,  1,610,  4,607,  4,609,  4,615,  4,616,  1],
    [  1,  0, 33,  0,  4,  0,  4,537,  4,534,  4,  0,  1],
    [  1,610,  1,342,  4,616,  4,609,  4,608,  4,617,  1],
    [  1,  0, 33,  0,  4,  0,  4,536,617,535,  4,  0,  1],
    [  1,342,  1,610,  4,606,  4,  4,  4,  4,  4,613,  1],
    [  1, 87, 33,  0,  4,538,610,538,611,538,612,538,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}