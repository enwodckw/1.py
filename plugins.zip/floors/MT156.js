main.floors.MT156=
{
    "floorId": "MT156",
    "title": "通天塔 156 ",
    "name": "通天塔156",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150000,
    "defaultGround": "grass",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT156_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT156_6_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_MT156_6_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT156_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20],
    [ 20,374,688,351,382, 20,383, 20,387,689,  0,689, 20],
    [ 20,367, 20, 20, 20, 20,695, 20, 20, 20,342, 20, 20],
    [ 20,374, 20,365,343,688,  0, 20,390,654, 21,382, 20],
    [ 20,687,342,349, 20,351, 21, 20, 22, 20, 20, 20, 20],
    [ 20, 20, 20,365, 20, 21,383, 20,687, 20,367,367, 20],
    [ 20,360, 20,691, 20, 20, 20, 20,342, 20, 20,689, 20],
    [ 20,360, 20,  0,564,374,  0,686,  0,351,  0, 21, 20],
    [ 20,690, 20,342, 20, 20, 85, 20, 20, 20,342, 20, 20],
    [ 20,  0,694,374,343,  0,568,  0, 20,  0,692,  0, 20],
    [ 20, 21, 20, 20, 20,694,  0,694, 20,360,349,360, 20],
    [ 20, 87,693,694,693,  0, 88,  0, 20,360,349,360, 20],
    [ 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20]
],
    "bgmap": [

],
    "fgmap": [

]
}