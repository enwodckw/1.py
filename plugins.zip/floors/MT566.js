main.floors.MT566=
{
    "floorId": "MT566",
    "title": "通天塔 566 ",
    "name": "通天塔566",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1431,538,1222,  1,1222,1430,1222,  1,  0,349, 87,  1],
    [  1,342,  1,  1,  1,  1,342,  1,  1,1429,  1,1427,  1],
    [  1,1222,538,1430,  1,1429,  0,  0,387,  0,342,  0,  1],
    [  1,  1,  1,342,  1,  0,  1,342,  1,  1,  1,  1,  1],
    [  1,1222,538,1432,342,  0,  1,349,1433,1219,1219,1219,  1],
    [  1,  1,  1,  1,  1,1438,342,  0,  1,  1,  1,  1,  1],
    [  1,1222,1356,1356,  1,  0,  1,349,1433,1220,1220,1220,  1],
    [  1,1222,  1,1356,  1,  0,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,1432,  1,  0,  1, 22,  1,1222,1222,1423,  1],
    [  1,  1,  1,342,  1,1429,  1,1356,  1,  1,  1,342,  1],
    [  1, 88,  0,1427,  0,  0,1438,  0,1431,1356, 22, 22,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}