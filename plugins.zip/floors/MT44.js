main.floors.MT44=
{
    "floorId": "MT44",
    "title": "通天塔 44 ",
    "name": "通天塔44",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "12,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,381,  1,380,  1,379,  1,369,  1,352,  1, 87,  1],
    [  1,373,  1,373,  1,373,  1,373,  1,373,  1,  0,  1],
    [  1,427,  1,424,  1,422,  1,420,  1,418,  1,350,  1],
    [  1,  0, 30,  0, 86,  0, 30,  0, 86,  0,  1,417,  1],
    [  1,342,  1,343,  1,342,  1,343,  1,417,  1, 30,  1],
    [  1,377,  1,378,  1,377,  1,378,  1,  0,344,  0, 88],
    [  1,417,  1,418,  1,417,  1,418,  1,417,  1,343,  1],
    [  1,  0, 30,  0, 86,  0, 30,  0, 86,  0,  1,425,  1],
    [  1,426,  1,423,  1,421,  1,419,  1,417,  1,390,  1],
    [  1,373,  1,373,  1,373,  1,373,  1,373,  1,390,  1],
    [  1,381,  1,380,  1,379,  1,362,  1,350,  1,382,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}