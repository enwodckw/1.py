main.floors.MT188=
{
    "floorId": "MT188",
    "title": "通天塔 188 ",
    "name": "临时教会住所188",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,9": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT188_10_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT188_10_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "3,3": [
            "吸收斩神剑剑意,全属性增加1亿",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "100000000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "100000000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "100000000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {
        "10,3": {
            "0": {
                "condition": "flag:door_MT188_10_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT188_10_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144,755,  0,565,  0,756,  0,565,144,  0,536,  0,144],
    [144,  0,144,144,144,144,144,343,144,569,  0,569,144],
    [144,565,144,398,  0,344,344,  0,144,144, 85,144,144],
    [144,  0,144,602,639,  0,764,764,144,763,  0,763,144],
    [144,754,144,144,144,144,144,144,144,144,342,144,144],
    [144,  0,  0,342,  0,766,  0,751,  0,378,  0,757,144],
    [144,569,  0,752,378,741,378,741,766,  0,741,602,144],
    [144,741,342,741,741,741,342,741,741,757,741,378,144],
    [144,  0,764,  0,741,  0,764,  0,741,  0,344, 87,144],
    [144,637,  0,637,741,637,  0,637,344,378,741,741,144],
    [144,  0,637,  0,741,  0,637,  0,741,  0,  0, 88,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}