main.floors.MT283=
{
    "floorId": "MT283",
    "title": "通天塔 283 ",
    "name": "通天塔283",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000,
    "defaultGround": "ground",
    "bgm": "yiji.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "8,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT283_9_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT283_9_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "9,2": {
            "0": {
                "condition": "flag:door_MT283_9_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT283_9_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [155,155,155,155,155,155,155,155,155,155,155,155,155],
    [155, 88,  0,349,  0,953, 21,155,956,155,384,  0,155],
    [155,342,155,155,342,343,  0,342,  0, 85,  0,536,155],
    [155,952,387,155,950,  0,348,155,956,155,384,  0,155],
    [155,564,  0,155,155,342,155,155,  0,155,155,155,155],
    [155,155,155,155,951,  0,951,155,958,370,570,370,155],
    [155,348,954,342,  0,  0,155,155,155,155,155,155,155],
    [155, 86,155,155,155,359, 21,155,349,155,385,385,155],
    [155,955, 22,387,155,155,342,155,349,155,370,370,155],
    [155,155,155,155,155,951,  0,155,349,155,957,370,155],
    [155,348,155, 22,950, 86,348,155,955,155,342,155,155],
    [155, 87, 86,  0,350,155,954,348,  0, 22,  0,359,155],
    [155,155,155,155,155,155,155,155,155,155,155,155,155]
],
    "bgmap": [

],
    "fgmap": [

]
}