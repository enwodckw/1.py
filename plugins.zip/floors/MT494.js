main.floors.MT494=
{
    "floorId": "MT494",
    "title": "通天塔 494 ",
    "name": "通天塔494",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  4,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1363,  4,1335,370,377,370,1335,538,370,377,370,  1],
    [  1,344,  4, 86,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,344,  4,1334,363,363,363,1334,356,356,356,1342,  1],
    [  1,344,  4,  1,  1,  1,  1,  1,  1,  1,  1, 86,  1],
    [  1,343,  1,1341, 29, 30, 29,1341, 29, 30, 29,1342,  1],
    [  1,343,  1, 86,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,343,  1,1340, 28, 28, 28,1340, 28, 28, 28,1339,  1],
    [  1,342,  1,  1,  1,  1,  1,  1,  1,  1,  1, 86,  1],
    [  1,342,  1,1338, 27, 27, 27,1338, 27, 27, 27,1339,  1],
    [  1,342,  1, 86,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,  0,1327,  0,1332,  0,1327,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}