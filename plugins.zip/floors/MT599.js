main.floors.MT599=
{
    "floorId": "MT599",
    "title": "通天塔 599 ",
    "name": "通天塔599",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 72,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "4,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT599_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT599_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "10,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT599_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "10,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT599_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT599_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT599_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT599_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT599_6_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,7": {
            "0": {
                "condition": "flag:door_MT599_6_7==8",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT599_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  0,1468,  0,  0,  0,  0,  0,  0,  0,1468,  0,  1],
    [  1,  0,  1,  1,1484,  1,342,  1,1484,  1,  1,  0,  1],
    [  1,  0,  1,  4,  4,  4,353,  4,  4,  4,  1,  0,  1],
    [  1,  0,1485,  4,1490,1490, 85,1358,1358,  4,1485,  0,  1],
    [  1,  0,  1,  4,1490, 86,1477, 86,1358,  4,  1,  0,  1],
    [  1,  0,342,353, 85,1477,1478,1477, 85,353,342,  0,  1],
    [  1,  0,  1,  4,1358, 86,1477, 86,1489,  4,  1,  0,  1],
    [  1,  0,1485,  4,1358,1358, 85,1489,1489,  4,1485,  0,  1],
    [  1,  0,  1,  4,  4,  4,353,  4,  4,  4,  1,  0,  1],
    [  1,1468,  1,  1,1484,  1,342,  1,1484,  1,  1,1468,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1, 88,  0,1468,  0,  0, 87,1468,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}