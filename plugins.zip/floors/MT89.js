main.floors.MT89=
{
    "floorId": "MT89",
    "title": "通天塔 89 ",
    "name": "通天塔89",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT89_7_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT89_7_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT89_2_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT89_2_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,2": {
            "0": {
                "condition": "flag:door_MT89_7_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT89_7_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,7": {
            "0": {
                "condition": "flag:door_MT89_2_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT89_2_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,472,472,472,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0,349,  1,  0,549,  1,384,385,386,387,  1],
    [  1,  0,349,  0,  1,  0,  0, 85,384,385,386,387,  1],
    [  1,349,  0,387,  1,  0,549,  1,384,385,386,387,  1],
    [  1,  1,  1,  1,  1,545,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,545,  0,545,  0,342,546,370,370,  1],
    [  1,551,  0,551,  1,342,  1,342,  1,  1,  1,370,  1],
    [  1,  1, 85,  1,  1,546,  1,552,349, 21,  1,370,  1],
    [  1,384,384,384,  1,356,  1, 22,  1, 21,  1,370,  1],
    [  1,385,385,385,  1,356,  1, 22,  1, 21,472,370,  1],
    [  1,386,386,386,  1,356,  1,  1,  1,  1,  1,  1,  1],
    [  1,387,387,387,  1, 22,547, 21, 21, 21,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}