main.floors.MT375=
{
    "floorId": "MT375",
    "title": "通天塔 375 ",
    "name": "黑暗深渊375",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT375_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT375_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT375_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT375_6_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_MT375_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT375_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,6": {
            "0": {
                "condition": "flag:door_MT375_6_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT375_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,639,1150,639,1150,1209,1215,1209,1150,568,342,1170,1150],
    [1150,639,1150,639,1150,1212,1215,1212,1150,  0,1150,1207,1150],
    [1150,1175,  0,1175,1150, 34,1176, 34,1150, 22,1150,1210,1150],
    [1150,1150,342,1150,1150,1150,342,1150,1150,1172,1150,1150,1150],
    [1150,  0,352,  0,1164,  0, 21,  0,1164,  0,342,1175,1150],
    [1150,342,1150,343,1150,1150, 85,1150,1150, 86,1150,1207,1150],
    [1150,1176,1150,540,1150,1162,  0,1162,1150,1170,1150,1210,1150],
    [1150,570,1150,1150,1150,  0,  0,  0,1150,  0,1150,1150,1150],
    [1150, 22, 22, 22,1150,1150, 85,1150,1150,352,1150,538,1150],
    [1150,1150,1150,1150,1150,1162,  0,1162,1150, 21,1150,342,1150],
    [1150,1207,1207,1207,1172,  0, 88,  0,344,  0,1162, 87,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}