main.floors.ML25=
{
    "floorId": "ML25",
    "title": "通天塔 25 ",
    "name": "地下25",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,1": {
            "floorId": "ML24",
            "loc": [
                1,
                1
            ]
        },
        "1,11": {
            "floorId": "ML24",
            "loc": [
                1,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,342, 30, 30, 30,  1,363, 21,514, 21,356,  1],
    [  1,349,  1,  1,  1, 21,  1,363,  1,  1,  1,356,  1],
    [  1,  0,513, 86,  0,512,  1,363,  1,391,  1,356,  1],
    [  1,513,  1,  1,349,  1,  1,343,  1,519,  1,514,  1],
    [  1,342,  1,  1,  0,513,  1,  0,342,  0,342,  0,  1],
    [  1,519,  0,343,343,  0,348,  0,512,  0,512,  0,  1],
    [  1,  0,391,  0,  1,  1,  1,  1,  1,  1,  1, 86,  1],
    [  1,352,  0,352,  1, 30, 30, 30,352,512, 86,  0,  1],
    [  1,  1,  1,  1,  1,  1,343,  1,  1,  1,  1,348,  1],
    [  1,  0,342,512, 30, 30,514, 30, 30,513,342,  0,  1],
    [  1, 88,  1, 30, 30,502,  1,330, 30, 30,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}