main.floors.MT589=
{
    "floorId": "MT589",
    "title": "通天塔 589 ",
    "name": "通天塔589",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 72,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,9": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1223, 22,1469,  0,1451, 22,  1,1451,342,  0, 88,  1],
    [  1,  1,  1,  1,342,  1,  1,  1,349,  1, 86,  1,  1],
    [  1,1218,  0,  1,1465,  1,534,  1, 21,1467,  0,1467,  1],
    [  1,349,1466,343,349,  1,1467,  1,  1,  1, 86,  1,  1],
    [  1,1218,  0,  1,  0, 86,  0,1355,  0,  0,1464,  0,  1],
    [  1,  1,  1,  1,1464,  1,1467,  1,1464,  1,  1,  1,  1],
    [  1,342,1218, 21,568,  1,  0,  1,  0,  1,1223,568,  1],
    [  1,342,  1,  1,  1,  1, 22,  1, 21,  1,  1,342,  1],
    [  1, 87,343,343,1218,1221,1221,  1,  0,1465,  0,1482,  1],
    [  1,534,  1,  1,  1,  1,  1,  1,348,  1,  1,342,  1],
    [  1,534,1466,  0,390,390,390,348,348,  1,1223,568,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}