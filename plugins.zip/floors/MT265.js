main.floors.MT265=
{
    "floorId": "MT265",
    "title": "通天塔 265 ",
    "name": "通天塔265",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000,
    "defaultGround": "ground",
    "bgm": "yiji.mp3",
    "firstArrive": [
        "\t[hero]器灵残片又出现了,看来只有取到这片残片，才能知道器灵去了哪里"
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "0,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT265_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT265_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT265_4_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT265_8_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT265_2_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT265_2_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT265_10_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT265_10_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "6,2": [
            "\t[器灵,thief]救……我……我",
            "\t[hero]怎么没了？看来器灵肯定遇到了危险，只能通过剩下的残片来确定器灵的位置了",
            "吸收斩神剑残片剑意，全属性增加2千亿",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "200000000000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "200000000000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "200000000000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_MT265_6_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT265_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "4,7": {
            "0": {
                "condition": "flag:door_MT265_4_7==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT265_4_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,7": {
            "0": {
                "condition": "flag:door_MT265_8_7==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT265_8_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,2": {
            "0": {
                "condition": "flag:door_MT265_2_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT265_2_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,2": {
            "0": {
                "condition": "flag:door_MT265_10_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT265_10_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [154,154,154,154,  4,  4,  4,  4,  4,154,154,154,154],
    [154,639,571,639,  4,564,  0,564,  4,639,571,639,154],
    [154,154, 85,154,  4,  0,396,  0,  4,154, 85,154,154],
    [154,945,  0,945,  4,564,  0,564,  4,945,  0,945,154],
    [154,154,342,154,  4,  4,938,  4,  4,154,342,154,154],
    [154,  0,570,  0,342,945,  0,945,342,  0,570,  0,154],
    [154,154,154,154,154,154,934,154,154,154,154,154,154],
    [154,  0,637,  0, 85,945,  0,945, 85,  0,637,  0,154],
    [154,538,  0,538,154,154, 85,154,154,538,  0,538,154],
    [154,154,343,154,154,933,  0,933,154,154,343,154,154],
    [154,379,  0,342,361,  0,343,  0,368,342,  0,381,154],
    [ 88,  0,  0,916,  0,350,927,350,  0,916,  0, 87,154],
    [154,154,154,154,154,154,154,154,154,154,154,154,154]
],
    "bgmap": [

],
    "fgmap": [

]
}