main.floors.MO1=
{
    "floorId": "MO1",
    "title": " 通天塔密室 ",
    "name": "临时教会密室001",
    "width": 13,
    "height": 13,
    "canFlyTo": false,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1000000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,7": [
            "实力不够请勿进入，否则将会强制战斗导致战斗失败",
            {
                "type": "hide"
            }
        ],
        "6,1": [
            {
                "type": "if",
                "condition": "(item:greenKey<1000)",
                "true": [
                    {
                        "type": "setValue",
                        "name": "status:hp",
                        "operator": "+=",
                        "value": "item:greenKey*100000000000+item:pickaxe*10000000000"
                    },
                    {
                        "type": "setValue",
                        "name": "status:hp",
                        "operator": "*=",
                        "value": "0.005"
                    },
                    {
                        "type": "win",
                        "reason": "作弊成仙(200F)"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "status:hp",
                        "operator": "+=",
                        "value": "item:yellowKey*50000000000+item:pickaxe*1000000000000+item:blueKey*200000000000+item:redKey*800000000000"
                    },
                    {
                        "type": "setValue",
                        "name": "status:hp",
                        "operator": "*=",
                        "value": "0.005"
                    },
                    {
                        "type": "win",
                        "reason": "快乐成仙(200F)"
                    }
                ]
            }
        ],
        "8,3": [
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        1
                    ]
                ],
                "floorId": "MO1"
            },
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        8,
                        4
                    ]
                ],
                "floorId": "MO1"
            },
            {
                "type": "if",
                "condition": "(item:greenKey===1000)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            2
                        ],
                        "floorId": "MO1"
                    }
                ],
                "false": []
            }
        ],
        "4,3": [
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        1
                    ]
                ],
                "floorId": "MO1"
            },
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        4,
                        4
                    ]
                ],
                "floorId": "MO1"
            },
            {
                "type": "if",
                "condition": "(item:greenKey<=999)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            4,
                            2
                        ],
                        "floorId": "MO1"
                    },
                    {
                        "type": "setValue",
                        "name": "item:greenKey",
                        "value": "1000"
                    }
                ],
                "false": []
            }
        ],
        "7,4": [
            "右为全绿通道"
        ],
        "5,4": [
            "左为咸绿通道"
        ]
    },
    "changeFloor": {
        "6,12": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "8,1": {
            "floorId": "MT201",
            "loc": [
                11,
                11
            ]
        },
        "4,1": {
            "floorId": "MT201",
            "loc": [
                11,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {
        "6,6": [
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        12
                    ]
                ],
                "floorId": "MO1"
            },
            {
                "type": "moveHero",
                "time": 10,
                "steps": [
                    "up:1"
                ]
            },
            {
                "type": "moveAction"
            },
            {
                "type": "setBlock",
                "number": "E769",
                "loc": [
                    [
                        6,
                        3
                    ]
                ],
                "floorId": "MO1"
            },
            {
                "type": "sleep",
                "time": 1000
            },
            {
                "type": "playBgm",
                "name": "boss.mp3"
            },
            "\t[萌一,E769]小友止步",
            "\t[hero]你是？看你的样子不像是这里面的怪物",
            "\t[萌一,E769]我当然不是，我也是这次求仙者，我来自萌新国，想必你也发现了，这里面修炼很快，你我都已成仙，不过我发现了一个秘密",
            "\t[hero]秘密？",
            "\t[萌一,E769]我原以为仙就是终点，现在才发现还有神,不过我已经找到了一条密道，如果穿过去我们就可以先一步成神，怎么样，有没有兴趣一起去探探？",
            "\t[hero](成神？如果成神了能够消灭塔灵吗？或许可以试试)我也正有此意",
            "\t[萌一,E769]好，咱们出发，你跟我来",
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "E770",
                "loc": [
                    [
                        7,
                        5
                    ]
                ],
                "floorId": "MO1"
            },
            {
                "type": "setBlock",
                "number": "E771",
                "loc": [
                    [
                        5,
                        5
                    ]
                ],
                "floorId": "MO1"
            },
            "\t[胖伯,E770]小友不可，你可知道他是谁？",
            "\t[hero]他不是本次求仙者之一吗？",
            "\t[胖伯,E770]开始是，现在就不一定了",
            "\t[哀如雪,E771]就是，小友千万别上当",
            "\t[萌一,E769]可恶，你们为啥总要跟我作对？",
            "\t[胖伯,E770]师弟，你何必执迷不悟，你以为塔灵就是什么好人？",
            "\t[哀如雪,E771]师弟，醒醒吧，塔灵就是恶魔，这么长时间了，你还看不清吗",
            "\t[萌一,E769]这世界就是肉弱强食，等我完成主人的愿望，被主人赐给强大的修为，何愁不能壮大萌新国",
            "\t[胖伯,E770]壮大萌新国我们自然会做，但不是你这种给别人当走狗，如果塔灵破了封印出去，整个世界生灵涂炭，你以为他会放过萌新国",
            "\t[萌一,E769]主人已经答应我了，只要完成他的愿望，就会帮我壮大萌新国，谁都不能阻止我",
            "\t[哀如雪,E771]醒醒吧，你不应该是这个样子，邪不胜正，塔灵终究会失败的，他…",
            "\t[萌一,E769]住口，凡阻止我的都得死，小友跟我走吧，让我带你成神",
            "\t[hero]我看这不是成神路，而是你想把我带去见塔灵吧，我不会跟你去的，我跟塔灵不共戴天",
            "\t[萌一,E769]为什么会这样，可恶，既然不听我的，那就去死吧",
            "\t[哀如雪,E771]小友小心",
            {
                "type": "move",
                "loc": [
                    6,
                    3
                ],
                "time": 50,
                "keep": true,
                "steps": [
                    "down:1"
                ]
            },
            {
                "type": "battle",
                "id": "E769"
            },
            "\t[萌一,E769]为什么会这样？我不应该…输的…",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        4
                    ]
                ],
                "floorId": "MO1"
            },
            "\t[哀如雪,E771]师弟",
            "\t[哀如雪,E771]师兄，师弟他",
            "\t[胖伯,E770]就算他不被小友杀死，也会死在别人手里，这就是命数吧，我们也该回去告诉国主这里发生的一切",
            "\t[哀如雪,E771]好吧，我们也走吧，小友再见",
            "\t[hero]再见",
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        5
                    ]
                ],
                "floorId": "MO1"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        5
                    ]
                ],
                "floorId": "MO1"
            },
            "\t[hero]一路走来，很少看到其他修炼者，估计差不多都被塔灵控制了吧，这里也没有找到器灵所说的信仰之泉，难道被取走了吗？",
            {
                "type": "openDoor",
                "loc": [
                    6,
                    2
                ],
                "floorId": "MO1"
            }
        ]
    },
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144,144,144,144, 89,144, 89,144, 89,144,144,144,144],
    [144,144,144,144, 85,144, 85,144, 85,144,144,144,144],
    [144,144,144,144,  0,144,  0,144,  0,144,144,144,144],
    [144,144,144,144,  0, 92,  0, 94,  0,144,144,144,144],
    [144,144,144,144,  0,  0, 56,  0,  0,144,144,144,144],
    [144,144,144,144,144,144,344,144,144,144,144,144,144],
    [144,569,569,569,344,  0,  0,  0,344,569,569,569,144],
    [144,144,144,144,144,571,639,571,144,144,144,144,144],
    [144,567,567,567,343,639,571,639,343,567,567,567,144],
    [144,144,144,144,144,571,639,571,144,144,144,144,144],
    [144,564,564,564,342,  0,  0,  0,342,564,564,564,144],
    [144,144,144,144,144,144, 88,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}