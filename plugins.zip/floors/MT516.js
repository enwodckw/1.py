main.floors.MT516=
{
    "floorId": "MT516",
    "title": "通天塔 516 ",
    "name": "通天塔516",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": "MT515",
            "loc": [
                11,
                11
            ]
        },
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  4,  1,  1,  1,  1],
    [  1, 87,342, 30,  4,348,1385,377,  4,348,1386,379,  1],
    [  1,1378,  1,  1,  4,  1,342,  1,  4,  1,342,  1,  1],
    [  1,  0,  1,603,  4, 33,1383,377,  4, 33,1384,378,  1],
    [  1,  0,342,1388,  4,  1,342,  1,  4,  1,342,  1,  1],
    [  1,1380,  1,603,  4, 34,1381,377,  4, 34,1382,378,  1],
    [  1,  0,  1,  1,  4,  1,342,  1,  4,  1,342,  1,  1],
    [  1, 32,  1,602,  4, 32,1379,377,  4, 32,1380,377,  1],
    [  1,  0,342,1387,  4,  1,342,  1,  4,  1,342,  1,  1],
    [  1,1377,  1,602,  4, 31,1377,377,  4, 31,1378,377,  1],
    [  1,  0,  1,  1,  4,  1,342,  1,  4,  1,342,  1,  1],
    [  1, 88,343,1381,  0, 31, 31, 31,  4,348,  0, 91,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  4,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}