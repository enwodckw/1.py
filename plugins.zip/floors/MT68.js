main.floors.MT68=
{
    "floorId": "MT68",
    "title": "通天塔 68 ",
    "name": "通天塔68",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 24,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT68_1_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT68_1_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "1,3": {
            "0": {
                "condition": "flag:door_MT68_1_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT68_1_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,379,343,  0, 88,  0,342,466,384, 21,  1],
    [  1,  0,350,  0,  1, 30,  0, 30,  1,  0,  0, 21,  1],
    [  1, 85,  1,  1,  1,  1,472,  1,  1,  0,354, 21,  1],
    [  1,  0,379,  0,342,469,  0,469,342,468,  0, 22,  1],
    [  1,464,  0,464,  1,  0,  0,  0,  1,  0,385,  0,  1],
    [  1,  1,  1,  1,  1,  1,343,  1,  1,  1,  1,  1,  1],
    [  1,  0,350, 21,  0,277,  0,277,  0, 21,350,  0,  1],
    [  1,275,  1,  1,  1,  1,342,  1,  1,  1,  1,275,  1],
    [  1, 21,  1,471, 86,  0,469,  0, 86,471,  1, 21,  1],
    [  1, 21,  1,361,  1,343,  1,343,  1,361,  1, 21,  1],
    [  1,380,  1,380,  1,380,246,380,  1,380,  1,380,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}