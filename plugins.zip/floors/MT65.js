main.floors.MT65=
{
    "floorId": "MT65",
    "title": "通天塔 65 ",
    "name": "通天塔65",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 24,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT65_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT65_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT65_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT65_6_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,10": {
            "0": {
                "condition": "flag:door_MT65_6_10==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT65_6_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,360,367,374,381, 34,279, 34,381,374,367,360,  1],
    [  1,344,  1,  1,  1,  1,342,  1,  1,  1,  1,343,  1],
    [  1,465,  0, 27, 27, 27,466, 28, 28, 28,  0,465,  1],
    [  1,  0,  1,  1,  1,  1,342,  1,  1,  1,  1,  0,  1],
    [  1, 29,  1, 21, 22,277,  0,277, 22, 21,  1, 29,  1],
    [  1, 29,  1,  1,  1,  1,342,  1,  1,  1,  1, 29,  1],
    [  1, 29,  1,380,343,  0, 31,  0,343,380,  1, 29,  1],
    [  1, 30,  1,469,  0,469, 85,469,  0,469,  1, 30,  1],
    [  1,464,  1,  0, 31, 85,387, 85, 31,  0,  1,464,  1],
    [  1,  0,  1,343,  0,469, 85,469,  0,343,  1,  0,  1],
    [  1, 88,  1,380,469,  0, 31,  0,469,380,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}