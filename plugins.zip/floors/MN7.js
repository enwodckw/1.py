main.floors.MN7=
{
    "floorId": "MN7",
    "title": "通天塔 M7 ",
    "name": "黑暗深渊M7",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000000000,
    "defaultGround": "ground",
    "bgm": "boss.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "4,8": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "8,4": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
    [ 15, 15, 15, 15,569,569,569, 15, 87, 15, 15, 15, 15],
    [ 15, 15, 15, 15, 15, 15,343, 15, 23, 15, 15, 15, 15],
    [ 15, 15, 15, 15,  0,  0,1237,  0,  0, 15, 15, 15, 15],
    [ 15, 15, 15, 15,  0, 15, 86, 15, 15, 15, 15, 15, 15],
    [ 15, 15, 15, 15, 88, 15,1224,1224,1224, 15, 15, 15, 15],
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
    [ 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15]
],
    "bgmap": [

],
    "fgmap": [

]
}