main.floors.ML30=
{
    "floorId": "ML30",
    "title": "通天塔 30 ",
    "name": "地下30",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 10000,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,1": {
            "floorId": "MT120",
            "loc": [
                1,
                1
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,2": [
            {
                "type": "if",
                "condition": "(flag:30>=1)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            3
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            4
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            11
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            9,
                            4
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            7
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            9,
                            11
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            9,
                            7
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                1,
                                1
                            ]
                        ],
                        "floorId": "MT120"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:30",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "8,2": [
            {
                "type": "if",
                "condition": "(flag:30>=1)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            3
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            4
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            11
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            9,
                            4
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            7
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            9,
                            11
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            9,
                            7
                        ],
                        "floorId": "ML30"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                1,
                                1
                            ]
                        ],
                        "floorId": "MT120"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:30",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [10041,10041,10041,10041,10041,10041,10041,10041,10041,10041,10041,10041,10041],
    [10041, 88,10041,  0,  0,  0,  0,  0,  0,  0,  0,  0, 89],
    [10041,  0,10041,10041,10041,10041,249,  0,249,10041,10041,10041,10041],
    [10041,  0,10041,380,380,10041,10041, 85,10041,10041,380,380,10041],
    [10041,  0,10041,354,354, 85,  0,  0,  0, 85,354,354,10041],
    [10041,  0,10041,380,380,10041,  0,  0,  0,10041,380,380,10041],
    [10041,  0,10041,10041,10041,10041,  0,  0,  0,10041,10041,10041,10041],
    [10041,  0,10041,  0,123, 85,  0,  0,  0, 85,367,354,10041],
    [10041,  0,10041, 46, 45,10041,  0,  0,  0,10041,367,354,10041],
    [10041,  0,10041,10041,10041,10041,  0,  0,  0,10041,10041,10041,10041],
    [10041,  0,10041,354,360,10041,  0,  0,  0,10041,367,354,10041],
    [10041, 87,10041,354,360, 85,  0,  0,  0, 85,360,354,10041],
    [10041,10041,10041,10041,10041,10041,10041,10041,10041,10041,10041,10041,10041]
],
    "bgmap": [

],
    "fgmap": [

],
    "underGround": true,
    "bgm": "ks.mp3"
}