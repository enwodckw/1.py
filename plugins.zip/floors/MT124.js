main.floors.MT124=
{
    "floorId": "MT124",
    "title": "通天塔 124 ",
    "name": "通天塔124",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "0,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT124_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT124_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT124_5_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT124_5_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT124_8_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT124_8_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT124_8_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,2": {
            "0": {
                "condition": "flag:door_MT124_4_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT124_4_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "5,10": {
            "0": {
                "condition": "flag:door_MT124_5_10==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT124_5_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "5,6": {
            "0": {
                "condition": "flag:door_MT124_5_6==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT124_5_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,4": {
            "0": {
                "condition": "flag:door_MT124_8_4==3",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT124_8_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  1,  1,  1,  1,  1,  1,  1,  1],
    [  4,570,  0,570,  4,653,  1,379,652,379,  1,381,  1],
    [  4,  0,454,  0, 85,  0,  1,  1,342,  1,  1,647,  1],
    [  4,570,  0,570,  4,653,  0,647,  0,647,  0,  0,  1],
    [  4,  4,  4,  4,  4,  1,  1,  1, 85,  1,  1,647,  1],
    [  1,353,  1,647,  0,  1,647,365,  0,358,  1,570,  1],
    [ 88,  0,342,  0,646, 85,  0,  0,652,  0,  1,  0,  1],
    [  1,  0,  1,647,  0,  1,647,358,  0,365,  1,651,  1],
    [  1,640,  1,  1,  1,  1,  1,  1,  1,  1,  1,342,  1],
    [  1,  0,  1,647,  0,  1,361,  0,368,  1,381,650,  1],
    [  1,379,342,  0,642, 85,  0,650,  0,  1,360,360,  1],
    [  1, 87,  1,647,  0,  1,368,  0,361,  1,367,367,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}