main.floors.MT73=
{
    "floorId": "MT73",
    "title": "通天塔 73 ",
    "name": "通天塔73",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 48,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT73_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT73_10_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,4": {
            "0": {
                "condition": "flag:door_MT73_10_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT73_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0,342,342,  0, 87,  0,  1,348,  0,348,  1],
    [  1,  0,  0,  1,  1, 21,  0,349,344,  0,329,  0,  1],
    [  1,486,  1,  1,  1,  1,342,  1,  1,348,  0,348,  1],
    [  1,486,  1, 21, 21, 21,  0,487,  1,  1, 85,  1,  1],
    [  1,486,  1,  1,  1,  1,  1,  0,  1,488,  0,488,  1],
    [  1,  0,348,348,348,  0,  1,348,  1,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,342,  1,  0,  1,  1,342,  1,  1],
    [  1,  0,348,  0,487,  0,  0,486,  0,348, 22,  0,  1],
    [  1,488,  1,  1,  1,  1,489,  1,  1,  1,  1,488,  1],
    [  1,349,  1,361,361,  1,380,  1,368,368,  1,349,  1],
    [  1, 22,343,490,361,  1, 23,  1,368,490,343, 22,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}