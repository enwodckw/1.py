main.floors.MT409=
{
    "floorId": "MT409",
    "title": "通天塔 409 ",
    "name": "黑暗深渊深处409",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 200000000000,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_9_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "10,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_9_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_9_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "10,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_9_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_3_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_3_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_3_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT409_3_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,5": {
            "0": {
                "condition": "flag:door_MT409_6_5==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT409_6_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "9,9": {
            "0": {
                "condition": "flag:door_MT409_9_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT409_9_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "9,3": {
            "0": {
                "condition": "flag:door_MT409_9_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT409_9_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "3,3": {
            "0": {
                "condition": "flag:door_MT409_3_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT409_3_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "3,9": {
            "0": {
                "condition": "flag:door_MT409_3_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT409_3_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 87, 30, 30, 30,342,350,342, 30, 30, 30,1249,1150],
    [1150, 30,  0,1254,  4,  4,343,  4,  4,1254,342, 30,1150],
    [1150, 30,1254, 85,533,  4,1254,  4,533, 85,1254, 30,1150],
    [1150, 30,  4,533,350,  4,1216,  4,350,533,  4, 30,1150],
    [1150,342,  4,  4,  4,  4, 85,  4,  4,  4,  4,342,1150],
    [1150,350,343,1254,1216, 85,913, 85,1216,1254,343,350,1150],
    [1150,342,  4,  4,  4,  4, 85,  4,  4,  4,  4,342,1150],
    [1150, 30,  4,533,350,  4,1216,  4,350,533,  4, 30,1150],
    [1150, 30,1254, 85,533,  4,1254,  4,533, 85,1254, 30,1150],
    [1150, 30,342,1254,  4,  4,343,  4,  4,1254,342, 30,1150],
    [1150,1249, 30, 30, 30,342, 88,342, 30, 30, 30,1249,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}