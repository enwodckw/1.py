main.floors.MT355=
{
    "floorId": "MT355",
    "title": "通天塔 355 ",
    "name": "黑暗深渊355",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 10000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "11,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT355_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT355_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT355_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT355_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT355_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT355_10_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,6": {
            "0": {
                "condition": "flag:door_MT355_10_6==6",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT355_10_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,353,353,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 88,343,353,1150,1150,1150,1150,1150,  0,  0,947,1150],
    [1150,  0,1150,1150,1150,1150,1150,1150,1150,947,  4,  4,  4],
    [1150,1106,1150,1150,1150,1150,1150,1150,1150,  0,  4,639,  4],
    [1150,  0,1150,1150,1150,1150,1150,1150,1150,  0,  4,564,  4],
    [1150,1140,1150,1147,1150,1147,1150,1147,1150,947,  4,564,  4],
    [1150,  0,342,  0, 86,  0, 86,  0, 86,  0, 85,910,  4],
    [1150,1140,1150,1147,1150,1147,1150,1147,1150,947,  4,564,  4],
    [1150,  0,1150,1150,1150,1150,1150,1150,1150,  0,  4,564,  4],
    [1150,1106,1150,1150,1150,1150,1150,1150,1150,  0,  4,639,  4],
    [1150,  0,1150,1150,1150,1150,1150,1150,1150,947,  4,  4,  4],
    [1150, 87,343,353,1150,1150,1150,1150,1150,  0,  0,947,1150],
    [1150,1150,1150,353,353,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}