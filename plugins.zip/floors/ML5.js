main.floors.ML5=
{
    "floorId": "ML5",
    "title": "通天塔 5 ",
    "name": "地下5",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "5,2": [
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        5,
                        3
                    ]
                ],
                "floorId": "ML5"
            },
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "1,6": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "4,2": [
            {
                "type": "if",
                "condition": "blockId:6,2",
                "true": [],
                "false": [
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            3
                        ],
                        "floorId": "ML5"
                    }
                ]
            }
        ],
        "6,2": [
            {
                "type": "if",
                "condition": "blockId:4,2",
                "true": [],
                "false": [
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            3
                        ],
                        "floorId": "ML5"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,380,  1, 23, 47,570, 47, 23,  1,  0,533, 88,  1],
    [  1,380,  1,534,591,  0,591,534,  1,578,  0,  0,  1],
    [  1,380,  1,  1,  1,583,  1,  1,  1,343,  1,342,  1],
    [  1,584,342,348,  1,342,  1,350,  0,584,  0,353,  1],
    [  1,  1,  1,587,342,  0,343,587,342,  1,  1,  1,  1],
    [  1, 87,  0,  0,349,588,  0,  0,348,342,343,342,  1],
    [  1,  1,  1,587,  1,342,343,587,  0,  1,  1,382,  1],
    [  1,577,342,348,  1,  0,576,  1,577,366,  1,567,  1],
    [  1,380,  1,342,  1,  1,373,  1,366,366,  1,583,  1],
    [  1,380,  1,576,359,  1,373,  1,  1,  1,  1,566,  1],
    [  1,380,  1,359,359,  1,373,  0,583,  0,382, 61,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}