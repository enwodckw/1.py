main.floors.MT217=
{
    "floorId": "MT217",
    "title": "通天塔 217 ",
    "name": "通天塔217",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 5000000,
    "defaultGround": "grass",
    "bgm": "waiwei.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,3": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,4": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT217_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT217_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT217_8_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT217_8_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,10": {
            "0": {
                "condition": "flag:door_MT217_4_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT217_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,10": {
            "0": {
                "condition": "flag:door_MT217_8_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT217_8_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [140,140,140,140,140,140,140,140,140,140,140,140,140],
    [140,140,140,140,140,140,140,140,140,140,140,140,140],
    [140,140,140,140,140,140,140,140,140,140,140,140,140],
    [148,148,148,148,148,148, 88,148,148,148,148,148,148],
    [148,  0,380,  0,782,342,  0,342,782,  0,380, 87,148],
    [148,783,148,148,148,148,  0,148,148,148,148,148,148],
    [148,380,148,383,  0,785,  0,785,  0,383,148, 31,148],
    [148,602,148,568,603,148, 86,148,603,568,148,348,148],
    [148,148,148,148,148,148, 86,148,148,148,148,342,148],
    [148,388,  0,388,148,786,  0,786,148,389,  0,389,148],
    [148,  0,568,  0, 85,  0,  0,  0, 85,  0,568,  0,148],
    [148,388,  0,388,148,786,  0,786,148,389,  0,389,148],
    [148,148,148,148,148,148,148,148,148,148,148,148,148]
],
    "bgmap": [

],
    "fgmap": [

]
}