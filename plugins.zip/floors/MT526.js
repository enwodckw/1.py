main.floors.MT526=
{
    "floorId": "MT526",
    "title": "通天塔 526 ",
    "name": "通天塔526",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "4,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_5_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_5_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_5_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_5_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_5_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_5_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_8_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_8_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_8_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT526_8_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "5,10": {
            "0": {
                "condition": "flag:door_MT526_5_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT526_5_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "5,6": {
            "0": {
                "condition": "flag:door_MT526_5_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT526_5_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "5,2": {
            "0": {
                "condition": "flag:door_MT526_5_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT526_5_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,2": {
            "0": {
                "condition": "flag:door_MT526_8_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT526_8_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,6": {
            "0": {
                "condition": "flag:door_MT526_8_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT526_8_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,10": {
            "0": {
                "condition": "flag:door_MT526_8_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT526_8_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  1,  0,1394,  1,  1,1392,  1,262,  0,353,  1],
    [  1,  0,343, 33,  0, 85, 33,  0, 85,353,1226,  0,  1],
    [  1,1385,  1,  0,1394,  1,342,1392,  1,262,  0,353,  1],
    [  1,1387,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  1,  0,1393,  1,  0,1396,  1,262,  0,353,  1],
    [  1,569,343, 33,  0, 85, 33,  0, 85,353,1226,  0,  1],
    [  1,  0,  1,  0,1393,  1,  0,1396,  1,262,  0,353,  1],
    [  1,1387,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1385,  1,  0,1395,  1,342,1392,  1,262,  0,353,  1],
    [  1,  0,343, 33,  0, 85, 33,  0, 85,353,1226,  0,  1],
    [  1, 88,  1,  0,1395,  1,  1,1392,  1,262,  0,353,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}