main.floors.MN2=
{
    "floorId": "MN2",
    "title": "通天塔 M2 ",
    "name": "黑暗深渊M2",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000000000,
    "defaultGround": "ground",
    "bgm": "boss.mp3",
    "firstArrive": [
        {
            "type": "hide",
            "loc": [
                [
                    6,
                    0
                ]
            ],
            "floorId": "MN10"
        },
        "\t[hero]果然还有后手,我还真是小瞧你了"
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,2": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "2,10": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,  4,1222,1222,1222,  4, 88,  0,  0,  0,  0,  4,1150],
    [1150,  4,  4,  4,1222,  4,  4,  4,  4,  4,  0,  4,1150],
    [1150,  4,  4,  4,1222,342,568,568,568,  4,  0,  4,1150],
    [1150,  4,  4,  4, 86,  4,  4,  4,  4,  4,1240,  4,1150],
    [1150,  4,  0,  0,1240,  0,  0,  0,  0,  0,  0,  4,1150],
    [1150,  4,  0,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,  4,  0,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,  4, 23,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,  4, 87,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}