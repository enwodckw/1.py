main.floors.MT496=
{
    "floorId": "MT496",
    "title": "通天塔 496 ",
    "name": "通天塔496",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,373,380,373,  1,365,365,365,  1,1339,  0, 88,  1],
    [  1,  0,1344,  0,  1,  0,1343,  0,  1, 30,1339,  0,  1],
    [  1,  1,342,  1,  1,  1,342,  1,  1,  1,  1,342,  1],
    [  1,356,  0, 33,  1,356,  0,  1, 27, 30,  0, 27,  1],
    [  1,356,  1,1341,  1,356, 33,  1,342,  1,1334,  1,  1],
    [  1,  0,  1,  0, 86,  0,1341,342,  0,1341,  0,1341,  1],
    [  1,1334,  1,  1,  1,  1,343,  1,  1,  1,  1, 86,  1],
    [  1,  0,348,  0,1334,  0,  0,343,378, 33,1334,  0,  1],
    [  1,1335,  1,  1,  1,  1, 33,  1,  1,  1,  1,344,  1],
    [  1,1335,  1,  1,  1,  1,344,  1, 47, 47,378,378,  1],
    [  1,  0,359,  0,1337,  0, 87,342,1373, 47,348,348,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}