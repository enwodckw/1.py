main.floors.MT23=
{
    "floorId": "MT23",
    "title": "通天塔 23 ",
    "name": "通天塔23",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,4": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0,  0,343,  0, 37,  0,343,  0, 38,  0,  1],
    [  1,  0,348,  0,  1, 21,236, 21,  1, 21,240, 21,  1],
    [  1,  1,  1,236,  1,  1,342,  1,  1,  1,342,  1,  1],
    [  1, 87,  1,  0,236,  0, 31,  0,233,  0, 31,  0,  1],
    [  1, 31,342, 34,  1,  1,342,  1,  1,  1,342,  1,  1],
    [  1, 21,  1,  0,  1,  0,223,  0,  1,  0,223,  0,  1],
    [  1,233,  0,236,344,380,  0,380,  1,380,  0,380,  1],
    [  1,  1,342,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0, 21,  0,  1,372, 33,342,232, 33,  1,372,  1],
    [  1,233,  1,343,  1, 33,372,  1, 33,372,  1, 33,  1],
    [  1,  0,380,  0,342,240, 33,  1,372, 33,342,240,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}