main.floors.MT552=
{
    "floorId": "MT552",
    "title": "通天塔 552 ",
    "name": "通天塔552",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "0,8": [
            {
                "type": "jumpHero",
                "loc": [
                    11,
                    1
                ],
                "time": 500
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1210,1210,538,  1,  0,1418,387,387,387,  1,  0,  1],
    [  1,1416,1207,1207,  1,1417,  1,  1,  1,  1,  1,348,  1],
    [  1, 86,  1,  1,  1,  0, 21, 21,538,  0,  1,348,  1],
    [  1, 22,391,538,  1,1417,  1,  1,  1,1418,  1,348,  1],
    [  1, 86,  1,  1,  1,  0,350,387,  1,387,  1,348,  1],
    [  1,1414,  0,1414,  1,387,344, 22,  1,387,  1,348,  1],
    [  1,  1,342,  1,  1,  1,342,1415,  1,387,  1,348,  1],
    [ 89,1409,  0,1414,385,385,  0,  1,  1,  1,  1,1478,  1],
    [  1,  1,342,  1,538,385,385,  1,384,538,  4,1421,  4],
    [  1,  0,  0,  1,  1,  1,344,  1,384,384,  4,538,  4],
    [  1, 88,  0,342,348,348,1413,342,1413,384,  4, 87,  4],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}