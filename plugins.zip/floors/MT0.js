main.floors.MT0=
{
    "floorId": "MT0",
    "title": "通天塔 0 ",
    "name": "通天塔",
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "defaultGround": "ground",
    "images": [],
    "ratio": 1,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1],
    [  1,  1,  4,  4,  4,  4,  0,  4,  4,  4,  4,  1,  1],
    [  1,  1,  4, 89, 85,  0,  0,  0, 85, 89,  4,  1,  1],
    [  1,  1,  4,  4,  4,  4,  0,  4,  4,  4,  4,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1, 89, 85,  0,  0,  0, 85, 89,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,129,  0,129,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "firstArrive": [
        {
            "type": "setValue",
            "name": "item:greenKey",
            "operator": "+=",
            "value": "1000"
        },
        {
            "type": "changePos",
            "loc": [
                6,
                2
            ],
            "direction": "down"
        },
        "\t[hero]这里就是通天塔吗？好强大的压迫感，我紧挨着他们进来，竟然一个人都看不到，难道进来的通道都不一样吗？"
    ],
    "parallelDo": "",
    "events": {
        "7,10": [
            "全绿计分:1黄等于5000万，1蓝等于2亿，1红等于8亿，1破等于10亿，解毒衰所有药水每个1亿",
            "总分乘以0.5得最后计分",
            "后续更新若有变动，以变动为准"
        ],
        "5,10": [
            "咸绿计分:1绿5亿，1破1亿，解毒衰药水每个2亿(黄蓝红不计分)",
            "总分乘以0.05得最后计分",
            "后续更新若有变动，以变动为准"
        ],
        "5,6": [
            {
                "type": "choices",
                "text": "是否进行全绿跨区跳跃",
                "choices": [
                    {
                        "text": "是",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:I1245",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1154",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I448",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I457",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I480",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1227",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I334",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:book",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:fly",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I346",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I347",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I396",
                                "operator": "+=",
                                "value": "5"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I397",
                                "operator": "+=",
                                "value": "3"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I398",
                                "operator": "+=",
                                "value": "6"
                            },
                            {
                                "type": "setValue",
                                "name": "status:exp",
                                "operator": "+=",
                                "value": "4863443295"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        1
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        11
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        5
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        10
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        8
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "openDoor",
                                "loc": [
                                    4,
                                    6
                                ],
                                "floorId": "MT0"
                            }
                        ]
                    },
                    {
                        "text": "否",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            }
                        ]
                    }
                ]
            }
        ],
        "6,10": [
            {
                "type": "hide",
                "loc": [
                    [
                        3,
                        3
                    ]
                ],
                "floorId": "MT0"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        3,
                        6
                    ]
                ],
                "floorId": "MT0"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        9,
                        3
                    ]
                ],
                "floorId": "MT0"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        9,
                        6
                    ]
                ],
                "floorId": "MT0"
            },
            {
                "type": "hide"
            }
        ],
        "6,8": [
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        3
                    ]
                ],
                "floorId": "MT0"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        3
                    ]
                ],
                "floorId": "MT0"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        6
                    ]
                ],
                "floorId": "MT0"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        6
                    ]
                ],
                "floorId": "MT0"
            },
            "\t[hero]嗯？？？",
            "\t[hero]有危险",
            {
                "type": "moveHero",
                "time": 50,
                "steps": [
                    "up:1"
                ]
            },
            {
                "type": "changePos",
                "loc": [
                    6,
                    7
                ],
                "direction": "down"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        8
                    ]
                ],
                "floorId": "MT0"
            },
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "man",
                "loc": [
                    [
                        6,
                        9
                    ]
                ],
                "floorId": "MT0"
            },
            "\t[塔灵,man]实力这么弱，有这么强的感知力，不错  不错",
            "\t[hero]前辈是谁？",
            "\t[塔灵,man]我是这座塔的塔灵，欢迎来到通天塔",
            "\t[hero]通天塔？难道外面传说都是真的，爬到塔顶就能得到成仙之道",
            "\t[塔灵,man]对，不过为了你们的安全，我要在你们身上种下神识，以免你们受到危险",
            "\t[hero]种下神识？那我岂不是都在你的监视之中，不行不行",
            "\t[塔灵,man]哈哈哈，进来了还想反抗，虽然你的根骨不错，但是我不喜欢不听话的，既然你不同意我种下神识，那我就只能把你杀了，你可以去死了",
            "\t[hero]前辈",
            {
                "type": "animate",
                "name": "zone",
                "loc": [
                    6,
                    7
                ]
            },
            {
                "type": "setHeroOpacity",
                "opacity": 0
            },
            "\t[塔灵,man]反抗我的人都得死，哈哈哈，再来一批修炼者，我就可以突破紫薇圣人的封印了，哈哈哈哈",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        9
                    ]
                ],
                "floorId": "MT0"
            },
            {
                "type": "changeFloor",
                "floorId": "ML30",
                "loc": [
                    3,
                    7
                ]
            },
            {
                "type": "setHeroOpacity",
                "opacity": 1
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[hero]这是哪？",
            "\t[器灵,thief]你醒了",
            "\t[hero]前辈，这是哪里？",
            "\t[器灵,thief]这里是通天塔的 黑水监狱",
            "\t[hero]我怎么会在这里？",
            "\t[器灵,thief]你在被塔灵击杀时，我利用空间法则把你救了下来",
            "\t[hero]我想起来了，这座塔是个骗局对不对",
            "\t[器灵,thief]对，也不对",
            "\t[hero]？",
            "\t[器灵,thief]你们不就想爬到塔顶找到成仙的秘诀吗？",
            "\t[hero]前辈都知道？爬到塔顶真的能成仙吗？",
            "\t[器灵,thief]这座塔可是主人留下来的圣器，成仙当然轻而易举，但是对于你们来说却难如登天",
            "\t[hero]是因为塔灵？",
            "\t[器灵,thief]你很聪明，当初主人强行让通天塔认他为主，虽然签缔了契约，但是塔灵一直都不服",
            "\t[器灵,thief]结果机会来了，主人用通天塔关押了各种凶恶之徒包括很多宗门做坏事的弟子，终于引来了所有凶恶之徒的同党以及宗门联手，对主人进行了一场埋伏，主人虽然实力强大，但架不住人多，在主人准备用通天塔将所有人收进去时，塔灵突然叛变，导致主人精神力受损，被敌人偷袭，我为了救主人直接引爆了自己，给主人赢取了逃跑时间",
            "\t[器灵,thief]然而塔灵竟然吸收了所有被关押在塔里的各种凶恶之徒的精神力，导致自身精神力大增，直接挣脱了主人签下的精神力契约，然后主人受到重创，自知逃不了了，遍用大神通将我自爆后的残魂以及通天塔塔灵全部封印在了通天塔内，谁也出不去",
            "\t[器灵,thief]塔灵给你们种下神识就是想让你们快速成长，吸取你们的精神力，冲破主人留下的封印，如果我所算不错的话，再有一批修炼者进来，那么塔灵就真的会冲破封印",
            "\t[hero]没办法阻止它吗？前辈你既然和它同一时代的人，应该能阻止它吧",
            "\t[器灵,thief]我现在只是一个残魂，在当初大战之前，我和它同等阶，我主杀伐，它主防御，如今他实力没受到啥影响。而我为了救主人发动了自爆，如今只是残魂，我无力阻止它了，如果它出去了，你们这一界都会生灵涂炭",
            "\t[hero]真没办法了吗？",
            "\t[器灵,thief]我感应到了我的其它残躯也在这座通天塔内，你如果能帮我找到全部碎片，等我融合后或许可以阻止它",
            "\t[hero]那行，我现在就为前辈去寻找",
            "\t[器灵,thief]先等一下，我在你身上感受到了一股很强大的精神力量，你是不是有什么宝物携带着？",
            "\t[hero]宝物？(说着掏出了绿钥匙)",
            "\t[hero]前辈是这个吗？",
            "\t[器灵,thief]我看看……果然是混沌石(不知道是谁竟然将混沌石打造成了绿钥匙？以主人的实力也未必能破坏混沌石吧)",
            "\t[器灵,thief]这种绿钥匙你有多少把",
            "\t[hero]1000",
            "\t[器灵,thief](噗)那你知道你这绿钥匙怎么来的吗？",
            "\t[hero]从我记事起就一直在身上，而且别人也拿不动，不知道为啥就我拿得动",
            "\t[器灵,thief](奇怪,这么多的绿钥匙需要好多的混沌石，整个真主界也没有多少混沌石吧！看来他身上有很大的秘密)混沌石并不是人人都可以拿得动，最少也要有仙神境以上的力量才能拿得动，那你收好吧，我估计塔灵是没有看出来，不然早就给你抢跑了，而它正好是仙神境界的人，你可以走了",
            "\t[hero]前辈不需要吗？我有这么多可以分给前辈",
            "\t[器灵,thief]也行，当然我不白拿，我这里有一部功法，你给我五把绿钥匙就能拿走，你要吗？",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我五绿，换取一部功法",
                "choices": [
                    {
                        "text": "换了",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "5"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I332",
                                "operator": "+=",
                                "value": "1"
                            },
                            "\t[器灵,thief]好了，我也要去寻找自身碎片了，先走了，记住没有实力千万别往下",
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        4,
                                        7
                                    ]
                                ],
                                "floorId": "ML30"
                            }
                        ]
                    },
                    {
                        "text": "不换了",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[器灵,thief]考虑好了再来找我吧",
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        4,
                                        7
                                    ]
                                ],
                                "floorId": "ML30"
                            }
                        ]
                    }
                ]
            },
            {
                "type": "hide",
                "loc": [
                    [
                        2,
                        7
                    ]
                ],
                "floorId": "ML30"
            },
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        1
                    ]
                ],
                "floorId": "MT0"
            }
        ],
        "7,6": [
            {
                "type": "choices",
                "text": "是否进行咸绿跨区跳跃",
                "choices": [
                    {
                        "text": "是",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1245",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1154",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I448",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I457",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I480",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I441",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I334",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:book",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:fly",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I346",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I347",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I396",
                                "operator": "+=",
                                "value": "5"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I397",
                                "operator": "+=",
                                "value": "3"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I398",
                                "operator": "+=",
                                "value": "6"
                            },
                            {
                                "type": "setValue",
                                "name": "status:exp",
                                "operator": "+=",
                                "value": "4863443295"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        1
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        11
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        5
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        8
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        10
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "openDoor",
                                "loc": [
                                    8,
                                    6
                                ],
                                "floorId": "MT0"
                            }
                        ]
                    },
                    {
                        "text": "否",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            }
                        ]
                    }
                ]
            }
        ],
        "5,3": [
            {
                "type": "choices",
                "text": "是否进行全绿(既0绿)跨区跳跃",
                "choices": [
                    {
                        "text": "是",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:I1245",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1153",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1154",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I450",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I458",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I481",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1229",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1440",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:book",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:fly",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I346",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I347",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I396",
                                "operator": "+=",
                                "value": "6"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I397",
                                "operator": "+=",
                                "value": "6"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I398",
                                "operator": "+=",
                                "value": "6"
                            },
                            {
                                "type": "setValue",
                                "name": "status:exp",
                                "operator": "+=",
                                "value": "6863899595"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        1
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        11
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        5
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        10
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        8
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "openDoor",
                                "loc": [
                                    4,
                                    3
                                ],
                                "floorId": "MT0"
                            }
                        ]
                    },
                    {
                        "text": "否",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            }
                        ]
                    }
                ]
            }
        ],
        "7,3": [
            {
                "type": "choices",
                "text": "是否进行咸绿跨区跳跃",
                "choices": [
                    {
                        "text": "是",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:I1245",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1153",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1154",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I450",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I458",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I481",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1440",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:book",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:fly",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I346",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I347",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I396",
                                "operator": "+=",
                                "value": "6"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I397",
                                "operator": "+=",
                                "value": "6"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I398",
                                "operator": "+=",
                                "value": "6"
                            },
                            {
                                "type": "setValue",
                                "name": "item:I1229",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setValue",
                                "name": "status:exp",
                                "operator": "+=",
                                "value": "6863899595"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        1
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        11
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        5
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        10
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        8
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "openDoor",
                                "loc": [
                                    8,
                                    3
                                ],
                                "floorId": "MT0"
                            }
                        ]
                    },
                    {
                        "text": "否",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        6
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        5,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        7,
                                        3
                                    ]
                                ],
                                "floorId": "MT0"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "3,3": {
            "floorId": "MT651",
            "loc": [
                6,
                2
            ]
        },
        "3,6": {
            "floorId": "MT456",
            "loc": [
                6,
                1
            ]
        },
        "9,6": {
            "floorId": "MT456",
            "loc": [
                6,
                1
            ]
        },
        "9,3": {
            "floorId": "MT651",
            "loc": [
                6,
                2
            ]
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [

],
    "fgmap": [

],
    "width": 13,
    "height": 13,
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {},
    "bgm": "ks.mp3"
}