main.floors.MT220=
{
    "floorId": "MT220",
    "title": "通天塔 220 ",
    "name": "通天塔220",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 5000000,
    "defaultGround": "grass",
    "bgm": "waiwei.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,12": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,2": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "4,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT220_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT220_6_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,7": {
            "0": {
                "condition": "flag:door_MT220_6_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT220_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [262,142,142,142,262,142,142,142,262,142,142,142,262],
    [142,142,142,142,142,142,142,142,142,142,142,142,142],
    [142,142,142,142,142,142, 87,142,142,142,142,142,142],
    [142,142,142,142,142,345,  0,345,142,142,142,142,142],
    [142,142,142,142,142,  0,784,  0,142,142,142,142,142],
    [142,142,142,142,142,345,  0,345,142,142,142,142,142],
    [142,142,142,142,142,540,540,540,142,142,142,142,142],
    [142,142,142,142,142,142, 85,142,142,142,142,142,142],
    [ 31,348, 31,342,353,142,639,142,353,342, 31,348, 31],
    [142,142,142,142,637,142,540,142,637,142,142,142,142],
    [142,142,142,142,786,142,787,142,786,142,142,142,142],
    [ 32,349, 32,343,  0,343,  0,343,  0,343, 32,349, 32],
    [142,142,142,142,142,142, 88,142,142,142,142,142,142]
],
    "bgmap": [

],
    "fgmap": [

]
}