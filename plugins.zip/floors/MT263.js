main.floors.MT263=
{
    "floorId": "MT263",
    "title": "通天塔 263 ",
    "name": "通天塔263",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000,
    "defaultGround": "ground",
    "bgm": "yiji.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT263_8_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT263_8_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "8,10": {
            "0": {
                "condition": "flag:door_MT263_8_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT263_8_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [154,154,154,154,154,154,154,154,154,154,154,154,154],
    [154, 87,535,  0,926,  0,916,382,154,637,154,637,154],
    [154,154,154,154,154,351,154,154,154,538,154,  0,154],
    [154,154,154,154,154,  0,929,537,154,931,154,538,154],
    [154,154,154,154,154,926,154,154,154,  0,154,  0,154],
    [154,154,154,154,154,  0,342,928,355,358,154,932,154],
    [154,154,154,154,154,351,154,154,154,154,154,  0,154],
    [154,154,154,154,154,  0,342,927,  0,358,358,358,154],
    [154,154,154,154,154,925,154,154,154,154,154,154,154],
    [154,  0,927,  0,154,  0,154,916,154, 21,  0, 21,154],
    [154,349,154,  0,926,  0,342,  0, 85,  0,897,  0,154],
    [154, 88,342,  0,154,382,154,916,154, 22,  0, 22,154],
    [154,154,154,154,154,154,154,154,154,154,154,154,154]
],
    "bgmap": [

],
    "fgmap": [

]
}