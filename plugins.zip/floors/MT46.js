main.floors.MT46=
{
    "floorId": "MT46",
    "title": "通天塔 46 ",
    "name": "通天塔46",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_2_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT46_2_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,6": {
            "0": {
                "condition": "flag:door_MT46_6_6==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT46_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,6": {
            "0": {
                "condition": "flag:door_MT46_10_6==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT46_10_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "4,2": {
            "0": {
                "condition": "flag:door_MT46_4_2==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT46_4_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,8": {
            "0": {
                "condition": "flag:door_MT46_2_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT46_2_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,373,  0,373,  1,428,  0,428,  1,348,349,348,  1],
    [  1,  0,452,  0, 85,  0,  0,  0,  1,  1,343,  1,  1],
    [  1,373,  0,373,  1,428,  0,428,343,349,  0,349,  1],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  0,391,  0,  1],
    [  1, 21,  0, 21,  4,539,434,539,  4,349,  0,349,  1],
    [  1,  0,433,  0,  4,  4, 85,  4,  4,  1, 85,  1,  1],
    [  1, 21,  0, 21,  4,  0,  0,  0,  4,429,  0,429,  1],
    [  1,  1, 85,  1,  4,  0,  0,  0,  4,  0,  0,  0,  1],
    [  1,417,  0,417,  4,  0,258,  0,  4,429,  0,429,  1],
    [  1,  1,342,  1,  4,  4,344,  4,  4,  1,343,  1,  1],
    [  1, 88,  0,372, 33, 21,419, 21, 33,372,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}