main.floors.MT549=
{
    "floorId": "MT549",
    "title": "通天塔 549 ",
    "name": "通天塔549",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "2,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,1226,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,1359,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,1359,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,1420,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,1420,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,1420,  1,  1,  1,  1, 87,  1],
    [  1,348,  0,1406,  0,348,  0,348,  0,348,1406,  0,  1],
    [  1,342,1405,  1,  1,  1,  1,  1,342,  1,  1,  1,  1],
    [  1,343,1407,  1,  1,  1,  1,  1,342,  1,  1,  1,  1],
    [  1,342,1405,  1,  1, 47,  1,  1,342,  1,  1, 23,  1],
    [  1,  0, 88,  1,  1,1223, 47,1419,  0,1419, 23,1223,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}