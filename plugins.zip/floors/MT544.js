main.floors.MT544=
{
    "floorId": "MT544",
    "title": "通天塔 544 ",
    "name": "通天塔544",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,344,348, 21, 21, 21,  1, 30,348,342, 30,  1],
    [  1,  0,  1,  1,  1,  1,533,  1,  1,  1,  1,342,  1],
    [  1,348,  1, 33, 33,  1, 22,  1, 30,348,342, 30,  1],
    [  1,  0,  1, 30, 33,  1, 22,  1,  1,  1,  1,342,  1],
    [  1,1405,  1,343,  1,  1,1407,  1, 30,348,342, 30,  1],
    [  1,  0,348,  0,1404,  0,  0,  1,  1,  1,  1,342,  1],
    [  1,1407,  1,  1,343,  1,  0,1403,  0,  0,348,  0,  1],
    [  1,373,  1, 33, 30,  1,1407,  1,342,  1,  1,1403,  1],
    [  1,373,  1, 33, 33,  1,348,  1,343,  1,  0,  0,  1],
    [  1,533,  1,  1,  1,  1,359,  1,1405, 86,1405,  0,  1],
    [  1,373,373,343,343,359,359,  1,381,  1,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}