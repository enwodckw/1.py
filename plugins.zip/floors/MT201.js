main.floors.MT201=
{
    "floorId": "MT201",
    "title": "通天塔 201 ",
    "name": "通天塔201",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 5000000,
    "defaultGround": "grass",
    "bgm": "waiwei.mp3",
    "firstArrive": [
        {
            "type": "disableShop",
            "id": "shop1"
        },
        {
            "type": "setValue",
            "name": "flag:__visited__",
            "value": "{}"
        },
        {
            "type": "function",
            "function": "function(){\ncore.visitFloor(\"MT201\")\n}"
        },
        {
            "type": "setValue",
            "name": "status:hp",
            "value": "18888888888888"
        },
        {
            "type": "setValue",
            "name": "status:atk",
            "value": "11000000000"
        },
        {
            "type": "setValue",
            "name": "status:def",
            "value": "11000000000"
        },
        {
            "type": "setValue",
            "name": "status:mdef",
            "value": "25000000000"
        },
        {
            "type": "setValue",
            "name": "item:yellowKey",
            "value": "30"
        },
        {
            "type": "setValue",
            "name": "item:blueKey",
            "value": "20"
        },
        {
            "type": "setValue",
            "name": "item:redKey",
            "value": "20"
        },
        {
            "type": "setValue",
            "name": "item:pickaxe",
            "value": "20"
        },
        {
            "type": "setValue",
            "name": "item:bomb",
            "value": "0"
        },
        {
            "type": "setValue",
            "name": "item:I618",
            "value": "0"
        },
        {
            "type": "setValue",
            "name": "item:earthquake",
            "value": "0"
        },
        {
            "type": "setGlobalValue",
            "name": "redPotion",
            "value": 5000
        },
        {
            "type": "setGlobalValue",
            "name": "bluePotion",
            "value": 10000
        },
        {
            "type": "setGlobalValue",
            "name": "yellowPotion",
            "value": 15000
        },
        {
            "type": "setGlobalValue",
            "name": "greenPotion",
            "value": 20000
        },
        {
            "type": "setGlobalValue",
            "name": "redGem",
            "value": 2
        },
        {
            "type": "setGlobalValue",
            "name": "blueGem",
            "value": 2
        },
        {
            "type": "setGlobalValue",
            "name": "greenGem",
            "value": 2
        },
        {
            "type": "disableShop",
            "id": "shop1"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "12,11": [
            {
                "type": "choices",
                "text": "给我一把绿升级梦云功法",
                "choices": [
                    {
                        "text": "升级",
                        "condition": "item:greenKey>=1",
                        "action": [
                            {
                                "type": "if",
                                "condition": "(item:greenKey>=1)",
                                "true": [
                                    {
                                        "type": "setValue",
                                        "name": "item:greenKey",
                                        "operator": "-=",
                                        "value": "1"
                                    },
                                    {
                                        "type": "openDoor",
                                        "loc": [
                                            12,
                                            10
                                        ],
                                        "floorId": "MT201"
                                    }
                                ],
                                "false": []
                            },
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不升级",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ],
        "10,10": [
            {
                "type": "choices",
                "text": "\t[咸鱼]是否开启超级爽塔模式(开启超级爽塔模式需要消耗1000绿钥匙且游戏结束无法计入榜单)",
                "choices": [
                    {
                        "text": "开启超级爽塔模式",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "if",
                                "condition": "(item:greenKey===1000)",
                                "true": [
                                    {
                                        "type": "setValue",
                                        "name": "item:greenKey",
                                        "operator": "-=",
                                        "value": "1000"
                                    },
                                    {
                                        "type": "setValue",
                                        "name": "item:I451",
                                        "operator": "+=",
                                        "value": "1"
                                    }
                                ],
                                "false": [
                                    "钥匙不足"
                                ]
                            },
                            {
                                "type": "exit"
                            }
                        ]
                    },
                    {
                        "text": "爬",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "exit"
                            }
                        ]
                    }
                ]
            }
        ],
        "6,12": [
            "因血瓶数值过大,取消血量计分，全部变成道具计分",
            "咸绿: 破每把计分 200000;  绿钥匙每把计分500000",
            "全绿: 黄钥匙每把1万; 蓝钥匙每把4万; 红钥匙每把16万; 破墙镐每把64万"
        ],
        "7,12": [
            "本区域开始到通关不会清理任何道具钥匙,(小声: 超市梦云)"
        ]
    },
    "changeFloor": {
        "6,3": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [140,140,140,140,140,140,140,140,140,140,140,140,140],
    [140,140,140,140,140,140,140,140,140,140,140,140,140],
    [140,140,140,140,140,140,140,140,140,140,140,140,140],
    [141,141,141,141,141,141, 87,141,141,141,141,141,141],
    [141,141,141,141,141,141, 86,141,141,141,141,141,141],
    [141,141,141,141,141,141, 33,141,141,141,141,141,141],
    [141,141,141,141,141,141,360,141,141,141,141,141,141],
    [141,141,141,141,141,141,360,141,141,141,141,141,141],
    [141,141,141,141,141,141,367,141,141,141,141,141,141],
    [141,141,141,141,141,141,367,141,141,141,141,141,440],
    [  4,  4,  4,  4,  4,  4,374,141,141,141,  0,141, 85],
    [536,536,536,345,345,345,374,381,381, 86,  0, 88,  0],
    [  4,  4,  4,  4,  4,  4,129,129,141,141,141,141,141]
],
    "bgmap": [
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,104,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0],
    [  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0]
],
    "fgmap": [

]
}