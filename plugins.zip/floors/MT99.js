main.floors.MT99=
{
    "floorId": "MT99",
    "title": "通天塔 99 ",
    "name": "通天塔99",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT99_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT99_6_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "3,8": [
            "吸收斩神剑剑意,全属性增加50000",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "50000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "50000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "50000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_MT99_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT99_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1],
    [  1,384,  1,385,  1,538,  0,538,  1,384,351,385,  1],
    [  1,351,  1,351,  1,  0,559,  0,  1,351,384,559,  1],
    [  1,555,  1,554,  1,  1,342,  1,  1,  1,  1,342,  1],
    [  1,  0,350,  0,552,  0,553,  0,552,  0,350,  0,  1],
    [  1,  1,342,  1,  1,  1,343,  1,  1,  1,342,  1,  1],
    [  1,  0,556,  0, 86, 21,  0, 21, 86,  0,556,  0,  1],
    [  1,559,  1,  1,  1,  0,536,  0,  1,  1,342,  1,  1],
    [  1,  0,  1,398,  1, 21,  0, 21,  1,  0,538,  0,  1],
    [  1, 22,  1,351,  1,  1, 85,  1,  1,557,  0,536,  1],
    [  1, 21,  1,351,  1,558,  0,558,  1,342,  1,  1,  1],
    [  1,348,342,559,  1,  0,  0,  0,342,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}