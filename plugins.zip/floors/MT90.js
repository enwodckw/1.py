main.floors.MT90=
{
    "floorId": "MT90",
    "title": "通天塔 90 ",
    "name": "通天塔90",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,377,370,342, 30,547,377,377,  1,349,354,349,  1],
    [  1,370,354,551,  0,  1,  0,  0,  1, 22,  0, 22,  1],
    [  1,377,370,  1, 30,472,370,370,  1,  1,551,342,  1],
    [  1,  1,  1,  1,  1,  1,342,550,  1,  0,352,  0,  1],
    [  1, 47, 47,552,343,  0,380,  0,  1,356,  0,356,  1],
    [  1, 21, 21, 21,  1,  1,342,  1,  1,  1,342,550,  1],
    [  1, 22, 22, 22,  1,  0,550,  0, 86, 86,  0,  0,  1],
    [  1,  1,  1,  1,  1,363,  0,363,  1,  1,  1,  1,  1],
    [  1,363,349,363,472,  0,349,  0,  1,356,352,356,  1],
    [  1,342,549,  1,  1,549,  1,342,  1,  1,549,342,  1],
    [  1, 87,  0,  0,352,  0,547,  0,348,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}