main.floors.MT289=
{
    "floorId": "MT289",
    "title": "通天塔 289 ",
    "name": "通天塔289",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000,
    "defaultGround": "ground",
    "bgm": "yiji.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT289_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT289_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT289_5_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT289_5_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT289_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT289_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT289_7_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT289_7_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,5": {
            "0": {
                "condition": "flag:door_MT289_6_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT289_6_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "5,6": {
            "0": {
                "condition": "flag:door_MT289_5_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT289_5_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,7": {
            "0": {
                "condition": "flag:door_MT289_6_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT289_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "7,6": {
            "0": {
                "condition": "flag:door_MT289_7_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT289_7_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [155,155,155,155,155,155,155,155,155,155,155,155,155],
    [155, 87,163,959,354,366,366,366, 21,958,163,  0,155],
    [155,161,155,155,155,155,161,155,155,155,155,161,155],
    [155,959,155,534,958,  0, 33,  0,958,534,155,959,155],
    [155,354,155,958,155,957,  0,957,155,958,155,354,155],
    [155,366,155,  0,957,155, 85,155,957,  0,155,359,155],
    [155,366,164, 33,  0, 85,639, 85,  0, 33,164,359,155],
    [155,366,155,  0,957,155, 85,155,957,  0,155,359,155],
    [155, 21,155,958,155,957,  0,957,155,958,155, 21,155],
    [155,958,155,534,958,  0, 33,  0,958,534,155,958,155],
    [155,161,155,155,155,155,161,155,155,155,155,161,155],
    [155, 88,164,958, 21,359,359,359,354,959,164,  0,155],
    [155,155,155,155,155,155,155,155,155,155,155,155,155]
],
    "bgmap": [

],
    "fgmap": [

]
}