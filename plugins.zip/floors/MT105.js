main.floors.MT105=
{
    "floorId": "MT105",
    "title": "通天塔 105 ",
    "name": "通天塔105",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT105_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT105_6_5",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,5": {
            "0": {
                "condition": "flag:door_MT105_6_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT105_6_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,390,  1,  1, 87,  1,  1,390,  1,  1,  1],
    [  1,  1,  1,533,  1,  1, 22,  1,  1,533,  1,  1,  1],
    [  1,  1,  1,390,  1,  1,535,  1,  1,390,  1,  1,  1],
    [  1,  1,  1,538,  1,  1, 21,  1,  1,538,  1,  1,  1],
    [  1,  1,  1,390,  1,  1, 85,  1,  1,390,  1,  1,  1],
    [  1,  1,  1,616,  1,613,  0,613,  1,616,  1,  1,  1],
    [  1,  1,  1, 86,  1,  1,342,  1,  1, 86,  1,  1,  1],
    [  1,  1,  1,348,370,611,  0,611,370,348,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,342,  1,  1,  1,  1,  1,  1],
    [  1,  1,365,365,365,614,  0,614,358,358,358,  1,  1],
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}