main.floors.MT76=
{
    "floorId": "MT76",
    "title": "通天塔 76 ",
    "name": "通天塔76",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 48,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "9,2": [
            "\t[器灵,thief]你的天赋真的恐怖，这才多久都快冲破凡阶阶段了，过了凡阶阶段就是仙了，想要继续增强吗？",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我10绿,全属性增加2000，换吗？",
                "choices": [
                    {
                        "text": "换了",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "10"
                            },
                            {
                                "type": "setValue",
                                "name": "status:atk",
                                "operator": "+=",
                                "value": "2000"
                            },
                            {
                                "type": "setValue",
                                "name": "status:def",
                                "operator": "+=",
                                "value": "2000"
                            },
                            {
                                "type": "setValue",
                                "name": "status:mdef",
                                "operator": "+=",
                                "value": "2000"
                            },
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不换",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[器灵,thief]有毅力",
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,381,352, 23,492,  0,  1,350,  1,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,375,343,349,  1,123,  0,  0,  1],
    [  1,359,  1,366,  1,375,  1,  1,  1,  0,  0,350,  1],
    [  1,350,  1,350,  1,355,375,493,  1,  1,342,  1,  1],
    [  1,359,  1,366,  1,  1,  1,342,  1, 33,  0,487,  1],
    [  1,491,  1,491,  1,  0,381,  0,  1,487,  1,360,  1],
    [  1,  0,  0,  0,343,490,  0,352,  1, 33,  0,487,  1],
    [  1,  1,342,  1,  1,  1,  1,  1,  1,  1,342,  1,  1],
    [  1,352,  0,489,  1,488,366,488,  1,  0,486,  0,  1],
    [  1,  1,343,  0,342,  0,  1,  0,342,  0,  0,  0,  1],
    [  1,360,490,  0,  1, 33,487, 33,  1, 33,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}