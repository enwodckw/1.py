main.floors.MT555=
{
    "floorId": "MT555",
    "title": "通天塔 555 ",
    "name": "通天塔555",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  1,343,343,343,343,  1,343,343,343,343,  1],
    [  1,  0,  1,343,344,344,343,  1,343,344,344,343,  1],
    [  1,362,  1,343,344,344,343,  1,343,344,344,343,  1],
    [  1,  0,  1,343,343,343,343,  1,343,343,343,343,  1],
    [  1,1409,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0, 86,1416,1417,1418,1417,1416,1365, 47,1397,1226,  1],
    [  1,1409,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  1,342,342,342,342,  1,342,342,342,342,  1],
    [  1,369,  1,342,343,343,342,  1,342,343,343,342,  1],
    [  1,  0,  1,342,343,343,342,  1,342,343,343,342,  1],
    [  1, 87,  1,342,342,342,342,  1,342,342,342,342,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}