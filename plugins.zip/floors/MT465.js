main.floors.MT465=
{
    "floorId": "MT465",
    "title": "通天塔 465 ",
    "name": "通天塔465",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,3": [
            {
                "type": "if",
                "condition": "(flag:465>=1)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            4
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            7
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            11
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            5
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            5
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            11
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            7
                        ],
                        "floorId": "MT465"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:465",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,3": [
            {
                "type": "if",
                "condition": "(flag:465>=1)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            4
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            7
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            11
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            5
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            5
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            11
                        ],
                        "floorId": "MT465"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            7,
                            7
                        ],
                        "floorId": "MT465"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:465",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0, 28, 29, 28,1318,  0, 27, 29, 27,344, 87,  1],
    [  1,342,  1,  1,  1,  1,342,  1,  1,  1,  1,  0,  1],
    [  1, 32,  1,370,  1,1328,  0,1328,  1,370,  1, 29,  1],
    [  1,343,  1,370,  1,  1, 85,  1,  1,370,  1, 21,  1],
    [  1, 34,  1,370,377, 85,  0, 85,377,370,  1,  0,  1],
    [  1, 31,  1,  1,  1,  1,  0,  1,  1,  1,  1,1317,  1],
    [  1,343,  1, 27, 30, 85,  0, 85, 30, 27,  1,  0,  1],
    [  1, 34,  1, 27, 27,  1,  0,  1, 27, 27,  1, 29,  1],
    [  1, 31,  1,  1,  1,  1,  0,  1,  1,  1,  1, 21,  1],
    [  1,344,  1, 28, 30,  1,  0,  1, 30, 28,  1,  0,  1],
    [  1,348,  1, 28, 28, 85,  0, 85, 28, 28,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}