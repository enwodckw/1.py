main.floors.MT595=
{
    "floorId": "MT595",
    "title": "通天塔 595 ",
    "name": "通天塔595",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 72,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "3,9": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "3,3": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  1],
    [  1,  2,  1,  1,  1,  1,  1,  1,  1,  1,  1,  2,  1],
    [  1,  2,  1, 87,342,564,343,566,344,568,  1,  2,  1],
    [  1,  2,  1,  0,  1,  1,  1,  1,  1,  1,  1,  2,  1],
    [  1,  2,  1,  0,342,564,343,566,344,568,  1,  2,  1],
    [  1,  2,  1,1469,  1,  1,  1,  1,  1,  1,  1,  2,  1],
    [  1,  2,  1,  0,342,564,343,566,344,568,  1,  2,  1],
    [  1,  2,  1,  0,  1,  1,  1,  1,  1,  1,  1,  2,  1],
    [  1,  2,  1, 88,342,564,343,566,344,568,  1,  2,  1],
    [  1,  2,  1,  1,  1,  1,  1,  1,  1,  1,  1,  2,  1],
    [  1,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}