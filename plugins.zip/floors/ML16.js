main.floors.ML16=
{
    "floorId": "ML16",
    "title": "通天塔 16 ",
    "name": "地下16",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "2,6": [
            {
                "type": "setValue",
                "name": "flag:door_ML16_1_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_ML16_1_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML16_1_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_ML16_1_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_ML16_11_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "10,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML16_11_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_ML16_11_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "10,6": [
            {
                "type": "setValue",
                "name": "flag:door_ML16_11_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "1,7": {
            "0": {
                "condition": "flag:door_ML16_1_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML16_1_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "1,3": {
            "0": {
                "condition": "flag:door_ML16_1_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML16_1_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "11,3": {
            "0": {
                "condition": "flag:door_ML16_11_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML16_11_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "11,7": {
            "0": {
                "condition": "flag:door_ML16_11_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML16_11_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21,533,  1,391,529,354,529,391,  1,533, 22,  1],
    [  1,529,538,  1,391,  1, 86,  1,391,  1,538,528,  1],
    [  1, 85,  1,  1,391,  1,527,  1,391,  1,  1, 85,  1],
    [  1,  0,526,  1,  1,  1, 86,  1,  1,  1,527,  0,  1],
    [  1,390,  0, 30,  0,525,  0,525,  0, 30,  0,390,  1],
    [  1,  0,526,  1,  1,  1, 86,  1,  1,  1,527,  0,  1],
    [  1, 85,  1,  1, 30,  1,526,  1, 30,  1,  1, 85,  1],
    [  1,528,538,  1, 30,  1, 86,  1, 30,  1,538,529,  1],
    [  1, 22,533,  1, 30,525,  0,525, 30,  1,533, 21,  1],
    [  1,  1,  1,  1,  1,  1,342,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,523,  0,  0,522,  0,  0,523,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}