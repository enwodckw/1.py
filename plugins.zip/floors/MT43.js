main.floors.MT43=
{
    "floorId": "MT43",
    "title": "通天塔 43 ",
    "name": "通天塔43",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "0,7": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,360,  0,  0,  1, 21, 21,  1,  0,367,  0,  1],
    [  1,360,  0,351,423,  1,422, 21,342,423,  0,367,  1],
    [  1,  1,  1,  1,342,  1,342,  1,  1,  1,  1,  1,  1],
    [  1, 21,  1,363,  0,  1,431,  0,431,343,349,  0,  1],
    [  1,348,  1,363,363,  1,  1,342,  1,  1,342,417,  1],
    [  1,417,  1,418,  1,  1,342,  0,417,  0, 21,349, 87],
    [ 88,  0,  0,  0,348, 21,  0,417,  0,342,  1,343,  1],
    [  1,  1,342,  1,  1,  1,  1,  1,  1,  1,  1,418,  1],
    [  1,431,  0,431,  1,387,422,  0, 22,  0,  1,356,  1],
    [  1,  0,  1,  1,  1,344,  1,  1,  1,419,  1,356,  1],
    [  1,  0,418,  0,349,  0,419,  0,349,  0,  1,356,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}