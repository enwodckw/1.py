main.floors.MT280=
{
    "floorId": "MT280",
    "title": "通天塔 280 ",
    "name": "通天塔280",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000,
    "defaultGround": "ground",
    "bgm": "yiji.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,8": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,6": [
            {
                "type": "openDoor",
                "loc": [
                    2,
                    3
                ],
                "floorId": "MT280"
            },
            {
                "type": "openDoor",
                "loc": [
                    10,
                    3
                ],
                "floorId": "MT280"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [154,154,154,154,154,154,154,154,154,154,154,154,154],
    [154,  4,  4,  4,  4,  4, 88,  4,  4,  4,  4,  4,154],
    [154,  4,361,361,361,945,  0,945,368,368,368,  4,154],
    [154,  4, 85,  5,  5,  5,344,  5,  5,  5, 85,  4,154],
    [154,  4,374,  5, 15, 15,  0, 15, 15,  5,374,  4,154],
    [154,  4,374,  5, 15,345,  0,345, 15,  5,374,  4,154],
    [154,  4,374,  5, 15,  0,948,  0, 15,  5,374,  4,154],
    [154,  4,374,  5, 15,345,  0,345, 15,  5,374,  4,154],
    [154,  4,374,  5, 15, 15, 87, 15, 15,  5,374,  4,154],
    [154,  4,374,  5,  5,  5,  5,  5,  5,  5,374,  4,154],
    [154,  4,374,374,374,637,  5,637,374,374,374,  4,154],
    [154,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,154],
    [154,154,154,154,154,154,154,154,154,154,154,154,154]
],
    "bgmap": [

],
    "fgmap": [

]
}