main.floors.MT128=
{
    "floorId": "MT128",
    "title": "通天塔 128 ",
    "name": "通天塔128",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  4,  4,  4],
    [652,537,351,653,342,  0,  0,643, 21,387,  4,618,  4],
    [  1,  1,  1,  1,  1,646,  1,  1,  1, 21,  4,344,  4],
    [652,537,351,653,342,349,  1,387,  1,644,  4,344,  4],
    [  1,  1,  1,  1,  1,365,342,645,  1,568,  4,344,  4],
    [650,537,351,653,342,365,  1,568,  1,533,  4,343,  4],
    [  1,  1,  1,  1,  1,349,  1,  1,  1,  1,  4,343,  4],
    [650,537,351,653,342,647,  0,647,  0,647,  4,343,  4],
    [  1,  1,  1,  1,  1,  1,342,343,342,  1,  4,342,  4],
    [  1,388,388,391,  1,343,647,  0,647,343,  4,342,  4],
    [  1,390,390,645,342,377,  1, 86,  1,377,  4,342,  4],
    [  1,389,389,391,  1,352,648,  0,648,352, 86, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}