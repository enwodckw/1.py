main.floors.MT117=
{
    "floorId": "MT117",
    "title": "通天塔 117 ",
    "name": "通天塔117",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT117_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT117_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT117_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT117_10_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "2,4": {
            "0": {
                "condition": "flag:door_MT117_2_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT117_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,4": {
            "0": {
                "condition": "flag:door_MT117_10_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT117_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,348,  0,348,  4,533,  0,533,  4,348,  0,348,  1],
    [  1,  0,387,  0,  4,  0,537,  0,  4,  0,387,  0,  1],
    [  1,348,  0,348,  4,533,  0,533,  4,348,  0,348,  1],
    [  1,  1, 85,  1,  4,  0,257,  0,  4,  1, 85,  1,  1],
    [  1,608,  0,608,  4,  4,344,  4,  4,608,  0,608,  1],
    [  1,  0, 30,  0, 21,  0, 88,  0, 21,  0, 30,  0,  1],
    [  1,342,  1,  1,  1,  1,538,  1,  1,  1,  1,342,  1],
    [  1,643,  1, 21,350,647,  0,647,350, 21,  1,643,  1],
    [  1,388,  1,609,  1,  1,342,  1,  1,609,  1,388,  1],
    [  1,389,  1,387,  1,538,  0,538,  1,387,  1,389,  1],
    [  1,391,  1,387,  1,  0, 22,  0,  1,387,  1,391,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}