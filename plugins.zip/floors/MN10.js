main.floors.MN10=
{
    "floorId": "MN10",
    "title": "通天塔 M10 ",
    "name": "黑暗深渊M10",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000000000,
    "defaultGround": "ground",
    "bgm": "boss.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,3": [
            "\t[hero]这次看你往哪里跑？",
            "\t[灭世者(代号:5594),E1235]想不到这么快就冲了上来,既然来了我就让你再死一次",
            {
                "type": "battle",
                "id": "E1235"
            },
            "\t[灭世者(代号:5594),E1235]咳咳咳…我又输了,长江后浪推前浪啊",
            "\t[hero]说吧,器灵被关在什么地方？说出来我或许可以饶你一死",
            "\t[灭世者(代号:5594),E1235]想不到你这么强,塔灵在你手里多次吃亏不无道理,器灵就在我身后监狱里关着,塔灵给我的命令是炼化器灵,呵呵…一笔交易让我教死伤惨重,原以为消灭你是一件微不足道的事,现在看来多么的可笑",
            "\t[hero]塔灵的好东西不少嘛,竟然让你这等强者都能够为他卖命",
            "\t[灭世者(代号:5594),E1235]我被困在这个境界太久了,塔灵以一座王座级高手坐落之地的图纸，换我消灭你,呵呵,你赢了,既然如此我跟塔灵的交易到此结束,图纸给你吧,或许你将是唯一能够终结塔灵的强者了",
            "\t[hero]王座级？看起来很强大的样子,既然如此那就饶你一命,图纸我就拿走了",
            {
                "type": "setValue",
                "name": "item:I1245",
                "operator": "+=",
                "value": "1"
            },
            "\t[灭世者(代号:5594),E1235]去吧,器灵那里已经没有守卫了,我就先撤了",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "MN10"
            },
            "\t[hero]这么着急离开？不会又有什么强者等我上钩吧",
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        0
                    ]
                ],
                "floorId": "MN10"
            },
            {
                "type": "openDoor",
                "loc": [
                    4,
                    2
                ],
                "floorId": "MN10"
            },
            {
                "type": "openDoor",
                "loc": [
                    8,
                    2
                ],
                "floorId": "MN10"
            },
            "\t[hero]先进去看一眼吧",
            {
                "type": "moveHero",
                "steps": [
                    "up:3"
                ]
            },
            {
                "type": "setHeroOpacity",
                "opacity": 0
            },
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "MN10"
            },
            "\t[灭世者(代号:5594),E1235]可恶,该死的塔灵,害我损兵折将,等我强大起来必灭尔等",
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "E403",
                "loc": [
                    [
                        6,
                        3
                    ]
                ],
                "floorId": "MN10"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[塔灵卫,E403]你没有机会了",
            "\t[灭世者(代号:5594),E1235]该死,是你？",
            {
                "type": "move",
                "loc": [
                    6,
                    2
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "up:1"
                ]
            },
            "\t[塔灵卫,E403]胆敢违抗主人命令,你去死",
            "\t[灭世者(代号:5594),E1235]既然如此,谁也别想过",
            {
                "type": "animate",
                "name": "baozha",
                "loc": [
                    6,
                    3
                ]
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        1
                    ]
                ],
                "floorId": "MN10"
            },
            {
                "type": "sleep",
                "time": 500
            },
            "\t[塔灵卫,E403]混账东西,一只蝼蚁靠偷袭竟然伤了我,看我把你的教会屠的一干二净,一只蚂蚁都不放过",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        3
                    ]
                ],
                "floorId": "MN10"
            },
            {
                "type": "changeFloor",
                "floorId": "MN11",
                "loc": [
                    6,
                    1
                ],
                "direction": "down"
            },
            {
                "type": "setHeroOpacity",
                "opacity": 1
            }
        ]
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,6": [
            {
                "type": "setBlock",
                "number": "E1235",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "MN10"
            },
            {
                "type": "openDoor",
                "loc": [
                    4,
                    7
                ],
                "floorId": "MN10"
            },
            {
                "type": "openDoor",
                "loc": [
                    8,
                    7
                ],
                "floorId": "MN10"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4, 87,  4,  4,  4,  4,  4,  4],
    [  4,570,  0,570,  4,571,  0,571,  4,570,  0,570,  4],
    [  4,  0,1226,  0, 85,  0,  0,  0, 85,  0,1226,  0,  4],
    [  4,570,  0,570,  4,571,  0,571,  4,570,  0,570,  4],
    [  4,  4,  4,  4,  4,  4,344,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,344,  4,  4,  4,  4,  4,  4],
    [  4,571,571,571,  4,  0,1244,  0,  4,571,571,571,  4],
    [  4,1225,1225,1225, 85,  0,  0,  0, 85,1225,1225,1225,  4],
    [  4,  4,  4,  4,  4,  4,344,  4,  4,  4,  4,  4,  4],
    [  4,570,  0,570,  4,  0,  0,  0,  4,570,  0,570,  4],
    [  4,  0,1226,  0,344,  0,  0,  0,344,  0,1226,  0,  4],
    [  4,570,  0,570,  4,  0, 88,  0,  4,570,  0,570,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}