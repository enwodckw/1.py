main.floors.MT82=
{
    "floorId": "MT82",
    "title": "通天塔 82 ",
    "name": "通天塔82",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 48,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,342,498,365,365,  1,358,358,498,342, 88,  1],
    [  1,  0,  1,348,365,365,499,358,358,348,  1,  0,  1],
    [  1,488,  1,  1,  1,  1,472,  1,  1,  1,  1,  0,  1],
    [  1,  0,379, 22,  0,490,  0,379,  0,488,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,498,  0,367,  0,367,  0,367,497,  0,  1,496,  1],
    [  1,  0,  1,  1,  1,342,  1,  1,  1, 21,  1,  0,  1],
    [  1,360,  1,352,  1,395,  1,352,  1, 21,  1,348,  1],
    [  1,360,  1,391,  1,352,  1,391,  1, 21,  1,348,  1],
    [  1,360,  1,352,  1,391,  1,352,  1,496,  1,348,  1],
    [  1,  0,342,501,  1,352,  1,501,342,  0,342,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}