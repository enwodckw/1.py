main.floors.MT421=
{
    "floorId": "MT421",
    "title": "通天塔 421 ",
    "name": "黑暗深渊深处421",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000000,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,3": [
            "\t[塔灵,thief]你来了",
            "\t[hero]前辈不是去找梦云前辈了吗？",
            "\t[塔灵,thief]我去了发现梦云真神的魂魄已经陷入了沉睡，如今事态紧急，唯一的希望就在你身上了",
            "\t[hero]这个我知道,不管如何我都要阻止他",
            "\t[塔灵,thief]如今只能想想办法如何才能让梦云醒过来,或许她能够阻止塔灵,到救得了一时，救不了一世,变强吧",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我50把绿钥匙,即可获得以下属性",
                "choices": [
                    {
                        "text": "全属性增加4000兆 (50绿钥匙)",
                        "condition": "item:greenKey≥50",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "50"
                            },
                            {
                                "type": "setValue",
                                "name": "status:atk",
                                "operator": "+=",
                                "value": "4000000000000000"
                            },
                            {
                                "type": "setValue",
                                "name": "status:def",
                                "operator": "+=",
                                "value": "4000000000000000"
                            },
                            {
                                "type": "setValue",
                                "name": "status:mdef",
                                "operator": "+=",
                                "value": "4000000000000000"
                            },
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不需要,谢谢",
                        "condition": "item:greenKey≥20",
                        "action": [
                            "\t[塔灵,thief]冲,打塔灵一个措手不及",
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 22,1150,383,1150,  0, 88,  0,1150,383,1150,380,1150],
    [1150, 22,1150,383,1150,  0,  0,  0,1150,383,1150,380,1150],
    [1150, 22,1150,383,1150,  0,123,  0,1150,383,1150,380,1150],
    [1150,344,1150,345,1150,1150,342,1150,1150,345,1150,344,1150],
    [1150,  0,348,  0,348,  0,  0,  0,348,  0,348,  0,1150],
    [1150,1150,1150,1150,1150,1150,1265,1150,1150,1150,1150,1150,1150],
    [1150,  0,348,  0,348,  0,  0,  0,348,  0,348,  0,1150],
    [1150,  0,1150,342,1150,343,1150,343,1150,343,1150,342,1150],
    [1150,1263,1150,538,1150, 21,1150,564,1150, 21,1150,538,1150],
    [1150,  0,1150,538,1150, 21,1150,564,1150, 21,1150,538,1150],
    [1150, 87,1150,538,1150, 21,1150,564,1150, 21,1150,538,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}