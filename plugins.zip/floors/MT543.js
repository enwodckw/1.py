main.floors.MT543=
{
    "floorId": "MT543",
    "title": "通天塔 543 ",
    "name": "通天塔543",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,348, 30,343,1405,  0, 47,381,  0,  0,  1,349,  1],
    [  1, 30, 30,  1,  1,  1,  1,  1,  1,342,  1,349,  1],
    [  1,  1,1404,  1,380, 47,380,349,349,1406,  1,349,  1],
    [  1, 31, 31,  1,  1,  1,  1,  1,  1,  1,  1,348,  1],
    [  1, 86,  1,  1, 21,343,1406,353,  1, 21,  1,348,  1],
    [  1, 30, 30,  1, 21,  1,380,353,344,348,  1,348,  1],
    [  1, 30,1403,  1, 21,  1,380,353,  1, 21,  1,1410,  1],
    [  1,  1,342,  1,1402,  1,  1,  1,  1,1402,  1,342,  1],
    [  1, 31,  0,343,  0,  0,1401,  0, 86,  0, 31,  0,  1],
    [  1,  0,  1,  1,  1, 31,  1,  1,342,  1,  1,1404,  1],
    [  1, 88,1401,1402,1401,  0,  1, 32,1403, 32,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}