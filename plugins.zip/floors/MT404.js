main.floors.MT404=
{
    "floorId": "MT404",
    "title": "通天塔 404 ",
    "name": "黑暗深渊深处404",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 200000000000,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT404_4_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT404_4_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,8": {
            "0": {
                "condition": "flag:door_MT404_4_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT404_4_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,570,1207,1250,381,374,374,374,374,1249,1150, 88,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,342,1150,  0,1150],
    [1150,348,  0,  0,1246,  0,348,  0,1246,  0,  0, 21,1150],
    [1150,342,1150,1247,1150,343,1150,1247,1150,1150,342,1150,1150],
    [1150,348,  0,348,1150,352,1209,352,1150,  0,1253,  0,1150],
    [1150,1150,342,1150,1150,1150,1150,1150,1150,1207,  0,1207,1150],
    [1150,  0,  0,1248,1150,379,  0,379,1150,1150,1150,1150,1150],
    [1150,1246,343,  0, 85,  0,570,  0,1150,381,381,352,1150],
    [1150,  0,  0,1248,1150,379,  0,379,1150,381,1150,1251,1150],
    [1150,1150,342,1150,1150,1150,1150,1150,1150,1249,1150,381,1150],
    [1150, 87,  0,1250,379,379,379,374,343,352,1150,381,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}