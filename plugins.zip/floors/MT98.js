main.floors.MT98=
{
    "floorId": "MT98",
    "title": "通天塔 98 ",
    "name": "通天塔98",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 300,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT98_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT98_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT98_6_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT98_6_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,2": {
            "0": {
                "condition": "flag:door_MT98_6_2==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT98_6_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,388,389,559,559,559,  0,559,559,559,389,388,  1],
    [  1,389,388,  1,  1,  1, 85,  1,  1,  1,388,389,  1],
    [  1,391,390,  1,  1,559,  0,559,  1,  1,390,391,  1],
    [  1,390,391,  1,  1,  0,  0,  0,  1,  1,391,390,  1],
    [  1,534,533,  1,  1,559,  0,559,  1,  1,534,534,  1],
    [  1,  1,  1,  1,  1,  1,342,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,538,  1,342,  1,538,  1,  1,  1,  1],
    [  1,  1,  1,  1,343,  1,343,  1,343,  1,  1,  1,  1],
    [353,351,  1,351,353,  1,343,  1,353,351,  1,351,353],
    [  1,342,  1,342,  1,  1,344,  1,  1,342,  1,342,  1],
    [  1, 88,  0,556,  0,  0,555,  0,  0,556,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}