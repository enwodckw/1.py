main.floors.ML20=
{
    "floorId": "ML20",
    "title": "通天塔 20 ",
    "name": "地下20",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "10,6": {
            "floorId": "ML21",
            "loc": [
                10,
                6
            ]
        },
        "1,1": {
            "floorId": "ML21",
            "loc": [
                1,
                1
            ]
        },
        "6,1": {
            "floorId": "ML21",
            "loc": [
                6,
                1
            ]
        },
        "6,11": {
            "floorId": "ML21",
            "loc": [
                6,
                11
            ]
        },
        "0,6": {
            "floorId": "ML19",
            "loc": [
                0,
                6
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,524,375,368,  1, 87, 33, 33,  1,350,350,  1],
    [  1,342,  1,  1,  1,  1,  1, 33, 33,343,349,349,  1],
    [  1,524,368,368,  1,379,  1,518,  1,  1,  1,  1,  1],
    [  1,375,375,375,  1,379,342,354,  1,378,378,378,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,525,  1,  1],
    [ 88,  0,376,363,363,515,356,356,376,  0, 87,  0,  1],
    [  1,342,  1,  1,  1,  1,  1,  1,  1,  1,525,  1,  1],
    [  1,  0,342,523,379,379,  1,361,  1,378,378,378,  1],
    [  1,522,  1,354,379,379,  1,375,  1,  1,  1,  1,  1],
    [  1,  0,  1,  1,343,  1,  1,524,343,524,361,361,  1],
    [  1,376,376,376,376,  1, 87,  0,  1,375,375,375,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}