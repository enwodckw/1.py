main.floors.MT205=
{
    "floorId": "MT205",
    "title": "通天塔 205 ",
    "name": "通天塔205",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 5000000,
    "defaultGround": "grass",
    "bgm": "waiwei.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,8": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,10": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT205_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT205_4_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,10": {
            "0": {
                "condition": "flag:door_MT205_4_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT205_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [140,140,140,140,140,140,140,140,140,140,140,140,140],
    [140,140,140,140,140,140,140,140,140,140,140,140,140],
    [148,148,148,148,148,148,148,148,148,148,148,148,148],
    [148,379,148,348,  0,379,148,  0, 33,  0,775,629,148],
    [148,  0,148,  0,148,148,148,365,148,148,148,148,148],
    [148,348,148,773,148, 30,148,774,148,775,359, 33,148],
    [148,776,148,342,148,776,148,342,148,342,148,148,148],
    [148,  0,344,  0,774,  0, 86,  0,772,  0,342,  0,148],
    [148, 88,343,780,148,148,148,775,148,343,148, 33,148],
    [148,780, 86,  0,148,379,148,377,148, 32,148,  0,148],
    [148,377,148,780, 85,379,148,377,148,348,148, 87,148],
    [141,141,141,141,141,141,141,141,141,141,141,343,141],
    [141,141,141,141,141,141,141,141,141,141, 31,350, 31]
],
    "bgmap": [

],
    "fgmap": [

]
}