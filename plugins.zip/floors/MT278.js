main.floors.MT278=
{
    "floorId": "MT278",
    "title": "通天塔 278 ",
    "name": "通天塔278",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000,
    "defaultGround": "ground",
    "bgm": "yiji.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT278_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT278_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT278_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT278_10_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT278_8_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT278_8_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT278_8_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT278_8_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,6": {
            "0": {
                "condition": "flag:door_MT278_10_6==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT278_10_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,3": {
            "0": {
                "condition": "flag:door_MT278_8_3==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT278_8_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [154,154,154,154,154,154,154,154,154,154,154,154,154],
    [154, 21,391, 21,154,391, 23,391,154, 22,391, 22,154],
    [154,154,939,154,154,154,940,154,154,154,939,154,154],
    [154,366,  0,538,638,538,  0,359, 85,938,  0,938,154],
    [154,154,154,154,154,154,154,154,154,  0,  0,  0,154],
    [154,537,603,564,945,  0,945,564,154,938,  0,938,154],
    [154,537,154,154,154, 21,154,154,154,154, 85,154,154],
    [154,345,154,354,154, 21,154,354,154,937,  0,937,154],
    [154,538,154,536,154, 21,154,536,154,  0,  0,  0,154],
    [154,353,154,940,154,939,154,940,154,937,  0,937,154],
    [154,343,154,342,154,343,154,342,154,154,342,154,154],
    [154, 87,933,  0,360,  0,928,  0,360,  0,932, 88,154],
    [154,154,154,154,154,154,154,154,154,154,154,154,154]
],
    "bgmap": [

],
    "fgmap": [

]
}