main.floors.MT192=
{
    "floorId": "MT192",
    "title": "通天塔 192 ",
    "name": "临时教会住所192",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "10,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT192_4_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT192_4_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT192_4_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT192_4_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,4": {
            "0": {
                "condition": "flag:door_MT192_4_4==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT192_4_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144,  0,741,751,  0,751,741,384,565,757,565,385,144],
    [144,754,342,  0,262,  0,741,741,741,342,741,741,144],
    [144,  0,741,751,  0,751,741,378,378,  0,747,  0,144],
    [144,391,741,741, 85,741,741,  0,741,741,344,741,144],
    [144,385,741,533,  0,533,741,749,741,385,  0,385,144],
    [144,  0,741,  0,565,  0,741,  0,741,  0, 87,  0,144],
    [144,756,741,533,  0,533,741,378,741,  0,765,  0,144],
    [144,342,741,741,344,741,741,  0,741,741,343,741,144],
    [144,  0,745,  0,378,378,  0,747,  0,378,378,378,144],
    [144,  0,741,741,343,741,741,741,741,342,741,741,144],
    [144, 88,741,355,355,355,741,384,384,756,384,384,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}