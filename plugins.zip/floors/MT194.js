main.floors.MT194=
{
    "floorId": "MT194",
    "title": "通天塔 194 ",
    "name": "临时教会住所194",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "2,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {
        "11,11": [
            "吸收斩神剑剑意,全属性增加1亿",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "100000000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "100000000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "100000000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144, 30,390,  0,  0,355,343,  0,355,343,355, 87,144],
    [144,342,741,755,387,  0,757,387,  0,758,  0,355,144],
    [144,343,741,  0,741,741,741,741,741,741,741,741,144],
    [144,342,741,  0,741,741,741,741,741,741,741,741,144],
    [144, 30,741,754,741,741,741,741,741,741,741,741,144],
    [144,  0, 88,  0,741,741,741,741,741,741,741,741,144],
    [144,261,  0,355,  0,764,348,348,348,348,348,446,144],
    [144,741,741,741,758,741,741,741,741,741,741,741,144],
    [144,741,741,741,  0,741,741,741,741,741,741,741,144],
    [144,741,741,741,351,741,741,741,741,741,741,741,144],
    [144,741,741,741,  0,765,348,348,348,348,348,398,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}