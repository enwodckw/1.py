main.floors.MT405=
{
    "floorId": "MT405",
    "title": "通天塔 405 ",
    "name": "黑暗深渊深处405",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 200000000000,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT405_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT405_6_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,3": {
            "0": {
                "condition": "flag:door_MT405_6_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT405_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,904,1257,  0,1150,534,534,534,1150,1246,1247,1246,1150],
    [1150,1257,  0,602,1150, 21, 22, 21,1150,  0,1150,  0,1150],
    [1150,  0,1250,  0,1150,1150, 85,1150,1150,388,1150,385,1150],
    [1150,1150,342,1150,1150,1258,  0,1258,1150,388,1150, 22,1150],
    [1150,384,  0, 21,1150,1150,1150,342,1150,388,1150,538,1150],
    [1150,384,1150,  0,1246,1247,1246,  0,538,  0,1150,385,1150],
    [1150,384,1150,1150,1150,1150,1150,385,  0,385,1150,  0,1150],
    [1150,384,  0,538,  0,1246,1150,1150,342,1150,1150,1246,1150],
    [1150,1150,1150,1150,1150,1247,1150,1248,  0,1248,1150,1247,1150],
    [1150,1150,534,  0,  0,1246,1150,  0,1249,  0,1150,1246,1150],
    [1150, 88,  0,1150,1150,1150,1150,534,534,534,1150, 87,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}