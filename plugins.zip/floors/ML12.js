main.floors.ML12=
{
    "floorId": "ML12",
    "title": "通天塔 12 ",
    "name": "地下12",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,10": [
            "\t[器灵,thief]这么快又回来了，塔灵好像去了更高层巡逻去了，这下边就是它的老巢了，我现在也不能频繁的出现了,塔灵好像已经知道我的存在了，已经在派人到处抓我，所以接下来我需要隐藏一段时间，剩下的全靠你了，继续增强实力吧",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我50绿,全属性增加10%，换吗？",
                "choices": [
                    {
                        "text": "换了",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "50"
                            },
                            {
                                "type": "setValue",
                                "name": "status:atk",
                                "operator": "*=",
                                "value": "1.1"
                            },
                            {
                                "type": "setValue",
                                "name": "status:def",
                                "operator": "*=",
                                "value": "1.1"
                            },
                            {
                                "type": "setValue",
                                "name": "status:mdef",
                                "operator": "*=",
                                "value": "1.1"
                            },
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不换",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[器灵,thief]接下来靠你自己了",
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "6,12": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,2": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21,387, 21,  1, 22,  0, 22,  1, 21,387, 21,  1],
    [  1, 21,564, 21,  1,  0, 88,  0,  1, 21,564, 21,  1],
    [  1,  0,588,  0,  1,538,  0, 21,  1,  0,588,  0,  1],
    [  1,  1,343,  1,  1,  1,342,  1,  1,  1,343,  1,  1],
    [  1,377,377,377,585, 33,  0, 33,585,377,377,377,  1],
    [  1,  1,  1,  1,  1,342,579,343,  1,  1,  1,  1,  1],
    [  1, 22, 22, 22,344, 33,  0, 33,344, 22, 22, 22,  1],
    [  1,  1,  1,  1,  1,579,  1,342,  1,  1,  1,  1,  1],
    [  1,353,343,350,342,  0,  0,  0,342,350,343,353,  1],
    [  1,343,  1,342,  1,  0,123,  0,  1,342,  1,343,  1],
    [  1,355,  1,351,  1,565,  0,565,  1,351,  1,355,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}