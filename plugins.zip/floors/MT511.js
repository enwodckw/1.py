main.floors.MT511=
{
    "floorId": "MT511",
    "title": "通天塔 511 ",
    "name": "通天塔511",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT511_4_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT511_4_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT511_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT511_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT511_4_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT511_4_5",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,8": {
            "0": {
                "condition": "flag:door_MT511_4_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT511_4_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        },
        "4,10": {
            "0": {
                "condition": "flag:door_MT511_4_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT511_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "4,5": {
            "0": {
                "condition": "flag:door_MT511_4_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT511_4_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,1378,  4,  4,  0,377,1392,  0,377,1392,  0, 88,  4],
    [  4,1378,  4,  4,1392,  4,  4,1378,  4,343,  4,  0,  4],
    [  4,1378,  4,  4,  0,  4,  4,1378,  4,343,  4,379,  4],
    [  4,1378,342,1392,540,1392,  4,1378,  4,343,  4,379,  4],
    [  4,  4,  4,  4, 85,  4,  4,1378,  4,343,  4,  0,  4],
    [  4,  4,  4,  0,568,  0,  4,  4,  4,343,  4,352,  4],
    [  4,  4,  4,1394,  0,1394,  4,  4,  4,343,  4,  0,  4],
    [  4,  4,  4,  4, 85,  4,  4,  4,  4,343,  4,379,  4],
    [  4, 47,  4,1392,  0,1392,  4, 47,  4,343,  4,379,  4],
    [  4,535,  4,  4, 85,  4,  4,535,  4,343,  4,  0,  4],
    [  4,540, 23,1392,1292,1392, 23,540,  4,639,  4, 87,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "bgmap": [

],
    "fgmap": [

]
}