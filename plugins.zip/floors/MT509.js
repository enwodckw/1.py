main.floors.MT509=
{
    "floorId": "MT509",
    "title": "通天塔 509 ",
    "name": "通天塔509",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "0,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,360,360,360,1385,342,1384,  0, 33,381, 33,1383,  1],
    [  1,367,367,367,382,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 33,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,380,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 33,  1],
    [ 88,  0,1378,  0, 34, 22,  0,1379,349,  1,  1,1382,  1],
    [  1, 31,  1,  1,  1,  1,  1,342,  1,  1,  1,  0,  1],
    [  1,  0,1378,  0, 33,377,  1,1380,377,  1,  1, 33,  1],
    [  1,1377,  1,  1,  1, 33,  1,377,377,  1,  1,379,  1],
    [  1,  0,  1, 34,  1,  0,  1,  1,  1,  1,  1, 33,  1],
    [  1, 87,342, 32,  1,1380,  0, 33,378, 33,  0,1381,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}