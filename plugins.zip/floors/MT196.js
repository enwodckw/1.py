main.floors.MT196=
{
    "floorId": "MT196",
    "title": "通天塔 196 ",
    "name": "临时教会住所196",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "2,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_3_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_3_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_3_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_3_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_8_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_7_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_7_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_7_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_7_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_3_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_3_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_3_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT196_3_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "3,6": {
            "0": {
                "condition": "flag:door_MT196_3_6==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT196_3_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,6": {
            "0": {
                "condition": "flag:door_MT196_8_6==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT196_8_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "7,4": {
            "0": {
                "condition": "flag:door_MT196_7_4==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT196_7_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "3,4": {
            "0": {
                "condition": "flag:door_MT196_3_4==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT196_3_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144, 88,  0,  0,  0,376,  0,  0,  0,376,741,383,144],
    [144,  0,752,741,752,  0,752,741,752,  0,342,757,144],
    [144,  0,741,533,741,  0,741,533,741,  0,741,383,144],
    [144,  0,752, 85,752,  0,752, 85,752,  0,766,741,144],
    [144,376,  0,  0,  0,766,  0,  0,  0,  0,351,351,144],
    [144,  0,752, 85,752,  0, 87,752, 85,752,351,351,144],
    [144,  0,741,533,741,  0,766,741,533,741,343,756,144],
    [144,  0,752,741,752,  0,  0,752,741,752,351,351,144],
    [144,  0,  0,  0,  0,376,  0,  0,  0,  0,351,351,144],
    [144,741,342,741,262,741,343,741,262,741,342,741,144],
    [144,355,354,355,741,538,355,538,741,355,354,355,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}