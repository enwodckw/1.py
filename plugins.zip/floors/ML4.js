main.floors.ML4=
{
    "floorId": "ML4",
    "title": "通天塔 4 ",
    "name": "地下4",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,9": [
            {
                "type": "setValue",
                "name": "flag:door_ML4_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,11": [
            {
                "type": "setValue",
                "name": "flag:door_ML4_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,4": [
            {
                "type": "setValue",
                "name": "flag:door_ML4_8_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_ML4_8_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,6": [
            {
                "type": "setValue",
                "name": "flag:door_ML4_8_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,10": {
            "0": {
                "condition": "flag:door_ML4_4_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML4_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,2": {
            "0": {
                "condition": "flag:door_ML4_8_2==3",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML4_8_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 33,589,539,533,539,  1,354,506,354,344, 87,  1],
    [  1,342,  1,  1,  1,  1,  1,  1, 85,  1,  1,  0,  1],
    [  1,  0,587,  0, 33,578, 33,  0,568,  0,576,  0,  1],
    [  1,342,  1,588,  1,343,  1,595,  1,589,  1,577,  1],
    [  1, 21, 21, 21,  1,355,533,355,  1,  0,  1,576,  1],
    [  1,  1,342,  1,  1,  1,  1,  1,  1,565,  1,578,  1],
    [  1,587,  0,587, 30,  1,383,383,593,  0,  1,354,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1,  1,342,  1,  1,  1],
    [  1, 30,343,584,  1,355,  0,355,  1,590,369,362,  1],
    [  1,  0,  1,  0, 85,  0,476,  0,  1,539,369,362,  1],
    [  1, 88,  1,583,  1,355,  0,355,  1,383,369,362,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}