main.floors.MT577=
{
    "floorId": "MT577",
    "title": "通天塔 577 ",
    "name": "通天塔577",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 72,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [
        "击败所有白衣血屠开启机关门"
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": "MT576",
            "loc": [
                6,
                6
            ]
        },
        "11,11": {
            "floorId": "MT578",
            "loc": [
                11,
                11
            ]
        },
        "1,11": {
            "floorId": "MT578",
            "loc": [
                1,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT577_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT577_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT577_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT577_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT577_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT577_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT577_4_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,2": {
            "0": {
                "condition": "flag:door_MT577_4_2==7",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT577_4_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  1,  1,  1,  1],
    [  4,1216, 23, 23,1474, 23, 23,342,  4,539,1451,539,  1],
    [  4,1216,  4,  4, 85,  4,  4,343,  4, 31,  1, 31,  1],
    [  4,1216,  4,  0,1449,  0,  1,344,  4,1450,  1,1450,  1],
    [  4,  4,  4,1449,1466,1449,  1,343,  4, 31,  1, 31,  1],
    [  1, 34,  1,  1,342,  1,  1,342,  4,1217,  1,1217,  1],
    [  1, 34,1449,  0,1449, 34,  0, 34,  1, 31,  1, 31,  1],
    [  1,  1,  1,342,  1,  1,343,  1,  1,1448,  1,1448,  1],
    [  1,1445,1445,  0,  0,1449,  0,1449,  1, 31,  1, 31,  1],
    [  1,1445,  1,  1,342,  1, 34,  1,  1,1217,  1,1217,  1],
    [  1,  0,  1,  1,342,  1, 86,  1,  1, 31,  1, 31,  1],
    [  1, 87,568,1224,342,  1, 88,  0,342,1446,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}