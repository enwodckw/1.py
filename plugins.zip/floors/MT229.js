main.floors.MT229=
{
    "floorId": "MT229",
    "title": "通天塔 229 ",
    "name": "通天塔229",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000,
    "defaultGround": "ski",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": "MT228",
            "loc": [
                1,
                11
            ]
        },
        "11,11": {
            "floorId": "MT230",
            "loc": [
                11,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT229_4_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT229_4_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,2": {
            "0": {
                "condition": "flag:door_MT229_4_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT229_4_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [788,788,788,788,788,788,788,788,788,788,788,788,788],
    [788,  0,367,367,354,360,360,  0,789,536,820,  0,788],
    [788,832,789,789, 85,789,789,832,789,789,789, 21,788],
    [788,535,789,816,  0,816,789,535,789,533,789, 21,788],
    [788,789,789,  0,343,  0,789,789,789, 33,789, 22,788],
    [788,379,343,379,789,379,342,  0,342,829,789, 22,788],
    [788,372,789,  0,343,  0,789,831,789, 33,342,820,788],
    [788,349,789,813,  0,813,789,  0,789,789,789,789,788],
    [788,349,789,789, 86,789,789,391,789,  0,348,348,788],
    [788,829,342,379,  0,344,  0, 21,342,812,348,348,788],
    [788,789,789,789,831,789,789,789,789,789,789,  0,788],
    [788, 87,  0, 33,  0,343,349,348,789,350,343, 88,788],
    [262,788,788,788,788,788,788,788,788,788,788,788,262]
],
    "bgmap": [

],
    "fgmap": [

],
    "underGround": true
}