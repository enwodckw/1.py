main.floors.MT534=
{
    "floorId": "MT534",
    "title": "通天塔 534 ",
    "name": "通天塔534",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,377,  0,377,342, 21,  1, 21,1404,358,  1, 88,  1],
    [  1,  1,1405,  1,  1,1401,  1,  1,342,  1,  1,  0,  1],
    [  1,  0,  0,  0,1405,  0,534,538,  0,1401,  0,  0,  1],
    [  1,1401,  1,342,  1,1402,343,  1,1403,  1,1405,342,  1],
    [  1,  0, 21,  0,  1,  0,363,  1,363,  1,  0,363,  1],
    [  1, 87,  0, 33,343,377,  0,  1, 33,342,377,  0,  1],
    [  1,  1,  1,  1,  1,  1,343,  1,  1,  1,  1,343,  1],
    [  1,  1,  1,  1,  1,  1,1409,  1,  1,  1,  1,1409,  1],
    [  1,  1,  1,  1,  1,  1,381,  1,  1,  1,  1,381,  1],
    [  1,  1,  1,  1,  1,  1,381,  1,  1,  1,  1,381,  1],
    [  1,  1,  1,  1,  1,  1,381,  1,  1,  1,  1,381,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}