main.floors.MT484=
{
    "floorId": "MT484",
    "title": "通天塔 484 ",
    "name": "通天塔484",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,9": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,380,1342,  1,1327,  0, 88,  0,1338, 31, 31, 31,  1],
    [  1,349,  0,342,  0,  1,  1,  1,  1,  1,  1,342,  1],
    [  1,380,1342,  1, 27,  1,357,375,1334, 86,343,1338,  1],
    [  1,344,  1,  1, 27,  1,357,357,  1,  1,  1, 30,  1],
    [  1, 33,  0, 86, 27,  1,  1,  1,  1,377,  1, 30,  1],
    [  1,  1,343,  1,  0,342,  0,  1, 21,377,  1,  1,  1],
    [  1,377,1334,  1,1341,  1,342,  1, 21,1335,343, 32,  1],
    [  1, 32, 32,  1, 30,343, 33,  1,  1,  1,  1, 29,  1],
    [  1, 29,  1,  1,  1,  1,  0,1327, 33,  0,  1, 87,  1],
    [  1, 29,  1,364,364,  1,342,  1,  1, 21,  1, 29,  1],
    [  1, 29,342,1335,364,  1,1340,1286,  1,  0,1341, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}