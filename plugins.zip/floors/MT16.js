main.floors.MT16=
{
    "floorId": "MT16",
    "title": "通天塔 16 ",
    "name": "通天塔16",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "0,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1, 21, 21, 21,  1,348, 22,348,  1,378, 23,378,  1],
    [  1,345,  1,  1,  1,345,  1,  1,  1,345,  1,  1,  1],
    [  1, 34, 29, 29, 34, 34,345, 29, 29, 34, 29, 29,  1],
    [  1, 29,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 29,  1, 36,  1, 30,  1, 30,  1, 30,  1, 30,  1],
    [  1,345,  1,224,  1,225,  1,226,  1,227,  1,228,  1],
    [ 88,  0,  0,  0,214,  0, 34,  0,214,  0,  0,  0, 87],
    [  1,345,  1,215,  1,219,  1,220,  1,218,  1,215,  1],
    [  1, 29,  1, 27,  1, 28,  1, 27,  1,372,  1, 28,  1],
    [  1, 29,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 34, 29, 29, 34, 34,345, 29, 29, 34, 29, 29,  1],
    [  1,345,  1,  1,  1,345,  1,  1,  1,345,  1,  1,  1],
    [  1, 21, 21, 21,  1,348, 22,348,  1,378, 23,378,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}