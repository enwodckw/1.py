main.floors.MT457=
{
    "floorId": "MT457",
    "title": "通天塔 457 ",
    "name": "通天塔457",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {
        "6,7": [
            {
                "type": "setValue",
                "name": "item:I1315",
                "operator": "+=",
                "value": "49"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 34,  0, 33,  1, 34, 87, 33,  1, 34,  0, 33,  1],
    [  1,  0,356,  0,342,  0,535,  0,342,  0,356,  0,  1],
    [  1, 31,  0, 32,  1, 31,  0, 32,  1, 31,  0, 32,  1],
    [  1,  1,342,  1,  1,  1,  1,  1,  1,  1,342,  1,  1],
    [  1, 34,  0, 33,  4,  4,  4,  4,  4, 34,  0, 33,  1],
    [  1,  0,363,  0,  4,378,378,378,  4,  0,363,  0,  1],
    [  1, 31,  0, 32,  4, 30,1315, 30,  4, 31,  0, 32,  1],
    [  1,  1,342,  1,  4,  4,345,  4,  4,  1,342,  1,  1],
    [  1, 34,  0, 33,  1,  0,  0,  0,  1, 34,  0, 33,  1],
    [  1,  0,356,  0,  1,  0,351,  0,342,  0,356,  0,  1],
    [  1, 31,  0, 32,  1,  0, 88,  0,  1, 31,  0, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}