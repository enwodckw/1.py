main.floors.MT126=
{
    "floorId": "MT126",
    "title": "通天塔 126 ",
    "name": "通天塔126",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT126_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT126_6_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_MT126_6_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT126_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,646,  0,  0,  1,565,  1,377,652,  0,363,  1],
    [  1,602,343,  1,646,  1,387,  1,  1,  1,363,650,  1],
    [  1,  1,342,377,  0,  1,651,  1, 22,  1,  1,342,  1],
    [  1,  0,652,  1,641,  1,348,  1,565,  1,356,  0,  1],
    [  1,647,  0,647,  0,  1,348,  1,649,342,650,356,  1],
    [  1,  1,342,  1,343,  1,643,  1,342,  1,  1,  1,  1],
    [  1,348,641,  0,348,647,  0,647,  0,644,348,391,  1],
    [  1,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1,  1],
    [  1,384,384,387,  1,642,  0,642,  1, 22,651, 22,  1],
    [  1,385,385,538,  1,  0,378,  0,  1,642,  1,342,  1],
    [  1,386,386,643,342, 22,  0,641,343,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}