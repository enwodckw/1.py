main.floors.ML11=
{
    "floorId": "ML11",
    "title": "通天塔 11 ",
    "name": "地下11",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,2": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,12": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,382, 21,355,  1, 21,  0, 21,  1,  0,586,534,  1],
    [  1,578,  1,343,  1,  0, 87,  0,  1,390,  1,  1,  1],
    [  1,382, 21,355,  1, 22,  0, 22,  1,390,  1,382,  1],
    [  1,578,  1,343,  1,  1,343,  1,  1,390,  1,390,  1],
    [  1,  0,348,580,  0,370,  0,342,585,390,  1,390,  1],
    [  1,  1,  1,  1,579,345,343,  1,  1,  1,  1,582,  1],
    [  1,  0,582,342,  0,370,  0,342,581,370,379,  0,  1],
    [  1,349,  1,  1,344,  1, 86,  1,  1,  1,  1,  1,  1],
    [  1,349,  1,505,355,345,579,342,581,370,348,379,  1],
    [  1,349,  1,  1,580,  1, 86,  1,  1,  1,  1,  1,  1],
    [  1, 23,534,344,  0,348,  0,342,582,390,390,382,  1],
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}