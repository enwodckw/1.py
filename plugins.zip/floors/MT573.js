main.floors.MT573=
{
    "floorId": "MT573",
    "title": "通天塔 573 ",
    "name": "通天塔573",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 72,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,359,359,359,342,1446, 88,  0,1446,359,359,359,  1],
    [  1,343,  1,  1,  1,  1,  0,351,  1,  1,342,  1,  1],
    [  1,366,366,366,1450,342,1444,  1,  1,1449,  0,1449,  1],
    [  1,343,  1,  1,  1,  1,  0, 21,  1,537,  1,537,  1],
    [  1,  0,1444,  0, 31,  0, 21,  0,  1,539,  1,539,  1],
    [  1,1451,  1,342,  1,342,  1,1444,  1,  1,  1,  1,  1],
    [  1,637,  1,342,  1,379, 22,  0,  0,1451,539,537,  1],
    [  1,  1,  1,342,  1,  1,  1,343,1448,  1,  1,  1,  1],
    [  1,  0,379,  0,1444,  0, 31,  0,  0, 21,379,  0,  1],
    [  1,1444,  1,539,  1,  1,  1,1444,  1,  1,  1,1446,  1],
    [  1, 87,342,  0,1445,380,342,  0,342,366,366,366,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}