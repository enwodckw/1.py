main.floors.MT572=
{
    "floorId": "MT572",
    "title": "通天塔 572 ",
    "name": "通天塔572",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 72,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1448,375,380,375,  1, 87,  1,375,  1,538, 23,  1],
    [  1,342,  1,  1,  1,  1,539,  1,380,  1,  1,1448,  1],
    [  1,350,350,350, 21,  1,  0,  1,375,1448,342,  0,  1],
    [  1,  1,  1,  1,1445,  1,1444,  1,  1,  1,  1,1444,  1],
    [  1,389, 33,1445,  0,342,  0,342,1445, 33,388,  0,  1],
    [  1,343,  1,  1,  1,  1, 86,  1,  1,  1,  1,343,  1],
    [  1,  0, 31,  0, 31,  0,  0,  0, 31,  0, 31,  0,  1],
    [  1,342,  1,342,  4,  4,1436,  4,  4,342,  1,342,  1],
    [  1,351,  1,351,  4,  0,  0,  0,  4,351,  1,351,  1],
    [  1,343,  1,343,  4,  0,  0,  0,  4,343,  1,343,  1],
    [  1,354,  1,354,  4,  0, 88,  0,  4,354,  1,354,  1],
    [  1,  1,  1,  1,  4,  4,  4,  4,  4,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}