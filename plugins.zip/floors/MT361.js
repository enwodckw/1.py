main.floors.MT361=
{
    "floorId": "MT361",
    "title": "通天塔 361 ",
    "name": "黑暗深渊361",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [
        {
            "type": "setGlobalValue",
            "name": "redPotion",
            "value": 500000
        },
        {
            "type": "setGlobalValue",
            "name": "bluePotion",
            "value": 800000
        },
        {
            "type": "setGlobalValue",
            "name": "yellowPotion",
            "value": 1100000
        },
        {
            "type": "setGlobalValue",
            "name": "greenPotion",
            "value": 1500000
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,2": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,  4,  4,  4,  4,  4,1150,1150,1150,1150],
    [1150, 47,1150, 21,  4,602,  0,603,  4, 21,1150, 47,1150],
    [1150, 21,1150, 21,  4,  0, 87,  0,  4, 21,1150, 21,1150],
    [1150, 21,1150, 21,  4,538,  0,538,  4, 21,1150, 21,1150],
    [1150,344,1150,343,  4,  4,344,  4,  4,343,1150,344,1150],
    [1150,375,375,375,375,  0,  0,  0,375,375,375,375,1150],
    [1150,1150,1150,1150,1150,571, 30,571,1150,1150,1150,1150,1150],
    [1150,602, 33, 33,344, 30, 23, 30,344, 33, 33,603,1150],
    [1150,1150,1150,1150,1150,571, 30,571,1150,1150,1150,1150,1150],
    [1150,375,375,375,375,  0,  0,  0,375,375,375,375,1150],
    [1150,1150, 86,1150,1150,1150, 86,1150,1150,  0,  0,  0,1150],
    [1150,637,637,637,1150,637,637,637,1150,  0,  0, 88,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}