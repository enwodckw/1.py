main.floors.MT478=
{
    "floorId": "MT478",
    "title": "通天塔 478 ",
    "name": "通天塔478",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "0,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,372,  0,372,  1,372,  0,372,  1,1324,  0, 88,  1],
    [  1,  0,380,  0,  1,  0,380,  0,  1,  0,343,  0,  1],
    [  1,372,  0,372,  1,372,  0,372,  1,377,  0,1324,  1],
    [  1,  1,1330,  1,  1,  1,1330,  1,  1, 86,  1,  1,  1],
    [  1, 30,  0,1329,  1, 30,  0,1321,  1, 32,  0, 32,  1],
    [ 87,  0, 34,  0, 86,  0, 34,  0, 86,  0,1332,  0,  1],
    [  1, 30,  0,1329,  1, 30,  0,1321,  1, 32,  0, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,1330,  1],
    [  1,375,  1, 32,1328, 32,  1, 32,1328, 32,  1, 34,  1],
    [  1,380,  1,359,  1,366,  1,366,  1,359,  1,  0,  1],
    [  1,375,1331, 32,  1, 32,1329, 32,  1, 32,1331, 47,  1],
    [261,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}