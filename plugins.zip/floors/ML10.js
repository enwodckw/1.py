main.floors.ML10=
{
    "floorId": "ML10",
    "title": "通天塔 10 ",
    "name": "地下10",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "5,3": [
            {
                "type": "setBlock",
                "number": "specialDoor",
                "loc": [
                    [
                        5,
                        4
                    ]
                ],
                "floorId": "ML10"
            },
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "4,3": [
            {
                "type": "if",
                "condition": "blockId:6,3",
                "true": [],
                "false": [
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            4
                        ],
                        "floorId": "ML10"
                    }
                ]
            }
        ],
        "6,3": [
            {
                "type": "if",
                "condition": "blockId:4,3",
                "true": [],
                "false": [
                    {
                        "type": "openDoor",
                        "loc": [
                            5,
                            4
                        ],
                        "floorId": "ML10"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  1,  0,378,378,378,  0,583,564,535,564,  1],
    [  1,  0,  1,355,378,378,378,355,  1,  1,  1,  1,  1],
    [  1,579,  1,  0,587,  0,587,  0,  1,384,384,386,  1],
    [  1,  0,  1,  1,  1,342,  1,  1,  1,384,386,386,  1],
    [  1, 30,342, 58,579,  0,342,586,  1,  1,386,588,  1],
    [  1, 86,  1, 86,342,385,  1,348, 21,  1,  1,342,  1],
    [  1,579,  0, 30,  1,  0,579,  1, 21,387,348,348,  1],
    [  1,  1,342,  1,  1,342,  0,  1,  1,  1,  1,343,  1],
    [  1,352,581,358,  1,  1,384,  1,386,385,  1, 21,  1],
    [  1,342,  1,365,372,  1,  0,342,588,385,  1, 21,  1],
    [  1,349,351,  1,379,343, 87,  1,386,385,  1, 21,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}