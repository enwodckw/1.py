main.floors.MT458=
{
    "floorId": "MT458",
    "title": "通天塔 458 ",
    "name": "通天塔458",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [
        {
            "type": "hide",
            "loc": [
                [
                    2,
                    10
                ]
            ],
            "floorId": "MT480"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,379,379,379, 31,345, 88,345, 31,379,379,379,  4],
    [  4,379,379,379, 31,  4,  0,  4,572,379,379,379,  4],
    [  4,  4,  4,  4,  4,  4,344,  4,  4,  4,  4,  4,  4],
    [  1, 34,342, 34,342,  0,349,  0,344, 33, 33, 33,  1],
    [  1,  1,  1,  1,  1,1316,  1,342,  1, 33, 33, 33,  1],
    [  1,356,  0,1317,343, 32, 32, 32,  1,  1,  1,  1,  1],
    [  1,  0,  1,  1,  1,  1,1316,  1,  1,363,  0,363,  1],
    [  1,356,  1,370,1318,343,  0, 86,1317,  0,363,  0,  1],
    [  1,  0,  1,  0,370,  1,342,  1,  1,  1,  1,343,  1],
    [  1,356,  1,370,  0,  1,1316, 30,  1,  0, 30,1318,  1],
    [  1, 33,  1,  0,377,  1, 87, 33,  1, 30,  0, 30,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}