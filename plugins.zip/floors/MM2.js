main.floors.MM2=
{
    "floorId": "MM2",
    "title": "通天塔",
    "name": "监狱1",
    "width": 13,
    "height": 13,
    "canFlyTo": false,
    "canFlyFrom": false,
    "canUseQuickShop": true,
    "cannotViewMap": true,
    "images": [],
    "ratio": 50,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [
        "\t[监狱守卫长,devilKnight]嗯？竟然有人擅闯监狱重地，杀无赦",
        {
            "type": "callBook"
        },
        "\t[hero]糟糕，动不了了",
        "\t[监狱守卫长,devilKnight]杀",
        {
            "type": "move",
            "loc": [
                6,
                1
            ],
            "time": 500,
            "keep": true,
            "steps": [
                "down:9"
            ]
        },
        {
            "type": "battle",
            "id": "devilKnight"
        },
        "\t[监狱守卫长,devilKnight]敢来截囚，你逃不掉了",
        {
            "type": "hide",
            "loc": [
                [
                    6,
                    10
                ]
            ],
            "floorId": "MM2"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "2,11": {
            "trigger": "action",
            "enable": true,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                "\t[雪月圣女,E473]你是谁？",
                "\t[hero]我叫影枫，我是和你们一起进来寻找成仙机缘的",
                "\t[雪月圣女,E473]我们都被封印关了起来，你是怎么逃脱的？还是说你和那个是一伙的",
                "\t[hero]别误会，我进来后发现你们都不见了，我就往上走，然后碰到一个叫塔灵的(省略一万字……说出了整个过程)",
                "\t[雪月圣女,E473]好大的胆子他，竟然敢算计我们，他以为真神境就无敌了吗？倘若全盛时期确实无敌，如今被紫薇圣人封印，只剩下真神境就敢肆无忌惮，多谢你的相救，我现在就出去告诉我爹娘，让他们派人来铲除塔灵，不过你既然救了我,我就将我仅存的力量传给你，希望你能拖住塔灵，等到我爹娘大军的降临",
                "\t[hero]这塔被封印了你们怎么出去",
                "\t[雪月圣女,E473]我们可都是有爹娘给的传送符，此符可以穿过圣人以下的所有封印，要不然中了塔灵的计，我们早就出去了，我要走了，你看看能不能找到其他人救出去吧，进来的很多都是宗门或者皇室子弟，对你有很大的好处，再见",
                {
                    "type": "hide",
                    "loc": [
                        [
                            2,
                            11
                        ]
                    ],
                    "floorId": "MM2"
                },
                "得到雪月圣女的力量,全属性增加3000",
                {
                    "type": "setValue",
                    "name": "status:atk",
                    "operator": "+=",
                    "value": "3000"
                },
                {
                    "type": "setValue",
                    "name": "status:def",
                    "operator": "+=",
                    "value": "3000"
                },
                {
                    "type": "setValue",
                    "name": "status:mdef",
                    "operator": "+=",
                    "value": "3000"
                }
            ]
        },
        "10,11": {
            "trigger": "action",
            "enable": true,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                "\t[天龙王子,E475]你是谁？",
                "\t[hero]我是影枫，也是这次寻求成仙机缘者之一(讲诉了自己的遭遇)",
                "\t[天龙王子,E475]塔灵？他还是真大的胆子，看来此塔留不得，感谢你救了我，只是我天龙帝国与此处极为遥远，只希望能有其他宗门或者帝国之人派人来消灭他了，但是你救了我我还是要感谢你的，我就将我仅存的力量传给你，另外再给你一件宝贝，希望你能用着着，嘿嘿嘿，我走了",
                {
                    "type": "hide",
                    "loc": [
                        [
                            10,
                            11
                        ]
                    ],
                    "floorId": "MM2"
                },
                "获得天龙王子的力量传承,全属性增加1000和一件护甲",
                {
                    "type": "setValue",
                    "name": "status:atk",
                    "operator": "+=",
                    "value": "1000"
                },
                {
                    "type": "setValue",
                    "name": "status:def",
                    "operator": "+=",
                    "value": "1000"
                },
                {
                    "type": "setValue",
                    "name": "status:mdef",
                    "operator": "+=",
                    "value": "1000"
                },
                {
                    "type": "setValue",
                    "name": "item:I474",
                    "operator": "+=",
                    "value": "1"
                }
            ]
        }
    },
    "changeFloor": {
        "6,11": {
            "floorId": "MT39",
            "loc": [
                6,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,2": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_2_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,2": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_2_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,2": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_10_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,2": [
            {
                "type": "setValue",
                "name": "flag:door_MM2_10_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,7": {
            "0": {
                "condition": "flag:door_MM2_6_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MM2_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,3": {
            "0": {
                "condition": "flag:door_MM2_6_3==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MM2_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,3": {
            "0": {
                "condition": "flag:door_MM2_2_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MM2_2_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,3": {
            "0": {
                "condition": "flag:door_MM2_10_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MM2_10_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [10043,10043,10043,10043,10043,10043,10043,10043,10043,10043,10043,10043,10043],
    [10043,  0,  0,  0, 85,  0,278,  0, 85,  0,  0,  0,10043],
    [10043,393,  0,393,10044,354,  0,354,10044,393,  0,393,10043],
    [10043,10044, 85,10044,10044,10044, 85,10044,10044,10044, 85,10044,10043],
    [10043,10044, 86,10044,10044,392,  0,392,10044,10044, 86,10044,10043],
    [10043,10044, 86,10044,10044,  0,349,  0,10044,10044, 86,10044,10043],
    [10043,10044, 86,10044,10044,392,  0,392,10044,10044, 86,10044,10043],
    [10043,10044, 86,10044,10044,10044, 85,10044,10044,10044, 86,10044,10043],
    [10043,10044, 86,10044,10044,392,  0,392,10044,10044, 86,10044,10043],
    [10043,10044, 86,10044,10044,  0,355,  0,10044,10044, 86,10044,10043],
    [10043,350,  0,350,10044,  0,  0,  0,10044,350,  0,350,10043],
    [10043,391,473,391,10044,378, 89,378,10044,391,475,391,10043],
    [10043,10043,10043,10043,10043,10043,10043,10043,10043,10043,10043,10043,10043]
],
    "bgmap": [

],
    "fgmap": [

]
}