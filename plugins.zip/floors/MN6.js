main.floors.MN6=
{
    "floorId": "MN6",
    "title": "通天塔 M6 ",
    "name": "黑暗深渊M6",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000000000,
    "defaultGround": "ground",
    "bgm": "boss.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "4,8": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "8,4": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16],
    [ 16, 16, 16, 16,571,571,571, 16, 88, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 16, 16,344, 16,  0, 16, 16, 16, 16],
    [ 16, 16, 16, 16,  0,  0,1236,  0,  0, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 23, 16,344, 16, 16, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 87, 16, 22, 22, 22, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16],
    [ 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16]
],
    "bgmap": [

],
    "fgmap": [

]
}