main.floors.MT530=
{
    "floorId": "MT530",
    "title": "通天塔 530 ",
    "name": "通天塔530",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [262,  1,  1,  1,  4,  4,  4,  4,  4,  1,  1,  1,262],
    [  1,351,  1,350,  4,345, 87,345,  4,350,  1,351,  1],
    [  1,343,  1,342,  4,1392,1400,1392,  4,342,  1,343,  1],
    [  1,350,  1,349,  4,345,  0,345,  4,349,  1,350,  1],
    [  1,343,  1,342,  4,  4,344,  4,  4,342,  1,343,  1],
    [  1,349,342,1392,342,568,  0,568,342,1392,342,349,  1],
    [  1,  1,  1,  1,  1, 22,1392, 21,  1,  1,  1,  1,  1],
    [  1,1220,1220,564,1396,  0,  0,  0,1396,564,1219,1219,  1],
    [  1,  1,  1,  1,  1, 22,1392, 21,  1,  1,  1,  1,  1],
    [  1,1222,1221,539,1396,  0,  0,  0,1396,539,1221,1222,  1],
    [  1,  1,  1,  1,  1, 22,1392, 21,  1,  1,  1,  1,  1],
    [  1,1224,1221,355,1396,  0, 88,  0,1396,355,1221,1224,  1],
    [262,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,262]
],
    "bgmap": [

],
    "fgmap": [

]
}