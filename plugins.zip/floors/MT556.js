main.floors.MT556=
{
    "floorId": "MT556",
    "title": "通天塔 556 ",
    "name": "通天塔556",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,1367,344,344,344,344,1367,344,344,344,344,1367,  1],
    [  1,344,344,344,344,344,344,344,344,344,344,344,  1],
    [  1,344,344,344,344,344,344,344,344,344,344,344,  1],
    [  1,344,344,344,344,344,344,344,344,344,344,344,  1],
    [  1,344,344,344,  4,  4,  4,  4,  4,344,344,344,  1],
    [  1,344,344,344,  4,1361,449,1361,  4,344,344,344,  1],
    [  1,344,344,344,  4,  4, 86,  4,  4,344,344,344,  1],
    [  1,344,344,344,  4,  4,1425,  4,  4,344,344,344,  1],
    [  1,344,344,344,  4,  4,344,  4,  4,344,344,344,  1],
    [  1,  1,  1,344,  4,  4,1414,  4,  4,344,  1,  1,  1],
    [  1, 88,  0,350,350,350,  0,350,350,350,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,1414,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}