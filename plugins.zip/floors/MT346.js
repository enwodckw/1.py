main.floors.MT346=
{
    "floorId": "MT346",
    "title": "通天塔 346 ",
    "name": "黑暗深渊346",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 10000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT346_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT346_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT346_11_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT346_11_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT346_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT346_2_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,4": {
            "0": {
                "condition": "flag:door_MT346_10_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT346_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        },
        "11,9": {
            "0": {
                "condition": "flag:door_MT346_11_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT346_11_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,4": {
            "0": {
                "condition": "flag:door_MT346_2_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT346_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,537,  0,537,1150,1150, 88,1150,1150,537,  0,537,1150],
    [1150,  0,1146,  0,1150,1150,  0,1150,1150,  0,1146,  0,1150],
    [1150,537,  0,537,1150,1150,  0,1150,1150,537,  0,537,1150],
    [1150,1150, 85,1150,1150,1150,1140,1150,1150,1150, 85,1150,1150],
    [1150,1145,  0,1145,1150,351,  0,351,1150,1147,  0,1147,1150],
    [1150,  0,  0,  0,342,  0, 22,  0,342,  0,349,  0,1150],
    [1150,1150,342,1150,1150,1140,1150,342,1150,1147,  0,1147,1150],
    [1150, 22,  0,351,1150,356,1150,1144,344,  0,349,  0,1150],
    [1150,1141,1150,343,1150,356,1150, 86,1150,1150,1150, 85,1150],
    [1150,  0,639,  0,344,356,1150,359,359,1150,639,639,1150],
    [1150, 87,  0,390,1150,351,1150,359,359,1150,639,639,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}