main.floors.MT134=
{
    "floorId": "MT134",
    "title": "通天塔 134 ",
    "name": "通天塔134",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT134_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT134_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT134_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT134_6_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,7": {
            "0": {
                "condition": "flag:door_MT134_6_7==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT134_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 47,637,678,  0,565,  4,565,  0,678,637, 47,  1],
    [  1,570,344,  0,535,  4,  4,  4,535,  0,344,570,  1],
    [  1,  4,  0,565,  4,  4,  4,  4,  4,565,  0,  4,  1],
    [  1,  0,535,  4,  4,  4,  4,  4,  4,  4,535,  0,  1],
    [  1,677,  4,  4,  4,  4,  4,  4,  4,  4,  4,677,  1],
    [  1,  0,387,  4,  4,  4,336,  4,  4,  4,387,  0,  1],
    [  1,  4,  0,387,  4,  4, 85,  4,  4,387,  0,  4,  1],
    [  1,570,344,  0,676,  0,569,  0,676,  0,344,570,  1],
    [  1, 47,637,678,  4,672,  0,672,  4,678,637, 47,  1],
    [  1,  4,  4,  4,  4,  4,344,  4,  4,  4,  4,  4,  1],
    [  1, 88,  0,  0,663,  0,533,  0,663,  0,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}