main.floors.MT399=
{
    "floorId": "MT399",
    "title": "通天塔 399 ",
    "name": "黑暗深渊399",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000000,
    "defaultGround": "ground",
    "bgm": "luolan.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT399_4_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT399_4_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT399_4_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT399_4_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "4,6": {
            "0": {
                "condition": "flag:door_MT399_4_6==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT399_4_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150,1217,1206,1217,1217,1150,1199,1208,1208,1208,1150, 88,1150],
    [1150,1150,342,1150,1150,1150,342,1150,1150,1150,1150,  0,1150],
    [1150,1218,1197,  0,1218,  0,1206,  0,353,353,1150,1189,1150],
    [  4,  4,  4,  4,  4,1150,1150,1150,1150,  0,1150,  0,1150],
    [  4,353,  0,353,  4,1205,  0,1205,1150,1190,1150,  0,1150],
    [  4,  0,480,  0, 85,  0,  0,  0,343,  0,344,1189,1150],
    [  4,353,  0,353,  4,1205,  0,1205,1150,1190,1150,  0,1150],
    [  4,  4,  4,  4,  4,1150,1150,1150,1150,  0,1150,  0,1150],
    [1150,369,1206,342,369,1199,342,362,362,1206,1150,1189,1150],
    [1150,369,369,1150,369,369,1150,362,362,362,1150,  0,1150],
    [1150,369,369,1150,369,369,1150,362,362,362,1150, 87,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}