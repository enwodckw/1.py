main.floors.ML1=
{
    "floorId": "ML1",
    "title": "通天塔 1 ",
    "name": "地下1",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 600,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,7": [
            {
                "type": "setBlock",
                "number": "E561",
                "loc": [
                    [
                        6,
                        1
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "sleep",
                "time": 1000
            },
            "\t[屠戮黑魔王,E561]你是谁？没有主人召唤,擅闯者都将格杀勿论",
            "\t[hero]不用吓唬我，就塔灵那个叛徒，我迟早要把它千刀万剐",
            "\t[屠戮黑魔王,E561]就凭你,一只蝼蚁而已,敢对主人大言不惭,给我杀了他",
            {
                "type": "move",
                "loc": [
                    5,
                    5
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "right:1",
                    "down:1"
                ]
            },
            {
                "type": "battle",
                "id": "E597"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    4,
                    5
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "right:2",
                    "down:1"
                ]
            },
            {
                "type": "battle",
                "id": "E597"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    3,
                    5
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "right:3",
                    "down:1"
                ]
            },
            {
                "type": "battle",
                "id": "E597"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    7,
                    5
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "left:1",
                    "down:1"
                ]
            },
            {
                "type": "battle",
                "id": "E598"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    8,
                    5
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "left:2",
                    "down:1"
                ]
            },
            {
                "type": "battle",
                "id": "E598"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    9,
                    5
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "left:3",
                    "down:1"
                ]
            },
            {
                "type": "battle",
                "id": "E598"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    4,
                    3
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "right:2",
                    "down:3"
                ]
            },
            {
                "type": "battle",
                "id": "E599"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    3,
                    3
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "right:3",
                    "down:3"
                ]
            },
            {
                "type": "battle",
                "id": "E599"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    2,
                    3
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "right:4",
                    "down:3"
                ]
            },
            {
                "type": "battle",
                "id": "E599"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    8,
                    3
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "left:2",
                    "down:3"
                ]
            },
            {
                "type": "battle",
                "id": "E600"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    9,
                    3
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "left:3",
                    "down:3"
                ]
            },
            {
                "type": "battle",
                "id": "E600"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            {
                "type": "move",
                "loc": [
                    10,
                    3
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "left:4",
                    "down:3"
                ]
            },
            {
                "type": "battle",
                "id": "E600"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            "\t[屠戮黑魔王,E561]可恶,给我死",
            {
                "type": "move",
                "loc": [
                    6,
                    1
                ],
                "time": 500,
                "keep": true,
                "steps": [
                    "down:5"
                ]
            },
            {
                "type": "battle",
                "id": "E561"
            },
            "\t[屠戮黑魔王,E561]怎么可能？我怎么会输给你",
            "\t[hero]邪不胜正，从你们当初做尽坏事开始，就已经注定了你们的失败",
            "\t[屠戮黑魔王,E561]不，这不可能，主人是不会放过你的",
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        6
                    ]
                ],
                "floorId": "ML1"
            },
            "\t[hero]塔灵，如今我已经摧毁了你的老巢，我一定会去找你的",
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_ML1_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_ML1_6_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_ML1_6_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML1_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,599,599,599,  0,  0,  0,600,600,600,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,597,597,597,  0,598,598,598,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1,  1],
    [  1,538,538,387,  1,604,  0,604,  1,387,596,387,  1],
    [  1,538,538,569,  1,  0,  0,  0,  1,595,  0,595,  1],
    [  1,387,569,596,343,  0,  0,  0,342,  0,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}