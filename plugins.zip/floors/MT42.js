main.floors.MT42=
{
    "floorId": "MT42",
    "title": "通天塔 42 ",
    "name": "通天塔42",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "0,7": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT42_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT42_2_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "2,4": {
            "0": {
                "condition": "flag:door_MT42_2_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT42_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21,  0, 21,  1,  0,  0,427,  0, 22,351,382,  1],
    [  1,  0,354,  0,  1, 30,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21,  0, 21,  1, 30,  1,  0,427,348,348,380,  1],
    [  1,  1, 85,  1,  1, 30,  1,349,  1,  1,  1,  1,  1],
    [  1,419,  0,419,  1,  0,  1,  0,  1,381, 21,425,  1],
    [  1,  1,342,  1,  1,423,  1,420,  1,  1,  1,343,  1],
    [ 87,  0, 86, 31,343,  0,342,  0,422,  0,348,  0,  1],
    [  1,342,  1,  0,  1,348,  1,420,  1,  1,  1,343,  1],
    [  1, 41,  1,342,  1,348,  1,  0,  1,381, 21,425,  1],
    [  1,417,  1,  0,  1,349,  1,349,  1,  1,  1,  1,  1],
    [  1, 88, 86, 31,342,422,  1,  0,427,348,348,380,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}