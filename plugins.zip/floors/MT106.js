main.floors.MT106=
{
    "floorId": "MT106",
    "title": "通天塔 106 ",
    "name": "通天塔106",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 2400,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "8,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT106_10_1",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT106_10_1",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT106_10_1",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT106_10_1",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,1": {
            "0": {
                "condition": "flag:door_MT106_10_1==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT106_10_1",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,378,350,376,614,342, 88,342,  0,  0, 85, 87,  1],
    [  1,615,  1,  1,  1,  1,  0,  1,612,612,343,  0,  1],
    [  1,376,  1,348,613,342,610,  1,612,612,  1,611,  1],
    [  1,350,  1,378,372,  1,  0,  1,  1,  1,  1,  0,  1],
    [  1,378,  1,378,372,  1,  0,613,  0, 22,376,350,  1],
    [  1,  1,  1,  1,  1,  1,343,  1,612,  1,  1,  1,  1],
    [  1,  0,348,348,348,617,  0, 31,  0,612,  0,  0,  1],
    [  1,617,  1,  1,  1,  1,342,  1,  1,  1,  1,606,  1],
    [  1,348,  1,366,366,  1,607,  1,359,359,  1,348,  1],
    [  1,348,  1,366,366,  1, 23,  1,359,359,  1,348,  1],
    [  1,348,  1,354,616,343,350,343,616,354,  1, 23,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}