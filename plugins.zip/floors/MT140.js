main.floors.MT140=
{
    "floorId": "MT140",
    "title": "通天塔 140 ",
    "name": "通天塔140",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 50000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  1,390,388,390,388,  1,389,390,389,390,  1],
    [  1,  0,  1, 21,  1,  1,  1,  1,  1,  1,  1, 22,  1],
    [  1, 33,  1,349,  1,362,362,355,369,369,  1,349,  1],
    [  1, 33,  1,673,  1,362,362,674,369,369,  1,670,  1],
    [  1, 33,  1,342,  1,  1,  1,342,  1,  1,  1,342,  1],
    [  1,  0,664,  0,348,  0,665,  0,348,  0,664,  0,  1],
    [  1,  1,  1,  1,  1,342,  1,  1,  1,  1,342,666,  1],
    [  1, 21, 21, 21,  0,674,  0,  0,675,  1,348,  0,  1],
    [  1,  1,342,  1,  1,342,  1,  1,355,  1,344,348,  1],
    [  1,355,674,  1,  0,676,  0,  1,355,  1,  0,669,  1],
    [  1,355,355,  1,391,  0,391,  1,355,  1,534, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}