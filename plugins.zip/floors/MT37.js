main.floors.MT37=
{
    "floorId": "MT37",
    "title": "通天塔 37 ",
    "name": "通天塔37",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "0,3": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT37_10_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT37_10_5",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,5": {
            "0": {
                "condition": "flag:door_MT37_10_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT37_10_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1, 87,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [410,  0,410,  1, 33, 33, 33,  1, 34,348,  1, 40,  1],
    [  1,  0,342,  1,  1,342,  1,  1,  1,342,  1,255,  1],
    [ 88,  0,  0,255,  0,  0,253,  0, 21,  0,  0,  0,  1],
    [  1,  1,342,  1,  1,342,  1,414,  1,413,  0,413,  1],
    [  1, 31,254,388,  1,342, 31, 31,  1,  1, 85,  1,  1],
    [  1, 31,  1,  1,  1,  1,377, 31,  1, 31,  0, 31,  1],
    [  1, 31,389, 21,248,  1,  1,  1,  1,  0,379,  0,  1],
    [  1,  1,  1,  1,342,  1,379, 31,415, 31,  0, 31,  1],
    [  1, 31, 31, 31,254,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,342,  1,  1,  1,  1,410,  1,  0, 31,  0, 31,  1],
    [  1,255, 31, 31, 31,380,  0,342,248,  0,387,  0,  1],
    [  1,  1,  1,  1,  1,  1,410,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}