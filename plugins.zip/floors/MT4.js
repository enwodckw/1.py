main.floors.MT4=
{
    "floorId": "MT4",
    "title": "通天塔 4 ",
    "name": "通天塔4",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "12,7": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [ 30,211,  0, 21,207,  0, 32,  0,205,  0,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1, 86,  1,  0,  1],
    [ 30,210,  0, 29,206,  0, 31,  0,203,  0,  1,201,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1, 86,  1,202,  1],
    [ 30,209,  0, 21,207,  0, 32,  0,202,  0,  1,201,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1, 86,  1, 33,  1],
    [ 30,210,  0, 29,204,  0, 33,  0,205,213,344,  0, 88],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1, 86,  1,342,  1],
    [ 30,211,  0, 21,206,  0, 33,  0,203,  0,  1,208,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1, 86,  1, 21,  1],
    [ 30,209,  0, 29,204,  0, 31,  0,202,  0,  1, 21,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "shanmai.mp3"
}