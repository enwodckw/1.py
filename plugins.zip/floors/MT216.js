main.floors.MT216=
{
    "floorId": "MT216",
    "title": "通天塔 216 ",
    "name": "通天塔216",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 5000000,
    "defaultGround": "grass",
    "bgm": "waiwei.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": "MT215",
            "loc": [
                11,
                1
            ]
        },
        "1,11": {
            "floorId": "MT215",
            "loc": [
                1,
                11
            ]
        },
        "1,1": {
            "floorId": "MT215",
            "loc": [
                1,
                1
            ]
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT216_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT216_6_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,6": {
            "0": {
                "condition": "flag:door_MT216_6_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT216_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [140,140,140,140,140,140,140,140,140,140,140,140,140],
    [141, 93,141,783,342,386, 87,386,342,783,141, 93,141],
    [141,786,141,388,148,343,148,343,148,388,141,786,141],
    [141,535,141,389,148,386,148,386,148,389,141,535,141],
    [141,535,141,390,148,387,148,387,148,390,141,535,141],
    [141,535,141,391,148,779,  0,779,148,391,141,535,141],
    [141,535,141,539,148,148, 85,148,148,539,141,535,141],
    [141,141,141,148,148,781,  0,781,148,148,141,141,141],
    [141,385,385,  0,148,  0,  0,  0,148,384,384,  0,141],
    [141,385,385,782,342,  0,564,  0,148,384,384,778,141],
    [141,141,141,141,141,141,141,777,148,148,148,342,141],
    [141, 93,786,536,536,536,141, 28, 28, 27, 27, 88,141],
    [262,141,141,141,141,141,141,141,141,141,141,141,141]
],
    "bgmap": [

],
    "fgmap": [

]
}