main.floors.ML24=
{
    "floorId": "ML24",
    "title": "通天塔 24 ",
    "name": "地下24",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": "ML25",
            "loc": [
                1,
                11
            ]
        },
        "1,1": {
            "floorId": "ML25",
            "loc": [
                1,
                1
            ]
        },
        "11,0": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "9,2": [
            {
                "type": "setValue",
                "name": "flag:door_ML24_10_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,2": [
            {
                "type": "setValue",
                "name": "flag:door_ML24_10_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "10,3": {
            "0": {
                "condition": "flag:door_ML24_10_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_ML24_10_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 88,  1],
    [  1, 87,  0,  0,512,  0, 21, 21, 21,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,515,  0,515,  1],
    [  1, 28,  0,522,348,348,348,536,  1,  1, 85,  1,  1],
    [  1, 28,  1,  1,  1,  1,343,  1,  1,349,  0,349,  1],
    [  1, 28,  0,521,348,348,348,  0,  1,  0,533,  0,  1],
    [  1,  1,343,  1,  1,  1,342,520,  1,349,  0,349,  1],
    [  1, 27,  0,519,348,348,348,  0,  1,  1,342,  1,  1],
    [  1, 27,  1,  1,  1,  1,  1,  1,  1,525,  0,525,  1],
    [  1, 27,  0,518,348,348,348,  0,  1,533,  1,533,  1],
    [  1,  1,343,  1,  1,  1,342,517,  1,533,  1,533,  1],
    [  1, 87,  0,516,348,348,348,  0,  1,533,  1,533,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}