main.floors.MT15=
{
    "floorId": "MT15",
    "title": "通天塔 15 ",
    "name": "通天塔15",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "0,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "8,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT15_9_2",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT15_9_2",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "9,2": {
            "0": {
                "condition": "flag:door_MT15_9_2==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT15_9_2",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 30,  0,226,342, 21,  1,  0,228,  1,363,356,  1],
    [  1, 21,349, 21,  1,  0,  1,  0,  0, 85,363,356,  1],
    [  1,  1,  1,  1,  1,225,342,  0,228,  1,363,356,  1],
    [  1,  0,342,  0, 27,  0,  1,342,  1,  1,  1,  1,  1],
    [  1, 28,  1,221,  1,219,  1,227, 21,377,  1, 31,  1],
    [ 87,  0, 86,  0, 86,  0,  1,370,370,370,  1, 32,  1],
    [  1,219,  1,221,  1, 28,  1,  1,  1,  1,  1,226,  1],
    [  1,  0, 27,  0,342,  0,217,  0, 34,  0,342,  0,  1],
    [  1,  1,342,  1,  1,  1,342,  1,  1,217,  1,214,  1],
    [  1,  0,222,  0,  1,  0,222,  0,  1,  0,  1,  0,  1],
    [  1,373,380,373,344,373,380,373,  1,  0,214, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}