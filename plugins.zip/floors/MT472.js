main.floors.MT472=
{
    "floorId": "MT472",
    "title": "通天塔 472 ",
    "name": "通天塔472",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,348,  0,348,  1, 32,1325,342, 32,1325,342, 88,  1],
    [  1,  0,379,  0,  1,377, 32,  1,377, 32,  1,  0,  1],
    [  1,  1,1329,  1,  1,  1,  1,  1,  1,  1,  1,  0,342],
    [  1, 32,  0,  0,1323,  0, 31, 31, 31,  0,1321,  0,1321],
    [  1,  1,1329,  1,  1,342,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,379,  0,  1,1324,  1,  1,  1,  1,  1,  1,  1],
    [  1,348,  0,348,  1,342,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1, 31,  0,1319, 28, 28, 28,  0,  1],
    [  1, 27, 27, 27,1323,  0, 31,  1,  1,  1,  1,1330,  1],
    [  1,344,  1,  1,  1,  1, 86,  1,  1,  1,  1,391,  1],
    [  1, 87,  0,348,  0,1321,  0,1321,  1,  1,  1,349,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}