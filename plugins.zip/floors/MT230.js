main.floors.MT230=
{
    "floorId": "MT230",
    "title": "通天塔 230 ",
    "name": "通天塔230",
    "width": 13,
    "height": 13,
    "canFlyTo": false,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000,
    "defaultGround": "ski",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": "MT229",
            "loc": [
                11,
                11
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT230_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT230_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT230_6_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT230_6_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,10": {
            "0": {
                "condition": "flag:door_MT230_6_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT230_6_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,7": {
            "0": {
                "condition": "flag:door_MT230_6_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT230_6_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [788,788,788,788,788,788,788,788,788,788,788,788,788],
    [788,788,788,788,788,262,  0,262,788,788,788,788,788],
    [788,788,788,788,788,  0,479,  0,788,788,788,788,788],
    [788,788,788,788,788,262,  0,262,788,788,788,788,788],
    [788,788,788,788,788,788,343,788,788,788,788,788,788],
    [788,788,788,788,788,  0,834,  0,788,788,788,788,788],
    [788,788,788,788,788,  0,  0,  0,788,788,788,788,788],
    [788,788,788,788,788,788, 85,788,788,788,788,788,788],
    [788,788,788,788,788,833,  0,833,788,788,788,788,788],
    [788,788,788,788,788,  0,  0,  0,788,788,788,788,788],
    [788,788,788,788,788,788, 85,788,788,788,788,788,788],
    [788,788,788,788,788,833,  0,833,  0,  0,  0, 87,788],
    [788,788,788,788,788,788,788,788,788,788,788,788,788]
],
    "bgmap": [

],
    "fgmap": [

],
    "underGround": true
}