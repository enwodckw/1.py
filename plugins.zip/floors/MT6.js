main.floors.MT6=
{
    "floorId": "MT6",
    "title": "通天塔 6 ",
    "name": "通天塔6",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "2,9": [
            "\t[hero]前辈是你呀！！！",
            "\t[器灵,thief]这么快都冲上来了？看来你的天赋不错，这么快都突破了",
            "\t[hero]我感觉好吃力,好累",
            "\t[器灵,thief]是不是发现你境界比他们高，打他们还很吃力？他们被关押了上万年，实力虽然在退化，但是在以前也是独霸一方的存在，你在跟他们战斗时，你没有战斗经验，所以才会感觉特别吃力，那我帮帮你吧，还有我在这里感受到了残片气息，可能这片区域就有残片，通天塔每十层为一个区域，每个区域有一个头目守着(也有十五层或者二十层为一个区域)，塔灵为了很好控制关押的各种怪物和人，把他们分成了好几个区域，你需要不断的战斗才能突破打败他们，现在你给我绿钥匙我就可以帮你获得新的力量，这样战斗时事成功倍",
            {
                "type": "choices",
                "text": "\t[器灵,thief]五把绿钥匙换取5点攻防,5000生命值，换不换？",
                "choices": [
                    {
                        "text": "换",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "5"
                            },
                            {
                                "type": "setValue",
                                "name": "status:atk",
                                "operator": "+=",
                                "value": "5"
                            },
                            {
                                "type": "setValue",
                                "name": "status:def",
                                "operator": "+=",
                                "value": "5"
                            },
                            {
                                "type": "setValue",
                                "name": "status:hp",
                                "operator": "+=",
                                "value": "5000"
                            },
                            "\t[器灵,thief]是不是变强了，下次再见，希望你能变得更强",
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不换",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[hero]不了吧，我还是想脚踏实地的去突破",
                            "\t[器灵,thief]真有毅力，我很看好你，加油",
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "12,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT6_6_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT6_6_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,3": {
            "0": {
                "condition": "flag:door_MT6_6_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT6_6_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,342,  0,  1,  0,377,  0,  1, 27,343,  0, 87],
    [  1,213,  1, 33,  1, 21,  0, 21,  1, 34,  1,203,  1],
    [  1, 33,  1,  0,  1,  1, 85,  1,  1, 27,  1,  0,  1],
    [  1, 28,  1,209,  1,204,  0,204,  1,210,  1, 32,  1],
    [  1,  1,  1,  0,201,  0,  0,  0,201,  0, 86,202,  1],
    [  1, 28,  1,343,  1,  1,  1,  1,  1,  1,  1,342,  1],
    [  1, 33,  1,  0,342, 28,342, 28,342, 28,342,  0,  1],
    [  1,213,  1,201,  1,208,  1,209,  1,208,  1,203,  1],
    [  1,  0,123,  0, 31,  0, 86,  0, 86,  0, 31,  0,  1],
    [  1,  0,  1,  1,  1,343,  1,344,  1,344,  1,343,  1],
    [  1, 88,344,350,  1, 33,  1,358,  1,365,  1, 33,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "shanmai.mp3"
}