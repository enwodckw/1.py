main.floors.MT85=
{
    "floorId": "MT85",
    "title": "通天塔 85 ",
    "name": "通天塔85",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 48,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "9,11": [
            "\t[器灵,thief]本层不可小觑,或许可以试试魔塔50层的打法",
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT85_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT85_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT85_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT85_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,2": [
            {
                "type": "if",
                "condition": "(flag:85>=3)",
                "true": [
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "atk",
                        "value": "350000"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "def",
                        "value": "200000"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "hp",
                        "value": "1500000"
                    },
                    {
                        "type": "setEnemy",
                        "id": "E509",
                        "name": "special",
                        "value": "[]"
                    },
                    {
                        "type": "update"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                5,
                                2
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                5,
                                4
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                7,
                                4
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                7,
                                2
                            ]
                        ],
                        "floorId": "MT85"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:85",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "6,3": [
            {
                "type": "show",
                "loc": [
                    [
                        11,
                        11
                    ]
                ],
                "floorId": "MT85"
            }
        ],
        "5,3": [
            {
                "type": "if",
                "condition": "(flag:85>=3)",
                "true": [
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "atk",
                        "value": "350000"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "def",
                        "value": "200000"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "hp",
                        "value": "1500000"
                    },
                    {
                        "type": "setEnemy",
                        "id": "E509",
                        "name": "special",
                        "value": "[]"
                    },
                    {
                        "type": "update"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                5,
                                2
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                5,
                                4
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                7,
                                4
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                7,
                                2
                            ]
                        ],
                        "floorId": "MT85"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:85",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "6,4": [
            {
                "type": "if",
                "condition": "(flag:85>=3)",
                "true": [
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "atk",
                        "value": "350000"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "def",
                        "value": "200000"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "hp",
                        "value": "1500000"
                    },
                    {
                        "type": "setEnemy",
                        "id": "E509",
                        "name": "special",
                        "value": "[]"
                    },
                    {
                        "type": "update"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                5,
                                2
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                5,
                                4
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                7,
                                4
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                7,
                                2
                            ]
                        ],
                        "floorId": "MT85"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:85",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,3": [
            {
                "type": "if",
                "condition": "(flag:85>=3)",
                "true": [
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "atk",
                        "value": "350000"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "def",
                        "value": "200000"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT85",
                        "name": "hp",
                        "value": "1500000"
                    },
                    {
                        "type": "setEnemy",
                        "id": "E509",
                        "name": "special",
                        "value": "[]"
                    },
                    {
                        "type": "update"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                5,
                                2
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                5,
                                4
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                7,
                                4
                            ]
                        ],
                        "floorId": "MT85"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                7,
                                2
                            ]
                        ],
                        "floorId": "MT85"
                    }
                ],
                "false": [
                    {
                        "type": "setValue",
                        "name": "flag:85",
                        "operator": "+=",
                        "value": "1"
                    }
                ]
            }
        ],
        "5,4": [
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        4
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        3
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        3
                    ]
                ],
                "floorId": "MT85"
            }
        ],
        "7,4": [
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        4
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        3
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        3
                    ]
                ],
                "floorId": "MT85"
            }
        ],
        "7,2": [
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        4
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        3
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        3
                    ]
                ],
                "floorId": "MT85"
            }
        ],
        "5,2": [
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        2
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        4
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        3
                    ]
                ],
                "floorId": "MT85"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        7,
                        3
                    ]
                ],
                "floorId": "MT85"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,6": {
            "0": {
                "condition": "flag:door_MT85_6_6==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT85_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,391,  1,  0,  0,  0,  0,  0,  1,391,  1,  1],
    [  1,  1,355,  1,  0,509,509,509,  0,  1,355,  1,  1],
    [  1,  1,355,  1,  0,509,508,509,  0,  1,355,  1,  1],
    [  1,354,  0,  0,  0,509,509,509,  0,  0,  0,354,  1],
    [  1,354,  0,  0,  0,  0,  0,  0,  0,  0,  0,354,  1],
    [  1,  1,355,  1,  1,  1, 85,  1,  1,  1,355,  1,  1],
    [  1,  1,355,  1,  1,498,  0,498,  1,  1,355,  1,  1],
    [  1,  1,391,  1,  1,  0,  0,  0,  1,  1,391,  1,  1],
    [  1,  1,  1,  1,  1,498,344,498,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,344,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0,  0,  0,  0,  0,  0,  0,123,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}