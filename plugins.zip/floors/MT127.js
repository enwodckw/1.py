main.floors.MT127=
{
    "floorId": "MT127",
    "title": "通天塔 127 ",
    "name": "通天塔127",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6000,
    "defaultGround": "ground",
    "bgm": "bgm1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "3,1": [
            "\t[器灵,thief]又见面了，想要继续增强吗？",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我20绿,全属性增加500万，换吗？",
                "choices": [
                    {
                        "text": "换了",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "20"
                            },
                            {
                                "type": "setValue",
                                "name": "status:atk",
                                "operator": "+=",
                                "value": "5000000"
                            },
                            {
                                "type": "setValue",
                                "name": "status:def",
                                "operator": "+=",
                                "value": "5000000"
                            },
                            {
                                "type": "setValue",
                                "name": "status:mdef",
                                "operator": "+=",
                                "value": "5000000"
                            },
                            "\t[器灵,thief]还记得器灵老巢出现的塔灵卫吗？听说正在本区域巡查，你要小心了",
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不换",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[器灵,thief]还记得器灵老巢出现的塔灵卫吗？听说正在本区域巡查，你要小心了",
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "1,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT127_2_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT127_2_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "2,8": {
            "0": {
                "condition": "flag:door_MT127_2_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT127_2_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88, 86,123,  1,645,  0,361,368,  0,650,  0,  1],
    [  1,  0,  1,  1,  1,342,  1,  1,  1,  1,  4,653,  4],
    [  1,646,  0, 30,  0,642,  0, 30, 30,  0,  4, 23,  4],
    [  1,  1,  1,342,  1,  1,  1,  1,  1,648,  4,639,  4],
    [  1,349,651,349,  1,368,361,644,342,  0,  4, 47,  4],
    [  1, 86,  1,  1,  1,651,  1,  1,  1, 30,  4,345,  4],
    [  1,645,  0,645,  1,368,361,647,  1,  0,646,  0,  1],
    [  1,  1, 85,  1,  1,  1,  1,343,342,349,  1,  0,  1],
    [  1,566,  0,566,  1,652,343,647,  1,342,  1,650,  1],
    [  1,  0,638,  0,  1,375,375,644,  1,342,  1,  0,  1],
    [  1, 47,602, 47,  1,382,382,603,  1,349,652, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}