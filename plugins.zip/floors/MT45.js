main.floors.MT45=
{
    "floorId": "MT45",
    "title": "通天塔 45 ",
    "name": "通天塔45",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 6,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "10,3": [
            "\t[器灵,thief]增强的机会又来了,来吧换取实力的机会走过路过不要错过",
            {
                "type": "choices",
                "text": "\t[器灵,thief]给我10绿,增加100点全属性，换吗？",
                "choices": [
                    {
                        "text": "换了",
                        "condition": "EvalString_default",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "item:greenKey",
                                "operator": "-=",
                                "value": "10"
                            },
                            {
                                "type": "setValue",
                                "name": "status:atk",
                                "operator": "+=",
                                "value": "100"
                            },
                            {
                                "type": "setValue",
                                "name": "status:def",
                                "operator": "+=",
                                "value": "100"
                            },
                            {
                                "type": "setValue",
                                "name": "status:mdef",
                                "operator": "+=",
                                "value": "100"
                            },
                            "\t[器灵,thief]加油！",
                            {
                                "type": "hide"
                            }
                        ]
                    },
                    {
                        "text": "不换",
                        "condition": "EvalString_default",
                        "action": [
                            "\t[器灵,thief]又变强了，不错",
                            {
                                "type": "hide"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {
        "9,1": [
            "吸收斩神剑剑意,全属性增加100",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "100"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "100"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "100"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 33,348, 33,  1, 33,348, 33,  1,396,344, 88,  1],
    [  1,  1,342,  1,  1,  1,342,  1,  1,  1,  1,  0,  1],
    [  1, 30,  0,417,  0,  0, 30,  0,350,  0,123,  0,  1],
    [  1,342,  1,  1,  1,417,  1,343,  1,342,  1,342,  1],
    [  1,350,  0,417,  0, 33,  1,426,  1,420,  1,420,  1],
    [  1,  1, 86,  1,  1,  1,  1, 33,  1,  0,  1,348,  1],
    [  1,  0,  0,342,  1,348,  1,358,  1, 33,  1,348,  1],
    [  1,418,  1,  0,342,419,  1,358,  1,  0,  1,  1,  1],
    [  1,  0,  0, 30,  1,348,  1,358,  1,427,  0,365,  1],
    [  1,342,417,  1,  1,  1,  1,  1,  1,  0,365,  0,  1],
    [  1, 87,  0,342,421, 30, 30, 30,  1,365,  0,351,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}