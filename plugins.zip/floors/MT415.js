main.floors.MT415=
{
    "floorId": "MT415",
    "title": "通天塔 415 ",
    "name": "黑暗深渊深处415",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 200000000000,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT415_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT415_4_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT415_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT415_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT415_8_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT415_8_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "9,3": [
            "吸收斩神剑剑意,全属性增加2000兆",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "2000000000000000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "2000000000000000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "2000000000000000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {
        "4,10": {
            "0": {
                "condition": "flag:door_MT415_4_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT415_4_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,10": {
            "0": {
                "condition": "flag:door_MT415_6_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT415_6_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "8,10": {
            "0": {
                "condition": "flag:door_MT415_8_10==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT415_8_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150],
    [1150, 88,  0,  0,1259,  0,569,  0,1259,  0,  0, 87,1150],
    [1150,1150,1150,1150,1150,1150,342,1150,1150,1150,1150,1150,1150],
    [1150,373,373,380,1150,1256,  0,1256,1150,396,348,348,1150],
    [1150,373,1150,1150,1150,  0,  0,  0,1150,1150,1150,348,1150],
    [1150,373,1150,638,1150,  0,1265,  0,1150,638,1150,348,1150],
    [1150,1263,1150,1261,1150,1150,342,1150,1150,1261,1150,1264,1150],
    [1150,  0,348,  0, 86,1262,  0,1262, 86,  0,348,  0,1150],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,344,1150],
    [  4,565,  0,565,  4,1256,  4,1256,  4,1256,  4, 33,1150],
    [  4,  0,334,  0, 85,  0, 85,  0, 85,  0,342, 33,1150],
    [  4,565,  0,565,  4,1256,  4,1256,  4,1256,  4, 33,1150],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}