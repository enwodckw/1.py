main.floors.MT236=
{
    "floorId": "MT236",
    "title": "通天塔 236 ",
    "name": "通天塔236",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 20000000,
    "defaultGround": "ski",
    "bgm": "q.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT236_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT236_6_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,4": {
            "0": {
                "condition": "flag:door_MT236_6_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT236_6_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [788,788,788,788,788,788,788,788,788,788,788,788,788],
    [788,788,788,788,788, 23,632, 23,788,788,788,788,788],
    [788,788,788,788,788,788,540,788,788,788,788,788,788],
    [788,788,788,788,788,788,  0,788,788,788,788,788,788],
    [788,788,788,788,788,788, 85,788,788,788,788,788,788],
    [788,788,788,788,788,833,  0,833,788,788,788,788,788],
    [788,387,790,348,790,  0,  0,  0,790,540,342,835,788],
    [788,390,790,348,790, 21,834, 21,790,390,790,390,788],
    [788,835,790,342,790,790,342,790,790,820,790,387,788],
    [788,  0, 21,  0,832,  0,832,  0,832,  0,790,390,788],
    [788,790,790,790,790,342,790,342,790,790,790,790,788],
    [788, 88,  0,  0,814,  0,602,  0,814,  0,  0, 87,788],
    [788,788,788,788,788,788,788,788,788,788,788,788,788]
],
    "bgmap": [

],
    "fgmap": [

]
}