main.floors.MT506=
{
    "floorId": "MT506",
    "title": "通天塔 506 ",
    "name": "通天塔506",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 12,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,6": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 22,1287, 22,1383,  0,638, 47,  0,1381,1382,1381,  1],
    [  1,344,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,344,  1,  1,  1,  1,  1,  1,  1,  1,  1,391,  1],
    [  1,356, 33,356,  1, 22,1380,349,362,  1,  1,  0,  1],
    [  1,343,  1,1379,  1,  1, 86,  1,  1,  1,  1,1382,  1],
    [  1, 87,1381,  0,348,  0,  0,  1,1380,  0,380,  0,  1],
    [  1,344,  1,  1,  1,  1,1378,  1, 86,  1,  1,  1,  1],
    [  1,  0,1377,370, 21,370,  0,  1,  0,1378,  0, 28,  1],
    [  1, 34,  1,  1,  1,  1,  1,  1, 21,  1, 28,  0,  1],
    [  1, 34,342, 29, 29,1377,  0,1379,  0,342,  0, 28,  1],
    [  1, 34,  1, 30, 29,  1,342, 34,342,  1,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}