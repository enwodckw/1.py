main.floors.MT536=
{
    "floorId": "MT536",
    "title": "通天塔 536 ",
    "name": "通天塔536",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,1406,374,380,374,  1,1407,377,377,377,377,  1],
    [  1,374,  1,  1,  1,  1,  1,343,  1,  1,  1,  1,  1],
    [  1,379,  1, 27, 27, 27,343,  0,1402, 33,377, 33,  1],
    [  1,374,  1,  1,  1, 28,  1,349,  0,  1,  1,  1,  1],
    [  1,  0,1405, 30,  1, 28,  1,1404,  0,1404, 33,377,  1],
    [  1,343,342,  1,  1,1405,  1,  1,342,  1,  1,  1,  1],
    [  1, 31, 31,  0,1403,  0, 86,1402,342,1402,  0,344,  1],
    [  1, 31, 31,  1,  1,  1, 33, 21,343,  0,1406,  0,  1],
    [  1,1403, 28,  1,538,  1,  1,  1,  1,345,  1,342,  1],
    [  1, 86,  1,  1,342,1404,  0,1401,1403,1401,  0, 21,  1],
    [  1, 88, 86,1402,  0,  0, 33,  1,  1,  1,353, 87,  1],
    [  1,  1,  1,  1,  1,1404,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}