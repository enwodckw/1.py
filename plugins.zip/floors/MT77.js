main.floors.MT77=
{
    "floorId": "MT77",
    "title": "通天塔 77 ",
    "name": "通天塔77",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 48,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT77_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT77_6_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT77_10_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT77_10_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT77_2_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT77_2_5",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,8": {
            "0": {
                "condition": "flag:door_MT77_6_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT77_6_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,5": {
            "0": {
                "condition": "flag:door_MT77_10_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT77_10_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "2,5": {
            "0": {
                "condition": "flag:door_MT77_2_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT77_2_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21,377, 21,486,  0, 87,  0,486, 21,377, 21,  1],
    [  1,  1,  1,  1,  1,342,  1,487,  1,  1,  1,  1,  1],
    [  1,  0,378,  0,  1,  0,  0,  0,  1,  0,378,  0,  1],
    [  1,378,  0,378,  1,342,488,342,  1,378,  0,378,  1],
    [  1,  1, 85,  1,  1,  0,  0,  0,  1,  1, 85,  1,  1],
    [  1,494,  0,494,  1,487,  1,342,  1,495,  0,495,  1],
    [  1,  0,  0,  0, 86,  0,  0,  0, 86,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1,  1],
    [  1,377,377,374,  1,487,  0,487,  1,377,489,377,  1],
    [  1,377,374,  0,  1,  0,  0,  0,  1,488,  0,488,  1],
    [  1,374,  0,494,342,  0,348,  0,342,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}