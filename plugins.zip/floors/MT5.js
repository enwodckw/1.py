main.floors.MT5=
{
    "floorId": "MT5",
    "title": "通天塔 5 ",
    "name": "通天塔5",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,12": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 32, 31, 32,  1, 32, 31, 32,  1, 71,201, 88,  1],
    [  1,  1,342,  1,  1,  1,342,  1,  1,  1,  1, 86,  1],
    [  1, 31,  0, 21,201,  0, 31,  0,201,  0, 86,  0,  1],
    [  1,342,  1,  1,  1,202,  1,342,  1,203,  1,201,  1],
    [  1,  0,202,  0, 30,  0,  1, 21, 28, 21,  1,  0,  1],
    [  1, 32,  1,  1,  1,  1,  1,  1,  1,  1,  1, 21,  1],
    [  1,  0,201,  0,  1,  0, 32,  1, 22, 34,204,  0,  1],
    [  1,343,  1, 21,342,207, 32,  1, 86,  1,  1,  1,  1],
    [  1,  0,201,  0,  1,  0, 32,  1,209, 22, 34, 28,  1],
    [  1, 86,  1,  1,  1,  1,  1,  1,  1,  1,  1, 86,  1],
    [  1,  0,343,214, 30, 33, 30,  1, 27, 34, 21,212,  1],
    [  1, 87,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "shanmai.mp3"
}