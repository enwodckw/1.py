main.floors.MT64=
{
    "floorId": "MT64",
    "title": "通天塔 64 ",
    "name": "通天塔64",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 24,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "12,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT64_7_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT64_7_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT64_7_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT64_7_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT64_7_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT64_7_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT64_7_3",
                "operator": "+=",
                "value": "1"
            }
        ],
        "8,2": [
            {
                "type": "setValue",
                "name": "flag:door_MT64_7_3",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "7,6": {
            "0": {
                "condition": "flag:door_MT64_7_6==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT64_7_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "7,7": {
            "0": {
                "condition": "flag:door_MT64_7_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT64_7_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "7,4": {
            "0": {
                "condition": "flag:door_MT64_7_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT64_7_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "7,3": {
            "0": {
                "condition": "flag:door_MT64_7_3==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT64_7_3",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,348,  0,465,  0,  0,  0,  0,  0,  0,462,  0, 88],
    [  1,466,  1,472,  1,279,275,  0,275,279,  1,  1,  1],
    [  1,  0,472,472,  1,  1,  1, 85,  1,  1,  1,  1,  1],
    [  1,348,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1],
    [  1, 22,  1,  1,  1,469,246,  0,246,469,  1,  1,  1],
    [  1,  0,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1],
    [  1,463,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1],
    [  1,  0,  1,  1,  1,388,388,390,389,389,  1,  1,  1],
    [  1,348,  1,  1,  1,391,  1,  1,  1,391,  1,  1,  1],
    [  1,  0,  1,  1,  1,391,  1,  1,  1,391,  1,  1,  1],
    [  1, 87,  1,  1,  1,389,389,390,388,388,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}