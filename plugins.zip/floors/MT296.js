main.floors.MT296=
{
    "floorId": "MT296",
    "title": "通天塔 296 ",
    "name": "通天塔296",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000000,
    "defaultGround": "ground",
    "bgm": "yiji.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,6": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT296_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT296_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT296_6_6",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT296_6_6",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,6": {
            "0": {
                "condition": "flag:door_MT296_6_6==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT296_6_6",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [155,155,155,155,155,155,155,155,155,155,155,155,155],
    [155,387,387,387,971,  0,966,380,380,380,155, 87,155],
    [155,155,155,155,155,  0,155,155,155,155,155,  0,155],
    [155,378,378,378,965,  0,964,377,377,377,155,571,155],
    [155,155,155,155,155,  0,155,155,155,155,155,961,155],
    [155,379,379,379,946,  0,155,963,  0,963,155,  0,155],
    [155,155,155,155,155,  0, 85,  0,  0,  0,343, 88,155],
    [155,569,569,569,970,  0,155,963,  0,963,155,343,155],
    [155,155,155,155,155,  0,155,155,155,155,155,962,155],
    [155,381,381,381,967,  0,971,366,366,366,155,363,155],
    [155,155,155,155,155,  0,155,155,155,155,155,363,155],
    [155,359,359,359,971,  0,968,382,382,382,155,363,155],
    [155,155,155,155,155,155,155,155,155,155,155,155,155]
],
    "bgmap": [

],
    "fgmap": [

]
}