main.floors.ML23=
{
    "floorId": "ML23",
    "title": "通天塔 23 ",
    "name": "地下23",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150,
    "defaultGround": "ground",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,0": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,11": {
            "floorId": "ML22",
            "loc": [
                11,
                11
            ]
        },
        "1,11": {
            "floorId": "ML22",
            "loc": [
                1,
                11
            ]
        },
        "1,6": {
            "floorId": "ML22",
            "loc": [
                1,
                6
            ]
        },
        "1,1": {
            "floorId": "ML22",
            "loc": [
                1,
                1
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 87,  1],
    [  1, 88,  0,379,  0,518,  0, 21, 21,  0,514,  0,  1],
    [  1,  1,  1,  1,  1,  1,342,  1,  1,513,  1, 21,  1],
    [  1,  1,  1,  1,  1,379,514,379,  1,359,  1,  0,  1],
    [  1,360,360,360,  1,  1,  1,  1,  1,  1,  1,513,  1],
    [  1,  1,  1,360,  1,380, 22,380,  1,377,  1,  0,  1],
    [  1, 88,  1,360,  1, 22,517, 22,  1,377,  1,349,  1],
    [  1,517,  1,520,  1,  1,342,  1,  1,512,  1, 21,  1],
    [  1,  0,342,  0,  0,349,516,349,  0,  0,343,  0,  1],
    [  1,517,  1,  1,342,  1,  1,  1,342,  1,  1,512,  1],
    [  1,  0,  1, 21,519, 21,  1, 21,515, 21,  1,  0,  1],
    [  1, 88,  1,380,348,380,  1,380,348,380,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "underGround": true,
    "bgmap": [

],
    "fgmap": [

],
    "bgm": "ks.mp3"
}