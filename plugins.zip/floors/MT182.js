main.floors.MT182=
{
    "floorId": "MT182",
    "title": "通天塔 182 ",
    "name": "临时教会住所182",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 500000,
    "defaultGround": "ground",
    "bgm": "qxzd.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {
        "6,3": [
            "吸收斩神剑剑意,全属性增加1亿",
            {
                "type": "setValue",
                "name": "status:atk",
                "operator": "+=",
                "value": "100000000"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "operator": "+=",
                "value": "100000000"
            },
            {
                "type": "setValue",
                "name": "status:mdef",
                "operator": "+=",
                "value": "100000000"
            }
        ]
    },
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [144,144,144,144,144,144,144,144,144,144,144,144,144],
    [144,384,741,  0,342,755,  0,144,348,741,348, 87,144],
    [144,384,741,533,741,384,384,144,348,741,  0,348,144],
    [144,384,741,  0,741, 23,398,144,748,343,748,  0,144],
    [144,384,741,754,144,144,144,144,  0,741,741,741,144],
    [144,754,342,  0,538,  0,753,741,350,741,538,376,144],
    [144,741,741,741,741,741,342,741,  0,741,376,662,144],
    [144, 21,391, 21,750,343,350,741,749,741,741,342,144],
    [144,342,741,741,741,741,  0,357,  0,350,  0,357,144],
    [144,752,389,389,389,741,750,741,342,741,741,342,144],
    [144,741,741,741,342,741,  0,343,  0,741,376,662,144],
    [144,388,388,388,753,741, 88,  0,749,741,376,538,144],
    [144,144,144,144,144,144,144,144,144,144,144,144,144]
],
    "bgmap": [

],
    "fgmap": [

]
}