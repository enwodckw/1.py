main.floors.MT568=
{
    "floorId": "MT568",
    "title": "通天塔 568 ",
    "name": "通天塔568",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 36,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,568,568,568,1223,344,1433,  0,1433,344,1222,1222,  1],
    [  1,1430,  1,  1,  1,  1,  1,342,  1,  1,  1,1222,  1],
    [  1,  0,1359,  0,1432,  0,343, 21,537,537,  1,1359,  1],
    [  1,1434,  1,  1,  1,  0,1430, 21,  1,  1,  1,603,  1],
    [  1,568,  1,537,  1, 86,342,342,  1,  0,1432, 21,  1],
    [  1,568,  1,537,  1,1438,  1,  1,602,391,  1,  1,  1],
    [  1,568,  1,1422,343,  0,  1,1359,  0,  1,  1,1221,  1],
    [  1,  1,  1,  1,  1,  0,1425, 86,  1,  1,1220,1221,  1],
    [  1,1219,1219,1219,  1,  0,1438,  1,342,1220,1220,1221,  1],
    [  1,342,343,1422,  1, 86,  1,  1,342,1425,  1,  1,  1],
    [  1, 88,  0,  0,391,  0,1429,  0,  0, 86,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}