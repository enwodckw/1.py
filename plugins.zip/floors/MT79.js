main.floors.MT79=
{
    "floorId": "MT79",
    "title": "通天塔 79 ",
    "name": "通天塔79",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 48,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,388,388,  1,351,343,351,  1, 21,389,  1, 30,  1],
    [  1,388,498,342,  0,495,  0,343,497,351,  1, 30,  1],
    [  1,  1,  1,  1,  1,  1,348,  1, 21,389,  1, 30,  1],
    [  1,  0,342,499,389,  1, 21,  1,  1,  1,  1, 30,  1],
    [  1,351,  1,389,389,  1,348,342,498,388,472, 30,  1],
    [  1,495,  1,  1,  1,  1,  0,  1,388,388,  1,497,  1],
    [  1,  0, 30,343, 30,  1,489,  1,  1,472,  1,342,  1],
    [  1,350,  0,488,  0,342,  0,489,  0, 21,350,  0,  1],
    [  1,  0,  1,472,  1,  1,489,  1,  1,  1,  1,496,  1],
    [  1,  0,  1,352,385,  1,  0,  1,384,352,  1,352,  1],
    [  1, 87,  1,385,496,342, 88,342,496,384,  1,352,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}