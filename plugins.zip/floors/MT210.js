main.floors.MT210=
{
    "floorId": "MT210",
    "title": "通天塔 210 ",
    "name": "通天塔210",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 5000000,
    "defaultGround": "grass",
    "bgm": "waiwei.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT210_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT210_6_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_MT210_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT210_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [148,148,148,148,148,148,148,148,148,148,148,148,148],
    [148, 87,342,  0,349,  0,148,  0,779,363,363,363,148],
    [148,774,148,342,148,343,148, 21,148,148,148,148,148],
    [148,386,148,  0,775,  0,148,  0,778,356,356,356,148],
    [148, 21,148,148,148, 21,148,349,148,148,148,148,148],
    [148,773, 21,386,774,  0,148,  0,148,778,377,371,148],
    [148,148,148,148,148,781,148,776,148,342,148,148,148],
    [148,358,349,365,777,  0,355,  0,148,371,377,776,148],
    [148,148,148,148,148,  0,  0,  0,148,148,148,342,148],
    [148,540,  0, 21,148,148, 85,148,148,777,377,371,148],
    [148,  0,383,  0,148,775,  0,775,148,342,148,148,148],
    [148, 21,  0,782,342,  0,  0,  0, 86,371,  0, 88,148],
    [148,148,148,148,148,148,148,148,148,148,148,148,148]
],
    "bgmap": [

],
    "fgmap": [

]
}