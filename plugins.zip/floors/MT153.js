main.floors.MT153=
{
    "floorId": "MT153",
    "title": "通天塔 153 ",
    "name": "通天塔山洞153",
    "width": 13,
    "height": 13,
    "canFlyTo": false,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 150000,
    "defaultGround": "T730",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,0": {
            "floorId": "MT152",
            "loc": [
                1,
                0
            ]
        },
        "12,3": {
            "floorId": "MT154",
            "loc": [
                12,
                3
            ]
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT153_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT153_6_5",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,5": {
            "0": {
                "condition": "flag:door_MT153_6_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT153_6_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [685, 93,726,726,726,726,726,726,726,726,726,726,685],
    [726,  0,726, 47,570,537,656,  0,656,537,570, 47,726],
    [726,692,726,726,726,726,726,342,726,726,726,726,726],
    [726,  0, 86,  0,681,  0,  0,  0,692,  0,654,564, 91],
    [726,679,726,654,726,680,  0,680,726,679,  4,  4,  4],
    [726,388,726,358,726,726, 85,726,726,  0,  4,637,  4],
    [726,391,726,358,726,565, 47,565,726,381,  4,566,  4],
    [726,726,726,358,726,602, 47,602,726,  0,  4,656,  4],
    [726,682,342,564,726,726,344,726,726,695,342,  0,602],
    [726,388,726,654,726,639, 23,540,726,  0,  4,656,  4],
    [726,389,726,379,726, 23,603,  0,726,381,  4,566,  4],
    [726,391,726,379,726,540,  0,682,342,603,  4,637,  4],
    [685,726,726,726,726,726,726,726,726,726,  4,  4,685]
],
    "bgmap": [

],
    "fgmap": [

]
}