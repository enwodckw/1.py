main.floors.MT20=
{
    "floorId": "MT20",
    "title": "通天塔 20 ",
    "name": "通天塔20",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "shanmai.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,0": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "6,9": [
            {
                "type": "openDoor",
                "loc": [
                    6,
                    5
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1, 88,  1,  1,  1,  1,  1,  1],
    [  1, 33,343, 33,342,  0,  0,  0,342, 33,343, 33,  1],
    [  1,348,  1,  1,  1,227,  0,227,  1,  1,  1,348,  1],
    [  1,344,  1, 29,  0,  0, 85,  0,  0, 29,  1,344,  1],
    [  1, 33,  1, 29,  0, 85,379, 85,  0, 29,  1, 33,  1],
    [  1,349,  1, 29,  0, 22, 85, 21,  0, 29,  1,349,  1],
    [  1, 33,  1, 29,  0,227,  0,227,  0, 29,  1, 33,  1],
    [  1,  1,  1,  1,  1,  1,344,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,345,  0,345,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  0,231,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,345,  0,345,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}