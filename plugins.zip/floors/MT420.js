main.floors.MT420=
{
    "floorId": "MT420",
    "title": "通天塔 420 ",
    "name": "黑暗深渊深处420",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 200000000000,
    "defaultGround": "ground",
    "bgm": "wuqu.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "6,0": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {
        "3,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT420_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT420_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT420_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT420_6_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "6,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT420_6_1",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {
        "6,5": {
            "0": {
                "condition": "flag:door_MT420_6_5==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT420_6_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,1": {
            "0": {
                "condition": "flag:door_MT420_6_1==1",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT420_6_1",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [ 85, 85, 85, 85, 85, 85, 87, 85, 85, 85, 85, 85, 85],
    [ 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85, 85],
    [1150,571,  4,571,  4,  0,  0,  0,  4,571,  4,571,1150],
    [1150,344,  4,344,  4,  0,1266,  0,  4,344,  4,344,1150],
    [1150,569,  4,569,  4,  0,  0,  0,  4,569,  4,569,1150],
    [1150,344,  4,344,  4,  4, 85,  4,  4,344,  4,344,1150],
    [1150,538,  4,1263,  0,1263,  0,1263,  0,1263,  4,538,1150],
    [1150,343,  4,  4,  4,  4,344,  4,  4,  4,  4,343,1150],
    [1150,1209,1209,1209,1264,  0,569,  0,1264,  0,1209,1209,1150],
    [1150,344,1150,1150,343,1150,1150,1150,343,1150,1150,1209,1150],
    [1150,568,1150,571,1265,571,1150,571,1265,571,1150,  0,1150],
    [1150,570,1150,1225,1225,1225,1150,1225,1225,1225,1150, 88,1150],
    [1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150,1150]
],
    "bgmap": [

],
    "fgmap": [

]
}