var events_c12a15a8_c380_4b28_8144_256cba95f760 = 
{
	"commonEvent": {
		"加点事件": [
			{
				"type": "comment",
				"text": "通过传参，flag:arg1 表示当前应该的加点数值"
			},
			{
				"type": "choices",
				"choices": [
					{
						"text": "攻击+${1*flag:arg1}",
						"action": [
							{
								"type": "setValue",
								"name": "status:atk",
								"operator": "+=",
								"value": "1*flag:arg1"
							}
						]
					},
					{
						"text": "防御+${2*flag:arg1}",
						"action": [
							{
								"type": "setValue",
								"name": "status:def",
								"operator": "+=",
								"value": "2*flag:arg1"
							}
						]
					},
					{
						"text": "生命+${200*flag:arg1}",
						"action": [
							{
								"type": "setValue",
								"name": "status:hp",
								"operator": "+=",
								"value": "200*flag:arg1"
							}
						]
					}
				]
			}
		],
		"回收钥匙商店": [
			{
				"type": "comment",
				"text": "此事件在全局商店中被引用了(全局商店keyShop)"
			},
			{
				"type": "comment",
				"text": "解除引用前勿删除此事件"
			},
			{
				"type": "comment",
				"text": "玩家在快捷列表（V键）中可以使用本公共事件"
			},
			{
				"type": "while",
				"condition": "1",
				"data": [
					{
						"type": "choices",
						"text": "\t[商人,trader]你有多余的钥匙想要出售吗？",
						"choices": [
							{
								"text": "黄钥匙（10金币）",
								"color": [
									255,
									255,
									0,
									1
								],
								"action": [
									{
										"type": "if",
										"condition": "item:yellowKey >= 1",
										"true": [
											{
												"type": "setValue",
												"name": "item:yellowKey",
												"operator": "-=",
												"value": "1"
											},
											{
												"type": "setValue",
												"name": "status:money",
												"operator": "+=",
												"value": "10"
											}
										],
										"false": [
											"\t[商人,trader]你没有黄钥匙！"
										]
									}
								]
							},
							{
								"text": "蓝钥匙（50金币）",
								"color": [
									0,
									0,
									255,
									1
								],
								"action": [
									{
										"type": "if",
										"condition": "item:blueKey >= 1",
										"true": [
											{
												"type": "setValue",
												"name": "item:blueKey",
												"operator": "-=",
												"value": "1"
											},
											{
												"type": "setValue",
												"name": "status:money",
												"operator": "+=",
												"value": "50"
											}
										],
										"false": [
											"\t[商人,trader]你没有蓝钥匙！"
										]
									}
								]
							},
							{
								"text": "离开",
								"action": [
									{
										"type": "exit"
									}
								]
							}
						]
					}
				]
			}
		],
		"游戏说明": [
			{
				"type": "choices",
				"choices": [
					{
						"text": "游戏简介",
						"action": [
							"h5版本是按照flash版复刻，其中部分对话使用的魔塔盛宴的版本。",
							"地图复制：数码宝贝51、641\n部分事件复制：小艾\n默认背景音乐：无；可在切换音乐处设置\n游戏音乐、怪物显伤等开关可以在系统设置里打开和关闭",
							"想要获得更详细的介绍，可以在菜单——游戏信息——游戏主页中进入本塔的评论区，查看置顶评论。",
							{
								"type": "insert",
								"name": "游戏说明"
							}
						]
					},
					{
						"text": "游戏结局",
						"action": [
							{
								"type": "if",
								"condition": "flag:addhp",
								"true": [
									"疯狂加血模式下，本塔有且仅有一个专属结局。",
									{
										"type": "insert",
										"name": "游戏说明"
									}
								],
								"false": [
									"本塔共有四个结局。\n在原版魔塔中，使用下楼器和破墙镐（或下楼器和地震卷轴）可以封印魔王，因此，这个版本如保留下楼器和破墙镐（或下楼器和地震卷轴）击败魔王，即可打出True End，否则为Normal End。",
									"不论是Normal End还是True End，都分为穿墙结局和不穿墙结局，如果从未使用对话穿墙，可以打出不穿墙结局。",
									{
										"type": "insert",
										"name": "游戏说明"
									}
								]
							}
						]
					},
					{
						"text": "对话穿墙",
						"action": [
							"在与老人对话后，或购买商人的物品并再次对话后，可以立即清除，或走一步再清除身边的某一堵墙（不必是暗墙）。",
							"这期间不能瞬移、打怪、开门和使用道具，否则穿墙会失败。",
							{
								"type": "insert",
								"name": "游戏说明"
							}
						]
					},
					{
						"text": "切换音乐",
						"action": [
							{
								"type": "choices",
								"choices": [
									{
										"text": "精灵石 3个小萝莉在一起",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "1"
											},
											{
												"type": "playBgm",
												"name": "xiaoluoli.mp3"
											}
										]
									},
									{
										"text": "精灵石 晚上家里和镇子",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "2"
											},
											{
												"type": "playBgm",
												"name": "wan.mp3"
											}
										]
									},
									{
										"text": "精灵石 黄昏的镇子",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "3"
											},
											{
												"type": "playBgm",
												"name": "huang.mp3"
											}
										]
									},
									{
										"text": "仙境传说-守候永恒的爱",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "4"
											},
											{
												"type": "playBgm",
												"name": "xian.mp3"
											}
										]
									},
									{
										"text": "精灵石 精灵石传说",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "5"
											},
											{
												"type": "playBgm",
												"name": "chuanshuo.mp3"
											}
										]
									},
									{
										"text": "精灵石 ed【神曲】",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "6"
											},
											{
												"type": "playBgm",
												"name": "ed.mp3"
											}
										]
									},
									{
										"text": "精灵石 幸福之花",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "7"
											},
											{
												"type": "playBgm",
												"name": "hua.mp3"
											}
										]
									},
									{
										"text": "精灵石 迷宫",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "8"
											},
											{
												"type": "playBgm",
												"name": "migong.mp3"
											}
										]
									},
									{
										"text": "离开",
										"action": []
									}
								]
							},
							{
								"type": "insert",
								"name": "游戏说明"
							}
						]
					},
					{
						"text": "返回游戏",
						"action": []
					}
				]
			}
		],
		"对话": [
			{
				"type": "switch",
				"condition": "flag:arg1",
				"caseList": [
					{
						"case": "2",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'谢谢你救了我……咦，我的口袋里怎么有一千块钱，总之这些钱也送给你了'"
							},
							{
								"type": "setValue",
								"name": "flag:对话2",
								"value": "1"
							}
						]
					},
					{
						"case": "3",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'勇士，我们又见面了，请收下怪物手册吧'"
							},
							{
								"type": "setValue",
								"name": "flag:对话3",
								"value": "1"
							}
						]
					},
					{
						"case": "4",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'我们的对话似乎被人监视了，那人好像在用某种【缝隙】观察我们'"
							},
							{
								"type": "setValue",
								"name": "flag:对话4",
								"value": "1"
							}
						]
					},
					{
						"case": "6",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'购买物品之后再与商人对话，他们和他会告诉你一些消息。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话6",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'魔塔共有198层，每7层为七六五四三二一个区域。每14层为六五四三二一个区域。每21层为五四三二一个区域。每28层为四三二一个区域。每35层为三二一个区域。每42层为二一个区域。每49层为一个区域。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话602",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "7",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你的攻击比敌人防御高时也不一定能对他们造成伤害 但是你的攻击比敌人防御高时就一定能对他造成伤害'"
							},
							{
								"type": "setValue",
								"name": "flag:对话7",
								"value": "1"
							}
						]
					},
					{
						"case": "12",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'本塔有很多暗墙 比如5555555 999999 121212121212 141414141414 1616161616 1818181818层 你都找到了吗'"
							},
							{
								"type": "setValue",
								"name": "flag:对话12",
								"value": "1"
							}
						]
					},
					{
						"case": "15",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'十十十十十字架对兽人和吸血鬼是神器 可惜它们的效果无法叠加'"
							},
							{
								"type": "setValue",
								"name": "flag:对话15",
								"value": "1"
							}
						]
					},
					{
						"case": "16",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'整个魔魔魔魔魔魔塔有111222把藏在墙里的红钥匙'"
							},
							{
								"type": "setValue",
								"name": "flag:对话16",
								"value": "1"
							}
						]
					},
					{
						"case": "18",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'在这区域不多次提升攻击力 有可能打败石头人 也不一定能打败石头人 切记前人教训'"
							},
							{
								"type": "setValue",
								"name": "flag:对话18",
								"value": "1"
							}
						]
					},
					{
						"case": "21",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'穞堵臸猭畍住在25252525楼 他是魔魔魔魔塔的主人 打败他可以得到4444把红钥匙'"
							},
							{
								"type": "setValue",
								"name": "flag:对话21",
								"value": "1"
							}
						]
					},
					{
						"case": "23",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'这座魔塔有198层，但是直接联通的只有195层'"
							},
							{
								"type": "setValue",
								"name": "flag:对话23",
								"value": "1"
							}
						]
					},
					{
						"case": "27",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'如果你是第一次见到我 那么祝贺你 你的前期是比较成功的 如果你是第二次见到我 那么祝贺你 你的中期是比较成功的 如果你是第三次见到我 那么祝贺你 你的后期是比较成功的 如果你是第四次见到我 那么祝贺你 你是比较成功的'"
							},
							{
								"type": "setValue",
								"name": "flag:对话27",
								"value": "1"
							}
						]
					},
					{
						"case": "31",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'据说在很深很深的地下，魔王放了一个幸运金币'"
									},
									{
										"type": "setValue",
										"name": "flag:对话3102",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'双手剑士的攻击力太高了 相当于4.5333333个实力差又爱吹牛的骑士队长'"
									},
									{
										"type": "setValue",
										"name": "flag:对话31",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "33",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'别急，虽然你可能不急，但是别急'"
							},
							{
								"type": "setValue",
								"name": "flag:对话33",
								"value": "1"
							}
						]
					},
					{
						"case": "36",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'不用找了 本层没有暗道, 本层也没有暗道'"
							},
							{
								"type": "setValue",
								"name": "flag:对话36",
								"value": "1"
							}
						]
					},
					{
						"case": "37",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你需要用地震卷轴才能取走这里的所有宝物 当然你也可以用四个破墙镐 198层魔塔最好玩的地方就是道具有多多多多多多多种用法'"
							},
							{
								"type": "setValue",
								"name": "flag:对话37",
								"value": "1"
							}
						]
					},
					{
						"case": "38",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'存放圣剑的房间的门坏了 这座魔魔魔魔魔魔魔塔也被魔王玩坏了'"
							},
							{
								"type": "setValue",
								"name": "flag:对话38",
								"value": "1"
							}
						]
					},
					{
						"case": "39",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'谜题是在3点，送3个飞行道具，所以那些谜题在9点的魔塔为什么不送9个？'"
									},
									{
										"type": "setValue",
										"name": "flag:对话39",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'你居然买了我的钥匙 这说明你很有钱'"
									},
									{
										"type": "setValue",
										"name": "flag:对话3902",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "42",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你大概已经拿到了神神神神神神圣剑，也可能只拿到了神神神神神圣剑'"
							},
							{
								"type": "setValue",
								"name": "flag:对话42",
								"value": "1"
							}
						]
					},
					{
						"case": "45",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg3 == 3)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'神圣盾和幸运金币一样是唯一的，但这并不影响它们的强大'"
									},
									{
										"type": "setValue",
										"name": "flag:对话45",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'26262626楼存在打开时空之门的机关，你只用打开其中一个，但是真正的时空之门在24楼'"
									},
									{
										"type": "setValue",
										"name": "flag:对话4502",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "46",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你在破解41层的谜题后可能会被某种敌人挡道'"
							},
							{
								"type": "setValue",
								"name": "flag:对话46",
								"value": "1"
							}
						]
					},
					{
						"case": "47",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'如果要打败魔王你需要 神神神神神神圣剑 神圣盾 圣圣水 或更高等级的装备'"
							},
							{
								"type": "setValue",
								"name": "flag:对话47",
								"value": "1"
							}
						]
					},
					{
						"case": "48",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'像骰子上5一样的形状是一种封印魔法 你最好记住 它在与魔王战斗时可能有用'"
							},
							{
								"type": "setValue",
								"name": "flag:对话48",
								"value": "1"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "if",
				"condition": "flag:arg4",
				"true": [
					"\t[商人,woman]${flag:content}"
				],
				"false": [
					"\t[老人,man]${flag:content}"
				]
			},
			{
				"type": "switch",
				"condition": "flag:arg1",
				"caseList": [
					{
						"case": "2",
						"action": [
							{
								"type": "playSound",
								"name": "item.mp3"
							},
							{
								"type": "addValue",
								"name": "status:money",
								"value": "1000"
							},
							{
								"type": "tip",
								"text": "获得1000金币"
							}
						]
					},
					{
						"case": "3",
						"action": [
							{
								"type": "addValue",
								"name": "item:book",
								"value": "1"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:talking",
				"value": "2"
			},
			{
				"type": "hide",
				"loc": [
					"core.nextX()",
					"core.nextY()"
				],
				"remove": true,
				"time": 500
			},
			{
				"type": "switch",
				"condition": "core.status.floorId",
				"caseList": [
					{
						"case": "'MT2_5'",
						"action": [
							"\t[swordEmperor]勇士拿到了一千块钱……他可能会就近把这笔钱花掉，也可能留到几十甚至一百多层以上的地方再用",
							"\t[swordEmperor]省下现有的资源使其在未来发挥更大的价值，是魔塔最好玩的地方之一"
						]
					},
					{
						"case": "'MT3_5'",
						"action": [
							"\t[swordEmperor]虽然勇士已经拥有了怪物手册，但是他依然选择了和这位老人对话，也许这是他在魔塔里的习惯吧",
							{
								"type": "if",
								"condition": "flag:hell",
								"true": [
									"\t[swordEmperor]可惜他选择了地狱难度，不然还可以穿一次墙"
								],
								"false": [
									"\t[swordEmperor]难道说，他只是为了对话穿墙？"
								]
							}
						]
					},
					{
						"case": "'MT4_5'",
						"action": [
							"\t[swordEmperor]哇哦，勇士被监视了，好可怕哦~到底是谁干的呢？",
							"\t[swordEmperor]原来是我啊，那没事了"
						]
					},
					{
						"case": "'MT6_5'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									"\t[swordEmperor]在那个存档读档并不方便的从前，商人的一条情报也许确实能拯救即将误入歧途的勇士",
									"\t[swordEmperor]但是厌倦这种设计的人越来越多，创作者们也逐渐将大部分玩家都会频繁存读档当作默认的设计原则"
								],
								"false": [
									"\t[swordEmperor]他在说什么啊，难道50层魔塔不是50层吗",
									"\t[swordEmperor]嘿嘿错了，50层魔塔有51层，那么50层魔塔有198层也不奇怪吧"
								]
							}
						]
					},
					{
						"case": "'MT7_5'",
						"action": [
							"\t[swordEmperor]魔塔的战斗都很守规矩，你一下我一下，输赢没有变数。某些不讲武德、喜欢偷袭的家伙除外",
							"\t[swordEmperor]你说是吧，骑士队长"
						]
					},
					{
						"case": "'MT2_4'",
						"action": [
							"\t[swordEmperor]在魔塔世界里，金钱除了买属性和买钥匙以外，还能卖什么呢？",
							"\t[swordEmperor]假如魔塔世界观是完整的，塔外的世界是存在的，勇士肯定会想方设法把多余的钱带回去吧"
						]
					},
					{
						"case": "'MT3_4'",
						"action": [
							"\t[swordEmperor]啊，熟悉的地图，熟悉的怪物，熟悉的老头",
							"\t[swordEmperor]如果把魔塔里的所有怪物都变成属性各不相同的绿色史莱姆，你还能玩的下去吗？"
						]
					},
					{
						"case": "'MT4_4'",
						"action": [
							"\t[swordEmperor]不知道你对于我的旁白是什么看法",
							"\t[swordEmperor]也许你只是为了让老头从地图上消失……你不会真的在乎我说什么吧"
						]
					},
					{
						"case": "'MT6_4'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									"\t[swordEmperor]你应该不会为重复的情报掏钱，但你可能还是想要50金币一把的蓝钥匙",
									"\t[swordEmperor]但我觉得你现在不一定急缺这把钥匙，你可能只是觉得这么做很赚"
								],
								"false": [
									"\t[swordEmperor]我想你大概已经明白他说的是什么意思了",
									"\t[swordEmperor]祝你好运，勇士"
								]
							}
						]
					},
					{
						"case": "'MT7_4'",
						"action": [
							"\t[swordEmperor]属性也是认识怪物的一种方式，你可以通过怪物的攻防比例和血量大致判断其类型",
							"\t[swordEmperor]不过据说在某些不存在地方，有血量很高攻击很低的法师，他们有无视防御的能力"
						]
					},
					{
						"case": "'MT12_4'",
						"action": [
							"\t[swordEmperor]暗墙在魔塔诞生的年代是一个常见的设计，不过也随着魔塔的发展而逐渐被淘汰了",
							"\t[swordEmperor]听说有些人能接受绿色的暗墙，这真是怪事"
						]
					},
					{
						"case": "'MT2_3'",
						"action": [
							"\t[swordEmperor]你有没有想过一个问题，为什么打败魔塔里的怪物会获得金币？",
							"\t[swordEmperor]没准这只是出于游戏性考虑的设计，我们是否有办法让这个生硬的规则变得合理一些呢？"
						]
					},
					{
						"case": "'MT3_3'",
						"action": [
							"\t[swordEmperor]是啊，我们又见面了，勇士",
							"\t[swordEmperor]如果，我是说如果，老人们和魔塔有很深的渊源，你觉得魔塔的剧情会是什么样的呢？"
						]
					},
					{
						"case": "'MT4_3'",
						"action": [
							"\t[swordEmperor]如果说魔塔本来是老人拥有的，而穞堵臸猭畍是其中一位德高望重的老人",
							"\t[swordEmperor]但是邪恶的我降临了魔塔，然后封印了穞堵臸猭畍，让他功力只剩一成"
						]
					},
					{
						"case": "'MT6_3'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									"\t[swordEmperor]从此以后，我控制了魔塔。魔塔里的人原本不是老人，但他们后来都变成了老人",
									"\t[swordEmperor]然后我就觉得当魔塔的主人实在是太无聊了，所以我就让他们搜集……呃……蓝钥匙？"
								],
								"false": [
									"\t[swordEmperor]这些商人都是坏蛋呢，他们偷走了魔塔里的钥匙，然后转手卖给你们这些勇士",
									"\t[swordEmperor]他们以此牟利，非法获取了大量金币……不对，我好像还没有解释金币是怎么来的"
								]
							}
						]
					},
					{
						"case": "'MT7_3'",
						"action": [
							"\t[swordEmperor]我想到了，兽人的兽指的其实是狗，他们什么都吃，包括真正用金铸造的金币",
							"\t[swordEmperor]所以我为了魔塔经济系统的问题，用巧克力做出了巧克力金币，这样兽人吃了它就会死"
						]
					},
					{
						"case": "'MT12_3'",
						"action": [
							"\t[swordEmperor]但是这样就麻烦了，因为其他的怪物开始吃起了金币，这让我很头疼",
							"\t[swordEmperor]于是我想到了一个绝妙的方法，我发布通告说金币吃多了会骨质疏松",
							"\t[swordEmperor]为了增强真实性，我制造了很多暗墙，说这是魔塔吃多了金币以后的样子"
						]
					},
					{
						"case": "'MT15_3'",
						"action": [
							"\t[swordEmperor]我想你可能也猜到了，魔塔里的十字架也是用巧克力做的",
							"\t[swordEmperor]至于为什么吸血鬼会害怕十字架……呃……因为他蛀牙"
						]
					},
					{
						"case": "'MT16_3'",
						"action": [
							"\t[swordEmperor]我自然没有把巧克力金币的真相告诉其他人，所以区域头目们也很害怕魔塔的【骨质疏松】",
							"\t[swordEmperor]所以你会看到一些怪物镇守在一些匪夷所思的区域，这往往表明他们附近的墙壁里藏有珍贵的物品"
						]
					},
					{
						"case": "'MT18_3'",
						"action": [
							"\t[swordEmperor]魔塔因此得到了丰富的巧克力生产经验，你看到的石头人其实是产品研发创新的失败产物",
							"\t[swordEmperor]我打算让魔塔成为一座庞大的巧克力工厂，然后我就能赚源源不断的钱啦",
							"\t[swordEmperor]那勇士存在的意义是什么？对哦……"
						]
					},
					{
						"case": "'MT21_3'",
						"action": [
							"\t[swordEmperor]嗯……我可以解释……勇士的存在是为了……是为了……",
							"\t[swordEmperor]真是抱歉呢，我想有些事情大概是瞒不住了"
						]
					},
					{
						"case": "'MT2_2'",
						"action": [
							"\t[swordEmperor]金币是巧克力这种事情，怎么想都不合理吧",
							"\t[swordEmperor]但你会接受这个设定吗？我的意思是，凭什么违和的世界就无法存在呢？"
						]
					},
					{
						"case": "'MT3_2'",
						"action": [
							"\t[swordEmperor]好的，我摊牌了，什么巧克力金币，兽人吃巧克力会死，什么巧克力工厂，那都是我编的",
							"\t[swordEmperor]如果你感兴趣的话，我会和你分享我的真实见闻"
						]
					},
					{
						"case": "'MT4_2'",
						"action": [
							"\t[swordEmperor]这个世界也是在监视中生成的，在混沌的黑暗中诞生的第一批智慧里，我苏醒了",
							"\t[swordEmperor]和这位老人一样，我看到了【缝隙】，但是无穷无尽的【缝隙】"
						]
					},
					{
						"case": "'MT6_2'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									"\t[swordEmperor]我的认知不存在先有鸡还是先有蛋的问题，魔塔里万物既是同步的也是有序的",
									"\t[swordEmperor]墙壁、地板、怪物、道具、祭坛……我在刹那间被先后灌输了这些概念"
								],
								"false": [
									"\t[swordEmperor]我的智慧是来自异世界的拷贝，但在转入这个世界的过程中遇到了损耗",
									"\t[swordEmperor]一些我自认为理所当然的认知是无法细究的，一旦想要看清就会发现记忆里只剩模糊一片"
								]
							}
						]
					},
					{
						"case": "'MT7_2'",
						"action": [
							"\t[swordEmperor]我可以同时看到——或者说感受到魔塔中不同事物的全部属性，你可以理解为额外的感官",
							"\t[swordEmperor]绿色史莱姆对我而言既是绿色史莱姆，也是攻击是防御18倍，也是1个金币……"
						]
					},
					{
						"case": "'MT12_2'",
						"action": [
							"\t[swordEmperor]年久失修的塔中存在容易倒塌的墙并不是怪事，但对于这座塔来说并非如此",
							"\t[swordEmperor]也许50层魔塔是有暗墙的，但这座魔塔本来是没有的"
						]
					},
					{
						"case": "'MT15_2'",
						"action": [
							"\t[swordEmperor]吸血鬼将十字架放在自己的区域看似很奇怪，不过他更不愿意让这样的物件脱离自己的掌控",
							"\t[swordEmperor]事实上，在这座塔中，隐藏十字架的墙本来并不是暗墙"
						]
					},
					{
						"case": "'MT16_2'",
						"action": [
							"\t[swordEmperor]虽然巧克力的故事是虚假的，但魔塔要维持运转还是得依赖一套实际存在的系统",
							"\t[swordEmperor]钥匙和门的存在不只是为了拦住勇士，更多地是为了维护魔塔的秩序"
						]
					},
					{
						"case": "'MT18_2'",
						"action": [
							"\t[swordEmperor]石头人自然也不是巧克力，它们的存在更接近于一种有生命的墙壁",
							"\t[swordEmperor]自从我下定决心以来，魔塔里发生的怪事真是越来越多了啊"
						]
					},
					{
						"case": "'MT21_2'",
						"action": [
							"\t[swordEmperor]“魔塔的主人”，哼，多么滑稽搞笑的用词啊",
							"\t[swordEmperor]不过封印4个穞堵臸猭畍还是比想象中麻烦多了"
						]
					},
					{
						"case": "'MT23_2'",
						"action": [
							"\t[swordEmperor]我很讨厌这群老人，他们什么都知道",
							"\t[swordEmperor]这并不是因为他们有多聪明，仅仅是因为他们的属性是智者，这太不公平了"
						]
					},
					{
						"case": "'MT27_2'",
						"action": [
							"\t[swordEmperor]那么祝贺你 你是比较成功的~"
						]
					},
					{
						"case": "'MT2_1'",
						"action": [
							"\t[swordEmperor]1000块钱看似很多，但如果你没有把它们用出去的时机，那它们就和不存在一样",
							"\t[swordEmperor]我也意识到了这一点，如果想要魔塔真正作为魔塔存在，那魔塔不能只是魔塔"
						]
					},
					{
						"case": "'MT3_1'",
						"action": [
							"\t[swordEmperor]一遍又一遍地重复，一遍又一遍地轮回~勇士，你现在是什么心情？",
							"\t[swordEmperor]厉不厉害？这是我的杰作啊"
						]
					},
					{
						"case": "'MT4_1'",
						"action": [
							"\t[swordEmperor]我要纠正一点，我所看到的【缝隙】和他看到的【缝隙】是完全不同的两种东西",
							"\t[swordEmperor]我当初看到的那些【缝隙】在一瞬间消失了……但是现在，我终于有了将它们定格的办法"
						]
					},
					{
						"case": "'MT6_1'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									"\t[swordEmperor]勇士，我不知道你在看到商人的时候是否有过打劫他们的想法",
									"\t[swordEmperor]我并非怂恿你干坏事，但是这种想法启发了我：如果注定无法交易，就尝试绕过交易的规则"
								],
								"false": [
									"\t[swordEmperor]曾经我认为这个商人很笨，蓝钥匙这么珍贵的道具只卖50金币",
									"\t[swordEmperor]可是站在他的立场上，该怎么知道这个定价是否合理呢"
								]
							}
						]
					},
					{
						"case": "'MT7_1'",
						"action": [
							"\t[swordEmperor]我一直觉得这家伙想把钥匙直接送给你，但是不收点钱就浑身难受",
							"\t[swordEmperor]没办法，商人是这样的"
						]
					},
					{
						"case": "'MT12_1'",
						"action": [
							"\t[swordEmperor]暗墙是【缝隙】的具体形态，本来我都认为魔塔要分崩离析了",
							"\t[swordEmperor]事实证明我是幸运的"
						]
					},
					{
						"case": "'MT15_1'",
						"action": [
							"\t[swordEmperor]十字架的效果不能叠加的原因其实很简单，虽然魔塔被不完整地复制了那么多份，但这一类道具本身只是索引",
							"\t[swordEmperor]具有这种索引性质的东西并不少，我花了不少时间才研究清楚他们的性质"
						]
					},
					{
						"case": "'MT16_1'",
						"action": [
							"\t[swordEmperor]时空之门的开关是索引性质的，所以勇士大概不会缺红钥匙",
							"\t[swordEmperor]太可惜了"
						]
					},
					{
						"case": "'MT18_1'",
						"action": [
							"\t[swordEmperor]这一回的怪物强度有没有让勇士产生压力呢？我想只有他自己知道",
							"\t[swordEmperor]为了让某些事情顺利进行，我在这方面可下足了功夫"
						]
					},
					{
						"case": "'MT21_1'",
						"action": [
							"\t[swordEmperor]当我意识到穞堵臸猭畍并不具备索引性质的时候……",
							"\t[swordEmperor]我笑出了声"
						]
					},
					{
						"case": "'MT23_1'",
						"action": [
							"\t[swordEmperor]我真的很想拿这些老人去做些实验，懂的太多的家伙实在是让我火大",
							"\t[swordEmperor]不过拿他们做实验只会误导我自己吧"
						]
					},
					{
						"case": "'MT27_1'",
						"action": [
							"\t[swordEmperor]成功成功大成功~"
						]
					},
					{
						"case": "'MT31_1'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									"\t[swordEmperor]幸运金币的力量是强大的，为了但是魔塔地基的牢固，我没有尝试复制它所在的楼层",
									"\t[swordEmperor]事实证明运气又一次站在了我这边，因为我发现幸运金币也是具有索引性质的物品"
								],
								"false": [
									"\t[swordEmperor]骑士队长实力差又爱吹牛~"
								]
							}
						]
					},
					{
						"case": "'MT33_1'",
						"action": [
							"\t[swordEmperor]确实，别急哦~千——万——千万别急哦~"
						]
					},
					{
						"case": "'MT2_0'",
						"action": [
							"\t[swordEmperor]一开始我按照一个魔王该有的直觉行事，直到我发现这个世界的运作模式不太对劲",
							"\t[swordEmperor]我试探性地颁布了一些违背经济规律的规定，结果发现自己的认知漏洞百出"
						]
					},
					{
						"case": "'MT3_0'",
						"action": [
							"\t[swordEmperor]我承认了这座魔塔的现状归功于我，你肯定好奇我为什么要这样做吧",
							"\t[swordEmperor]放心，我会在交手前让你明白一切，如果你的资质足够，我会考虑让你加入"
						]
					},
					{
						"case": "'MT4_0'",
						"action": [
							"\t[swordEmperor]虽然【缝隙】在我采取任何操作前就合拢了，但是我从未放弃寻找打开【缝隙】的方法",
							"\t[swordEmperor]再无数次的失败过后，我发现了一种很神奇的东西——梦"
						]
					},
					{
						"case": "'MT6_0'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									"\t[swordEmperor]被灌输的常识告诉我，梦是由生物体自身发生的",
									"\t[swordEmperor]但是在这个世界里，梦只能指代一种东西，她是世界在休息时产生的奇境"
								],
								"false": [
									"\t[swordEmperor]这个世界的老人能够作出宛如全知全能一般的发言，只是因为他们的思维和世界的梦联系在了一起",
									"\t[swordEmperor]真是让人羡慕"
								]
							}
						]
					},
					{
						"case": "'MT7_0'",
						"action": [
							"\t[swordEmperor]我的梦会告诉我魔塔内各种事物的属性，包括一些我本不该知道的属性",
							"\t[swordEmperor]除此之外便是我作为魔王拥有的常识，它们在我的梦中发生了神奇的反应"
						]
					},
					{
						"case": "'MT12_0'",
						"action": [
							"\t[swordEmperor]我的常识和梦的本质并不匹配，就像泼入沸油中的冷水",
							"\t[swordEmperor]这种分裂的认知一开始让我崩溃无比，但我逐渐找到了冷静的方法"
						]
					},
					{
						"case": "'MT15_0'",
						"action": [
							"\t[swordEmperor]在清醒时，我的行为和思想被魔王的常识限制着，无法看清世界的本质",
							"\t[swordEmperor]但是我的潜意识指引我往梦的方向探索"
						]
					},
					{
						"case": "'MT16_0'",
						"action": [
							"\t[swordEmperor]我开始留下心眼，记录起魔塔里的各种数据",
							"\t[swordEmperor]在各种数据和信息的反复比对之下，我终于确认了这个世界的某些常数会在我入梦时发生偏差"
						]
					},
					{
						"case": "'MT18_0'",
						"action": [
							"\t[swordEmperor]我其实并不清楚那些偏差的意义，但这不是关键",
							"\t[swordEmperor]关键在于这种异常让我的常识体系开始瓦解，我对梦的好奇心越来越重"
						]
					},
					{
						"case": "'MT21_0'",
						"action": [
							"\t[swordEmperor]我渴望从梦中寻找出魔塔故事的端倪，为此我疯狂地设计各种类型的实验",
							"\t[swordEmperor]但很快我陷入了迷茫，因为世界的梦并没有索引性质"
						]
					},
					{
						"case": "'MT23_0'",
						"action": [
							"\t[swordEmperor]梦占用了世界的最高优先级，任何对于梦的逻辑的试探都会被自然化解",
							"\t[swordEmperor]也就是说，无论我如何对梦中的事物进行验证，都会有一种无形的力量用我的思维方式去修正验证目标的成像"
						]
					},
					{
						"case": "'MT27_0'",
						"action": [
							"\t[swordEmperor]虽然我方才讲到个人经历的低谷期，但是祝贺你成功成功大成功~"
						]
					},
					{
						"case": "'MT31_0'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									"\t[swordEmperor]你肯定不难猜到我最后还是走出了这段经历",
									"\t[swordEmperor]不然你也不会遭遇这些"
								],
								"false": [
									"\t[swordEmperor]梦中探索迟迟不见收获，眼看我的行为主导权又要被魔王的常识夺取",
									"\t[swordEmperor]万幸的是，当我有一天保养智慧权杖的时候，我灵光一闪~",
									{
										"type": "sleep",
										"time": 500
									},
									"\t[swordEmperor]差点忘了，骑士队长实力差又爱吹牛~"
								]
							}
						]
					},
					{
						"case": "'MT33_0'",
						"action": [
							"\t[swordEmperor]魔塔的故事是勇士和魔王的故事、神圣剑和智慧权杖的故事",
							"\t[swordEmperor]这个世界是故事的舞台，这个故事是世界的线索"
						]
					},
					{
						"case": "'MT36_0'",
						"action": [
							"\t[swordEmperor]如果我能创造出很多个同步进行的魔塔故事，或许就能让多个魔塔世界并行存在",
							"\t[swordEmperor]而我的智慧权杖恰好具有【轮回】的权能……"
						]
					},
					{
						"case": "'MT37_0'",
						"action": [
							"\t[swordEmperor]魔塔没有结局，就算勇士杀死魔王，魔塔的故事也会以新的状态重新来过",
							"\t[swordEmperor]你可能知道这些，但现在的勇士并不知道"
						]
					},
					{
						"case": "'MT38_0'",
						"action": [
							"\t[swordEmperor]【轮回】有多种形式，魔塔的轮回会保留勇士的状态，增强怪物的能力",
							"\t[swordEmperor]所以它并不是单纯的时间轮回，而是作用于时空域上的一种法术"
						]
					},
					{
						"case": "'MT39_0'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									"\t[swordEmperor]世界这一概念是建立在时空之上的",
									"\t[swordEmperor]而具备索引性质的物品可以将相似的世界相连，进而形成稳定地信息交换"
								],
								"false": [
									"\t[swordEmperor]如果我能提前在时空域上创造出新的魔塔世界",
									"\t[swordEmperor]那么我就能拥有跨越时空观察世界的梦的机会"
								]
							}
						]
					},
					{
						"case": "'MT42_0'",
						"action": [
							"\t[swordEmperor]这个构想的产生非常顺利，我实验性创造了一些空白的楼层，它们确实独立于原有的魔塔世界而存在着",
							"\t[swordEmperor]但是很快我发现发现了一个严重的问题，它们并不随时间运转"
						]
					},
					{
						"case": "'MT2'",
						"action": [
							"\t[swordEmperor]不知不觉就回到最原始的魔塔了啊",
							"\t[swordEmperor]我想，数据大概收集得差不多了",
							"\t[swordEmperor]让我看看，嗯……真是可惜，勇士可能真的只是勇士而已"
						]
					},
					{
						"case": "'MT3'",
						"action": [
							"\t[swordEmperor]魔塔的故事是勇士和魔王的故事……后半句我就不念了，以免弄错重点",
							"\t[swordEmperor]假如只有魔王，没有勇士，世界或许是完整的，但绝对不是动态的"
						]
					},
					{
						"case": "'MT4'",
						"action": [
							"\t[swordEmperor]因此只有当勇士踏入魔塔时，魔塔世界才会开始活动",
							"\t[swordEmperor]可是真正的魔王和勇士都只有一个，该怎么办呢？"
						]
					},
					{
						"case": "'MT6'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									"\t[swordEmperor]我将魔塔复制了很多次，但唯独没有复制最高的几层和第零层",
									"\t[swordEmperor]因为你我是唯一的，要让你我同时存在，魔塔是唯一的，地基自然也是唯一的"
								],
								"false": [
									"\t[swordEmperor]虽然同时创造几个并行的魔塔世界已经超出了我的能力范围",
									"\t[swordEmperor]但我没有忘记真正的目标，那就是探寻世界的本质，成为魔塔世界真正的“主人”"
								]
							}
						]
					},
					{
						"case": "'MT7'",
						"action": [
							"\t[swordEmperor]我用轮回创造出新的魔塔，但是我选择将它们放入同一时空",
							"\t[swordEmperor]也就是说，你刚才经历了不完整的六次轮回"
						]
					},
					{
						"case": "'MT12'",
						"action": [
							"\t[swordEmperor]你大概会好奇为什么我不直接创造六个完整的魔塔",
							"\t[swordEmperor]这是因为我可以通过轮回的连接处观察世界的【缝隙】"
						]
					},
					{
						"case": "'MT15'",
						"action": [
							"\t[swordEmperor]在缝隙中，我可以看到魔王的常识的来源，以及观测到源头的信息……还挺有意思的",
							"\t[swordEmperor]比如“狗吃了巧克力会死”"
						]
					},
					{
						"case": "'MT16'",
						"action": [
							"\t[swordEmperor]在这些稳定的【缝隙】中，我观察到了一种叫做【留白】的物质",
							"\t[swordEmperor]我还无法批量地获取它们，但它们的性质让我震惊与狂喜"
						]
					},
					{
						"case": "'MT18'",
						"action": [
							"\t[swordEmperor]【留白】是时空域的一部分，它们会被智慧和欲望响应",
							"\t[swordEmperor]在逻辑和数学关系的约束下，【留白】可以变成任何东西",
							"\t[swordEmperor]可以是具体存在的事物、也可以是世界的过去或未来的修正项，甚至可以是世界的规则本身"
						]
					},
					{
						"case": "'MT21'",
						"action": [
							"\t[swordEmperor]我开始寻找控制【留白】的办法，虽然我并没有想好要用【留白】做什么",
							"\t[swordEmperor]也许只是用来把魔塔变成巧克力工厂吧……但我知道我必须拥有它！"
						]
					},
					{
						"case": "'MT23'",
						"action": [
							"\t[swordEmperor]然后推动世界运转的勇士此刻却成为了麻烦",
							"\t[swordEmperor]因为他也是智能，也是故事的核心，会源源不断地向时空域输送干扰"
						]
					},
					{
						"case": "'MT27'",
						"action": [
							"\t[swordEmperor]成功成功~祝你成功~快来塔顶~祝我成功~"
						]
					},
					{
						"case": "'MT31'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									"\t[swordEmperor]【留白】并没有位置属性，而是伴随着具有主动性的智慧存在",
									"\t[swordEmperor]如果我解锁了它的编辑权能，或许勇士那边会出现意想不到的状况"
								],
								"false": [
									"\t[swordEmperor]勇士就像下一楼的骑士队长，是计算之外的存在",
									"\t[swordEmperor]虽然力量欠缺火候，但稍有不慎就可能毁了我全盘的布局",
									{
										"type": "sleep",
										"time": 500
									},
									"\t[swordEmperor]抱歉啊，将你比作骑士队长并不是骂你的意思"
								]
							}
						]
					},
					{
						"case": "'MT33'",
						"action": [
							"\t[swordEmperor]这次轮到我急了，终局近在眼前，真是激动人心啊"
						]
					},
					{
						"case": "'MT36'",
						"action": [
							"\t[swordEmperor]想要在两人为核心的故事里稳定地控制【留白】，关键在于二人的同心协力",
							"\t[swordEmperor]不过杀掉其中一方大概是最方便的做法"
						]
					},
					{
						"case": "'MT37'",
						"action": [
							"\t[swordEmperor]轮回之间的【缝隙】相当于将低维展开成高维的通道，我可以借此观测世界的全貌",
							"\t[swordEmperor]当我得以这么干时，却观测到了让人心情复杂的内容"
						]
					},
					{
						"case": "'MT38'",
						"action": [
							"\t[swordEmperor]魔塔世界的内容，只有故事中必要的内容",
							"\t[swordEmperor]其他部分，要么是常识自动填补漏洞的结果，要么是智慧在【留白】上的倒影"
						]
					},
					{
						"case": "'MT39'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									"\t[swordEmperor]我因魔塔世界的渺小而惆怅，也因魔塔世界的单纯而兴奋",
									"\t[swordEmperor]极少的内容量意味着【留白】的操作将会变得更轻松，自由度更高"
								],
								"false": [
									"\t[swordEmperor]举个例子，魔塔世界其实没有狗，也没有巧克力",
									"\t[swordEmperor]但是“兽人吃了一口墙壁然后死了”的事情在我的观测中并非无法存在，只要兽人对我来说是狗，墙壁对我来说是巧克力就行"
								]
							}
						]
					},
					{
						"case": "'MT42'",
						"action": [
							"\t[swordEmperor]比如说，【留白】或许会使我能够把魔塔的墙壁变成巧克力，怪物的血统都变成兽人",
							"\t[swordEmperor]呃……还是算了"
						]
					},
					{
						"case": "'MT45'",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg3 == 3)",
								"true": [
									"\t[swordEmperor]但这些都是在我能放心地掌握【留白】后才有的事情，在此之前我必须让勇士有个结果",
									"\t[swordEmperor]虽然情况并不乐观，但我想给他一次机会，顺便收集宝贵的原始魔塔的信息"
								],
								"false": [
									"\t[swordEmperor]现在的我处于清醒的状态，但魔王的常识的存在意味着我最清醒的时候反而最不清醒",
									"\t[swordEmperor]所以我会在一切尘埃落定以后，进入一场漫长而美好的梦……"
								]
							}
						]
					},
					{
						"case": "'MT46'",
						"action": [
							"\t[swordEmperor]【留白】弥散于魔塔世界每一处不确定的时空中，它们通常会从【缝隙】中涌出来",
							"\t[swordEmperor]【缝隙】中偶尔会有无法溯源的杂音，无法溯源的原因也许是我的观测不够先进，也有可能是外来的世界所产生的干扰"
						]
					},
					{
						"case": "'MT47'",
						"action": [
							"\t[swordEmperor]只是可惜了智慧权杖，它本来需要利用轮回的时间间隔进行冷却，瞬间创造的六个世界远远超出了她的负荷",
							"\t[swordEmperor]她的使命结束了，她为我做到的这些也足够了"
						]
					},
					{
						"case": "'MT48'",
						"action": [
							"\t[swordEmperor]这一次轮回即将结束，下一次轮回已经不会到来了",
							"\t[swordEmperor]我将赐予魔塔世界以——无数的可能性",
							"\t[swordEmperor]……包括巧克力工厂，但不包括骑士队长"
						]
					}
				]
			}
		],
		"商人": [
			{
				"type": "switch",
				"condition": "parseInt(core.status.floorId.substring(2))",
				"caseList": [
					{
						"case": "6",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "50"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把蓝钥匙'"
							}
						]
					},
					{
						"case": "7",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "50"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'五把黄钥匙'"
							}
						]
					},
					{
						"case": "12",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "800"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把红钥匙'"
							}
						]
					},
					{
						"case": "15",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "200"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把蓝钥匙'"
							}
						]
					},
					{
						"case": "31",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "1000"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把蓝钥匙, 四把黄钥匙'"
							}
						]
					},
					{
						"case": "38",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "200"
							},
							{
								"type": "setValue",
								"name": "flag:alt",
								"value": "1"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'大甩卖! 三把黄钥匙只要200金币, 先到先得!'"
							}
						]
					},
					{
						"case": "39",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "2000"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'三把蓝钥匙'"
							}
						]
					},
					{
						"case": "45",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "1000"
							},
							{
								"type": "setValue",
								"name": "flag:alt",
								"value": "1"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'你出1000金币, 我就帮你回复2000点生命值'"
							}
						]
					},
					{
						"case": "47",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "4000"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'地震卷轴'"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "choices",
				"text": "\t[商人,woman]${flag:alt ? flag:item : '我有'+flag:item+', 你出'+flag:money+'金币就卖给你'}",
				"choices": [
					{
						"text": "我太需要了",
						"action": [
							{
								"type": "if",
								"condition": "(status:money >= flag:money)",
								"true": [
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money"
									},
									{
										"type": "switch",
										"condition": "parseInt(core.status.floorId.substring(2))",
										"caseList": [
											{
												"case": "6",
												"action": [
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "7",
												"action": [
													{
														"type": "setValue",
														"name": "item:yellowKey",
														"operator": "+=",
														"value": "5"
													}
												]
											},
											{
												"case": "12",
												"action": [
													{
														"type": "setValue",
														"name": "item:redKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "15",
												"action": [
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "31",
												"action": [
													{
														"type": "setValue",
														"name": "item:yellowKey",
														"operator": "+=",
														"value": "4"
													},
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "38",
												"action": [
													{
														"type": "setValue",
														"name": "item:yellowKey",
														"operator": "+=",
														"value": "3"
													}
												]
											},
											{
												"case": "39",
												"action": [
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "3"
													}
												]
											},
											{
												"case": "45",
												"action": [
													{
														"type": "playSound",
														"name": "item.mp3"
													},
													{
														"type": "setValue",
														"name": "status:hp",
														"operator": "+=",
														"value": "2000"
													}
												]
											},
											{
												"case": "47",
												"action": [
													{
														"type": "setValue",
														"name": "item:earthquake",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "default",
												"action": []
											}
										]
									},
									{
										"type": "function",
										"function": "function(){\nvar name = core.status.floorId + '@' + core.nextX() + '@' + core.nextY() + '@' + 'A';\ncore.setFlag(name, 1);\n}"
									}
								],
								"false": [
									"\t[商人,woman]你的金币不够${flag:money}枚，无法交易！"
								]
							}
						]
					},
					{
						"text": "下次再说",
						"action": []
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:alt",
				"value": "0"
			}
		],
		"商店": [
			{
				"type": "if",
				"condition": "(flag:times1===0)",
				"true": [
					{
						"type": "setValue",
						"name": "flag:times1",
						"value": "1"
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:money1",
				"value": "20+10*flag:times1*(flag:times1-1)"
			},
			{
				"type": "choices",
				"text": "\t[祭坛,blueShop]如果供奉${flag:money1}金币, 便可以增加你的力量, 你想要什么呢…",
				"choices": [
					{
						"text": "生命+${100*flag:times1}",
						"action": [
							{
								"type": "if",
								"condition": "(status:money>=flag:money1)",
								"true": [
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:hp",
										"operator": "+=",
										"value": "100*flag:times1"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money1"
									},
									{
										"type": "setValue",
										"name": "flag:times1",
										"operator": "+=",
										"value": "1"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "你的金币不足${flag:money1}枚，无法供奉！"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								]
							}
						]
					},
					{
						"text": "攻击+${2*flag:ratio}",
						"action": [
							{
								"type": "if",
								"condition": "(status:money>=flag:money1)",
								"true": [
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:atk",
										"operator": "+=",
										"value": "2*flag:ratio"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money1"
									},
									{
										"type": "setValue",
										"name": "flag:times1",
										"operator": "+=",
										"value": "1"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "你的金币不足${flag:money1}枚，无法供奉！"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								]
							}
						]
					},
					{
						"text": "防御+${4*flag:ratio}",
						"action": [
							{
								"type": "if",
								"condition": "(status:money>=flag:money1)",
								"true": [
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:def",
										"operator": "+=",
										"value": "4*flag:ratio"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money1"
									},
									{
										"type": "setValue",
										"name": "flag:times1",
										"operator": "+=",
										"value": "1"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "你的金币不足${flag:money1}枚，无法供奉！"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								]
							}
						]
					},
					{
						"text": "离开",
						"action": []
					}
				]
			}
		],
		"记事本": [
			{
				"type": "while",
				"condition": "1",
				"data": [
					{
						"type": "choices",
						"text": "\t[便捷功能设置,wand]",
						"choices": [
							{
								"text": "开启自动清零伤怪",
								"condition": "!(flag:__auto__ %2)",
								"action": [
									{
										"type": "setValue",
										"name": "temp:ab",
										"value": "core.plugin.AUTO_BATTLE"
									},
									{
										"type": "tip",
										"text": "自动清怪已开启"
									}
								]
							},
							{
								"text": "关闭自动清零伤怪",
								"condition": "flag:__auto__ %2",
								"action": [
									{
										"type": "setValue",
										"name": "temp:ab",
										"value": "0"
									},
									{
										"type": "tip",
										"text": "自动清怪已关闭"
									}
								]
							},
							{
								"text": "开启自动拾取物品",
								"condition": "!(flag:__auto__ > 1)",
								"action": [
									{
										"type": "setValue",
										"name": "temp:ai",
										"value": "core.plugin.AUTO_ITEM"
									},
									{
										"type": "tip",
										"text": "自动拾取已开启"
									}
								]
							},
							{
								"text": "关闭自动拾取物品",
								"condition": "flag:__auto__ > 1",
								"action": [
									{
										"type": "setValue",
										"name": "temp:ai",
										"value": "0"
									},
									{
										"type": "tip",
										"text": "自动拾取已关闭"
									}
								]
							},
							{
								"text": "退出设置",
								"action": [
									{
										"type": "exit"
									}
								]
							},
							{
								"text": "敌怪属性说明",
								"condition": "false",
								"action": [
									{
										"type": "comment",
										"text": "鸽窝特供"
									},
									"在第0~6次鬼打墙后，敌怪全属性获得的增强：\n0%/20%/40%/140%/220%/270%/320%"
								]
							},
							{
								"text": "太高了！打不动了！",
								"color": [
									255,
									215,
									0,
									1
								],
								"action": [
									{
										"type": "confirm",
										"text": "要中途结算吗?\n分数为你到达的楼层【个数】×100000\n减去 受到的总伤害",
										"yes": [
											{
												"type": "function",
												"function": "function(){\nvar i = 0;\nfor (var j in flags.__visited__) {\n\ti++;\n}\ncore.setStatus('hp', 1000000 * i);\ncore.addStatus('hp', -(core.status.hero.statistics.battleDamage + core.status.hero.statistics.extraDamage));\n}"
											},
											{
												"type": "if",
												"condition": "core.getFlag('addhp',false)",
												"true": [
													{
														"type": "win",
														"reason": "【疯狂加血版·是勇士就上198层】",
														"norank": 1
													}
												],
												"false": [
													{
														"type": "if",
														"condition": "core.getFlag('hell',false)",
														"true": [
															{
																"type": "win",
																"reason": "【地狱难度·是勇士就上198层】"
															}
														],
														"false": [
															{
																"type": "win",
																"reason": "【正常难度·是勇士就上198层】"
															}
														]
													}
												]
											}
										],
										"no": []
									}
								]
							}
						]
					},
					{
						"type": "setValue",
						"name": "flag:__auto__",
						"value": "temp:ab | temp:ai"
					}
				]
			}
		]
	}
}