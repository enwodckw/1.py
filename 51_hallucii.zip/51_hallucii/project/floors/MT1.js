main.floors.MT1=
{
    "floorId": "MT1",
    "title": "魔塔 第01层",
    "name": "第 1 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,201,202,201,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1, 31,  0,  0, 81,  0,  1, 27, 21,  0,  1,  0,  1],
    [  1,  0,209,  0,  1,  0,  1, 28, 31,  0,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  1,  1,  1, 81,  1,  0,  1],
    [  1, 21,  0,  0,  1,  0, 81,205,217,205,  1,  0,  1],
    [  1,  0,210,  0,  1,  0,  1,  1,  1,  1,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1, 81,  1,  1,  1, 81,  1,  1],
    [  1, 31,  0, 21,  1, 21,  0,  0,  1,  0,205,  0,  1],
    [  1, 31, 46, 21,  1,  0,  0,  0,  1,201, 32,201,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [
        {
            "type": "if",
            "condition": "core.getFlag('hallucii', false)",
            "true": [
                {
                    "type": "if",
                    "condition": "flag:begin",
                    "true": [
                        {
                            "type": "switch",
                            "condition": "flag:begin",
                            "caseList": [
                                {
                                    "case": "1",
                                    "action": [
                                        "\t[swordEmperor]看到熟悉的景象，勇士有些迷茫。但他很快认清了现状，心无旁骛地继续前进了。",
                                        "\t[swordEmperor]毕竟他是勇士",
                                        "\t[swordEmperor]不过他可能没有意识到，从这一层开始，所有敌人的属性都增强了20%",
                                        {
                                            "type": "setValue",
                                            "name": "flag:begin",
                                            "value": "2"
                                        }
                                    ]
                                },
                                {
                                    "case": "2",
                                    "action": [
                                        "\t[swordEmperor]勇士对这种重复的楼层已经不陌生了，他开始思考如何规划可以重复获得的资源",
                                        "\t[swordEmperor]在不知不觉间，从这一层开始，所有敌人的属性又增强了20%",
                                        {
                                            "type": "setValue",
                                            "name": "flag:begin",
                                            "value": "3"
                                        }
                                    ]
                                },
                                {
                                    "case": "3",
                                    "action": [
                                        "\t[swordEmperor]勇士似乎总结出了自己的一套战斗规律，他仿佛已经对这座魔塔了如指掌了",
                                        "\t[swordEmperor]非常突然地，从这一层开始，所有敌人的属性又增强了100%；真希望以后不要再有这么夸张的增强了",
                                        {
                                            "type": "setValue",
                                            "name": "flag:begin",
                                            "value": "4"
                                        }
                                    ]
                                },
                                {
                                    "case": "4",
                                    "action": [
                                        "\t[swordEmperor]上次的增强或许让勇士有些疲惫，但他知道旅途已经近半，这座魔塔肯定难不倒自己",
                                        "\t[swordEmperor]非常不幸地，从这一层开始，所有敌人的属性又增强了80%……至少比上一次要好，不是么",
                                        {
                                            "type": "setValue",
                                            "name": "flag:begin",
                                            "value": "5"
                                        }
                                    ]
                                },
                                {
                                    "case": "5",
                                    "action": [
                                        "\t[swordEmperor]聪明的勇士已经明白了为什么此前的增强幅度会如此夸张，但他很聪明，所以可以轻松应对",
                                        "\t[swordEmperor]令人安心的是，从这一层开始，所有敌人的属性只额外增强了50%……也许幕后主使快到极限了吧，勇士这么想着",
                                        {
                                            "type": "setValue",
                                            "name": "flag:begin",
                                            "value": "6"
                                        }
                                    ]
                                },
                                {
                                    "case": "6",
                                    "action": [
                                        "\t[swordEmperor]勇士的直觉告诉它，这次鬼打墙大概是最后一次了，胜利就在眼前！",
                                        "\t[swordEmperor]令人安心的是，从这一层开始，所有敌人的属性也只增强了50%，勇士仿佛看到了自己光明的未来",
                                        {
                                            "type": "setValue",
                                            "name": "flag:begin",
                                            "value": "7"
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            "type": "exit"
                        }
                    ]
                },
                {
                    "type": "setValue",
                    "name": "flag:begin",
                    "value": "1"
                },
                {
                    "type": "while",
                    "condition": "1",
                    "data": [
                        {
                            "type": "tip",
                            "text": "游戏已重启"
                        },
                        "\t[swordEmperor]勇士踏入了50层魔塔，这表明他是个勇士。但他不知道的是，这次的50层魔塔好像有些不同寻常……",
                        {
                            "type": "choices",
                            "text": "\t[游戏难度选择：,swordEmperor]\r[rgb(0,255,0)]疯狂加血版\r\r[rgb(255,255,255)]/正常难度\r下\n· 3楼的魔王只会在第一次重置你的攻防\n\r[rgb(255,64,64)]地狱难度\r下\n· 无法对话穿墙\n· 3楼的魔王每次都会重置你的攻防\n· 最终Boss的攻击力增加4000点\n",
                            "choices": [
                                {
                                    "text": "疯狂加血版",
                                    "color": [
                                        0,
                                        255,
                                        0,
                                        1
                                    ],
                                    "action": [
                                        "\t[swordEmperor]勇士选择了\\d\r[rgb(0,255,0)]疯狂加血版\r\\d，但他依然是个勇士。",
                                        {
                                            "type": "setValue",
                                            "name": "flag:addhp",
                                            "value": "1"
                                        },
                                        {
                                            "type": "exit"
                                        }
                                    ]
                                },
                                {
                                    "text": "正常难度",
                                    "action": [
                                        "\t[swordEmperor]勇士选择了\\d正常难度\\d，祝他好运！",
                                        {
                                            "type": "exit"
                                        }
                                    ]
                                },
                                {
                                    "text": "困难难度",
                                    "color": [
                                        255,
                                        192,
                                        64,
                                        1
                                    ],
                                    "condition": "false",
                                    "action": [
                                        "\t[swordEmperor]勇士选择了\\d\r[rgb(255,192,64)]困难难度\r\\d，这表明他确实是个勇士",
                                        {
                                            "type": "setValue",
                                            "name": "flag:hell",
                                            "value": "1"
                                        },
                                        {
                                            "type": "exit"
                                        }
                                    ]
                                },
                                {
                                    "text": "地狱难度",
                                    "color": [
                                        255,
                                        64,
                                        64,
                                        1
                                    ],
                                    "action": [
                                        "\t[swordEmperor]勇士选择了\\d\r[rgb(255,64,64)]地狱难度\r\\d，这表明他确实是个勇士",
                                        {
                                            "type": "setValue",
                                            "name": "flag:hell",
                                            "value": "1"
                                        },
                                        {
                                            "type": "exit"
                                        }
                                    ]
                                },
                                {
                                    "text": "嘿嘿错了，我先存个档",
                                    "color": [
                                        255,
                                        255,
                                        255,
                                        1
                                    ],
                                    "action": [
                                        "\t[swordEmperor]勇士选择了先存个档，这表明他是个稳健的勇士",
                                        {
                                            "type": "callSave"
                                        }
                                    ]
                                }
                            ]
                        }
                    ]
                }
            ],
            "false": [
                {
                    "type": "setValue",
                    "name": "flag:hallucii",
                    "value": "1"
                },
                {
                    "type": "setValue",
                    "name": "flag:__visited__",
                    "value": "{}"
                },
                {
                    "type": "changeFloor",
                    "floorId": "MT1_5"
                }
            ]
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {
        "6,9": [
            {
                "type": "if",
                "condition": "flag:wandTip",
                "true": [],
                "false": [
                    "\t[swordEmperor]勇士随身携带怪物手册和楼层传送器似乎是可以理解的，那么他为什么要带一个记事本呢？",
                    {
                        "type": "setValue",
                        "name": "flag:wandTip",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        2,
        1
    ],
    "downFloor": [
        6,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}