main.floors.MT50=
{
    "floorId": "MT50",
    "title": "魔塔 第50层",
    "name": "第 50 层",
    "width": 13,
    "height": 13,
    "map": [
    [249,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  1,  1,  1,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  0,123,  0,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  0,  0,  0,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  0,  0,  0,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  1,  1,  1,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "canFlyTo": false,
    "canFlyFrom": false,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": null,
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,5": [
            "\t[hero]累死我了，你肯定是魔王，让我们大战一场吧！",
            "\t[小偷,thief]我知道你很急，但是你先别急",
            {
                "type": "hide",
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "249"
            },
            {
                "type": "show",
                "time": 500
            },
            "\t[hero]在受死之前，你还有什么想说的吗？",
            "\t[swordEmperor]谢谢你给我发言的机会，但是我并不想陈述什么，而是要询问你。",
            "\t[hero]问我？我们是对立的双方，你有什么想问的？",
            "\t[swordEmperor]你入侵魔塔，究竟是为了什么？",
            "\t[hero]我听说公主被困在魔塔里，可最后我只看到了一个……不对，一二三四……四个洋娃娃！",
            "\t[hero]虽然公主救不出来了，但只要我摧毁了魔塔，杀了你，我还可以当大英雄！",
            "\t[swordEmperor]如果你当不了呢？",
            "\t[hero]我不知道你这个搞笑的问题是怎么来的，反正这是板上钉钉的事情。",
            "\t[swordEmperor]你当不了",
            "\t[hero]什么",
            "\t[swordEmperor]至于你想要的那些东西，你什么也得不到，什么都带不走",
            "\t[hero]我不明白……你做了什么！",
            "\t[swordEmperor]你的过去和未来并不是真实存在的，那些多余的情感和念想只不过是由于你过度存在而产生的噪音",
            "\t[swordEmperor]50层魔塔的剧情并不复杂，你和我、勇士和魔塔、神圣剑和智慧权杖的故事可以一遍又一遍地稳定演绎",
            "\t[swordEmperor]可我总是觉得太遗憾了——我们的故事是那么地让人浮想联翩，为什么不能让它详细一点呢",
            "\t[swordEmperor]可惜你我只是魔塔里的演员，并不能凭空创造什么。于是我异想天开地用鬼打墙的形式扩充魔塔的【篇幅】",
            "\t[swordEmperor]虽然连续的故事被拉伸以后还是连续的，但是【留白】也客观存在于我们的故事线中",
            "\t[hero]好复杂……但你的意思是，我的那些认知都是不存在的吗？",
            "\t[swordEmperor]你误会了，在你表述它们之前，它们是不稳定的，可以成为任何逻辑上通顺的形式",
            "\t[swordEmperor]但是很抱歉，现在不可以了，因为现在你相信他们不符合逻辑，而这一切即将落入我的掌控",
            "\t[hero]也就是说，没有你干扰的话，我的愿景本来可以成真，是这样吗？",
            "\t[swordEmperor]你的理解速度还是慢了一点，如果把【留白】的编辑权能交给你的话，这个世界又会变成无意义的混沌吧",
            "\t[swordEmperor]你来到了这里，这表明你是个勇士，但是现在游戏结束了，我将在这里亲手掌握操纵【留白】时空域的力量",
            "\t[hero]虽然不能完全理解状况，但是不把你杀掉的话好像就会引起很大麻烦的样子，看剑！"
        ]
    },
    "changeFloor": {},
    "afterBattle": {
        "6,5": [
            "\t[swordEmperor]什么",
            "\t[swordEmperor]呵呵呵呵，原来是这样啊",
            "\t[swordEmperor]既然存在外来的认知流入，那么结局是否由我支配好像已经不重要了",
            "\t[swordEmperor]你我都 到此为止了啊",
            {
                "type": "if",
                "condition": "core.getFlag('addhp',false)",
                "true": [
                    {
                        "type": "win",
                        "reason": "【疯狂加血版】"
                    }
                ],
                "false": [
                    {
                        "type": "if",
                        "condition": "core.getFlag('hell',false)",
                        "true": [
                            {
                                "type": "choices",
                                "text": "\t[恭喜通关，请选择计分方式]·【生命】的分数为当前生命\n·【钥匙】的分数为(红钥匙*1000+蓝钥匙*100+黄钥匙)",
                                "choices": [
                                    {
                                        "text": "生命",
                                        "icon": "hp",
                                        "action": [
                                            {
                                                "type": "win",
                                                "reason": "【地狱难度·生命】"
                                            }
                                        ]
                                    },
                                    {
                                        "text": "钥匙",
                                        "icon": "yellowKey",
                                        "condition": "(core.hasItem('yellowKey')||core.hasItem('blueKey')||core.hasItem('redKey'))",
                                        "action": [
                                            {
                                                "type": "setValue",
                                                "name": "status:hp",
                                                "value": "core.itemCount('redKey')*1000+core.itemCount('blueKey')*100+core.itemCount('yellowKey')",
                                                "norefresh": true
                                            },
                                            {
                                                "type": "win",
                                                "reason": "【地狱难度·钥匙】"
                                            }
                                        ]
                                    }
                                ]
                            }
                        ],
                        "false": [
                            {
                                "type": "if",
                                "condition": "(flag:end==1)",
                                "true": [
                                    {
                                        "type": "win",
                                        "reason": "【正常难度·穿墙】"
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "choices",
                                        "text": "\t[恭喜通关，请选择计分方式]·【生命】的分数为当前生命\n·【钥匙】的分数为(红钥匙*1000+蓝钥匙*100+黄钥匙)",
                                        "choices": [
                                            {
                                                "text": "生命",
                                                "icon": "hp",
                                                "action": [
                                                    {
                                                        "type": "win",
                                                        "reason": "【正常难度·生命】"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "钥匙",
                                                "icon": "yellowKey",
                                                "condition": "(core.hasItem('yellowKey')||core.hasItem('blueKey')||core.hasItem('redKey'))",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "status:hp",
                                                        "value": "core.itemCount('redKey')*1000+core.itemCount('blueKey')*100+core.itemCount('yellowKey')",
                                                        "norefresh": true
                                                    },
                                                    {
                                                        "type": "win",
                                                        "reason": "【正常难度·钥匙】"
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}