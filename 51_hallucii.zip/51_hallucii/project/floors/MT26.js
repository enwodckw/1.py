main.floors.MT26=
{
    "floorId": "MT26",
    "title": "魔塔 第26层",
    "name": "第 26 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1,  1,  1,  1,  0,  0,  0,  1],
    [  1,  0,  0,  1,  1,  1,  1,  1,  1,  1,  0,  0,  1],
    [  1,  0,  1,  1,  1,  5,  5,  5,  1,  1,  1,  0,  1],
    [  1,  0,  1,  1,  5,  5,  5,  5,  5,  1,  1,  0,  1],
    [  1,  0,  1,  1,  5,  5,132,  5,  5,  1,  1,  0,  1],
    [  1,  0,  1,  1,  5,  5,  5,  5,  5,  1,  1,  0,  1],
    [  1,  0,  1,  1,  1,  5, 83,  5,  1,  1,  1,  0,  1],
    [  1,  0,  0,  1,  1,  1, 83,  1,  1,  1,  0,  0,  1],
    [  1,  0, 87,  0,  1,  1, 83,  1,  1,  0,  0,  0,  1],
    [  1, 88,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 3,
    "defaultGround": "ground",
    "bgm": "section3.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,6": [
            {
                "type": "if",
                "condition": "switch:A",
                "true": [],
                "false": [
                    "\t[swordEmperor]在这个鬼打墙的魔塔里，虽然每一个洋娃娃都能打开时空之门的入口，但只有真正的时空之门会被激活",
                    "\t[swordEmperor]我们的主角勇士终于发现了这一切都是一个阴谋，很快就是激动人心的结局了",
                    {
                        "type": "setBlock",
                        "number": "1",
                        "loc": [
                            [
                                5,
                                1
                            ]
                        ],
                        "floorId": "MT24"
                    },
                    {
                        "type": "setBlock",
                        "number": "1",
                        "loc": [
                            [
                                7,
                                1
                            ]
                        ],
                        "floorId": "MT24"
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                2
                            ]
                        ],
                        "floorId": "MT24"
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                3
                            ]
                        ],
                        "floorId": "MT24"
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ],
                        "floorId": "MT24"
                    },
                    {
                        "type": "show",
                        "loc": [
                            [
                                6,
                                1
                            ]
                        ],
                        "floorId": "MT24",
                        "time": 0
                    },
                    {
                        "type": "setValue",
                        "name": "switch:A",
                        "value": "1"
                    },
                    {
                        "type": "playBgm",
                        "name": "truth.mp3",
                        "keep": true
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "2,10": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        2,
        11
    ],
    "downFloor": [
        2,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}