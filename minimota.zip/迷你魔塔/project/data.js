data_a1e2fb4a_e986_4524_b0da_9b7ba7c0874d = 
{
	"main": {
		"floorIds": [
			"MT1",
			"MT2",
			"MT3",
			"MT4"
		],
		"images": [
			"bg.jpg",
			"anqiang"
		],
		"animates": [
			"hand",
			"sword",
			"zone",
			"yongchang",
			"a1"
		],
		"bgms": [
			"xiaoluoli.mp3",
			"xian.mp3",
			"qianjin.mid",
			"star.mid",
			"wan.mp3",
			"huang.mp3",
			"hua.mp3",
			"chuanshuo.mp3",
			"migong.mp3",
			"ed.mp3"
		],
		"sounds": [
			"floor.mp3",
			"attack.ogg",
			"door.ogg",
			"item.ogg",
			"zone.ogg"
		],
		"bgmRemote": true,
		"startBackground": "bg.jpg",
		"startLogoStyle": "color: black",
		"levelChoose": [
			[
				"简单",
				"Easy"
			],
			[
				"普通",
				"Normal"
			],
			[
				"困难",
				"Hard"
			],
			[
				"噩梦",
				"Hell"
			]
		]
	},
	"firstData": {
		"title": "迷你魔塔",
		"name": "minimota",
		"version": "Ver 2.0.1",
		"floorId": "MT1",
		"hero": {
			"name": "勇士",
			"lv": 1,
			"hpmax": 100000,
			"hp": 400,
			"atk": 10,
			"def": 10,
			"mdef": 10,
			"money": 0,
			"experience": 0,
			"items": {
				"keys": {
					"yellowKey": 0,
					"blueKey": 0,
					"redKey": 0
				},
				"constants": {},
				"tools": {}
			},
			"flyRange": [],
			"loc": {
				"direction": "down",
				"x": 3,
				"y": 12
			},
			"flags": {
				"poison": false,
				"weak": false,
				"curse": false
			},
			"steps": 0
		},
		"startText": [
			"ak47系列游戏16 迷你魔塔 作者 伋 复制者 数码宝贝51 祝你玩的开心 默认音乐 精灵石 3个小萝莉在一起 和老人对话可以换音乐"
		],
		"shops": [],
		"levelUp": []
	},
	"values": {
		"lavaDamage": 100,
		"poisonDamage": 10,
		"weakValue": 20,
		"redJewel": 1,
		"blueJewel": 1,
		"greenJewel": 5,
		"redPotion": 50,
		"bluePotion": 100,
		"yellowPotion": 200,
		"greenPotion": 500,
		"sword0": 0,
		"shield0": 0,
		"sword1": 5,
		"shield1": 5,
		"sword2": 8,
		"shield2": 8,
		"sword3": 40,
		"shield3": 40,
		"sword4": 50,
		"shield4": 50,
		"sword5": 10,
		"shield5": 10,
		"moneyPocket": 50,
		"breakArmor": 0.9,
		"counterAttack": 0.1,
		"purify": 3,
		"hatred": 2,
		"animateSpeed": 400
	},
	"flags": {
		"enableFloor": true,
		"enableLv": false,
		"enableHPMax": false,
		"enableMDef": true,
		"enableMoney": true,
		"enableExperience": false,
		"enableLevelUp": false,
		"enableDebuff": false,
		"flyNearStair": true,
		"pickaxeFourDirections": true,
		"bombFourDirections": true,
		"bigKeyIsBox": false,
		"equipment": false,
		"enableDeleteItem": false,
		"enableAddPoint": false,
		"enableNegativeDamage": false,
		"hatredDecrease": true,
		"betweenAttackCeil": true,
		"startDirectly": true,
		"canOpenBattleAnimate": true,
		"showBattleAnimateConfirm": true,
		"battleAnimate": false,
		"displayEnemyDamage": true,
		"displayExtraDamage": true,
		"enableGentleClick": false,
		"potionWhileRouting": false,
		"enableViewMaps": true,
		"portalWithoutTrigger": false,
		"enableMoveDirectly": true
	}
}