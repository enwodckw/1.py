main.floors.MT4=
{
"floorId": "MT4",
"title": "地下室",
"name": "地下室",
"canFlyTo": false,
"canUseQuickShop": true,
"defaultGround": "ground",
"png": [],
"map": [
    [ 87,  0,  0,  0,  0,  0, 23,  1, 43,  1,132,  1, 44],
    [  1,  1,  1,  1,  1,122,  0,  1,  0,  1, 84,  1,  0],
    [ 32, 27, 31, 27, 31,  1,  0,  1, 24,  1, 84,  1, 24],
    [ 33, 32, 27, 31, 27, 83,  0,  1,  0,  1, 84,  1,  0],
    [ 32, 27, 31, 27, 31,  1,  0,  1,258,  1,257,  1,258],
    [  1,  1,  1,  1,  1,  1,258,  1,  0, 34,  0, 34,  0],
    [  0,  0,  0, 16,  0,  0,  0,  1,  0,  0,  0,  0,  0],
    [ 16,  1,  1,  1,  1,  1,  1,  1,  1,  1, 16,  1,  1],
    [  0,  0,  0, 16,  0,  0,  0, 16,  0,  0, 16,  0,  0],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1, 16],
    [  0,  0,  0, 16,  0,  0,  0, 16,  0,  0, 16,  0,  0],
    [ 16,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  0,  0,  0, 16,  0,  0,  0, 16,  0,  0, 16, 24, 33]
],
"firstArrive": [],
"events": {
    "10,1": null,
    "6,1": null,
    "8,2": null,
    "3,8": null,
    "5,1": [
        {
            "type": "choices",
            "text": "\t[老人,man]少年，你需要属性吗？\n我这里有大把的！",
            "choices": [
                {
                    "text": "3攻击（${8}金币）",
                    "action": [
                        {
                            "type": "if",
                            "condition": "status:money>=8",
                            "true": [
                                {
                                    "type": "setValue",
                                    "name": "status:money",
                                    "value": "status:money-8"
                                },
                                {
                                    "type": "setValue",
                                    "name": "status:atk",
                                    "value": "status:atk+3"
                                }
                            ],
                            "false": [
                                "\t[老人,man]你的金钱不足！",
                                {
                                    "type": "revisit"
                                }
                            ]
                        }
                    ]
                },
                {
                    "text": "3防御（${8}金币）",
                    "action": [
                        {
                            "type": "if",
                            "condition": "status:money>=8",
                            "true": [
                                {
                                    "type": "setValue",
                                    "name": "status:money",
                                    "value": "status:money-8"
                                },
                                {
                                    "type": "setValue",
                                    "name": "status:def",
                                    "value": "status:def+3"
                                }
                            ],
                            "false": [
                                "\t[老人,man]你的金钱不足！",
                                {
                                    "type": "revisit"
                                }
                            ]
                        }
                    ]
                },
                {
                    "text": "500生命（${8}金币）",
                    "action": [
                        {
                            "type": "if",
                            "condition": "status:money>=8",
                            "true": [
                                {
                                    "type": "setValue",
                                    "name": "status:money",
                                    "value": "status:money-8"
                                },
                                {
                                    "type": "setValue",
                                    "name": "status:hp",
                                    "value": "status:hp+500"
                                }
                            ],
                            "false": [
                                "\t[老人,man]你的金钱不足！",
                                {
                                    "type": "revisit"
                                }
                            ]
                        }
                    ]
                },
                {
                    "text": "离开",
                    "action": [
                        {
                            "type": "exit"
                        }
                    ]
                }
            ]
        },
        {
            "type": "revisit"
        }
    ],
    "10,0": [
        "\t[hero]我们走吧！",
        "勇士救出了公主 这真是太好了！\n请继续点击几次来统计通关人数",
        {
            "type": "win",
            "reason": "恭喜通关"
        }
    ]
},
"changeFloor": {
    "1,11": null,
    "11,11": null,
    "0,0": {
        "floorId": "MT1",
        "loc": [
            3,
            11
        ],
        "direction": "down"
    }
},
"afterBattle": {},
"afterGetItem": {},
"afterOpenDoor": {},
"cannotMove": {},
}