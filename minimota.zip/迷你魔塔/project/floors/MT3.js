main.floors.MT3=
{
"floorId": "MT3",
"title": "9-15层",
"name": "9-15层",
"canFlyTo": true,
"canUseQuickShop": true,
"defaultGround": "ground",
"png": [],
"map": [
    [  1,  1,  1,273,  1, 27, 27, 27, 23,206, 21,  1, 88],
    [  1,123,  1, 84,  1, 27,  1,  1,  1, 31,  1,122,  0],
    [  1, 85,  1,168,121,  1, 63, 31,206, 27,213,  1,  0],
    [  0,  0,  0,226,  1, 21,  1,  1,  1,  1,209,209,209],
    [  0,  0,  0,213,217, 21,  1, 21, 32, 31,  1,209,209],
    [  1,  1,  1,  1,  1, 83, 21,  1, 27, 31, 31, 81,  0],
    [  0,  0,  0,  0, 81, 81,  1, 27,  1,  1,  1,  1,  0],
    [  0,  1,  1,  1, 83,  1, 28, 22, 21, 32, 31, 81,  0],
    [  0,226,226,226,  0,  0,  1,  1,  1,  1,  1,  1,  0],
    [  1,  1,  1,  1, 81,  0,222,  1,222, 81,  0,  0,  0],
    [  1, 38,  1,222,226,  1, 82,  1,222,  1, 81,  1, 81],
    [  1, 16,  1, 31,222,  1,226,  1,222,  1, 28,  1, 27],
    [  1,  0, 81, 31,222,  1,213, 82,222,  1, 28,  1, 27]
],
"firstArrive": [],
"events": {
    "11,4": null,
    "5,7": null,
    "5,8": null,
    "4,9": null,
    "6,9": null,
    "5,10": null,
    "5,9": null,
    "3,2": [
        "\t[M273]我要彻底毁灭你！",
        {
            "type": "hide"
        }
    ],
    "3,8": null,
    "4,2": [
        "\t[老人,man]这个魔塔里还有更好的商店 最好留点金币"
    ],
    "1,1": [
        "\t[小偷,thief]谢谢你救了我 我帮你打通去地下室的路",
        {
            "type": "show",
            "loc": [
                [
                    3,
                    12
                ]
            ],
            "floorId": "MT1"
        },
        {
            "type": "hide"
        }
    ],
    "11,1": [
        {
            "type": "choices",
            "text": "\t[老人,man]少年，你需要属性吗？\n我这里有大把的！",
            "choices": [
                {
                    "text": "3攻击（${12}金币）",
                    "action": [
                        {
                            "type": "if",
                            "condition": "status:money>=12",
                            "true": [
                                {
                                    "type": "setValue",
                                    "name": "status:money",
                                    "value": "status:money-12"
                                },
                                {
                                    "type": "setValue",
                                    "name": "status:atk",
                                    "value": "status:atk+3"
                                }
                            ],
                            "false": [
                                "\t[老人,man]你的金钱不足！",
                                {
                                    "type": "revisit"
                                }
                            ]
                        }
                    ]
                },
                {
                    "text": "3防御（${12}金币）",
                    "action": [
                        {
                            "type": "if",
                            "condition": "status:money>=12",
                            "true": [
                                {
                                    "type": "setValue",
                                    "name": "status:money",
                                    "value": "status:money-12"
                                },
                                {
                                    "type": "setValue",
                                    "name": "status:def",
                                    "value": "status:def+3"
                                }
                            ],
                            "false": [
                                "\t[老人,man]你的金钱不足！",
                                {
                                    "type": "revisit"
                                }
                            ]
                        }
                    ]
                },
                {
                    "text": "500生命（${12}金币）",
                    "action": [
                        {
                            "type": "if",
                            "condition": "status:money>=12",
                            "true": [
                                {
                                    "type": "setValue",
                                    "name": "status:money",
                                    "value": "status:money-12"
                                },
                                {
                                    "type": "setValue",
                                    "name": "status:hp",
                                    "value": "status:hp+500"
                                }
                            ],
                            "false": [
                                "\t[老人,man]你的金钱不足！",
                                {
                                    "type": "revisit"
                                }
                            ]
                        }
                    ]
                },
                {
                    "text": "离开",
                    "action": [
                        {
                            "type": "exit"
                        }
                    ]
                }
            ]
        },
        {
            "type": "revisit"
        }
    ]
},
"changeFloor": {
    "1,11": null,
    "11,11": null,
    "12,0": {
        "floorId": "MT2",
        "loc": [
            4,
            8
        ],
        "direction": "down"
    }
},
"afterBattle": {
    "3,0": [
        "\t[hero]快说公主在哪",
        "\t[M273]就在地下室 你不怕死就去吧",
        {
            "type": "setValue",
            "name": "flag:231",
            "value": "flag:231+1"
        },
        {
            "type": "if",
            "condition": "flag:231==1",
            "true": [
                {
                    "type": "openDoor",
                    "loc": [
                        1,
                        2
                    ]
                }
            ],
            "false": []
        }
    ]
},
"afterGetItem": {},
"afterOpenDoor": {},
"cannotMove": {},
}