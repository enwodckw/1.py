main.floors.MT1=
{
"floorId": "MT1",
"title": "1-4层",
"name": "1-4层",
"canFlyTo": true,
"canUseQuickShop": true,
"defaultGround": "ground",
"png": [],
"map": [
    [  0,  0,  0,  0, 46,  0,  0,  0,  0, 83,206,206,217],
    [ 21,  1,  1,  1,  1,  1,  1,  1,213,  1,  1,  1,217],
    [ 21,  1, 21, 27, 31,  1, 21,  1, 31,  1, 28, 27,123],
    [206,  1,209, 28,206,  1, 82,  1,209,  0,  1,  1,  1],
    [209,  1, 81,  1, 81,213,  0, 21,  1,  0, 21,  0, 87],
    [ 81, 21,  0,213,  1, 27,  1,209,  1, 85,  1,  1,  1],
    [  1, 32,  1, 81,  1,  1,206,  0,  1,  0,  0,222, 27],
    [ 32,  1, 22, 81, 23, 83,206,206,  1,  0,  1,  1, 27],
    [ 32, 21,  1,206,  1,  1,  1,  1,217,  0,217,  1, 27],
    [ 32,203, 81,209, 81,209,209,  1,213,  1,213,  1, 27],
    [  1,  1,  1, 21,  1,209,209,  1, 21,  1, 32,  1, 27],
    [ 31,206, 81,125, 45,  1, 81,  1, 21,  1, 32,  1, 27],
    [ 27, 28,121, 88,121,122, 27,  1, 35,  1, 36,  1, 27]
],
"firstArrive": [
    {
        "type": "if",
        "condition": "!core.musicStatus.bgmStatus",
        "true": [
            "\t[系统提示]你当前音乐处于关闭状态，本塔开音乐游戏效果更佳"
        ],
        "false": []
    }
],
"events": {
    "5,11": null,
    "7,11": null,
    "7,10": null,
    "5,10": null,
    "6,8": null,
    "5,8": null,
    "4,6": null,
    "7,5": null,
    "12,2": [
        "\t[小偷,thief]谢谢你救了我 我帮你打开下面的门",
        {
            "type": "openDoor",
            "loc": [
                9,
                5
            ]
        },
        "\t[小偷,thief]还有一个和我长的一样的人 可能也被关起来了",
        "\t[hero]好 我知道了 我上去看看",
        {
            "type": "hide"
        }
    ],
    "3,12": {
        "trigger": "action",
        "enable": false,
        "noPass": null,
        "displayDamage": true,
        "data": []
    },
    "3,11": [
        "\t[魔法老人,magician]这是迷你魔塔 你需要去闯并救出公主",
        "\t[hero]怎么这么奇怪啊",
        "\t[魔法老人,magician]原来每层只有7×7 我把很多层都合并了 这样看起来比较方便",
        {
            "type": "hide"
        }
    ],
    "2,12": [
        {
            "type": "choices",
            "text": "背景音乐选择（注意菜单里的系统设置也要打开）",
            "choices": [
                {
                    "text": "精灵石 3个小萝莉在一起",
                    "action": [
                        {
                            "type": "playBgm",
                            "name": "xiaoluoli.mp3"
                        }
                    ]
                },
                {
                    "text": "精灵石 晚上家里和镇子",
                    "action": [
                        {
                            "type": "playBgm",
                            "name": "wan.mp3"
                        }
                    ]
                },
                {
                    "text": "精灵石 黄昏的镇子",
                    "action": [
                        {
                            "type": "playBgm",
                            "name": "huang.mp3"
                        }
                    ]
                },
                {
                    "text": "仙境传说-守候永恒的爱",
                    "action": [
                        {
                            "type": "playBgm",
                            "name": "xian.mp3"
                        }
                    ]
                },
                {
                    "text": "离开",
                    "action": []
                }
            ]
        }
    ],
    "4,12": [
        {
            "type": "choices",
            "text": "背景音乐选择（注意菜单里的系统设置也要打开）",
            "choices": [
                {
                    "text": "精灵石 精灵石传说",
                    "action": [
                        {
                            "type": "playBgm",
                            "name": "chuanshuo.mp3"
                        }
                    ]
                },
                {
                    "text": "精灵石 ed【神曲】",
                    "action": [
                        {
                            "type": "playBgm",
                            "name": "ed.mp3"
                        }
                    ]
                },
                {
                    "text": "精灵石 幸福之花",
                    "action": [
                        {
                            "type": "playBgm",
                            "name": "hua.mp3"
                        }
                    ]
                },
                {
                    "text": "精灵石 迷宫",
                    "action": [
                        {
                            "type": "playBgm",
                            "name": "migong.mp3"
                        }
                    ]
                },
                {
                    "text": "离开",
                    "action": []
                }
            ]
        }
    ],
    "5,12": [
        {
            "type": "choices",
            "text": "\t[老人,man]少年，你需要属性吗？\n我这里有大把的！",
            "choices": [
                {
                    "text": "2攻击（${10}金币）",
                    "action": [
                        {
                            "type": "if",
                            "condition": "status:money>=10",
                            "true": [
                                {
                                    "type": "setValue",
                                    "name": "status:money",
                                    "value": "status:money-10"
                                },
                                {
                                    "type": "setValue",
                                    "name": "status:atk",
                                    "value": "status:atk+2"
                                }
                            ],
                            "false": [
                                "\t[老人,man]你的金钱不足！",
                                {
                                    "type": "revisit"
                                }
                            ]
                        }
                    ]
                },
                {
                    "text": "2防御（${10}金币）",
                    "action": [
                        {
                            "type": "if",
                            "condition": "status:money>=10",
                            "true": [
                                {
                                    "type": "setValue",
                                    "name": "status:money",
                                    "value": "status:money-10"
                                },
                                {
                                    "type": "setValue",
                                    "name": "status:def",
                                    "value": "status:def+2"
                                }
                            ],
                            "false": [
                                "\t[老人,man]你的金钱不足！",
                                {
                                    "type": "revisit"
                                }
                            ]
                        }
                    ]
                },
                {
                    "text": "400生命（${10}金币）",
                    "action": [
                        {
                            "type": "if",
                            "condition": "status:money>=10",
                            "true": [
                                {
                                    "type": "setValue",
                                    "name": "status:money",
                                    "value": "status:money-10"
                                },
                                {
                                    "type": "setValue",
                                    "name": "status:hp",
                                    "value": "status:hp+400"
                                }
                            ],
                            "false": [
                                "\t[老人,man]你的金钱不足！",
                                {
                                    "type": "revisit"
                                }
                            ]
                        }
                    ]
                },
                {
                    "text": "离开",
                    "action": [
                        {
                            "type": "exit"
                        }
                    ]
                }
            ]
        },
        {
            "type": "revisit"
        }
    ]
},
"changeFloor": {
    "1,1": null,
    "7,10": null,
    "3,12": {
        "floorId": "MT4",
        "loc": [
            1,
            0
        ],
        "direction": "down"
    },
    "12,4": {
        "floorId": "MT2",
        "loc": [
            12,
            12
        ],
        "direction": "down"
    }
},
"afterBattle": {},
"afterGetItem": {},
"afterOpenDoor": {
    "4,6": null
},
"cannotMove": {},
}