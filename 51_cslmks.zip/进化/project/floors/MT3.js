main.floors.MT3=
{
    "floorId": "MT3",
    "title": "魔塔 第03层",
    "name": "第 3 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21, 28,  1, 21, 32, 21,  1,  0,  1,  0, 31,  1],
    [  1,  0, 31,  1, 32, 21, 32,  1,  0, 81,205,  0,  1],
    [  1,217,  0,  1, 21, 22, 21,  1,  0,  1,  1,  1,  1],
    [  1, 81,  1,  1,  1,  0,  1,  1,  0,  1,  0,121,  1],
    [  1,  0,  0,205,  0,  0,  0,201,  0,  0,  0,  0,  1],
    [  1, 81,  1,  1,  0,  0,  0,  1,  0,  1,  1,  1,  1],
    [  1,209,  0,  1,  1,245,  1,  1,  0,  1,  0, 31,  1],
    [  1,  0, 21,  1,  0,126,  0,  1,  0, 81,217, 21,  1],
    [  1, 31, 27,  1,126,  0,126,  1,  0,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,126,  1,  1,202,  1,  0,  0,  1],
    [  1, 88,  0,  0,  0,  0,  0,  1,  0, 81,  0, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "4,9": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": false,
            "data": []
        },
        "5,8": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": false,
            "data": []
        },
        "6,9": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": false,
            "data": []
        },
        "5,10": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": false,
            "data": []
        },
        "5,7": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": false,
            "data": []
        },
        "5,9": [
            {
                "type": "setValue",
                "name": "flag:03",
                "value": "1"
            },
            {
                "type": "playSound",
                "name": "3F.mp3"
            },
            {
                "type": "show",
                "loc": [
                    [
                        5,
                        7
                    ]
                ],
                "time": 500
            },
            "\t[魔王,redKing]欢迎来到魔塔 你是第100位挑战者 你若能打败我所有的手下 我就与你一对一的决斗 现在你必须接受我的安排",
            {
                "type": "show",
                "loc": [
                    [
                        5,
                        8
                    ],
                    [
                        4,
                        9
                    ],
                    [
                        6,
                        9
                    ],
                    [
                        5,
                        10
                    ]
                ],
                "time": 500
            },
            "\t[hero]什么",
            {
                "type": "setCurtain",
                "color": [
                    0,
                    0,
                    0,
                    1
                ],
                "time": 1000,
                "keep": true,
                "async": true
            },
            {
                "type": "playSound",
                "name": "zone.mp3",
                "stop": true
            },
            {
                "type": "sleep",
                "time": 300
            },
            {
                "type": "playSound",
                "name": "zone.mp3"
            },
            {
                "type": "sleep",
                "time": 150
            },
            {
                "type": "playSound",
                "name": "zone.mp3"
            },
            {
                "type": "sleep",
                "time": 300
            },
            {
                "type": "playSound",
                "name": "zone.mp3"
            },
            {
                "type": "sleep",
                "time": 150
            },
            {
                "type": "playSound",
                "name": "zone.mp3"
            },
            {
                "type": "waitAsync"
            },
            {
                "type": "setValue",
                "name": "status:hp",
                "value": "35"
            },
            {
                "type": "setValue",
                "name": "status:atk",
                "value": "18"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "value": "1"
            },
            {
                "type": "setValue",
                "name": "flag:03",
                "value": "1"
            },
            {
                "type": "setValue",
                "name": "flag:nowWeapon",
                "value": "null"
            },
            {
                "type": "setValue",
                "name": "flag:nowShield",
                "value": "null"
            },
            {
                "type": "function",
                "function": "function(){\nlet m = \"greenSlime\";\nlet bi = core.getBlockInfo(m);\nvar getImage = function (img, m) {\n\tconst canvas = document.createElement('canvas');\n\tconst ctx = canvas.getContext('2d');\n\n\tconst partX = 0; // 截取的起始X坐标\n\tconst partY = core.material.icons.enemys[m] * 32; // 截取的起始Y坐标\n\tconst partWidth = 64; // 截取的宽度\n\tconst partHeight = 32; // 截取的高度\n\n\t// 设置 canvas 的大小\n\tcanvas.width = partWidth * 2; // 横向复制后宽度加倍\n\tcanvas.height = partHeight * 4; // 纵向复制 4 次后的高度\n\n\t// 截取图片的一部分并绘制到 canvas 上\n\tfor (let y = 0; y < 4; y++) {\n\t\tfor (let x = 0; x < 2; x++) {\n\t\t\tctx.drawImage(\n\t\t\t\timg,\n\t\t\t\tpartX, partY, partWidth, partHeight, // 从图片中截取的部分\n\t\t\t\tx * partWidth, y * partHeight, partWidth, partHeight // 绘制在 canvas 上的目标位置\n\t\t\t);\n\t\t}\n\t}\n\n\t/*const imgElement = new Image(); \n\timgElement.src = canvas.toDataURL('image/png'); \n\timgElement.setAttribute('_width', canvas.width);\n\timgElement.setAttribute('_height', canvas.height);*/\n\treturn canvas;\n};\nlet img = getImage(bi.image, m);\ncore.status.hero.image = bi.name;\ncore.material.images.hero = img;\ncore.material.icons.hero.width = 32;\ncore.material.icons.hero.height = 32;\n//core.control.updateHeroIcon(bi.name);\ncore.drawHero();\n}"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        5,
                        7
                    ],
                    [
                        5,
                        8
                    ],
                    [
                        4,
                        9
                    ],
                    [
                        6,
                        9
                    ],
                    [
                        5,
                        10
                    ]
                ],
                "time": 0
            },
            {
                "type": "sleep",
                "time": 500
            },
            {
                "type": "changeFloor",
                "floorId": "MT2",
                "loc": [
                    3,
                    8
                ],
                "direction": "down",
                "time": 0
            }
        ],
        "11,4": {
            "trigger": "action",
            "enable": true,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                "\t[老头,man]哈哈！我打赢复活赛啦！",
                "\t[作者,oldMan]你说什么？你敢再说一次！魔塔不需要你这种把我惹怒的老人，来人给我踢了！",
                "\t[老头,man]饶命啊！",
                {
                    "type": "jump",
                    "from": [
                        11,
                        4
                    ],
                    "to": [
                        0,
                        0
                    ],
                    "time": 1000
                },
                {
                    "type": "hide",
                    "remove": true
                }
            ]
        }
    },
    "changeFloor": {
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        10,
        11
    ],
    "downFloor": [
        2,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}