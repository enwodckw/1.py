main.floors.MT1=
{
    "floorId": "MT1",
    "title": "魔塔 第01层",
    "name": "第 1 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,201,202,201,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1, 31,  0,  0, 81,  0,  1, 27, 21,  0,  1,  0,  1],
    [  1,  0,209,  0,  1,  0,  1, 28, 31,  0,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  1,  1,  1, 81,  1,  0,  1],
    [  1, 21,  0,  0,  1,  0, 81,205,217,205,  1,  0,  1],
    [  1,  0,210,  0,  1,  0,  1,  1,  1,  1,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1, 86,  1,  1,  1, 81,  1,  1],
    [  1, 31,  0, 21,  1, 25, 73,127,  1,  0,205,  0,  1],
    [  1, 31,  0, 21,  1, 46,  0, 45,  1,201, 32,201,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [
        {
            "type": "tip",
            "text": "游戏已重启"
        },
        {
            "type": "loadBgm",
            "name": "Ending.mp3"
        },
        {
            "type": "loadBgm",
            "name": "SkeletonA.mp3"
        },
        {
            "type": "loadBgm",
            "name": "Vampire.mp3"
        },
        {
            "type": "loadBgm",
            "name": "GreatMagicMaster.mp3"
        },
        {
            "type": "loadBgm",
            "name": "Knight.mp3"
        },
        {
            "type": "loadBgm",
            "name": "Zeno.mp3"
        },
        {
            "type": "setValue",
            "name": "flag:调试模式",
            "value": "false"
        },
        {
            "type": "setValue",
            "name": "flag:黄钥匙回收价格",
            "value": "100"
        },
        {
            "type": "choices",
            "text": "\t[作者,oldMan]选择模式",
            "choices": [
                {
                    "text": "中心对称",
                    "action": [
                        {
                            "type": "setValue",
                            "name": "flag:中心对称",
                            "value": "true"
                        }
                    ]
                },
                {
                    "text": "xy对称",
                    "action": [
                        {
                            "type": "setValue",
                            "name": "flag:xy对称",
                            "value": "true"
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    9,
                                    11
                                ]
                            ],
                            "floorId": "MT15",
                            "remove": true
                        }
                    ]
                },
                {
                    "text": "中心与xy对称",
                    "action": [
                        {
                            "type": "setValue",
                            "name": "flag:中心对称",
                            "value": "true"
                        },
                        {
                            "type": "setValue",
                            "name": "flag:xy对称",
                            "value": "true"
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    9,
                                    11
                                ]
                            ],
                            "floorId": "MT15",
                            "remove": true
                        }
                    ]
                },
                {
                    "text": "勇士周围四格",
                    "action": [
                        {
                            "type": "setValue",
                            "name": "flag:勇士周围四格",
                            "value": "true"
                        }
                    ]
                },
                {
                    "text": "怪物周围八格",
                    "action": [
                        {
                            "type": "setValue",
                            "name": "flag:怪物周围八格",
                            "value": "true"
                        },
                        {
                            "type": "setBlock",
                            "number": "greenSlime",
                            "loc": [
                                [
                                    2,
                                    1
                                ]
                            ]
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    7,
                                    5
                                ]
                            ],
                            "floorId": "MT3",
                            "remove": true
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    9,
                                    11
                                ]
                            ],
                            "floorId": "MT15",
                            "remove": true
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    1,
                                    9
                                ],
                                [
                                    3,
                                    11
                                ],
                                [
                                    9,
                                    11
                                ],
                                [
                                    11,
                                    9
                                ],
                                [
                                    11,
                                    6
                                ],
                                [
                                    11,
                                    3
                                ],
                                [
                                    9,
                                    1
                                ]
                            ],
                            "floorId": "MT37",
                            "remove": true
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    1,
                                    3
                                ]
                            ],
                            "floorId": "MT14",
                            "remove": true
                        },
                        {
                            "type": "setBlock",
                            "number": "slimeMan",
                            "loc": [
                                [
                                    4,
                                    10
                                ]
                            ],
                            "floorId": "MT31"
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    1,
                                    3
                                ]
                            ],
                            "floorId": "MT38",
                            "remove": true
                        }
                    ]
                }
            ]
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "7,10": [
            "\t[作者,oldMan]战后，若对应位置为墙或门，则打开。若对应位置是空地，则生成一堵墙"
        ]
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {
        "6,9": [
            "修改较多，放在样板简介里面了！就是工具栏那个长得像卷轴一样的东西"
        ]
    },
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        2,
        1
    ],
    "downFloor": [
        6,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}