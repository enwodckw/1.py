var events_c12a15a8_c380_4b28_8144_256cba95f760 = 
{
	"commonEvent": {
		"加点事件": [
			{
				"type": "comment",
				"text": "通过传参，flag:arg1 表示当前应该的加点数值"
			},
			{
				"type": "choices",
				"text": "\t[加点]",
				"choices": [
					{
						"text": "攻击+${2*flag:shopratio*flag:arg1}",
						"action": [
							{
								"type": "setValue",
								"name": "status:atk",
								"operator": "+=",
								"value": "2*flag:shopratio*flag:arg1"
							}
						]
					},
					{
						"text": "防御+${4*flag:shopratio*flag:arg1}",
						"action": [
							{
								"type": "setValue",
								"name": "status:def",
								"operator": "+=",
								"value": "4*flag:shopratio*flag:arg1"
							}
						]
					},
					{
						"text": "生命+${200*flag:shopratio*flag:arg1}",
						"action": [
							{
								"type": "setValue",
								"name": "status:hp",
								"operator": "+=",
								"value": "200*flag:shopratio*flag:arg1"
							}
						]
					}
				]
			},
			{
				"type": "function",
				"function": "function(){\ncore.checkSkill(6)\n}"
			}
		],
		"回收钥匙商店": [
			{
				"type": "while",
				"condition": "true",
				"data": [
					{
						"type": "choices",
						"text": "\t[商人,woman]我可以回收各种钥匙！",
						"choices": [
							{
								"text": "一次出售的数量:${flag:bulk}",
								"action": [
									{
										"type": "input",
										"text": "请输入一次出售的数量"
									},
									{
										"type": "setValue",
										"name": "flag:bulk",
										"value": "flag:input"
									}
								]
							},
							{
								"text": "黄钥匙(100金币)",
								"need": "item:yellowKey>=flag:bulk",
								"action": [
									{
										"type": "setValue",
										"name": "item:yellowKey",
										"operator": "-=",
										"value": "flag:bulk"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "+=",
										"value": "100*flag:bulk"
									}
								]
							},
							{
								"text": "蓝钥匙(200金币)",
								"need": "item:blueKey>=flag:bulk",
								"action": [
									{
										"type": "setValue",
										"name": "item:blueKey",
										"operator": "-=",
										"value": "flag:bulk"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "+=",
										"value": "200*flag:bulk"
									}
								]
							},
							{
								"text": "红钥匙(500金币)",
								"need": "item:redKey>=flag:bulk",
								"action": [
									{
										"type": "setValue",
										"name": "item:redKey",
										"operator": "-=",
										"value": "flag:bulk"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "+=",
										"value": "500*flag:bulk"
									}
								]
							},
							{
								"text": "绿钥匙(800金币)",
								"need": "item:greenKey>=flag:bulk",
								"action": [
									{
										"type": "setValue",
										"name": "item:greenKey",
										"operator": "-=",
										"value": "flag:bulk"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "+=",
										"value": "800*flag:bulk"
									}
								]
							},
							{
								"text": "大黄门钥匙(1000金币)",
								"need": "item:bigKey>=flag:bulk",
								"action": [
									{
										"type": "setValue",
										"name": "item:bigKey",
										"operator": "-=",
										"value": "flag:bulk"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "+=",
										"value": "1000*flag:bulk"
									}
								]
							},
							{
								"text": "下次再说",
								"action": [
									{
										"type": "exit"
									}
								]
							}
						]
					}
				]
			}
		],
		"游戏说明": [
			{
				"type": "choices",
				"choices": [
					{
						"text": "游戏简介",
						"action": [
							"h5版本是按照flash版复刻，其中部分对话使用的魔塔盛宴的版本。",
							"地图复制：数码宝贝51、641\n部分事件复制：小艾\n默认背景音乐：无；可在切换音乐处设置\n游戏音乐、怪物显伤等开关可以在系统设置里打开和关闭",
							"想要获得更详细的介绍，可以在菜单——游戏信息——游戏主页中进入本塔的评论区，查看置顶评论。",
							{
								"type": "insert",
								"name": "游戏说明"
							}
						]
					},
					{
						"text": "游戏结局",
						"action": [
							{
								"type": "if",
								"condition": "flag:addhp",
								"true": [
									"疯狂加血模式下，本塔有且仅有一个专属结局。",
									{
										"type": "insert",
										"name": "游戏说明"
									}
								],
								"false": [
									"本塔共有四个结局。\n在原版魔塔中，使用下楼器和破墙镐（或下楼器和地震卷轴）可以封印魔王，因此，这个版本如保留下楼器和破墙镐（或下楼器和地震卷轴）击败魔王，即可打出True End，否则为Normal End。",
									"不论是Normal End还是True End，都分为穿墙结局和不穿墙结局，如果从未使用对话穿墙，可以打出不穿墙结局。",
									{
										"type": "insert",
										"name": "游戏说明"
									}
								]
							}
						]
					},
					{
						"text": "对话穿墙",
						"action": [
							"在与老人对话后，或购买商人的物品并再次对话后，可以立即清除，或走一步再清除身边的某一堵墙（不必是暗墙）。",
							"这期间不能瞬移、打怪、开门和使用道具，否则穿墙会失败。",
							{
								"type": "insert",
								"name": "游戏说明"
							}
						]
					},
					{
						"text": "切换音乐",
						"action": [
							{
								"type": "choices",
								"choices": [
									{
										"text": "精灵石 3个小萝莉在一起",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "1"
											},
											{
												"type": "playBgm",
												"name": "xiaoluoli.mp3"
											}
										]
									},
									{
										"text": "精灵石 晚上家里和镇子",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "2"
											},
											{
												"type": "playBgm",
												"name": "wan.mp3"
											}
										]
									},
									{
										"text": "精灵石 黄昏的镇子",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "3"
											},
											{
												"type": "playBgm",
												"name": "huang.mp3"
											}
										]
									},
									{
										"text": "仙境传说-守候永恒的爱",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "4"
											},
											{
												"type": "playBgm",
												"name": "xian.mp3"
											}
										]
									},
									{
										"text": "精灵石 精灵石传说",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "5"
											},
											{
												"type": "playBgm",
												"name": "chuanshuo.mp3"
											}
										]
									},
									{
										"text": "精灵石 ed【神曲】",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "6"
											},
											{
												"type": "playBgm",
												"name": "ed.mp3"
											}
										]
									},
									{
										"text": "精灵石 幸福之花",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "7"
											},
											{
												"type": "playBgm",
												"name": "hua.mp3"
											}
										]
									},
									{
										"text": "精灵石 迷宫",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "8"
											},
											{
												"type": "playBgm",
												"name": "migong.mp3"
											}
										]
									},
									{
										"text": "离开",
										"action": []
									}
								]
							},
							{
								"type": "insert",
								"name": "游戏说明"
							}
						]
					},
					{
						"text": "返回游戏",
						"action": []
					}
				]
			}
		],
		"对话": [
			{
				"type": "switch",
				"condition": "flag:arg1",
				"caseList": [
					{
						"case": "2",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'谢谢你救了我，为了感谢你的帮助请收下这些礼物。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话2",
								"value": "1"
							}
						]
					},
					{
						"case": "3",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你已经有怪物手册了'"
							},
							{
								"type": "setValue",
								"name": "flag:对话3",
								"value": "1"
							}
						]
					},
					{
						"case": "4",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你对话后没有神秘的能力'"
							},
							{
								"type": "setValue",
								"name": "flag:对话4",
								"value": "1"
							}
						]
					},
					{
						"case": "6",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'购买物品之后再与商人对话，他会告诉你一些重要的消息。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话6",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'魔塔共有50层，每10层为一个区域。如果不打败此区域的头目就不能到更高的地方。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话602",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "7",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你的攻击比敌人防御高时就能对他造成伤害 你防御比敌人攻击高或一样时就能无伤'"
							},
							{
								"type": "setValue",
								"name": "flag:对话7",
								"value": "1"
							}
						]
					},
					{
						"case": "12",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'本塔有很多暗墙 比如5 9 12 14 16 18层 你都找到了吗'"
							},
							{
								"type": "setValue",
								"name": "flag:对话12",
								"value": "1"
							}
						]
					},
					{
						"case": "15",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'十字架对兽人和吸血鬼是神器 它被藏在这之上的某层中'"
							},
							{
								"type": "setValue",
								"name": "flag:对话15",
								"value": "1"
							}
						]
					},
					{
						"case": "16",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'整个魔塔有2把藏在墙里的红钥匙'"
							},
							{
								"type": "setValue",
								"name": "flag:对话16",
								"value": "1"
							}
						]
					},
					{
						"case": "18",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'在这区域不多次提升攻击力 就不能打败石头人 切记前人教训'"
							},
							{
								"type": "setValue",
								"name": "flag:对话18",
								"value": "1"
							}
						]
					},
					{
						"case": "21",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'欢迎来到最后一区。本区域的宝石和血瓶在大法师的影响下，属性大幅度提高了。祝你好运。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话21",
								"value": "1"
							}
						]
					},
					{
						"case": "23",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'如果你到达这里时还没有幸运金币，那么你的运气是比较差的'"
							},
							{
								"type": "setValue",
								"name": "flag:对话23",
								"value": "1"
							}
						]
					},
					{
						"case": "27",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'这是最后一个祭坛了。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话27",
								"value": "1"
							}
						]
					},
					{
						"case": "30",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'第21-29层被藏在了异空间，你打败49层的魔王后就会解锁，当然你可以使用移动宝物进去。还有，如果你能活着来到这里，那么你的前期是比较成功的'"
							},
							{
								"type": "setValue",
								"name": "flag:对话30",
								"value": "1"
							}
						]
					},
					{
						"case": "31",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'你居然买了我的钥匙 那我就告诉你一个秘密 魔塔里有一堆幸运金币 拥有它们在打败敌人后能获得多倍的金币' "
									},
									{
										"type": "setValue",
										"name": "flag:对话3102",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'双手剑士的攻击力太高了 你最好到能对他一击必杀时再与他战斗, 但是如果他主动攻击你, 你仍然会受到一次伤害'"
									},
									{
										"type": "setValue",
										"name": "flag:对话31",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "33",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'别匆忙, 放慢速度'"
							},
							{
								"type": "setValue",
								"name": "flag:对话33",
								"value": "1"
							}
						]
					},
					{
						"case": "36",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'本层有4条暗道，合理利用它们可以避免和强敌作战。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话36",
								"value": "1"
							}
						]
					},
					{
						"case": "37",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你需要用地震卷轴才能取走这里的所有宝物 当然你也可以不取 51层魔塔最好玩的地方就是可以玩很多mod'"
							},
							{
								"type": "setValue",
								"name": "flag:对话37",
								"value": "1"
							}
						]
					},
					{
						"case": "38",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'永远不存在没有门卫的特殊门。换言之，一定有门卫守卫同楼层的特殊门。所以……'"
							},
							{
								"type": "setValue",
								"name": "flag:对话38",
								"value": "1"
							}
						]
					},
					{
						"case": "39",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'谜题 在3点 拥有传送功能的密宝 就会出现'"
									},
									{
										"type": "setValue",
										"name": "flag:对话39",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'你居然买了我的钥匙 那我就告诉你一个秘密 神圣剑有2147483647种方法可以得到 比如通过摸牌获取'"
									},
									{
										"type": "setValue",
										"name": "flag:对话3902",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "42",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'巫师会用魔法攻击路过的人 在2个魔法警卫间通过会使你的生命减少一半'"
							},
							{
								"type": "setValue",
								"name": "flag:对话42",
								"value": "1"
							}
						]
					},
					{
						"case": "45",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg3 == 3)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'神圣盾能防御魔法攻击 但它被藏在异空间的楼层内'"
									},
									{
										"type": "setValue",
										"name": "flag:对话45",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'44楼被藏在异空间 你只能用移动宝物才能到达'"
									},
									{
										"type": "setValue",
										"name": "flag:对话4502",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "46",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'41层其实是左右对称的 你应该能发现 打怪时如果不和怪物重叠 可以规避一些魔法攻击'"
							},
							{
								"type": "setValue",
								"name": "flag:对话46",
								"value": "1"
							}
						]
					},
					{
						"case": "47",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'如果要打败魔龙你需要 圣剑 圣盾 屠龙匕 或更高等级的装备'"
							},
							{
								"type": "setValue",
								"name": "flag:对话47",
								"value": "1"
							}
						]
					},
					{
						"case": "48",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'像骰子上5一样的形状是一种封印魔法 你最好记住 它在与魔王战斗时可能有用'"
							},
							{
								"type": "setValue",
								"name": "flag:对话48",
								"value": "1"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "if",
				"condition": "flag:arg4",
				"true": [
					"\t[商人,woman]${flag:content}"
				],
				"false": [
					"\t[老人,man]${flag:content}"
				]
			},
			{
				"type": "switch",
				"condition": "flag:arg1",
				"caseList": [
					{
						"case": "2",
						"action": [
							{
								"type": "playSound",
								"name": "item.mp3"
							},
							{
								"type": "addValue",
								"name": "status:money",
								"value": "1000"
							},
							{
								"type": "tip",
								"text": "获得1000金币"
							}
						]
					},
					{
						"case": "3",
						"action": [
							{
								"type": "addValue",
								"name": "item:book",
								"value": "1"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "if",
				"condition": "(flag:arg1==48)",
				"true": [
					"\t[老人,man]什么 别说胡话了 这个房间里有魔法警卫"
				],
				"false": [
					{
						"type": "hide",
						"loc": [
							"core.nextX()",
							"core.nextY()"
						],
						"remove": true,
						"time": 500
					}
				]
			},
			{
				"type": "function",
				"function": "function(){\ncore.checkSkill(5)\n}"
			}
		],
		"商人": [
			{
				"type": "switch",
				"condition": "parseInt(core.status.floorId.substring(2))",
				"caseList": [
					{
						"case": "6",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "50"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把蓝钥匙'"
							}
						]
					},
					{
						"case": "7",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "50"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'五把黄钥匙'"
							}
						]
					},
					{
						"case": "12",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "800"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把红钥匙'"
							}
						]
					},
					{
						"case": "15",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "200"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把蓝钥匙'"
							}
						]
					},
					{
						"case": "31",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "1000"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把蓝钥匙, 四把黄钥匙'"
							}
						]
					},
					{
						"case": "38",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "200"
							},
							{
								"type": "setValue",
								"name": "flag:alt",
								"value": "1"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'大甩卖! 三把黄钥匙只要200金币, 先到先得!'"
							}
						]
					},
					{
						"case": "39",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "2000"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'三把蓝钥匙'"
							}
						]
					},
					{
						"case": "45",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "1000"
							},
							{
								"type": "setValue",
								"name": "flag:alt",
								"value": "1"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'你出1000金币, 我就帮你回复2000点生命值'"
							}
						]
					},
					{
						"case": "47",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "4000"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'地震卷轴'"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:money",
				"operator": "*=",
				"value": "core.shopMult()"
			},
			{
				"type": "choices",
				"text": "\t[商人,woman]${flag:alt ? flag:item : '我有'+flag:item+', 你出'+flag:money+'金币就卖给你'}",
				"choices": [
					{
						"text": "我太需要了",
						"action": [
							{
								"type": "if",
								"condition": "(status:money >= flag:money)",
								"true": [
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money"
									},
									{
										"type": "function",
										"function": "function(){\ncore.checkSkill(8,flags.money)\n}"
									},
									{
										"type": "switch",
										"condition": "parseInt(core.status.floorId.substring(2))",
										"caseList": [
											{
												"case": "6",
												"action": [
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "7",
												"action": [
													{
														"type": "setValue",
														"name": "item:yellowKey",
														"operator": "+=",
														"value": "5"
													}
												]
											},
											{
												"case": "12",
												"action": [
													{
														"type": "setValue",
														"name": "item:redKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "15",
												"action": [
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "31",
												"action": [
													{
														"type": "setValue",
														"name": "item:yellowKey",
														"operator": "+=",
														"value": "4"
													},
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "38",
												"action": [
													{
														"type": "setValue",
														"name": "item:yellowKey",
														"operator": "+=",
														"value": "3"
													}
												]
											},
											{
												"case": "39",
												"action": [
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "3"
													}
												]
											},
											{
												"case": "45",
												"action": [
													{
														"type": "playSound",
														"name": "item.mp3"
													},
													{
														"type": "setValue",
														"name": "status:hp",
														"operator": "+=",
														"value": "2000"
													}
												]
											},
											{
												"case": "47",
												"action": [
													{
														"type": "setValue",
														"name": "item:earthquake",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "default",
												"action": []
											}
										]
									},
									{
										"type": "function",
										"function": "function(){\nvar name = core.status.floorId + '@' + core.nextX() + '@' + core.nextY() + '@' + 'A';\ncore.setFlag(name, 1);\n}"
									}
								],
								"false": [
									"\t[商人,woman]你的金币不够${flag:money}枚，无法交易！"
								]
							}
						]
					},
					{
						"text": "下次再说",
						"action": []
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:alt",
				"value": "0"
			}
		],
		"商店": [
			{
				"type": "if",
				"condition": "(flag:times1===0)",
				"true": [
					{
						"type": "setValue",
						"name": "flag:times1",
						"value": "1"
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:money1",
				"value": "20+10*flag:times1*(flag:times1-1)"
			},
			{
				"type": "setValue",
				"name": "flag:money1",
				"operator": "*=",
				"value": "core.shopMult()"
			},
			{
				"type": "choices",
				"text": "\t[祭坛,blueShop]如果供奉${flag:money1}金币, 便可以增加你的力量, 你想要什么呢…",
				"choices": [
					{
						"text": "生命+${100*flag:times1}",
						"action": [
							{
								"type": "if",
								"condition": "(status:money>=flag:money1)",
								"true": [
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:hp",
										"operator": "+=",
										"value": "100*flag:times1"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money1"
									},
									{
										"type": "setValue",
										"name": "flag:times1",
										"operator": "+=",
										"value": "1"
									},
									{
										"type": "function",
										"function": "function(){\ncore.checkSkill(6);core.checkSkill(8,flags.money1);\n}"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "你的金币不足${flag:money1}枚，无法供奉！"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								]
							}
						]
					},
					{
						"text": "攻击+${2*flag:shopratio}",
						"action": [
							{
								"type": "if",
								"condition": "(status:money>=flag:money1)",
								"true": [
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:atk",
										"operator": "+=",
										"value": "2*flag:shopratio"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money1"
									},
									{
										"type": "setValue",
										"name": "flag:times1",
										"operator": "+=",
										"value": "1"
									},
									{
										"type": "function",
										"function": "function(){\ncore.checkSkill(6);core.checkSkill(8,flags.money1);\n}"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "你的金币不足${flag:money1}枚，无法供奉！"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								]
							}
						]
					},
					{
						"text": "防御+${4*flag:shopratio}",
						"action": [
							{
								"type": "if",
								"condition": "(status:money>=flag:money1)",
								"true": [
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:def",
										"operator": "+=",
										"value": "4*flag:shopratio"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money1"
									},
									{
										"type": "setValue",
										"name": "flag:times1",
										"operator": "+=",
										"value": "1"
									},
									{
										"type": "function",
										"function": "function(){\ncore.checkSkill(6);core.checkSkill(8,flags.money1);\n}"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "你的金币不足${flag:money1}枚，无法供奉！"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								]
							}
						]
					},
					{
						"text": "离开",
						"action": []
					}
				]
			}
		],
		"记事本": [
			{
				"type": "if",
				"condition": "(flag:翻页==0)",
				"true": [
					{
						"type": "setValue",
						"name": "flag:翻页",
						"value": "1"
					}
				]
			},
			{
				"type": "if",
				"condition": "(flag:翻页==1)",
				"true": [
					{
						"type": "while",
						"condition": "true",
						"data": [
							{
								"type": "choices",
								"text": "记事本（只显示对话过的）",
								"choices": [
									{
										"text": "2层老人",
										"condition": "flag:对话2==1",
										"action": [
											"谢谢你救了我，为了感谢你的帮助请收下这些礼物。"
										]
									},
									{
										"text": "3层老人",
										"condition": "flag:对话3==1",
										"action": [
											"我可以给你怪物手册<快捷键x> 它能预测出当前楼层各类怪物对你的伤害"
										]
									},
									{
										"text": "4层老人",
										"condition": "flag:对话4==1",
										"action": [
											"你对话后没有神秘的能力"
										]
									},
									{
										"text": "6层老人",
										"condition": "flag:对话6==1",
										"action": [
											"购买物品之后再与商人对话，他会告诉你一些重要的消息。"
										]
									},
									{
										"text": "6层商人",
										"condition": "flag:对话602==1",
										"action": [
											"魔塔共有50层，每10层为一个区域。如果不打败此区域的头目就不能到更高的地方。"
										]
									},
									{
										"text": "7层商人",
										"condition": "flag:对话7==1",
										"action": [
											"你的攻击比敌人防御高时就能对他造成伤害 你防御比敌人攻击高或一样时就能无伤"
										]
									},
									{
										"text": "12层商人",
										"condition": "flag:对话12==1",
										"action": [
											"本塔有很多暗墙 比如5 9 12 14 16 18层 你都找到了吗"
										]
									},
									{
										"text": "15层商人",
										"condition": "flag:对话15==1",
										"action": [
											"十字架对兽人和吸血鬼是神器 它被藏在这之上的某层中"
										]
									},
									{
										"text": "16层老人",
										"condition": "flag:对话16==1",
										"action": [
											"整座魔塔中有2把藏在墙里的红钥匙"
										]
									},
									{
										"text": "跳到尾页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "3"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "下一页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "2"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "离开",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "exit"
											}
										]
									}
								]
							}
						]
					}
				],
				"false": []
			},
			{
				"type": "if",
				"condition": "(flag:翻页==2)",
				"true": [
					{
						"type": "while",
						"condition": "true",
						"data": [
							{
								"type": "choices",
								"text": "记事本（只显示对话过的）",
								"choices": [
									{
										"text": "18层老人",
										"condition": "flag:对话18==1",
										"action": [
											"在这区域不多次提升攻击力 就不能打败石头人 切记前人教训"
										]
									},
									{
										"text": "21层老人",
										"condition": "flag:对话21==1",
										"action": [
											"大法师住在25楼 他是魔塔的主人 以你现在的状态去攻击他简直就是自杀 你应当在取得更高级别的道具后再去打败他"
										]
									},
									{
										"text": "23层老人",
										"condition": "flag:对话23==1",
										"action": [
											"我没有什么可说的，但有一个确切的消息藏在这个楼层"
										]
									},
									{
										"text": "27层老人",
										"condition": "flag:对话27==1",
										"action": [
											"如果你没有使用过4层的祭坛 在12层供奉不超过4次 那么祝贺你 你的前期是比较成功的"
										]
									},
									{
										"text": "31层商人",
										"condition": "flag:对话3102==1",
										"action": [
											"你居然买了我的钥匙 那我就告诉你一个秘密 魔塔里有个幸运金币 拥有它在打败敌人后能获得2倍的金币"
										]
									},
									{
										"text": "31层老人",
										"condition": "flag:对话31==1",
										"action": [
											"双手剑士的攻击力太高了 你最好到能对他一击必杀时再与他战斗 但是如果他主动攻击你, 你仍然会受到一次伤害"
										]
									},
									{
										"text": "33层老人",
										"condition": "flag:对话33==1",
										"action": [
											"别匆忙, 放慢速度"
										]
									},
									{
										"text": "36层老人",
										"condition": "flag:对话36==1",
										"action": [
											"本层有4条暗道，合理利用可以避免与强敌作战"
										]
									},
									{
										"text": "37层老人",
										"condition": "flag:对话37==1",
										"action": [
											"你需要用地震卷轴才能取走这里的所有宝物 当然你也可以不取 51层魔塔最好玩的地方就是道具有多种用法"
										]
									},
									{
										"text": "上一页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "下一页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "3"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "离开",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "exit"
											}
										]
									}
								]
							}
						]
					}
				],
				"false": []
			},
			{
				"type": "if",
				"condition": "(flag:翻页==3)",
				"true": [
					{
						"type": "while",
						"condition": "true",
						"data": [
							{
								"type": "choices",
								"text": "记事本（只显示对话过的）",
								"choices": [
									{
										"text": "38层商人",
										"condition": "flag:对话38==1",
										"action": [
											"永远不存在没有门卫的特殊门。换言之，一定有门卫守卫同楼层的特殊门。所以……"
										]
									},
									{
										"text": "39层老人",
										"condition": "flag:对话39==1",
										"action": [
											"谜题 在3点 拥有传送功能的密宝 就会出现"
										]
									},
									{
										"text": "39层商人",
										"condition": "flag:对话3902==1",
										"action": [
											"你居然买了我的钥匙 那我就告诉你一个秘密 神圣剑有3种方法可以得到 不同的方法路线也会不同"
										]
									},
									{
										"text": "42层老人",
										"condition": "flag:对话42==1",
										"action": [
											"巫师会用魔法攻击路过的人 在2个魔法警卫间通过会使你的生命减少一半"
										]
									},
									{
										"text": "45层老人",
										"condition": "flag:对话45==1",
										"action": [
											"神圣盾能防御魔法攻击 但它被藏在异空间的楼层内"
										]
									},
									{
										"text": "45层商人",
										"condition": "flag:对话4502==1",
										"action": [
											"44层被藏在异空间 你只能用移动宝物才能到达"
										]
									},
									{
										"text": "46层老人",
										"condition": "flag:对话46==1",
										"action": [
											"41层其实是左右对称的\n还有, 打怪时如果不和怪物重叠 可以规避一些魔法攻击"
										]
									},
									{
										"text": "47层商人",
										"condition": "flag:对话47==1",
										"action": [
											"如果要打败魔龙你需要 圣剑 圣盾 屠龙匕 或更高等级的装备"
										]
									},
									{
										"text": "48层老人",
										"condition": "flag:对话48==1",
										"action": [
											"像骰子上5一样的形状是一种封印魔法 你最好记住 它在与魔王战斗时可能有用 "
										]
									},
									{
										"text": "上一页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "2"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "跳到首页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "离开",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "exit"
											}
										]
									}
								]
							}
						]
					}
				],
				"false": []
			}
		],
		"计分方式": [
			{
				"type": "choices",
				"text": "选择计分方式",
				"choices": [
					{
						"text": "生命",
						"action": [
							{
								"type": "setValue",
								"name": "flag:mode",
								"value": "'生命'"
							}
						]
					},
					{
						"text": "攻击",
						"action": [
							{
								"type": "setValue",
								"name": "status:hp",
								"value": "status:atk"
							},
							{
								"type": "setValue",
								"name": "flag:mode",
								"value": "'攻击'"
							}
						]
					},
					{
						"text": "防御",
						"action": [
							{
								"type": "setValue",
								"name": "status:hp",
								"value": "status:def"
							},
							{
								"type": "setValue",
								"name": "flag:mode",
								"value": "'防御'"
							}
						]
					}
				]
			}
		],
		"设置": [
			{
				"type": "while",
				"condition": "true",
				"data": [
					{
						"type": "choices",
						"text": "\t[选项,null]",
						"choices": [
							{
								"text": "查看或使用技能",
								"action": [
									{
										"type": "while",
										"condition": "true",
										"data": [
											{
												"type": "function",
												"function": "function(){\nvar text = \"\\t[查看或使用技能]你拥有的技能如下：\";\nvar hint = { \"type\": \"choices\", \"text\": text, \"choices\": [] };\nfor (var i = 0; i < flags.skills.length; ++i) {\n\tvar x = flags.skills[i];\n\thint.text = hint.text + `\n${core.getShortDescription(x)}`\n\tif (x != null && x.condition == 9) hint.choices.push({ \"text\": \"发动技能\" + (i + 1), \"action\": [{ \"type\": \"function\", \"function\": \"function(){core.useSkill(\" + i + \")}\" }] });\n}\nhint.choices.push({ \"text\": \"返回\", \"action\": [{ \"type\": \"break\", \"n\": \"1\" }] });\nhint.choices.push({\n\t\"text\": \"使用技能名缩写:${(flag:useShort)?'是':'否'}\",\n\t\"action\": [\n\t\t{ \"type\": \"setValue\", \"name\": \"flag:useShort\", \"value\": \"(!flag:useShort)\" },\n\t]\n})\ncore.insertAction(hint);\n}"
											}
										]
									}
								]
							},
							{
								"text": "查看护盾等其他属性",
								"action": [
									"你的护盾为${status:mdef}\n你拥有的buff有：${[\"魔攻\",\"连击\",\"无视技能\",\"用一摸一\"].filter(x=>core.hasFlag(x)).join('、')}\n你最多拥有${flag:maxCount}个技能，每个技能最多使用${flag:maxTime}次\n你濒死了${flag:death}次\n你${flag:awaken?\"已经\":\"尚未\"}使用过觉醒技\n\\d${core.getFlag(\"inverted\")?\"你处于翻面状态!\":\"\"}\\d"
								]
							},
							{
								"text": "查看游戏说明",
								"action": [
									{
										"type": "while",
										"condition": "true",
										"data": [
											{
												"type": "choices",
												"text": "\t[游戏说明,null]",
												"choices": [
													{
														"text": "查看改版介绍",
														"action": [
															{
																"type": "insert",
																"loc": [
																	10,
																	2
																],
																"floorId": "MToutside"
															}
														]
													},
													{
														"text": "查看名词解释",
														"action": [
															{
																"type": "insert",
																"loc": [
																	10,
																	3
																],
																"floorId": "MToutside"
															}
														]
													},
													{
														"text": "查看技能触发时机",
														"action": [
															{
																"type": "insert",
																"loc": [
																	10,
																	4
																],
																"floorId": "MToutside"
															}
														]
													},
													{
														"text": "查看技能效果",
														"action": [
															{
																"type": "insert",
																"loc": [
																	10,
																	5
																],
																"floorId": "MToutside"
															}
														]
													},
													{
														"text": "查看物品爆率",
														"action": [
															{
																"type": "insert",
																"loc": [
																	10,
																	6
																],
																"floorId": "MToutside"
															}
														]
													},
													{
														"text": "返回",
														"action": [
															{
																"type": "break",
																"n": 1
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"text": "常规设置",
								"action": [
									{
										"type": "while",
										"condition": "true",
										"data": [
											{
												"type": "choices",
												"text": "\t[常规设置,null]",
												"choices": [
													{
														"text": "宝石血瓶数据：${(flag:itemDetail)?'开':'关'}",
														"action": [
															{
																"type": "setValue",
																"name": "flag:itemDetail",
																"value": "(!flag:itemDetail)"
															}
														]
													},
													{
														"text": "抽卡结果提示：${(flag:showResult)?'开':'关'}",
														"action": [
															{
																"type": "setValue",
																"name": "flag:showResult",
																"value": "(!flag:showResult)"
															}
														]
													},
													{
														"text": "跳过部分动画：${(flag:skipAnimate)?'是':'否'}",
														"action": [
															{
																"type": "setValue",
																"name": "flag:skipAnimate",
																"value": "(!flag:skipAnimate)"
															}
														]
													},
													{
														"text": "批量出售/弃牌数量:${flag:bulk}",
														"action": [
															{
																"type": "input",
																"text": "请输入一次出售/弃牌的数量"
															},
															{
																"type": "setValue",
																"name": "flag:bulk",
																"value": "flag:input"
															}
														]
													},
													{
														"text": "返回",
														"action": [
															{
																"type": "break",
																"n": 1
															}
														]
													},
													{
														"text": "使用技能名缩写:${(flag:useShort)?'是':'否'}",
														"action": [
															{
																"type": "setValue",
																"name": "flag:useShort",
																"value": "(!flag:useShort)"
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"text": "返回",
								"action": [
									{
										"type": "break",
										"n": 1
									}
								]
							}
						]
					}
				]
			}
		],
		"弃牌": [
			{
				"type": "setValue",
				"name": "flag:__discard__",
				"value": "0"
			},
			{
				"type": "setValue",
				"name": "flag:bulk",
				"value": "1"
			},
			{
				"type": "setValue",
				"name": "flag:quit1",
				"value": "true"
			},
			{
				"type": "while",
				"condition": "flag:quit1",
				"data": [
					{
						"type": "choices",
						"text": "\t[弃牌,null]你目前弃置了${flag:__discard__}张牌",
						"choices": [
							{
								"text": "一次弃置的数量:${flag:bulk}",
								"action": [
									{
										"type": "input",
										"text": "请输入一次弃置的数量"
									},
									{
										"type": "setValue",
										"name": "flag:bulk",
										"value": "flag:input"
									}
								]
							},
							{
								"text": "弃置血瓶",
								"icon": "bluePotion",
								"need": "status:hp>200*core.status.thisMap.ratio*flag:bulk",
								"action": [
									{
										"type": "setValue",
										"name": "status:hp",
										"operator": "-=",
										"value": "200*core.status.thisMap.ratio*flag:bulk"
									},
									{
										"type": "setValue",
										"name": "flag:__discard__",
										"operator": "+=",
										"value": "flag:bulk"
									}
								]
							},
							{
								"text": "弃置宝石",
								"icon": "yellowGem",
								"action": [
									{
										"type": "while",
										"condition": "true",
										"data": [
											{
												"type": "choices",
												"choices": [
													{
														"text": "一次弃置的数量:${flag:bulk}",
														"action": [
															{
																"type": "input",
																"text": "请输入一次弃置的数量"
															},
															{
																"type": "setValue",
																"name": "flag:bulk",
																"value": "flag:input"
															}
														]
													},
													{
														"text": "红宝石",
														"icon": "redGem",
														"need": "status:atk>=core.status.thisMap.ratio*flag:bulk",
														"action": [
															{
																"type": "setValue",
																"name": "status:atk",
																"operator": "-=",
																"value": "core.status.thisMap.ratio*flag:bulk"
															},
															{
																"type": "setValue",
																"name": "flag:__discard__",
																"operator": "+=",
																"value": "flag:bulk"
															}
														]
													},
													{
														"text": "蓝宝石",
														"icon": "blueGem",
														"need": "status:def>=core.status.thisMap.ratio*flag:bulk",
														"action": [
															{
																"type": "setValue",
																"name": "status:def",
																"operator": "-=",
																"value": "core.status.thisMap.ratio*flag:bulk"
															},
															{
																"type": "setValue",
																"name": "flag:__discard__",
																"operator": "+=",
																"value": "flag:bulk"
															}
														]
													},
													{
														"text": "绿宝石",
														"icon": "greenGem",
														"need": "status:mdef>=3*core.status.thisMap.ratio*flag:bulk",
														"action": [
															{
																"type": "setValue",
																"name": "status:mdef",
																"operator": "-=",
																"value": "3*core.status.thisMap.ratio*flag:bulk"
															},
															{
																"type": "setValue",
																"name": "flag:__discard__",
																"operator": "+=",
																"value": "flag:bulk"
															}
														]
													},
													{
														"text": "返回",
														"action": [
															{
																"type": "break",
																"n": 1
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"text": "弃置钥匙",
								"icon": "steelKey",
								"action": [
									{
										"type": "while",
										"condition": "true",
										"data": [
											{
												"type": "choices",
												"choices": [
													{
														"text": "一次弃置的数量:${flag:bulk}",
														"action": [
															{
																"type": "input",
																"text": "请输入一次弃置的数量"
															},
															{
																"type": "setValue",
																"name": "flag:bulk",
																"value": "flag:input"
															}
														]
													},
													{
														"text": "黄钥匙",
														"icon": "yellowKey",
														"need": "item:yellowKey>=flag:bulk",
														"action": [
															{
																"type": "setValue",
																"name": "item:yellowKey",
																"operator": "-=",
																"value": "flag:bulk"
															},
															{
																"type": "setValue",
																"name": "flag:__discard__",
																"operator": "+=",
																"value": "flag:bulk"
															}
														]
													},
													{
														"text": "蓝钥匙",
														"icon": "blueKey",
														"need": "item:blueKey>=flag:bulk",
														"action": [
															{
																"type": "setValue",
																"name": "item:blueKey",
																"operator": "-=",
																"value": "flag:bulk"
															},
															{
																"type": "setValue",
																"name": "flag:__discard__",
																"operator": "+=",
																"value": "flag:bulk"
															}
														]
													},
													{
														"text": "红钥匙",
														"icon": "redKey",
														"need": "item:redKey>=flag:bulk",
														"action": [
															{
																"type": "setValue",
																"name": "item:redKey",
																"operator": "-=",
																"value": "flag:bulk"
															},
															{
																"type": "setValue",
																"name": "flag:__discard__",
																"operator": "+=",
																"value": "flag:bulk"
															}
														]
													},
													{
														"text": "绿钥匙",
														"icon": "greenKey",
														"need": "item:greenKey>=flag:bulk",
														"action": [
															{
																"type": "setValue",
																"name": "item:greenKey",
																"operator": "-=",
																"value": "flag:bulk"
															},
															{
																"type": "setValue",
																"name": "flag:__discard__",
																"operator": "+=",
																"value": "flag:bulk"
															}
														]
													},
													{
														"text": "返回",
														"action": [
															{
																"type": "break",
																"n": 1
															}
														]
													}
												]
											}
										]
									}
								]
							},
							{
								"text": "结束弃牌",
								"action": [
									{
										"type": "setValue",
										"name": "flag:quit1",
										"value": "false"
									}
								]
							}
						]
					}
				]
			}
		],
		"濒死": [
			{
				"type": "setValue",
				"name": "flag:death",
				"operator": "+=",
				"value": "1"
			},
			{
				"type": "setValue",
				"name": "flag:dying",
				"value": "true"
			},
			{
				"type": "function",
				"function": "function(){\ncore.checkSkill(7);\n}"
			},
			{
				"type": "if",
				"condition": "(!flag:awaken)",
				"true": [
					{
						"type": "animate",
						"name": "awaken",
						"loc": "hero"
					},
					"首次死亡，发动觉醒技！\n技能存储上限提升，并解锁更多发动时机和效果！",
					{
						"type": "setValue",
						"name": "flag:awaken",
						"value": "true"
					},
					{
						"type": "setValue",
						"name": "flag:maxCount",
						"operator": "+=",
						"value": "1"
					}
				]
			},
			{
				"type": "while",
				"condition": "(status:hp<=0)",
				"data": [
					{
						"type": "choices",
						"text": "\t[濒死状态,null]是否使用圣水救命？\n当前圣水效果：${Math.round(5*(status:atk+status:def))}",
						"choices": [
							{
								"text": "是",
								"need": "item:superPotion>0",
								"action": [
									{
										"type": "useItem",
										"id": "superPotion"
									}
								]
							},
							{
								"text": "否",
								"action": [
									{
										"type": "lose",
										"reason": ""
									}
								]
							}
						]
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:dying",
				"value": "false"
			}
		],
		"抽取技能": [
			{
				"type": "function",
				"function": "function(){\nvar skillCondition1 = core.plugin.skillCondition.filter(function (x) { return core.getFlag(\"awaken\") || x.length < 4 });\nvar a = []\nfor (var i = 0; i < 3; ++i) {\n\tvar j = core.rand(skillCondition1.length);\n\ta.push(skillCondition1[j][0]);\n\tskillCondition1.splice(j, 1);\n}\ncore.setFlag(\"conditions\", a);\n}"
			},
			{
				"type": "choices",
				"text": "\t[抽取技能]请选择一个技能发动时机",
				"choices": [
					{
						"text": "${core.coloredName(flags.conditions[0])}",
						"action": [
							{
								"type": "setValue",
								"name": "flag:condition",
								"value": "flags.conditions[0]"
							}
						]
					},
					{
						"text": "${core.coloredName(flags.conditions[1])}",
						"action": [
							{
								"type": "setValue",
								"name": "flag:condition",
								"value": "flags.conditions[1]"
							}
						]
					},
					{
						"text": "${core.coloredName(flags.conditions[2])}",
						"action": [
							{
								"type": "setValue",
								"name": "flag:condition",
								"value": "flags.conditions[2]"
							}
						]
					}
				]
			},
			{
				"type": "function",
				"function": "function(){\nvar skillList1 = core.plugin.skillList.filter(function (x) { return core.satisfyCondition(x) });\nvar a = []\nfor (var i = 0; i < 3; ++i) {\n\tvar j = core.rand(skillList1.length);\n\ta.push(skillList1[j].id);\n\tskillList1.splice(j, 1);\n}\ncore.setFlag(\"effects\", a);\n}"
			},
			{
				"type": "choices",
				"text": "\t[抽取技能]请选择一个技能效果",
				"choices": [
					{
						"text": "${core.coloredName1(flags.effects[0])}",
						"action": [
							{
								"type": "setValue",
								"name": "flag:effect",
								"value": "flags.effects[0]"
							}
						]
					},
					{
						"text": "${core.coloredName1(flags.effects[1])}",
						"action": [
							{
								"type": "setValue",
								"name": "flag:effect",
								"value": "flags.effects[1]"
							}
						]
					},
					{
						"text": "${core.coloredName1(flags.effects[2])}",
						"action": [
							{
								"type": "setValue",
								"name": "flag:effect",
								"value": "flags.effects[2]"
							}
						]
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:toInsert",
				"value": "flags.skills.findIndex(x=>x==null)"
			},
			{
				"type": "setValue",
				"name": "flag:thisSkill",
				"value": "core.generateSkill(flags.condition,flags.effect)"
			},
			{
				"type": "function",
				"function": "function(){\nif (flags.toInsert == -1 && flags.skills.length < flags.maxCount) core.setFlag(\"toInsert\", flags.skills.length);\n}"
			},
			{
				"type": "if",
				"condition": "(flag:toInsert==-1)",
				"true": [
					{
						"type": "function",
						"function": "function(){\nvar text = `\\t[抽取技能,null]你选择的技能为：\n${core.getSkillDescription(flags.thisSkill)}\n当前技能位已满，是否选择一个进行替换?`\nvar hint = { \"type\": \"choices\", \"text\": text, \"choices\": [] };\nfor (var i = 0; i < flags.skills.length; ++i) {\n\tvar x = flags.skills[i];\n\thint.choices.push({ \"text\": core.getShortDescription(x), \"action\": [{ \"type\": \"function\", \"function\": \"function(){flags.skills[\" + i + \"]=flags.thisSkill}\" }] });\n}\nhint.choices.push({ \"text\": \"取消\", \"action\": [] });\ncore.insertAction(hint);\n}"
					}
				],
				"false": [
					{
						"type": "function",
						"function": "function(){\nflags.skills[flags.toInsert]=flags.thisSkill;\n}"
					},
					"\t[抽取技能,null]已获得新技能：\n${core.getSkillDescription(flags.thisSkill)}"
				]
			}
		],
		"自选技能": [
			{
				"type": "setValue",
				"name": "flag:page",
				"value": "0"
			},
			{
				"type": "setValue",
				"name": "flag:pageMax",
				"value": "Math.ceil(core.plugin.skillCondition.length/5)-1"
			},
			{
				"type": "while",
				"condition": "true",
				"data": [
					{
						"type": "choices",
						"text": "\t[自选技能]请选择一个技能发动时机",
						"choices": [
							{
								"text": "${core.coloredName(flag:page*5+0)}",
								"action": [
									{
										"type": "setValue",
										"name": "flag:condition",
										"value": "flag:page*5+0"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "${core.coloredName(flag:page*5+1)}",
								"condition": "flag:page*5+1<core.plugin.skillCondition.length",
								"action": [
									{
										"type": "setValue",
										"name": "flag:condition",
										"value": "flag:page*5+1"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "${core.coloredName(flag:page*5+2)}",
								"condition": "flag:page*5+2<core.plugin.skillCondition.length",
								"action": [
									{
										"type": "setValue",
										"name": "flag:condition",
										"value": "flag:page*5+2"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "${core.coloredName(flag:page*5+3)}",
								"condition": "flag:page*5+3<core.plugin.skillCondition.length",
								"action": [
									{
										"type": "setValue",
										"name": "flag:condition",
										"value": "flag:page*5+3"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "${core.coloredName(flag:page*5+4)}",
								"condition": "flag:page*5+4<core.plugin.skillCondition.length",
								"action": [
									{
										"type": "setValue",
										"name": "flag:condition",
										"value": "flag:page*5+4"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "上一页",
								"need": "flag:page>0",
								"action": [
									{
										"type": "setValue",
										"name": "flag:page",
										"operator": "-=",
										"value": "1"
									}
								]
							},
							{
								"text": "下一页",
								"need": "flag:page<flag:pageMax",
								"action": [
									{
										"type": "setValue",
										"name": "flag:page",
										"operator": "+=",
										"value": "1"
									}
								]
							}
						]
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:page",
				"value": "0"
			},
			{
				"type": "setValue",
				"name": "flag:pageMax",
				"value": "Math.ceil(core.plugin.skillList.length/5)-1"
			},
			{
				"type": "while",
				"condition": "true",
				"data": [
					{
						"type": "choices",
						"text": "\t[自选技能]请选择一个技能效果",
						"choices": [
							{
								"text": "${core.coloredName1(flag:page*5+0)}",
								"need": "core.satisfyCondition(flag:page*5+0)",
								"action": [
									{
										"type": "setValue",
										"name": "flag:effect",
										"value": "flag:page*5+0"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "${core.coloredName1(flag:page*5+1)}",
								"need": "core.satisfyCondition(flag:page*5+1)",
								"condition": "flag:page*5+1<core.plugin.skillList.length",
								"action": [
									{
										"type": "setValue",
										"name": "flag:effect",
										"value": "flag:page*5+1"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "${core.coloredName1(flag:page*5+2)}",
								"need": "core.satisfyCondition(flag:page*5+2)",
								"condition": "flag:page*5+2<core.plugin.skillList.length",
								"action": [
									{
										"type": "setValue",
										"name": "flag:effect",
										"value": "flag:page*5+2"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "${core.coloredName1(flag:page*5+3)}",
								"need": "core.satisfyCondition(flag:page*5+3)",
								"condition": "flag:page*5+3<core.plugin.skillList.length",
								"action": [
									{
										"type": "setValue",
										"name": "flag:effect",
										"value": "flag:page*5+3"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "${core.coloredName1(flag:page*5+4)}",
								"need": "core.satisfyCondition(flag:page*5+4)",
								"condition": "flag:page*5+4<core.plugin.skillList.length",
								"action": [
									{
										"type": "setValue",
										"name": "flag:effect",
										"value": "flag:page*5+4"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							},
							{
								"text": "上一页",
								"need": "flag:page>0",
								"action": [
									{
										"type": "setValue",
										"name": "flag:page",
										"operator": "-=",
										"value": "1"
									}
								]
							},
							{
								"text": "下一页",
								"need": "flag:page<flag:pageMax",
								"action": [
									{
										"type": "setValue",
										"name": "flag:page",
										"operator": "+=",
										"value": "1"
									}
								]
							}
						]
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:toInsert",
				"value": "flags.skills.findIndex(x=>x==null)"
			},
			{
				"type": "setValue",
				"name": "flag:thisSkill",
				"value": "core.generateSkill(flags.condition,flags.effect)"
			},
			{
				"type": "function",
				"function": "function(){\nif (flags.toInsert == -1 && flags.skills.length < flags.maxCount) core.setFlag(\"toInsert\", flags.skills.length);\n}"
			},
			{
				"type": "if",
				"condition": "(flags.toInsert==-1)",
				"true": [
					{
						"type": "function",
						"function": "function(){\nvar text = `\\t[自选技能,null]你选择的技能为：\n${core.getSkillDescription(flags.thisSkill)}\n当前技能位已满，是否选择一个进行替换?`\nvar hint = { \"type\": \"choices\", \"text\": text, \"choices\": [] };\nfor (var i = 0; i < flags.skills.length; ++i) {\n\tvar x = flags.skills[i];\n\thint.choices.push({ \"text\": core.getShortDescription(x), \"action\": [{ \"type\": \"function\", \"function\": \"function(){flags.skills[\" + i + \"]=flags.thisSkill}\" }] });\n}\nhint.choices.push({ \"text\": \"取消\", \"action\": [] });\ncore.insertAction(hint);\n}"
					}
				],
				"false": [
					{
						"type": "function",
						"function": "function(){\nflags.skills[flags.toInsert]=flags.thisSkill;\n}"
					},
					"\t[自选技能,null]已获得新技能：\n${core.getSkillDescription(flags.thisSkill)}"
				]
			}
		],
		"选怪翻面": [
			{
				"type": "while",
				"condition": "(flag:arg1>0)",
				"data": [
					{
						"type": "tip",
						"text": "请选择要翻面的怪物(至多${flag:arg1}个)，点击非怪物位置退出"
					},
					{
						"type": "wait",
						"forceChild": true,
						"data": [
							{
								"case": "condition",
								"condition": "(flag:type==1)",
								"action": []
							}
						]
					},
					{
						"type": "if",
						"condition": "(core.getBlockCls(1+flags.x,1+flags.y)!=='enemys')",
						"true": [
							{
								"type": "tip",
								"text": "取消选择"
							},
							{
								"type": "break",
								"n": 1
							}
						],
						"false": [
							{
								"type": "if",
								"condition": "[\"blackMagician\",\"swordEmperor\"].includes(core.getBlockId(1+flags.x,1+flags.y))",
								"true": [
									{
										"type": "tip",
										"text": "该怪物无法被翻面"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "翻面成功"
									},
									{
										"type": "function",
										"function": "function(){\ncore.checkSkill(11);\n}"
									},
									{
										"type": "setValue",
										"name": "flag:arg1",
										"operator": "-=",
										"value": "1"
									},
									{
										"type": "animate",
										"name": "zone",
										"loc": [
											"1+flags.x",
											"1+flags.y"
										]
									},
									{
										"type": "setEnemyOnPoint",
										"loc": [
											"1+flags.x",
											"1+flags.y"
										],
										"name": "inverted",
										"value": "true"
									},
									{
										"type": "insert",
										"loc": [
											"1+flags.x",
											"1+flags.y"
										],
										"which": "afterBattle"
									},
									{
										"type": "hide",
										"loc": [
											"1+flags.x",
											"1+flags.y"
										]
									}
								]
							}
						]
					}
				]
			}
		]
	}
}