var plugins_bb40132b_638b_4a9f_b028_d3fe47acc8d1 = 
{
    "init": function () {

	console.log("插件编写测试");

	this._afterLoadResources = function () {
		// 本函数将在所有资源加载完毕后，游戏开启前被执行
		// 可以在这个函数里面对资源进行一些操作。
		// 若需要进行切分图片，可以使用 core.splitImage() 函数，或直接在全塔属性-图片切分中操作
		// 
		core.ui.statusBar.init();
	}

	// 可以在任何地方（如afterXXX或自定义脚本事件）调用函数，方法为 core.plugin.xxx();
	// 从V2.6开始，插件中用this.XXX方式定义的函数也会被转发到core中，详见文档-脚本-函数的转发。
},
    "resizeTo11": function () {
	if (main.mode == 'editor') {
		return;
	}

	// 在不修改libs的情况下将页面适配为11x11
	core.__SIZE__ = 11;
	core.__PIXELS__ = core.__SIZE__ * 32;
	core.__HALF_SIZE__ = 5;
	// core.bigmap.width = core.__SIZE__;
	// core.bigmap.height = core.__SIZE__;
	core.actions.SIZE = core.__SIZE__;
	core.actions.HSIZE = core.__HALF_SIZE__;
	core.actions.LAST = core.__SIZE__ - 1;
	core.actions.CHOICES_LEFT = 3;
	core.actions.CHOICES_RIGHT = core.actions.LAST - core.actions.CHOICES_LEFT;
	core.ui.SIZE = core.__SIZE__;
	core.ui.HSIZE = core.__HALF_SIZE__;
	core.ui.LAST = core.__SIZE__ - 1;
	core.ui.PIXEL = core.__PIXELS__;
	core.ui.HPIXEL = core.__PIXELS__ / 2;
},
    "statusBar": function () {
	main.dom.floorMsgGroup.style.display = 'none';
	main.dom.statusBar.style.display = 'none';
	main.dom.toolBar.style.display = 'none';

	const GAMEVIEW_WIDTH = 640;
	const GAMEVIEW_HEIGHT = 422;

	const GAMEVIEW_WIDTH_VERTICAL = 388;
	const GAMEVIEW_HEIGHT_VERTICAL = 630;

	const BAR_WIDTH = 125;
	const BAR_HEIGHT_VERTICAL = 130;
	const BORDER_WIDTH = 18;
	const BORDER_HEIGHT = 24;

	const ITEM_BOX_LEFT = 13;
	const ITEM_BOX_TOP = 214;
	const ITEM_BOX_LEFT_VERTICAL = 219;
	const ITEM_BOX_TOP_VERTICAL = 10;

	const ITEM_ICON_OUTER_SIZE = 33;

	const EQUIP_BLOCK_LEFT = 525;
	const EQUIP_BLOCK_TOP = 40;
	const EQUIP_BLOCK_LEFT_VERTICAL = 108;
	const EQUIP_BLOCK_TOP_VERTICAL = 0;

	const KEY_BLOCK_LEFT = EQUIP_BLOCK_LEFT;
	const KEY_BLOCK_LEFT_VERTICAL = EQUIP_BLOCK_LEFT_VERTICAL;
	const KEY_BLOCK_TOP_VERTICAL = 86;

	const INFO_BLOCK_LEFT = EQUIP_BLOCK_LEFT;
	const INFO_BLOCK_TOP = 220;
	const INFO_BLOCK_LEFT_VERTICAL = 8;
	const INFO_BLOCK_TOP_VERTICAL = 538;

	const TOOL_BOX_LEFT = EQUIP_BLOCK_LEFT;
	const TOOL_BOX_TOP = 318;
	const TOOL_BOX_LEFT_VERTICAL = 278;
	const TOOL_BOX_TOP_VERTICAL = INFO_BLOCK_TOP_VERTICAL;

	const TOOL_ICON_OUTER_SIZE = 34;

	const INFO_BAR_HEIGHT = 22;
	const INFO_BAR_HEIGHT_VERTICAL = 18;
	const INFO_BAR_TOP = GAMEVIEW_HEIGHT - INFO_BAR_HEIGHT;
	const INFO_BAR_TOP_VERTICAL = GAMEVIEW_HEIGHT_VERTICAL - INFO_BAR_HEIGHT_VERTICAL;

	const TEXT_COLOR = "#E1E1E1";

	const FORCE_COUNTABLE_ITEMS = ["cross", "superPotion", "pickaxe", "bomb", "centerFly", "upFly", "downFly", "knife", "bigKey", "earthquake", "coin"];

	const outerBackground = document.createElement('canvas');
	outerBackground.style.position = 'absolute';
	outerBackground.style.zIndex = 5;
	outerBackground.id = 'outerBackground';
	main.dom.outerBackground = outerBackground;
	main.dom.startPanel.insertAdjacentElement('afterend', outerBackground);

	const outerUI = document.createElement('canvas');
	outerUI.style.position = 'absolute';
	outerUI.style.zIndex = 165;
	outerUI.id = 'outerUI';
	main.dom.outerUI = outerUI;
	outerBackground.insertAdjacentElement('afterend', outerUI);
	setTimeout(function () {
		// Should be executed immediately after init()
		main.canvas.outerUI = outerUI.getContext('2d');
	});
	outerUI.onclick = function (e) {
		try {
			e.preventDefault();
			if (!core.isPlaying()) return false;
			const left = core.dom.gameGroup.offsetLeft;
			const top = core.dom.gameGroup.offsetTop;
			const px = parseInt((e.clientX - left) / core.domStyle.scale),
				py = parseInt((e.clientY - top) / core.domStyle.scale);
			core.ui.statusBar.onclick(px, py);
		} catch (ee) {
			main.log(ee);
		}
	}

	const _resize_gameGroup = function (obj) {
		const gameGroup = core.dom.gameGroup;
		gameGroup.style.width = obj.totalWidth + "px";
		gameGroup.style.height = obj.totalHeight + "px";
		gameGroup.style.left = (obj.clientWidth - obj.totalWidth) / 2 + "px";
		gameGroup.style.top = (obj.clientHeight - obj.totalHeight) / 2 + "px";

		core.dom.musicBtn.style.right = (obj.clientWidth - obj.totalWidth) / 2 + "px";
		core.dom.musicBtn.style.bottom = (obj.clientHeight - obj.totalHeight) / 2 - 27 + "px";
		core.dom.enlargeBtn.style.right = (obj.clientWidth - obj.totalWidth) / 2 + 31 + "px";
		core.dom.enlargeBtn.style.bottom = (obj.clientHeight - obj.totalHeight) / 2 - 27 + "px";

		main.dom.startBackground.src = main.styles.startBackground;
	}

	const _resize_canvas = function (obj) {
		main.dom.outerBackground.style.width = obj.totalWidth + 'px';
		main.dom.outerBackground.style.height = obj.totalHeight + 'px';
		main.dom.outerUI.style.width = obj.totalWidth + 'px';
		main.dom.outerUI.style.height = obj.totalHeight + 'px';

		const innerSize = (obj.canvasWidth * core.domStyle.scale) + "px";
		for (let i = 0; i < core.dom.gameCanvas.length; ++i)
			core.dom.gameCanvas[i].style.width = core.dom.gameCanvas[i].style.height = innerSize;
		core.dom.gif.style.width = core.dom.gif.style.height = innerSize;
		core.dom.gif2.style.width = core.dom.gif2.style.height = innerSize;
		core.dom.gameDraw.style.width = core.dom.gameDraw.style.height = innerSize;
		core.dom.gameDraw.style.top = obj.gameDrawBox.top * core.domStyle.scale + "px";
		core.dom.gameDraw.style.left = (obj.gameDrawBox.left) * core.domStyle.scale + "px";

		// resize bigmap
		core.bigmap.canvas.forEach(function (cn) {
			const ratio = core.canvas[cn].canvas.hasAttribute('isHD') ? core.domStyle.ratio : 1;
			core.canvas[cn].canvas.style.width = core.canvas[cn].canvas.width / ratio * core.domStyle.scale + "px";
			core.canvas[cn].canvas.style.height = core.canvas[cn].canvas.height / ratio * core.domStyle.scale + "px";
		});
		// resize dynamic canvas
		for (const name in core.dymCanvas) {
			const ctx = core.dymCanvas[name],
				canvas = ctx.canvas;
			const ratio = canvas.hasAttribute('isHD') ? core.domStyle.ratio : 1;
			canvas.style.width = canvas.width / ratio * core.domStyle.scale + "px";
			canvas.style.height = canvas.height / ratio * core.domStyle.scale + "px";
			canvas.style.left = parseFloat(canvas.getAttribute("_left")) * core.domStyle.scale + "px";
			canvas.style.top = parseFloat(canvas.getAttribute("_top")) * core.domStyle.scale + "px";
		}
		// resize next
		main.dom.next.style.width = main.dom.next.style.height = 5 * core.domStyle.scale + "px";
		main.dom.next.style.borderBottomWidth = main.dom.next.style.borderRightWidth = 4 * core.domStyle.scale + "px";

	}

	core.control.resize = function () {
		if (main.mode == 'editor') return;

		const clientWidth = main.dom.body.clientWidth,
			clientHeight = main.dom.body.clientHeight;
		const canvasWidth = core.__PIXELS__;

		const isVertical = clientHeight > clientWidth;
		core.domStyle.isVertical = isVertical;

		const totalWidth = isVertical ? GAMEVIEW_WIDTH_VERTICAL : GAMEVIEW_WIDTH,
			totalHeight = isVertical ? GAMEVIEW_HEIGHT_VERTICAL : GAMEVIEW_HEIGHT;

		const maxRatio = Math.min(clientWidth / totalWidth, clientHeight / totalHeight);

		core.domStyle.availableScale = [];
		[1, 1.25, 1.5, 1.75, 2].forEach(function (v) {
			if (maxRatio >= v) {
				core.domStyle.availableScale.push(v);
			}
		});

		if (core.domStyle.availableScale.indexOf(core.domStyle.scale) < 0) {
			core.domStyle.scale = Math.min(1, maxRatio);
		} else if (core.getLocalStorage('scale') == null && core.domStyle.availableScale.length >= 2) {
			core.domStyle.scale = core.domStyle.availableScale[core.domStyle.availableScale.length - 2];
			core.setLocalStorage('scale', core.domStyle.scale);
		}

		const totalWidthScaled = totalWidth * core.domStyle.scale,
			totalHeightScaled = totalHeight * core.domStyle.scale;

		const gameDrawBox = isVertical ? { left: BORDER_WIDTH, top: BAR_HEIGHT_VERTICAL + BORDER_HEIGHT } : { left: BAR_WIDTH + BORDER_WIDTH, top: BORDER_HEIGHT };

		const obj = {
			clientWidth: clientWidth,
			clientHeight: clientHeight,
			canvasWidth: canvasWidth,
			totalWidth: totalWidthScaled,
			totalHeight: totalHeightScaled,
			gameDrawBox: gameDrawBox,
			globalAttribute: core.status.globalAttribute || core.initStatus.globalAttribute,
		};

		_resize_gameGroup(obj);
		_resize_canvas(obj);

		if (core.status.automaticRoute == null) core.status.automaticRoute = {};
		core.control.setViewport(32, 32);
		core.updateStatusBar();
	}

	class StatusBar {
		constructor() {
			this.itemMx = [
				["book", "wand", "fly"],
				["cross", "superPotion", "pickaxe"],
				["bomb", "centerFly", "upFly"],
				["downFly", "knife", "snow"],
				["bigKey", "earthquake", "coin"],
			];
		}
		init() {
			this.toolbarAction = [
				[main.core.openKeyBoard, main.core.openQuickShop, function () { core.insertAction([{ type: "insert", name: "游戏说明" }]); }],
				[main.core.save, main.core.load, main.core.openSettings]
			];
			this.replayAction = [
				[core.triggerReplay, core.stopReplay, core.rewindReplay],
				[core.speedDownReplay, core.speedUpReplay, core.saveReplay]
			];
		}
		update() {
			this._update_background();
			this._update_props();
			this._update_items();
			this._update_equips();
			this._update_keys();
			this._update_infoWindow();
			this._update_infoBar();
		}
		_update_background(updatedFloorTitle) {
			const bgctx = main.dom.outerBackground.getContext("2d");
			const uictx = main.dom.outerUI.getContext("2d");
			if (core.domStyle.isVertical) {
				bgctx.canvas.width = GAMEVIEW_WIDTH_VERTICAL;
				bgctx.canvas.height = GAMEVIEW_HEIGHT_VERTICAL;
				uictx.canvas.width = GAMEVIEW_WIDTH_VERTICAL;
				uictx.canvas.height = GAMEVIEW_HEIGHT_VERTICAL;
				const bg = core.material.images.images["statusBackground_vertical.png"];
				bgctx.drawImage(bg, 0, 0, GAMEVIEW_WIDTH_VERTICAL, GAMEVIEW_HEIGHT_VERTICAL);
				core.setTextAlign('outerUI', 'center');
			} else {
				bgctx.canvas.width = GAMEVIEW_WIDTH;
				bgctx.canvas.height = GAMEVIEW_HEIGHT;
				uictx.canvas.width = GAMEVIEW_WIDTH;
				uictx.canvas.height = GAMEVIEW_HEIGHT;
				const bg = core.material.images.images["statusBackground.jpg"];
				bgctx.drawImage(bg, 0, 0, GAMEVIEW_WIDTH, GAMEVIEW_HEIGHT - INFO_BAR_HEIGHT);
				bgctx.fillStyle = "#676767";
				bgctx.fillRect(0, INFO_BAR_TOP, GAMEVIEW_WIDTH, INFO_BAR_HEIGHT);
				core.setTextAlign('outerUI', 'center');
			}
		}
		// 更新属性
		_update_props(updatedFloorTitle) {
			if (!updatedFloorTitle && core.status.floorId) {
				updatedFloorTitle = core.status.maps[core.status.floorId].title;
			}
			const statusList = ['hp', 'atk', 'def', 'money', 'mdef'];
			const drawStatusList = (baseX, baseY) => {
				let curh = baseY;
				core.setTextAlign('outerUI', 'right');
				statusList.forEach((item) => {
					// 四舍五入
					core.status.hero[item] = Math.round(core.status.hero[item]);
					// 大数据格式化
					core.fillText("outerUI", core.formatBigNumber(core.getRealStatus(item)), baseX, curh, TEXT_COLOR);
					curh += 24;
				});
				core.setTextAlign('outerUI', 'center');
			};
			const drawBuff=(x,y)=>{
				core.setTextAlign('outerUI','center');
				core.setFont("outerUI", 'bold 14px Verdana');
				if(core.hasFlag("魔攻"))core.fillText("outerUI","魔攻",x,y,"#bbb0ff");
				if(core.hasFlag("连击"))core.fillText("outerUI","连击",x+32,y,"#ffee77");
				if(core.getFlag("inverted"))core.fillText("outerUI","翻面",x+64,y,"#ffae57");
			}
			if (core.domStyle.isVertical) {
				core.clearMap("outerUI", 10, 0, 105, 120);
				core.setFont("outerUI", 'bold 14px Verdana');
				if (updatedFloorTitle) {
					core.fillText("outerUI", updatedFloorTitle, 54, 22, TEXT_COLOR);
				}
				core.setFont("outerUI", 'bold 14px Verdana');
				core.fillText("outerUI",core.endName(),347,124,core.difficultyColor());
				drawBuff(233,124);
				drawStatusList(96, 46);
			} else {
				core.clearMap("outerUI", 10, 10, 105, 150);
				core.setFont("outerUI", 'bold 16px Verdana');
				if (updatedFloorTitle) {
					core.fillText("outerUI", updatedFloorTitle, 62, 61, TEXT_COLOR);
				}
				core.fillText("outerUI",core.endName(),62,31,core.difficultyColor());
				drawBuff(544,32);
				drawStatusList(110, 93);
			}
		}
		_update_items() {
			const drawItemMx = (drawFn) => {
				for (let i = 0; i < this.itemMx.length; i++) {
					for (let j = 0; j < this.itemMx[i].length; j++) {
						var item = this.itemMx[i][j];
						drawFn(i, j, item);
					}
				}
			};
			const drawItem = (item, posx, posy) => {
				const icon = core.material.icons.items[item],
					image = core.material.images.items;
				core.drawImage('outerUI', image, 0, 32 * icon, 32, 32, posx, posy, 32, 32);
				const cnt = core.itemCount(item);
				if ((core.items.items[item].cls === "tools" && cnt > 1) || FORCE_COUNTABLE_ITEMS.includes(item)) {
					core.fillText('outerUI', cnt, posx + 25, posy + 28, '#FFFFFF', "bold 12px Verdana");
				}
				// if (this.selectId == item)
				//     core.strokeRect('outerUI', posx + 17, posy - 4, 40, 40, '#FFD700');
			}
			if (core.domStyle.isVertical) {
				core.clearMap("outerUI", ITEM_BOX_LEFT_VERTICAL, ITEM_BOX_TOP_VERTICAL, 185, 100);
				drawItemMx((i, j, item) => {
					if (core.hasItem(item)) {
						const posx = ITEM_BOX_LEFT_VERTICAL + i * 33,
							posy = ITEM_BOX_TOP_VERTICAL + j * 32;
						drawItem(item, posx, posy);
					}
				});
			} else {
				core.clearMap("outerUI", ITEM_BOX_LEFT, ITEM_BOX_TOP, 105, 185);
				drawItemMx((i, j, item) => {
					if (core.hasItem(item)) {
						const posx = ITEM_BOX_LEFT + j * 33,
							posy = ITEM_BOX_TOP + i * 32;
						drawItem(item, posx, posy);
					}
				});
			}
		}
		_update_equips() {
			core.setFont("outerUI", 'bold 16px Verdana');
			const drawEquip = (baseX, baseY, id, color, back) => {
				if (!id) core.fillText("outerUI", back, baseX + 50, baseY + 22, color);
				else {
					core.fillText("outerUI", core.material.items[id].name, baseX + 32, baseY + 22, color);
					var icon = core.material.icons.items[id];
					core.drawImage('outerUI', core.material.images.items, 0, 32 * icon, 32, 32, baseX + 64, baseY, 32, 32);
				}
			};
			if (core.domStyle.isVertical) {
				core.clearMap("outerUI", EQUIP_BLOCK_LEFT_VERTICAL, EQUIP_BLOCK_TOP_VERTICAL, 105, 95);
				drawEquip(EQUIP_BLOCK_LEFT_VERTICAL, EQUIP_BLOCK_TOP_VERTICAL + 9, core.getFlag("nowWeapon"), "#FFCFAE", "无武器");
				drawEquip(EQUIP_BLOCK_LEFT_VERTICAL, EQUIP_BLOCK_TOP_VERTICAL + 49, core.getFlag("nowShield"), core.hasFlag("shield5")?"#74FDB4":"#D1CEFF", "无防具");
			} else {
				core.clearMap("outerUI", EQUIP_BLOCK_LEFT, EQUIP_BLOCK_TOP, 105, 95);
				drawEquip(EQUIP_BLOCK_LEFT, EQUIP_BLOCK_TOP + 8, core.getFlag("nowWeapon"), "#FFCFAE", "无武器");
				drawEquip(EQUIP_BLOCK_LEFT, EQUIP_BLOCK_TOP + 56, core.getFlag("nowShield"), core.hasFlag("shield5")?"#74FDB4":"#D1CEFF", "无防具");
			}
		}
		_update_keys() {
			const drawKeyList = (baseX, baseY, lines, rows) => {
				const todraw = [],
					keyList = ['yellowKey', 'blueKey', 'redKey', 'greenKey'];
				let total = 0;
				keyList.forEach(function (key, i) {
					todraw[i] = core.itemCount(key);
					total += todraw[i];
				});
				if (total > lines * rows) {
					let dn = 3;
					for (let i = 0; i <= dn; i++) {
						let deltaX = i * 26,
							deltaY = parseInt((lines - 1) / 2 * 14);
						this.drawKey(keyList[i], baseX + deltaX - 4, baseY + deltaY);
						core.setFont("outerUI", 'bold 12px Verdana');
						core.setTextAlign("outerUI", "left");
						core.fillText("outerUI", todraw[i], baseX + deltaX + 6, baseY + deltaY + 20, TEXT_COLOR);
					}
				} else {
					let dn = 3,
						dc = 0;
					while (dn >= 0 && dc < lines * rows) {
						if (todraw[dn]) {
							this.drawKey(keyList[dn], baseX + (dc % rows) * 14, baseY + parseInt(dc / rows) * 17);
							todraw[dn]--, dc++;
						} else dn--;
					}
				}
			};
			if (core.domStyle.isVertical) {
				core.clearMap("outerUI", KEY_BLOCK_LEFT_VERTICAL, KEY_BLOCK_TOP_VERTICAL, 105, 75);
				drawKeyList(KEY_BLOCK_LEFT_VERTICAL + 3, KEY_BLOCK_TOP_VERTICAL + 2, 2, 7);
			} else {
				core.clearMap("outerUI", KEY_BLOCK_LEFT, 140, 105, 75);
				drawKeyList(KEY_BLOCK_LEFT + 3, 142, 3, 7);
			}
		}
		drawKey(key, x, y) {
			let sx = 3,
				sy = 0;
			if (key == "blueKey") sx += 16;
			else if (key == "yellowKey") sy += 16;
			else if (key == "greenKey") { sx += 16;
				sy += 16; }
			core.drawImage("outerUI", core.statusBar.icons.keys, sx, sy, 10, 16, x, y, 10, 16);
		}
		_update_infoWindow() {
			const itemId = this.selectedItem;
			if (core.domStyle.isVertical) {
				core.clearMap("outerUI", INFO_BLOCK_LEFT_VERTICAL, INFO_BLOCK_TOP_VERTICAL, 260, 64);
				if (this.selectedItem) {
					const icon = core.material.icons.items[itemId];
					core.fillText("outerUI", core.material.items[itemId].name, INFO_BLOCK_LEFT_VERTICAL + 32, INFO_BLOCK_TOP_VERTICAL + 35, "#D1CEFF");
					core.drawImage('outerUI', core.material.images.items, 0, 32 * icon, 32, 32, INFO_BLOCK_LEFT_VERTICAL + 64, INFO_BLOCK_TOP_VERTICAL + 15, 32, 32);
					core.ui.drawTextContent("outerUI", core.material.items[itemId].text, {
						left: INFO_BLOCK_LEFT_VERTICAL + 100,
						top: INFO_BLOCK_TOP_VERTICAL + 3,
						maxWidth: 160,
						color: "#D1CEFF"
					});
				}
			} else {
				core.clearMap("outerUI", INFO_BLOCK_LEFT, INFO_BLOCK_TOP, 105, 100);
				if (this.selectedItem) {
					const icon = core.material.icons.items[itemId];
					core.fillText("outerUI", core.material.items[itemId].name, INFO_BLOCK_LEFT + 32, INFO_BLOCK_TOP + 25, "#D1CEFF");
					core.drawImage('outerUI', core.material.images.items, 0, 32 * icon, 32, 32, INFO_BLOCK_LEFT + 64, INFO_BLOCK_TOP + 4, 32, 32);
					core.ui.drawTextContent("outerUI", core.material.items[itemId].text, {
						left: INFO_BLOCK_LEFT + 1,
						top: INFO_BLOCK_TOP + 36,
						maxWidth: 105,
						color: "#D1CEFF"
					});
				}
			}
		}
		showItemInfo(itemId) {
			this.selectedItem = itemId;
			this._update_infoWindow();
		}
		clearItemInfo() {
			this.selectedItem = null;
			this._update_infoWindow();
		}
		_update_toolBox() {
			const tools = core.isReplaying() ? [
				[core.status.replay.pausing ? "play" : "pause", "stop", "rewind"],
				["speedDown", "speedUp", "save"],
			] : [
				["keyboard", "shop", "help"],
				["save", "load", "settings"],
			];
			if (core.domStyle.isVertical) {
				core.clearMap("outerUI", TOOL_BOX_LEFT_VERTICAL, TOOL_BOX_TOP_VERTICAL, 115, 80);
				for (let i = 0; i < tools.length; i++) {
					for (let j = 0; j < tools[i].length; j++) {
						core.drawIcon("outerUI", tools[i][j], TOOL_BOX_LEFT_VERTICAL + j * 34, TOOL_BOX_TOP_VERTICAL + i * 34, 32, 32);
					}
				}
			} else {
				core.clearMap("outerUI", TOOL_BOX_LEFT, TOOL_BOX_TOP, 115, 80);
				for (let i = 0; i < tools.length; i++) {
					for (let j = 0; j < tools[i].length; j++) {
						core.drawIcon("outerUI", tools[i][j], TOOL_BOX_LEFT + j * 34, TOOL_BOX_TOP + i * 34, 32, 32);
					}
				}
			}
		}
		onclick(x, y) {
			const makeBox = ([x, y], [w, h]) => {
				return [
					[x, y],
					[x + w, y + h]
				];
			}
			const gridify = ([x, y], [gw, gh]) => {
				return [parseInt(x / gw), parseInt(y / gh)];
			}
			const useItem = (itemId) => {
				if (!core.hasItem(itemId)) return;
				if (core.material.items[itemId].cls == "constants") {
					switch (itemId) {
					case "book":
						core.openBook(true);
						break;
					case "fly":
						core.useFly(true);
						break;
					case "wand":
						core.useItem("wand");
						break;
					case "snow":
						core.useItem("snow");
						break;
					default:
						this.showItemInfo(itemId);
					}
				} else if (itemId != this.selectedItem) {
					this.showItemInfo(itemId);
				} else {
					switch (itemId) {
					case "centerFly":
						core.ui._drawCenterFly();
						break;
					default:
						core.useItem(itemId);
					}
				}
			}
			const inRect = ([x, y], [
				[sx, sy],
				[dx, dy]
			]) => {
				return sx <= x && x <= dx && sy <= y && y <= dy;
			};
			const relativeTo = ([x, y], [ax, ay]) => {
				return [x - ax, y - ay];
			}
			const pos = [x, y];
			if (core.domStyle.isVertical) {
				const itemBox = makeBox([ITEM_BOX_LEFT_VERTICAL, ITEM_BOX_TOP_VERTICAL], [32 * 5, 33 * 3]);
				if (inRect(pos, itemBox)) {
					if (core.isReplaying() || core.status.lockControl || core.isMoving()) return;
					const [gx, gy] = gridify(relativeTo(pos, itemBox[0]), [32, 33]);
					const itemId = this.itemMx[gx][gy];
					useItem(itemId);
					return;
				}
				const toolBox = makeBox([TOOL_BOX_LEFT_VERTICAL, TOOL_BOX_TOP_VERTICAL], [34 * 3, 34 * 2]);
				if (inRect(pos, toolBox)) {
					const [row, col] = gridify(relativeTo(pos, toolBox[0]), [34, 34]);
					if (core.isReplaying()) {
						this.replayAction[col][row].call(core);
					} else if (core.isPlaying()) {
						this.toolbarAction[col][row].call(core, true);
					}
					return;
				}
			} else {
				const itemBox = makeBox([ITEM_BOX_LEFT, ITEM_BOX_TOP], [33 * 3, 32 * 5]);
				if (inRect(pos, itemBox)) {
					if (core.isReplaying() || core.status.lockControl || core.isMoving()) return;
					const [gx, gy] = gridify(relativeTo(pos, itemBox[0]), [33, 32]);
					const itemId = this.itemMx[gy][gx];
					useItem(itemId);
					return;
				}
				const toolBox = makeBox([TOOL_BOX_LEFT, TOOL_BOX_TOP], [34 * 3, 34 * 2]);
				if (inRect(pos, toolBox)) {
					const [row, col] = gridify(relativeTo(pos, toolBox[0]), [34, 34]);
					if (core.isReplaying()) {
						this.replayAction[col][row].call(core);
					} else if (core.isPlaying()) {
						this.toolbarAction[col][row].call(core, true);
					}
					return;
				}
			}
		}
		infoText;
		infocnt = 0;
		_update_infoBar() {
			core.setTextAlign('outerUI', 'left');
			const text = this.infoText;
			if (core.domStyle.isVertical) {
				core.clearMap("outerUI", 0, INFO_BAR_TOP_VERTICAL, GAMEVIEW_WIDTH, INFO_BAR_HEIGHT_VERTICAL);
				core.setFont("outerUI", 'bold 14px Verdana');
				if (text) {
					core.fillText("outerUI", text, 10, INFO_BAR_TOP_VERTICAL + 14, TEXT_COLOR);
				}
			} else {
				core.clearMap("outerUI", 0, INFO_BAR_TOP, GAMEVIEW_WIDTH, INFO_BAR_HEIGHT);
				core.setFont("outerUI", 'bold 16px Verdana');
				if (text) {
					core.fillText("outerUI", text, 10, INFO_BAR_TOP + 16, TEXT_COLOR);
				}
			}
			core.setTextAlign('outerUI', 'center');
		}
		print(text, cnt = 1) {
			this.infoText = text;
			this.infocnt = cnt;
			this._update_infoBar();
		}
		static infoRules = [
			{ id: "lava", text: "岩浆好热啊!" },
			{ id: "upFloor", text: "你看到了楼梯" },
			{ id: "downFloor", text: "你看到了楼梯" },
			{ id: "blueShop", text: "你看到了一个祭坛" },
			{ id: "man", text: "你看到了一个老人" },
			{ id: "woman", text: "你看到了一个商人" },
			{ id: "fairy", text: "你看到了一个商人" },
			{ id: "thief", text: "你看到了一个小偷" },
		]
		printEnvironmentInfo() {
			if (!this.infocnt) {
				return;
			}
			const ids = [];
			for (const block of core.status.thisMap.blocks) {
				if (!block.disable && core.nearHero(block.x, block.y)) ids.push(block.event.id);
			}
			for (const infoRule of StatusBar.infoRules) {
				if (ids.indexOf(infoRule.id) >= 0) {
					this.print(infoRule.text);
					return;
				}
			}
		}
		clearInfo(etype) {
			this.clearItemInfo();
			if (this.infocnt == 1) {
				setTimeout(() => {
					if (this.infocnt === 0) {
						this.infoText = void 0;
						this._update_infoBar();
					}
				}, 200);
				this.infocnt = 0;
			} else if (this.infocnt > 1) {
				this.infocnt--;
			}
		}
	}

	core.ui.statusBar = new StatusBar();

	core.control.clearStatusBar = function () {
		core.clearMap("outerUI");
	}
	// init() called in `afterLoadResources`.
},
    "override": function () {

	core.statusBar.icons = {
		'floor': 0,
		'name': null,
		'lv': 1,
		'hpmax': 2,
		'hp': 3,
		'atk': 4,
		'def': 5,
		'mdef': 6,
		'money': 7,
		'experience': 8,
		'up': 9,
		'book': 10,
		'fly': 11,
		'toolbox': 12,
		'keyboard': 13,
		'shop': 14,
		'save': 15,
		'load': 16,
		'settings': 17,
		'play': 18,
		'pause': 19,
		'stop': 20,
		'speedDown': 21,
		'speedUp': 22,
		'rewind': 23,
		'equipbox': 24,
		'mana': 25,
		'skill': 26,
		'paint': 27,
		'erase': 28,
		'empty': 29,
		'exit': 30,
		'btn1': 31,
		'btn2': 32,
		'btn3': 33,
		'btn4': 34,
		'btn5': 35,
		'btn6': 36,
		'btn7': 37,
		'btn8': 38,
		'keys': 39,
		'help': 40,
		'battle': 41
	};

	core.actions._clickCenterFly = function (x, y) {
		var posX = core.status.event.data.posX,
			posY = core.status.event.data.posY;
		core.ui.closePanel();
		if (x == posX && y == posY) {
			if (core.canUseItem('centerFly')) {
				core.useItem('centerFly');
			} else {
				core.drawTip('当前不能使用中心对称飞行器');
			}
		} else core.drawTip('取消使用');
	}

	var _clickSL = core.actions._clickSL;
	core.actions._clickSL = function (x, y) {
		var page = core.status.event.data.page,
			offset = core.status.event.data.offset;
		var index = page * 10 + offset;

		// 上一页
		if ((x == this.HSIZE - 1 || x == this.HSIZE - 2) && y == this.LAST) {
			core.ui._drawSLPanel(10 * (page - 1) + offset);
			return;
		}
		// 下一页
		if ((x == this.HSIZE + 1 || x == this.HSIZE + 2) && y == this.LAST) {
			core.ui._drawSLPanel(10 * (page + 1) + offset);
			return;
		}
		if ((x == this.HSIZE - 3 || x == this.HSIZE + 3) && y == this.LAST) {
			return;
		}
		_clickSL.call(this, x, y);
	}

	var _sys_longClick_lockControl = core.actions._sys_longClick_lockControl;
	core.actions._sys_longClick_lockControl = function (x, y) {
		if (!core.status.lockControl) return false;

		// 长按SL上下页快速翻页
		if (["save", "load", "replayLoad", "replayRemain"].indexOf(core.status.event.id) >= 0) {
			if (y == this.LAST && x <= this.HSIZE + 3 && x >= this.HSIZE - 3) {
				core.actions._clickSL(x, y);
				return true;
			}
		}
		return _sys_longClick_lockControl.call(this, x, y);
	}
	core.registerAction('longClick', '_sys_longClick_lockControl', core.actions._sys_longClick_lockControl, 50);

	core.control._moveHero_moving = function () {
		core.status.heroStop = false;
		core.status.automaticRoute.moveDirectly = false;
		var move = function () {
			if (!core.status.heroStop) {
				if (core.hasFlag('debug') && core.status.ctrlDown) {
					if (core.status.heroMoving != 0) return;
					// 检测是否穿出去
					var nx = core.nextX(),
						ny = core.nextY();
					if (nx < 1 || nx >= core.bigmap.width - 1 || ny < 1 || ny >= core.bigmap.height - 1) return;
					core.eventMoveHero([core.getHeroLoc('direction')], core.values.moveSpeed, move);
				} else {
					core.moveAction();
					setTimeout(move, 50);
				}
			}
		}
		move();
	}

	core.control._drawHero_updateViewport = function (x, y, offset) {}

	var _drawThumbnail_drawTempCanvas = core.maps._drawThumbnail_drawTempCanvas;
	core.maps._drawThumbnail_drawTempCanvas = function (floorId, blocks, options) {
		if (main.mode == 'editor') {
			_drawThumbnail_drawTempCanvas.call(this, floorId, blocks, options);
			return;
		}

		var width = core.floors[floorId].width;
		var height = core.floors[floorId].height;
		// 绘制到tempCanvas上面
		var tempCanvas = core.bigmap.tempCanvas;
		options.v2 = false;
		tempCanvas.canvas.width = width * 32;
		tempCanvas.canvas.height = height * 32;
		options.ctx = tempCanvas;

		var hasHero = core.status.hero != null,
			flags = null;
		if (options.flags) {
			if (!hasHero) core.status.hero = {};
			flags = core.status.hero.flags;
			core.status.hero.flags = options.flags;
		}
		this._drawThumbnail_realDrawTempCanvas(floorId, blocks, options);

		if (!hasHero) delete core.status.hero;
		else if (flags != null) core.status.hero.flags = flags;
		tempCanvas.setTransform(1, 0, 0, 1, 0, 0);
	}

	var _drawThumbnail_drawToTarget = core.maps._drawThumbnail_drawToTarget;
	core.maps._drawThumbnail_drawToTarget = function (floorId, options) {
		if (main.mode == 'editor') {
			_drawThumbnail_drawToTarget.call(this, floorId, options);
			return;
		}

		var ctx = core.getContextByName(options.ctx);
		if (ctx == null) return;
		var x = options.x || 0,
			y = options.y || 0,
			size = options.size || core.__PIXELS__;
		var tempCanvas = core.bigmap.tempCanvas;
		core.drawImage(ctx, tempCanvas.canvas, 32, 32, core.__PIXELS__, core.__PIXELS__, x, y, size, size);
	}

	var _drawWindowSkin = core.ui.drawWindowSkin;
	core.ui.drawWindowSkin = function (background, ctx, x, y, w, h, direction, px, py) {
		_drawWindowSkin.call(this, background, ctx, x, y, w, h, direction, px, py);

		var c = parseInt(w / 2);
		core.drawImage(ctx, background, 160, 90, 16, 6, x + c - 8, y, 16, 6);
	}

	var _drawPagination = ui.prototype.drawPagination;
	core.ui.drawPagination = function (page, totalPage, y) {
		if (["save", "load", "replayLoad", "replayRemain", "replaySince"].indexOf(core.status.event.id) >= 0) {
			if (totalPage <= 1) return;
			if (y == null) y = this.LAST;

			core.setFillStyle('ui', '#DDDDDD');
			var length = core.calWidth('ui', page, this._buildFont(15, true));

			core.setTextAlign('ui', 'left');
			core.fillText('ui', page, parseInt((this.PIXEL - length) / 2), y * 32 + 19);

			core.setTextAlign('ui', 'center');
			if (page > 1)
				core.fillText('ui', '上一页', this.HPIXEL - 48, y * 32 + 19);
			if (page < totalPage)
				core.fillText('ui', '下一页', this.HPIXEL + 48, y * 32 + 19);
			return;
		}
		_drawPagination.call(this, page, totalPage, y);
	}

	core.ui._drawCenterFly = function () {
		core.lockControl();
		core.status.event.id = 'centerFly';
		var fillstyle = 'rgba(255,0,0,0.5)';
		if (core.canUseItem('centerFly')) fillstyle = 'rgba(0,255,0,0.5)';
		var toX = core.bigmap.width - 1 - core.getHeroLoc('x'),
			toY = core.bigmap.height - 1 - core.getHeroLoc('y');
		this.clearUI();
		core.fillRect('ui', 0, 0, this.PIXEL, this.PIXEL, '#000000');
		core.drawThumbnail(null, null, { heroLoc: core.status.hero.loc, heroIcon: core.status.hero.image, ctx: 'ui', centerX: toX, centerY: toY });
		var offsetX = 1,
			offsetY = 1;
		core.fillRect('ui', (toX - offsetX) * 32, (toY - offsetY) * 32, 32, 32, fillstyle);
		core.status.event.data = { "x": toX, "y": toY, "posX": toX - offsetX, "posY": toY - offsetY };
		core.playSound('打开界面');
		core.drawTip("请确认当前" + core.material.items['centerFly'].name + "的位置", 'centerFly');
		return;
	}

	core.ui.drawHelp = function () {
		core.clearUI();
		core.status.event.id = 'help';
		core.lockControl();
		core.setAlpha('ui', 1);
		core.fillRect('ui', 0, 0, this.PIXEL, this.PIXEL, '#FFFFFF');
		core.drawImage('ui', core.material.images.keyboard, 0, 0, 416, 416, 0, 0, 352, 352);
	}

	core.actions._getClickLoc = function (x, y) {
		var size = 32 * core.domStyle.scale;
		var left = main.dom.gameDraw.offsetLeft + main.dom.gameGroup.offsetLeft;
		var top = main.dom.gameDraw.offsetTop + main.dom.gameGroup.offsetTop;
		var loc = { 'x': Math.max(x - left, 0), 'y': Math.max(y - top, 0), 'size': size };
		return loc;
	}

	core.enemys.getDamageString = function (enemy, x, y, floorId) {
		if (typeof enemy == 'string') enemy = core.material.enemys[enemy];
		var damage = this.getDamage(enemy, x, y, floorId);

		var color = '#000000';

		if (damage == null) {
			damage = "???";
			color = '#FF2222';
		} else {
			if (core.hasFlag('addhp')) {
				if (damage < core.status.hero.hp) color = '#11FF11';
				else color = '#FF2222';
			} else if (damage <= 0) color = '#11FF11';
			else if (damage < core.status.hero.hp / 3) color = '#FFFFFF';
			else if (damage < core.status.hero.hp * 2 / 3) color = '#FFFF00';
			else if (damage < core.status.hero.hp) color = '#FF9933';
			else color = '#FF2222';

			damage = core.formatBigNumber(damage, true);
			if (core.enemys.hasSpecial(enemy, 19))
				damage += "+";
			if (core.enemys.hasSpecial(enemy, 21))
				damage += "-";
			if (core.enemys.hasSpecial(enemy, 11))
				damage += "^";
		}

		return {
			"damage": damage,
			"color": color
		};
	}

	core.ui._drawBook_drawDamage = function (index, enemy, offset, position) {
		core.setTextAlign('ui', 'center');
		var damage = enemy.damage,
			color = '#FFFF00';
		if (damage == null) {
			damage = '不可攻击';
			color = '#FF2222';
		}
		if (damage == 0) {
			damage = '无危险';
			color = '#11FF11';
		} else {
			if (damage >= core.status.hero.hp) color = '#FF2222';
			else if (damage >= core.status.hero.hp * 2 / 3) color = '#FF9933';
			else if (damage <= 0) color = '#11FF11';
			damage = core.formatBigNumber(damage);
			if (core.enemys.hasSpecial(enemy, 19)) damage += "+";
			if (core.enemys.hasSpecial(enemy, 21)) damage += "-";
			if (core.enemys.hasSpecial(enemy, 11)) damage += "^";
		}
		if (enemy.notBomb) damage += "[b]";
		core.fillText('ui', damage, offset, position, color, this._buildFont(13, true));
	}

	core.control.checkBlock = function () {
		var x = core.getHeroLoc('x'),
			y = core.getHeroLoc('y'),
			loc = x + "," + y;
		var damage = core.status.checkBlock.damage[loc];
		if (damage) {
			core.status.hero.hp -= damage;
			core.checkSkill(12, damage);
			core.drawTip("你没有神圣盾不能防御，受到 " + damage + " 点魔法伤害");
			core.playSound('zone.mp3');
			this._checkBlock_disableQuickShop();
			core.status.hero.statistics.extraDamage += damage;
			if (core.status.hero.hp <= 0) {
				core.updateStatusBar();
				if (!flags.dying) core.insertCommonEvent("濒死");
				return;
			} else {
				core.updateStatusBar();
			}
		}
		this._checkBlock_ambush(core.status.checkBlock.ambush[loc]);
		this._checkBlock_repulse(core.status.checkBlock.repulse[loc]);
	}

	core.registerSystemEvent("man", function (data, callback) {
		var a = parseInt(core.status.floorId.substring(2));
		var b = core.nextX();
		var c = core.nextY();
		core.insertAction([
			{ "type": "insert", "name": "对话", "args": [a, b, c, 0] },
		]);
		//console.log(data);
		if (callback) callback();
	});

	core.registerSystemEvent("woman", function (data, callback) {
		var name = core.status.floorId + '@' + core.nextX() + '@' + core.nextY() + '@' + 'A';
		if (core.getFlag(name, 0) == 1) {
			var a = parseInt(core.status.floorId.substring(2));
			var b = core.nextX();
			var c = core.nextY();
			core.insertAction([
				{ "type": "insert", "name": "对话", "args": [a, b, c, 1] },
			]);
		} else {
			core.insertAction([
				{ "type": "insert", "name": "商人", "args": [0] },
			]);
		}
		//console.log(data);
		if (callback) callback();
	});

	core.registerSystemEvent("specialwall", function (data, callback) {
		if (data.event.id == 'whiteWall' || core.getFlag('talking') > 0) {
			core.insertAction({ 'type': 'openDoor', loc: [data.x, data.y] });
			if (data.event.id != 'whiteWall') {
				core.setFlag('end', 1);
			}
			//core.setFlag('talking', 0); //穿墙之后不能再次穿墙
		}
		//console.log(data);
		if (callback) callback();
	});

	core.registerSystemEvent("fakeWall", function (data, callback) {
		if (data.event.id == 'blueWall') {
			core.insertAction([
				{ "type": "openDoor", loc: [data.x, data.y] },
			]);
		}
		//console.log(data);
		if (callback) callback();
	});

	core.ui._drawWindowSelector = function (background, x, y, w, h) {
		w = Math.round(w) + 48;
		h = Math.round(h);
		var ctx = core.ui.createCanvas("_selector", x - 24, y, w, h, 165);
		ctx.canvas.id = '';
		this._drawSelector(ctx, background, w, h);
	}

	core.ui._drawSelector = function (ctx, background, w, h, left, top) {
		left = left || 0;
		top = top || 0;
		ctx = this.getContextByName(ctx);
		if (!ctx) return;
		if (typeof background == 'string')
			background = core.material.images.images[background];
		if (!(background instanceof Image)) return;
		// badge
		ctx.drawImage(background, 132, 68, 24, 24, left + 4, top + 4, 24, 24);
		ctx.drawImage(background, 132, 68, 24, 24, w - left - 28, top + 4, 24, 24);
	}

	core.ui.drawTip = function (text, id, clear) {
		core.ui.statusBar.print(text);
	}

	core.ui.clearMap = function (name, x, y, width, height) {
		if (name == 'all') {
			for (var m in core.canvas) {
				core.canvas[m].clearRect(0, 0, core.bigmap.width * 32, core.bigmap.height * 32);
			}
			core.clearMap("outerUI");
			core.dom.gif.innerHTML = "";
			core.removeGlobalAnimate();
		} else {
			var ctx = this.getContextByName(name);
			if (ctx) ctx.clearRect(x || 0, y || 0, width || ctx.canvas.width, height || ctx.canvas.height);
		}
	}

	core.control._updateStatusBar_setToolboxIcon = function () {
		core.ui.statusBar._update_toolBox();
	}

	var _changeFloor_getInfo = core.events._changeFloor_getInfo;
	core.events._changeFloor_getInfo = function (floorId, stair, heroLoc, time) {
		var info = _changeFloor_getInfo.call(this, floorId, stair, heroLoc, time);
		if (info == null) return null;
		info.time = 0;
		info.origin = floorId;
		return info;
	}

	core.events._changeFloor_afterChange = function (info, callback) {
		if (!info.locked) core.unlockControl();
		core.status.replay.animate = false;
		core.events.afterChangeFloor(info.floorId);

		if (info.origin == ':before') core.ui.statusBar.print('走下了楼梯')
		else if (info.origin == ':next') core.ui.statusBar.print('登上了楼梯')
		if (callback) callback();
	}

	if (window.jsinterface && window.jsinterface.requestLandscape) {
		window.jsinterface.requestLandscape();
	}
},
    "shop": function () {
	// 【全局商店】相关的功能
	// 
	// 打开一个全局商店
	// shopId：要打开的商店id；noRoute：是否不计入录像
	this.openShop = function (shopId, noRoute) {
		var shop = core.status.shops[shopId];
		// Step 1: 检查能否打开此商店
		if (!this.canOpenShop(shopId)) {
			core.drawTip("该商店尚未开启");
			return false;
		}

		// Step 2: （如有必要）记录打开商店的脚本事件
		if (!noRoute) {
			core.status.route.push("shop:" + shopId);
		}

		// Step 3: 检查道具商店 or 公共事件
		if (shop.item) {
			if (core.openItemShop) {
				core.openItemShop(shopId);
			} else {
				core.playSound('操作失败');
				core.insertAction("道具商店插件不存在！请检查是否存在该插件！");
			}
			return;
		}
		if (shop.commonEvent) {
			core.insertCommonEvent(shop.commonEvent, shop.args);
			return;
		}

		_shouldProcessKeyUp = true;

		// Step 4: 执行标准公共商店    
		core.insertAction(this._convertShop(shop));
		return true;
	}

	////// 将一个全局商店转变成可预览的公共事件 //////
	this._convertShop = function (shop) {
		return [
			{ "type": "function", "function": "function() {core.addFlag('@temp@shop', 1);}" },
			{
				"type": "while",
				"condition": "true",
				"data": [
					// 检测能否访问该商店
					{
						"type": "if",
						"condition": "core.isShopVisited('" + shop.id + "')",
						"true": [
							// 可以访问，直接插入执行效果
							{ "type": "function", "function": "function() { core.plugin._convertShop_replaceChoices('" + shop.id + "', false) }" },
						],
						"false": [
							// 不能访问的情况下：检测能否预览
							{
								"type": "if",
								"condition": shop.disablePreview,
								"true": [
									// 不可预览，提示并退出
									{ "type": "playSound", "name": "操作失败" },
									"当前无法访问该商店！",
									{ "type": "break" },
								],
								"false": [
									// 可以预览：将商店全部内容进行替换
									{ "type": "tip", "text": "当前处于预览模式，不可购买" },
									{ "type": "function", "function": "function() { core.plugin._convertShop_replaceChoices('" + shop.id + "', true) }" },
								]
							}
						]
					}
				]
			},
			{ "type": "function", "function": "function() {core.addFlag('@temp@shop', -1);}" }
		];
	}

	this._convertShop_replaceChoices = function (shopId, previewMode) {
		var shop = core.status.shops[shopId];
		var choices = (shop.choices || []).filter(function (choice) {
			if (choice.condition == null || choice.condition == '') return true;
			try { return core.calValue(choice.condition); } catch (e) { return true; }
		}).map(function (choice) {
			var ableToBuy = core.calValue(choice.need);
			return {
				"text": choice.text,
				"icon": choice.icon,
				"color": ableToBuy && !previewMode ? choice.color : [153, 153, 153, 1],
				"action": ableToBuy && !previewMode ? [{ "type": "playSound", "name": "商店" }].concat(choice.action) : [
					{ "type": "playSound", "name": "操作失败" },
					{ "type": "tip", "text": previewMode ? "预览模式下不可购买" : "购买条件不足" }
				]
			};
		}).concat({ "text": "离开", "action": [{ "type": "playSound", "name": "取消" }, { "type": "break" }] });
		core.insertAction({ "type": "choices", "text": shop.text, "choices": choices });
	}

	/// 是否访问过某个快捷商店
	this.isShopVisited = function (id) {
		if (!core.hasFlag("__shops__")) core.setFlag("__shops__", {});
		var shops = core.getFlag("__shops__");
		if (!shops[id]) shops[id] = {};
		return shops[id].visited;
	}

	/// 当前应当显示的快捷商店列表
	this.listShopIds = function () {
		return Object.keys(core.status.shops).filter(function (id) {
			return core.isShopVisited(id) || !core.status.shops[id].mustEnable;
		});
	}

	/// 是否能够打开某个商店
	this.canOpenShop = function (id) {
		if (this.isShopVisited(id)) return true;
		var shop = core.status.shops[id];
		if (shop.item || shop.commonEvent || shop.mustEnable) return false;
		return true;
	}

	/// 启用或禁用某个快捷商店
	this.setShopVisited = function (id, visited) {
		if (!core.hasFlag("__shops__")) core.setFlag("__shops__", {});
		var shops = core.getFlag("__shops__");
		if (!shops[id]) shops[id] = {};
		if (visited) shops[id].visited = true;
		else delete shops[id].visited;
	}

	/// 能否使用快捷商店
	this.canUseQuickShop = function (id) {
		// 如果返回一个字符串，表示不能，字符串为不能使用的提示
		// 返回null代表可以使用

		// 检查当前楼层的canUseQuickShop选项是否为false
		if (core.status.thisMap.canUseQuickShop === false)
			return '当前楼层不能使用快捷商店。';
		return null;
	}

	var _shouldProcessKeyUp = true;

	/// 允许商店X键退出
	core.registerAction('keyUp', 'shops', function (keycode) {
		if (!core.status.lockControl || core.status.event.id != 'action') return false;
		if ((keycode == 13 || keycode == 32) && !_shouldProcessKeyUp) {
			_shouldProcessKeyUp = true;
			return true;
		}

		if (!core.hasFlag("@temp@shop") || core.status.event.data.type != 'choices') return false;
		var data = core.status.event.data.current;
		var choices = data.choices;
		var topIndex = core.actions._getChoicesTopIndex(choices.length);
		if (keycode == 88 || keycode == 27) { // X, ESC
			core.actions._clickAction(core.actions.HSIZE, topIndex + choices.length - 1);
			return true;
		}
		return false;
	}, 60);

	/// 允许长按空格或回车连续执行操作
	core.registerAction('keyDown', 'shops', function (keycode) {
		if (!core.status.lockControl || !core.hasFlag("@temp@shop") || core.status.event.id != 'action') return false;
		if (core.status.event.data.type != 'choices') return false;
		var data = core.status.event.data.current;
		var choices = data.choices;
		var topIndex = core.actions._getChoicesTopIndex(choices.length);
		if (keycode == 13 || keycode == 32) { // Space, Enter
			core.actions._clickAction(core.actions.HSIZE, topIndex + core.status.event.selection);
			_shouldProcessKeyUp = false;
			return true;
		}
		return false;
	}, 60);

	// 允许长按屏幕连续执行操作
	core.registerAction('longClick', 'shops', function (x, y, px, py) {
		if (!core.status.lockControl || !core.hasFlag("@temp@shop") || core.status.event.id != 'action') return false;
		if (core.status.event.data.type != 'choices') return false;
		var data = core.status.event.data.current;
		var choices = data.choices;
		var topIndex = core.actions._getChoicesTopIndex(choices.length);
		if (x >= core.actions.CHOICES_LEFT && x <= core.actions.CHOICES_RIGHT && y >= topIndex && y < topIndex + choices.length) {
			core.actions._clickAction(x, y);
			return true;
		}
		return false;
	}, 60);
},
    "itemDetail": function () {
	/* 宝石血瓶左下角显示数值
	 * 需要将 变量：itemDetail改为true才可正常运行
	 * 请尽量减少勇士的属性数量，否则可能会出现严重卡顿
	 * 注意：这里的属性必须是core.status.hero里面的，flag无法显示
	 * 如果不想显示，可以core.setFlag("itemDetail", false);
	 * 然后再core.getItemDetail();
	 * 如有bug在大群或造塔群@古祠
	 */

	// 谁tm在即捡即用效果里面调用带有含刷新状态栏的函数
	var origin = core.control.updateStatusBar;
	core.updateStatusBar = core.control.updateStatusBar = function () {
		if (core.getFlag('__statistics__')) return;
		else return origin.apply(core.control, arguments);
	}

	core.bigmap.threshold = 256;

	core.control.updateDamage = function (floorId, ctx) {
		floorId = floorId || core.status.floorId;
		if (!floorId || core.status.gameOver || main.mode != 'play') return;
		var onMap = ctx == null;

		// 没有怪物手册
		if (!core.hasItem('book')) return;
		core.status.damage.posX = core.bigmap.posX;
		core.status.damage.posY = core.bigmap.posY;
		if (!onMap) {
			var width = core.floors[floorId].width,
				height = core.floors[floorId].height;
			// 地图过大的缩略图不绘制显伤
			if (width * height > core.bigmap.threshold) return;
		}
		this._updateDamage_damage(floorId, onMap);
		this._updateDamage_extraDamage(floorId, onMap);
		core.getItemDetail(floorId); // 宝石血瓶详细信息
		this.drawDamage(ctx);
	};
	// 绘制地图显示
	control.prototype._drawDamage_draw = function (ctx, onMap) {
		if (!core.hasItem('book')) return;
		// *** 下一句话可以更改你想要的显示字体
		core.setFont(ctx, "bold 11px Arial");
		// ***
		core.setTextAlign(ctx, 'left');
		core.status.damage.data.forEach(function (one) {
			var px = one.px,
				py = one.py;
			if (onMap && core.bigmap.v2) {
				px -= core.bigmap.posX * 32;
				py -= core.bigmap.posY * 32;
				if (px < -32 * 2 || px > core.__PX__ + 32 || py < -32 || py > core.__PY__ + 32)
					return;
			}
			core.fillBoldText(ctx, one.text, px, py, one.color);
		});
		core.setTextAlign(ctx, 'center');
		core.status.damage.extraData.forEach(function (one) {
			var px = one.px,
				py = one.py;
			if (onMap && core.bigmap.v2) {
				px -= core.bigmap.posX * 32;
				py -= core.bigmap.posY * 32;
				if (px < -32 || px > core.__PX__ + 32 || py < -32 || py > core.__PY__ + 32)
					return;
			}
			core.fillBoldText(ctx, one.text, px, py, one.color);
		});
	};
	// 获取宝石信息 并绘制
	this.getItemDetail = function (floorId) {
		if (!core.getFlag("itemDetail")) return;
		floorId = floorId || core.status.thisMap.floorId;
		core.status.maps[floorId].blocks.forEach(function (block) {
			if (block.event.cls !== 'items' || block.event.id === 'superPotion') return;
			var x = block.x,
				y = block.y;
			// v2优化，只绘制范围内的部分
			if (core.bigmap.v2) {
				if (x < core.bigmap.posX - core.bigmap.extend || x > core.bigmap.posX + core.__SIZE__ + core.bigmap.extend ||
					y < core.bigmap.posY - core.bigmap.extend || y > core.bigmap.posY + core.__SIZE__ + core.bigmap.extend) {
					return;
				}
			}
			var id = block.event.id;
			var item = core.material.items[id];
			if (item.cls === 'equips') {
				// 装备也显示
				var diff = core.clone(item.equip.value || {});
				var per = item.equip.percentage;
				for (var name in per) {
					diff[name + 'per'] = per[name].toString() + '%';
				}
				drawItemDetail(diff, x, y);
				return;
			}
			var before = core.clone(core.status.hero);
			//跟数据统计原理一样 执行效果前后比较
			core.setFlag("__statistics__", true);
			try {
				eval(item.itemEffect);
			} catch (error) {}
			var diff = compareObject(before, core.status.hero);
			core.status.hero = hero = before;
			flags = core.status.hero.flags;
			drawItemDetail(diff, x, y);
		});
	};
	// 比较两个对象之间每一项的数值差异（弱等于） 返回数值差异
	function compareObject(a, b) {
		a = a || {};
		b = b || {};
		var diff = {}; // 差异
		for (var name in a) {
			diff[name] = b[name] - (a[name] || 0);
			if (!diff[name]) diff[name] = void 0;
		}
		return diff;
	};
	// 绘制
	function drawItemDetail(diff, x, y) {
		var px = 32 * x + 2,
			py = 32 * y + 30;
		var content = "";
		// 获得数据和颜色
		var i = 0;
		for (var name in diff) {
			if (!diff[name]) continue;
			var color = "#ffffff";
			if (typeof diff[name] === 'number')
				diff[name] = core.formatBigNumber(diff[name], true);
			switch (name) {
			case 'atk':
			case 'atkper':
				color = "#FF7A7A";
				break;
			case 'def':
			case 'defper':
				color = "#00E6F1";
				break;
			case 'mdef':
			case 'mdefper':
				color = "#6EFF83";
				break;
			case 'hp':
				color = "#A4FF00";
				break;
			case 'hpmax':
			case 'hpmaxper':
				color = "#F9FF00";
				break;
			case 'mana':
				color = "#cc6666";
				break;
			}
			content = diff[name];
			// 绘制
			core.status.damage.data.push({ text: content, px: px, py: py - 10 * i, color: color });
			i++;
		}
	}
	//  执行效果 前后比较
},
    "抽卡": function () {
	this.getResult = function (n) {
		n = Math.max(0, Math.min(999, n));
		if (n < 70) return "redGem";
		if (n < 140) return "blueGem";
		if (n < 210) return "yellowGem";
		if (n < 280) return "greenGem";
		if (n < 350) return "redPotion";
		if (n < 420) return "bluePotion";
		if (n < 490) return "yellowPotion";
		if (n < 560) return "greenPotion";
		if (n < 620) return "redKey";
		if (n < 680) return "blueKey";
		if (n < 740) return "yellowKey";
		if (n < 800) return "greenKey";
		if (n < 820) return "pickaxe";
		if (n < 840) return "bomb";
		if (n < 860) return "centerFly";
		if (n < 880) return "upFly";
		if (n < 900) return "downFly";
		if (n < 920) return "superPotion";
		if (n < 930) return "earthquake";
		if (n < 940) return "cross";
		if (n < 950) return "knife";
		if (n < 960) return "coin";
		if (n < 970) return "bigKey";
		if (n < 975) return "sword1";
		if (n < 980) return "shield1";
		if (n < 985) return "sword2";
		if (n < 990) return "shield2";
		if (n < 992) return "sword3";
		if (n < 994) return "shield3";
		if (n < 996) return "sword4";
		if (n < 998) return "shield4";
		if (n < 999) return "sword5";
		if (n < 1000) return "shield5";
	}
	this.getColor = function (s) {
		var colorList = {
			"red": ["redGem", "redKey", "redPotion", "bomb", "upFly"],
			"blue": ["blueKey", "blueGem", "bluePotion", "downFly", "superPotion", "shield1", "sword1", "shield5", "sword5"],
			"green": ["greenKey", "greenGem", "greenPotion", "sword4", "shield4"],
			"yellow": ["yellowKey", "yellowGem", "yellowPotion", "pickaxe", "centerFly", "earthquake", "coin", "cross", "bigKey", "sword3", "shield3"]
		};
		for (var i in colorList) {
			var color = colorList[i];
			if (color.includes(s)) {
				return i;
			}
		}
		return 'none';
	}
	this.randGem = function () {
		return core.getResult(core.rand(280));
	}
	this.randPotion = function () {
		return core.getResult(core.rand(280) + 280);
	}
	this.randKey = function () {
		return core.getResult(core.rand(240) + 560);
	}
	this.randBasic = function () {
		return core.getResult(core.rand(800));
	}
	this.randTool = function () {
		return core.getResult(core.rand(200) + 800);
	}
	this.randAll = function () {
		return core.getResult(core.rand(1000));
	}
	this.randEquip = function () {
		return core.getResult(core.rand(30) + 970);
	}
	this.chouka = function (gen, times) {
		gen = gen || core.randAll;
		times = times || 1;
		let res = {};
		for (var i = 0; i < times; ++i) {
			let r1 = gen();
			if (res[r1]) {
				++res[r1];
			} else {
				res[r1] = 1;
			}
		}
		let resList = [];
		for (let i in res) {
			resList.push(core.material.items[i].name + 'x' + res[i]);
			core.getItem(i, res[i]);
			core.checkSkill(15, i);
		}
		if (core.getFlag("showResult")) {
			core.insertAction([
				"\\t[摸牌结果]" + resList.join('、')
			]);
		}
	}
},
    "万能钥匙": function () {
	events.prototype._openDoor_check = function (block, x, y, needKey) {
		var clearAndReturn = function () {
			core.clearContinueAutomaticRoute();
			return false;
		}

		if (block == null || block.event == null) return clearAndReturn();
		var id = block.event.id;

		// 是否存在门或暗墙
		if (core.material.icons.animates[id] == null && core.material.icons.npc48[id] == null) {
			return clearAndReturn();
		}

		if (id == 'steelDoor' && core.flags.steelDoorWithoutKey)
			needKey = false;
		var doorInfo = block.event.doorInfo;
		if (doorInfo == null) return clearAndReturn();
		// Check all keys
		var keyInfo = doorInfo.keys || {};
		//缺少的钥匙
		var lessKey = [];
		var needGreenKey = 0;
		if (needKey) {
			for (var keyName in keyInfo) {
				var keyValue = keyInfo[keyName];
				if (keyName.endsWith(':o')) keyName = keyName.substring(0, keyName.length - 2);

				// --- 如果是一个不存在的道具，则直接认为无法开启
				if (!core.material.items[keyName]) {
					needGreenKey += keyValue;
					continue;
				}
				if (core.itemCount(keyName) < keyValue) {
					lessKey.push(keyName);
					needGreenKey += keyValue - core.itemCount(keyName);
				}
			}
			if (core.itemCount("greenKey") < needGreenKey) {
				var tip = "你的";
				if (lessKey.length > 0) {
					tip = tip + lessKey.map(function (x) { return ((core.material.items[x] || {}).name) }).join("、") + "或绿钥匙不足！"
				} else {
					tip = tip + "绿钥匙不足！"
				}
				core.stopSound();
				core.playSound("操作失败");
				core.drawTip(tip);
				return false;
			}
			if (!core.status.event.id) core.autosave(true);
			for (var keyName in keyInfo) {
				if (!keyName.endsWith(':o')) core.removeItem(keyName, Math.min(core.itemCount(keyName), keyInfo[keyName]));
			}
			core.removeItem("greenKey", needGreenKey);
		}
		core.playSound(doorInfo.openSound);
		return true;
	}
},
    "其他函数": function () {
	this.instantUseItem = function (itemName) {
		var a = core.itemCount(itemName);
		core.addItem(itemName);
		core.useItem(itemName, true);
		if (core.itemCount(itemName) > a) {
			core.removeItem(itemName);
		}
	}
	this.flip = function () {
		core.checkSkill(11);
		core.setFlag("inverted", !core.getFlag("inverted", false));
	}
	this.difficultyText = function () {
		return ["乱撞", "简单", "普通", "较难", "极难"][core.getFlag("difficulty")];
	}
	this.difficultyColor = function () {
		if (core.getFlag("overload")) return '#ded0ff';
		return ["#c0c0c0", "#add8e6", "#90ee90", "#ffc088", "#ff9999"][core.getFlag("difficulty")];
	}
	this.endName = function () {
		return (core.getFlag('ZiXuan') ? '自选' : '随机') + '-' + (core.getFlag('overload') ? '失衡' : core.difficultyText());
	}
	this.getFloorItems = function (n) {
		var itemList = core.searchBlockWithFilter(function (block) { return block.event.cls == "items" });
		n = Math.min(itemList.length, n);
		for (var i = 0; i < n; ++i) {
			var j = core.rand(itemList.length);
			var block = itemList[j].block;
			core.getItem(block.event.id, 1, block.x, block.y);
			itemList.splice(j, 1);
		}
	}
	this.hardcap = function () {
		if (hero.hp > 1e8) hero.hp = 1e8;
		if (hero.atk > 1e6) hero.atk = 1e6;
		if (hero.def > 1e6) hero.def = 1e6;
		if (hero.mdef > 1e6) hero.mdef = 1e8;
		if (hero.money > 1e8) hero.money = 1e8;
		['yellowKey', 'blueKey', 'redKey', 'greenKey'].forEach(function (x) {
			if (core.itemCount(x) > 999) core.setItem(x, 999);
		});
		['pickaxe', 'bomb', 'centerFly', 'upFly', 'downFly', 'superPotion', 'cross', 'knife', 'bigKey', 'earthquake', 'coin'].forEach(function (x) {
			if (core.itemCount(x) > 99) core.setItem(x, 99);
		});
	}
	this.shopMult = function (x) {
		return core.getFlag("difficulty") == 4 ? 1.5 : 1;
	}
	this.hpMult = function (x) {
		return core.getFlag("difficulty") == 4 ? 0.6 : 1;
	}
	this.floorMult = function (floorId) {
		switch (core.getFlag("difficulty")) {
		case 0:
			return 1;
		case 1:
			return 1.2;
		case 2:
			return 1.5;
		default:
			var floorNumber = parseInt(floorId.slice(2));
			if (floorNumber > 20 && floorNumber < 30) floorNumber += 20;
			if (floorNumber >= 30 && floorNumber < 50) floorNumber -= 10;
			return 1.5 + 0.02 * floorNumber;
		}
	}
	events.prototype._action_setValue = function (data, x, y, prefix) {
		this.setValue(data.name, data.operator, data.value, prefix);
		if (!data.norefresh) {
			if (core.status.hero.hp <= 0) {
				//if (!flags.dying) core.insertCommonEvent("濒死");
				core.updateStatusBar();
				//core.events.lose();
			} else {
				core.updateStatusBar();
			}
		}
		core.doAction();
	}
	enemys.prototype.canBattle = function (enemy, x, y, floorId) {
		if (typeof enemy == 'string') enemy = core.material.enemys[enemy];
		var damage = this.getDamage(enemy, x, y, floorId);
		return damage != null; /*&& damage < core.status.hero.hp;*/
	}
	enemys.prototype.hasSpecial = function (special, test) {
		if (special == null) return false;
		if (core.hasFlag("无视技能")) return false;
		if (special instanceof Array) {
			return special.indexOf(test) >= 0;
		}
		if (typeof special == 'number') {
			return special === test;
		}
		if (typeof special == 'string') {
			return this.hasSpecial(core.material.enemys[special], test);
		}
		if (special.special != null) {
			return this.hasSpecial(special.special, test);
		}
		return false;
	}
	items.prototype._afterUseItem = function (itemId) {
		// 道具使用完毕：删除
		if (!["book", "wand", "fly"].includes(itemId)) {
			core.checkSkill(2, itemId);
			if (core.hasFlag("用一摸一")) core.chouka(core.randAll, 1)
		}
		var itemCls = core.material.items[itemId].cls;
		if (itemCls == 'tools')
			core.status.hero.items[itemCls][itemId]--;
		if (core.status.hero.items[itemCls][itemId] <= 0)
			delete core.status.hero.items[itemCls][itemId];
		core.updateStatusBar();
	}
},
    "技能效果": function () {
	this.skillList = [{
			id: 0,
			desc: function () { return ("你加点" + this.args[0] + "次"); },
			run: function () { core.insertCommonEvent("加点事件", [this.args[0]]) },
			args: [1],
		},
		{
			id: 1,
			desc: function () { return ("你摸" + this.args[0] + "张牌"); },
			run: function () { core.chouka(core.randAll, this.args[0]) },
			args: [1],
		},
		{
			id: 2,
			short: '随机宝石',
			desc: function () { return ("你获得" + this.args[0] + "个随机宝石"); },
			run: function () { core.chouka(core.randGem, this.args[0]) },
			args: [2],
		},
		{
			id: 3,
			short: '随机血瓶',
			desc: function () { return ("你获得" + this.args[0] + "个随机血瓶"); },
			run: function () { core.chouka(core.randPotion, this.args[0]) },
			args: [2],
		},
		{
			id: 4,
			short: '随机钥匙',
			desc: function () { return ("你获得" + this.args[0] + "把随机钥匙"); },
			run: function () { core.chouka(core.randKey, this.args[0]) },
			args: [2],
		},
		{
			id: 5,
			short: '基本随机',
			desc: function () { return ("你获得" + this.args[0] + "个基本物品"); },
			run: function () { core.chouka(core.randBasic, this.args[0]) },
			args: [2],
		},
		{
			id: 6,
			short: '道具大师',
			desc: function () { return ("你获得" + this.args[0] + "个随机道具"); },
			run: function () { core.chouka(core.randTool, this.args[0]) },
			args: [1],
			awaken: true,
		},
		{
			id: 7,
			short: '制衡',
			desc: function () { return ("你可弃置任意张牌，然后摸X+" + this.args[0] + "个基本物品(X为弃置的牌数且至多为999)"); },
			run: function () {
				var a = this.args[0];
				var event = [{ "type": "insert", "name": "弃牌" },
					{ "type": "setValue", "name": "flag:__discard__", "operator": "min=", "value": 999 },
					{ "type": "setValue", "name": "flag:__discard__", "operator": "+=", "value": a },
					{ "type": "function", "function": "function(){core.chouka(core.randBasic,flags.__discard__)}" }
				];
				if (core.getFlag('overload')) event.splice(1, 1);
				core.insertAction(event);
			},
			args: [1],
			awaken: true,
		},
		{
			id: 8,
			short: '摸牌翻面',
			desc: function () { return ("你摸" + this.args[0] + "张牌并翻面"); },
			run: function () {
				core.chouka(core.randAll, this.args[0]);
				core.flip();
			},
			args: [3],
		},
		{
			id: 9,
			short: '获得破墙',
			desc: function () { return ("你获得一个破墙镐"); },
			run: function () { core.getItem("pickaxe") },
			args: [],
		},
		{
			id: 10,
			short: '山崩地裂',
			desc: function () { return ("你发动一次地震卷轴"); },
			run: function () { core.instantUseItem("earthquake") },
			args: [],
			awaken: true,
		},
		{
			id: 11,
			short: '芝麻开门',
			desc: function () { return ("你发动一次大黄门钥匙"); },
			run: function () { core.instantUseItem("bigKey") },
			args: [],
		},
		{
			id: 12,
			short: '获得圣水',
			desc: function () { return ("你获得并使用一瓶圣水"); },
			run: function () { core.instantUseItem("superPotion") },
			args: [],
		},
		{
			id: 13,
			short: '获得瞬移',
			desc: function () { return ("你获得一个对称飞行器"); },
			run: function () {
				core.getItem("centerFly")
			},
			args: [],
		},
		{
			id: 14,
			short: '对话穿墙',
			desc: function () { return ("你在" + this.args[0] + "步内获得对话穿墙效果"); },
			run: function () { core.setFlag("talking", this.args[0]) },
			args: [5],
		},
		{
			id: 15,
			short: '获得炸弹',
			desc: function () { return ("你获得一个炸弹"); },
			run: function () { core.getItem("bomb") },
			args: [],
		},
		{
			id: 16,
			short: '财源滚滚',
			desc: function () { return ("你获得" + this.args[0] + "枚幸运金币"); },
			run: function () { core.getItem("coin", this.args[0]); },
			args: [1],
			awaken: true,
		},
		{
			id: 17,
			short: '隔空取物',
			desc: function () { return ("你获得本层至多" + this.args[0] + "个随机物品"); },
			run: function () { core.getFloorItems(this.args[0]) },
			args: [3],
		},
		{
			id: 18,
			short: '进攻姿态',
			desc: function () { return ("你下一次战斗攻击变为" + this.args[0] + "倍"); },
			run: function () { core.setBuff('atk', this.args[0]); },
			args: [2],
		},
		{
			id: 19,
			short: '防御姿态',
			desc: function () { return ("你下一次战斗防御变为" + this.args[0] + "倍"); },
			run: function () { core.setBuff('def', this.args[0]); },
			args: [2],
		},
		{
			id: 20,
			short: '生生不息',
			desc: function () { return ("你的生命值变为" + this.args[0] + "倍,至多为1亿"); },
			run: function () {
				var hp = Math.floor(hero.hp * this.args[0]);
				if (!core.getFlag('overload')) hp = Math.min(hp, 1e8);
				core.status.hero.hp = Math.max(hp, hero.hp);
				core.updateStatusBar();
			},
			args: [1.5],
			awaken: true,
		},
		{
			id: 21,
			short: '本层魔攻',
			desc: function () { return ("你获得魔攻直到切换楼层"); },
			run: function () { core.setFlag("魔攻", true); },
			args: [],
		},
		{
			id: 22,
			short: '本层连击',
			desc: function () { return ("你获得" + this.args[0] + "连击直到切换楼层"); },
			run: function () { core.setFlag("连击", this.args[0]); },
			args: [2],
		},
		{
			id: 23,
			short: '无视技能',
			desc: function () { return ("你无视敌人的技能直到切换楼层"); },
			run: function () { core.setFlag("无视技能", true); },
			args: [],
		},
		{
			id: 24,
			short: '“用一摸一”',
			desc: function () { return ("你使用道具后摸一张牌直到切换楼层"); },
			run: function () { core.setFlag("用一摸一", true); },
			args: [],
			awaken: true,
		},
		{
			id: 25,
			short: '伪神圣盾',
			desc: function () { return ("你永久无视阻激夹域，或获得三个蓝宝石"); },
			run: function () {
				if (!core.hasFlag("shield5")) {
					core.setFlag("shield5", true)
				} else {
					core.getItem("blueGem", 3);
				}
			},
			args: [],
		},
		{
			id: 26,
			short: '天降神兵',
			desc: function () { return ("你获得" + this.args[0] + "个随机剑盾"); },
			run: function () { core.chouka(core.randEquip, this.args[0]) },
			args: [1],
			awaken: true,
		},
		{
			id: 27,
			short: '金币偷取',
			desc: function () { return ("你获得等同于伤害或金币值" + (this.args[0] * 10) + "%的金币"); },
			run: function (x) { core.status.hero.money += Math.floor(x * 0.1 * this.args[0]) },
			data: 1,
			args: [2],
		},
		{
			id: 28,
			short: '呼吸摸牌',
			desc: function () { return ("你摸X张牌(X为伤害或金币值/200且至少为1至多为100)"); },
			run: function (x) {
				var times = Math.floor(x / 200);
				if (!core.getFlag('overload')) times = Math.min(times, 100);
				core.chouka(core.randAll, times);
			},
			data: 1,
			args: [],
			awaken: true,
		},
		{
			id: 29,
			short: '双倍快乐',
			desc: function () { return ("你再获得一次该物品"); },
			run: function (x) { core.getItem(x); },
			data: 2,
			args: [],
		},
		{
			id: 30,
			short: '遇蓝摸牌',
			desc: function () { return ("若物品为蓝色，你摸" + this.args[0] + "张牌"); },
			run: function (x) { if (core.getColor(x) == 'blue') core.chouka(core.randAll, this.args[0]); },
			data: 2,
			args: [3],
		},
		{
			id: 31,
			short: '遇红回血',
			desc: function () { return ("若物品为红色，你获得" + this.args[0] + "个黄血瓶"); },
			run: function (x) { if (core.getColor(x) == 'red') core.getItem("yellowPotion", this.args[0]) },
			data: 2,
			args: [2],
		},
		{
			id: 32,
			short: '遇黄加点',
			desc: function () { return ("若物品为黄色，你加点" + this.args[0] + "次"); },
			run: function (x) { if (core.getColor(x) == 'yellow') core.insertCommonEvent("加点事件", [this.args[0]]); },
			data: 2,
			args: [2],
		},
		{
			id: 33,
			short: '重置商店',
			desc: function () { return ("你重置祭坛的购买次数"); },
			run: function () { core.setFlag("times1", 1); },
			args: [],
			awaken: true,
		},
		{
			id: 34,
			short: '生命偷取',
			desc: function () { return ("你获得等同于伤害或金币值" + (this.args[0] * 10) + "%的生命"); },
			run: function (x) { core.status.hero.hp += Math.floor(x * 0.1 * this.args[0]) },
			args: [3],
			data: 1,
		},
		{
			id: 35,
			short: '刷新技能',
			desc: function () { return ("你重置其它技能的发动次数，然后删除此技能"); },
			run: function () {
				flags.skills.forEach(function (x) {
					if (x) x.time = x.max;
				})
				this.time = 0;
				core.checkSkill(-1);
			},
			args: [],
			awaken: true,
		},
		{
			id: 36,
			short: '耐久提升',
			desc: function () { return ("你令技能的发动次数上限加一(上限为10)，然后删除此技能"); },
			run: function () {
				if (core.getFlag('overload') || core.getFlag("maxCount") < 10) {
					core.addFlag("maxTime", 1);
					flags.skills.forEach(function (x) {
						if (x) x.max = flags.maxTime;
					})
				}
				this.time = 0;
				core.checkSkill(-1);
			},
			args: [],
			awaken: true,
		},
		{
			id: 37,
			short: '存储提升',
			desc: function () { return ("你令技能的存储数量上限加一(上限为10)"); },
			run: function () { if (core.getFlag('overload') || core.getFlag("maxCount") < 10) core.addFlag("maxCount", 1); },
			args: [],
			awaken: true,
		},
		{
			id: 38,
			short: '再抽一次',
			desc: function () { return ("你重新抽取一次技能，然后删除此技能"); },
			run: function () {
				core.insertCommonEvent(core.getFlag("ZiXuan") ? "自选技能" : "抽取技能");
				this.time = 0;
				core.checkSkill(-1);
			},
			args: [],
		},
		{
			id: 39,
			short: '选怪翻面',
			desc: function () { return ("你令至多" + this.args[0] + "个敌人翻面"); },
			run: function () {
				core.insertCommonEvent("选怪翻面", [this.args[0]]);
			},
			args: [1],
		},
		{
			id: 40,
			short: '均衡提升',
			desc: function () { return ("你获得" + this.args[0] + "个黄宝石和蓝血瓶"); },
			run: function () {
				core.getItem("yellowGem", this.args[0]);
				core.getItem("bluePotion", this.args[0]);
			},
			args: [1],
		},
		{
			id: 41,
			short: '攻击偷取',
			desc: function () { return ("你获得等同于伤害或金币值" + this.args[0] + "%的攻击(至少+1)"); },
			run: function (x) { core.status.hero.atk += Math.max(1, Math.floor(x * 0.01 * this.args[0])) },
			args: [1],
			data: 1,
		},
		{
			id: 42,
			short: '防御偷取',
			desc: function () { return ("你获得等同于伤害或金币值" + this.args[0] + "%的防御(至少+1)"); },
			run: function (x) { core.status.hero.def += Math.max(1, Math.floor(x * 0.01 * this.args[0])) },
			args: [1],
			data: 1,
		},
		{
			id: 43,
			short: '大量护盾',
			desc: function () { return ("你获得" + this.args[0] + "个绿宝石"); },
			run: function () {
				core.getItem("greenGem", this.args[0]);
			},
			args: [5],
		},
		{
			id: 44,
			short: '生命献祭',
			desc: function () { return (`你的生命变成1点，并根据消耗生命的${this.args[0]}%,${this.args[1]}%,${this.args[2]}%增加攻击,防御,护盾(在100w点生命时达到软上限)`); },
			run: function () {
				var d = hero.hp - 1;
				var softcap = 1e6;
				if (!core.getFlag('overload') && d >= softcap) {
					d = Math.floor(Math.sqrt(d / softcap) * softcap);
				}
				if (d > 0) {
					hero.hp = 1;
					hero.atk += Math.floor(d * 0.01 * this.args[0]);
					hero.def += Math.floor(d * 0.01 * this.args[1]);
					hero.mdef += Math.floor(d * 0.01 * this.args[2]);
					core.updateStatusBar();
				}
			},
			args: [1, 1, 3],
		},
		{
			id: 45,
			short: '生命重置',
			desc: function () { return ("你将生命补充至" + 800 * this.args[0] + "x区域倍率"); },
			run: function () {
				var d = 800 * this.args[0] * core.status.thisMap.ratio;
				if (d > hero.hp) hero.hp = d;
				core.updateStatusBar();
			},
			args: [1],
		},
	];
	this.coloredName1 = function (x) {
		if (typeof (x) == 'number') {
			x = core.plugin.skillList[x];
		}
		var res = ((core.getFlag("useShort") && x.short) ? x.short : x.desc());
		if (x.awaken) {
			return '(R)' + res;
		} else {
			return res;
		}
	}
	this.effectFullList = function () {
		var res = [];
		var tmp = '技能效果列表(R表示需要觉醒):\n';
		for (var i = 0; i < core.plugin.skillList.length; ++i) {
			var x = core.plugin.skillList[i];
			tmp = tmp + (i + 1).toString() + '.' + core.coloredName1(i);
			if (x.short) tmp = tmp + ":" + x.desc();
			if (i % 8 == 7) {
				res.push(tmp);
				tmp = '';
			} else {
				tmp = tmp + '\n';
			}
		}
		res.push(tmp);
		core.insertAction(res);
	}
},
    "发动时机": function () {
	//第一项：id
	//第二项：描述
	//第三项：提供的参数,1为伤害或金币值,2为物品名称
	//第四项：是否需要觉醒
	this.skillCondition = [
		[0, "切换楼层后"],
		[1, "开门后"],
		[2, "使用道具后", 2],
		[3, "你击杀怪物后", 1],
		[4, "拾取物品后", 2],
		[5, "对话后"],
		[6, "加点或供奉祭坛后"],
		[7, "你进入濒死状态时"],
		[8, "消耗金币后", 1],
		[9, "主动技"],
		[10, "到达新楼层后"],
		[11, "玩家或怪物翻面前"],
		[12, "你受到伤害后", 1],
		[13, "战斗前"],
		[14, "触发非本技能时", null, true],
		[15, "你摸牌获得物品后", 2]
	];
	this.conditionName = function (x) {
		return core.plugin.skillCondition[x][1];
	}
	this.conditionData = function (x) {
		return (core.plugin.skillCondition[x][2] || 0);
	}
	this.satisfyCondition = function (x) {
		if (typeof x == "number") x = core.plugin.skillList[x];
		var y = core.getFlag("condition", 0);
		return (core.getFlag("awaken") || !x.awaken) && (!x.data || x.data == core.conditionData(y));
	}
	this.needAwaken = function (x) {
		return core.plugin.skillCondition[x].length == 4;
	}
	this.coloredName = function (x) {
		if (core.needAwaken(x)) {
			return "(R)" + core.conditionName(x);
		} else {
			return core.conditionName(x);
		}
	}
	this.conditionFullList = function () {
		var res = [];
		var tmp = '技能发动时机列表(R表示需要觉醒):\n';
		for (var i = 0; i < core.plugin.skillCondition.length; ++i) {
			tmp = tmp + `${i+1}.${core.coloredName(i)}`;
			if (i % 10 == 9) {
				res.push(tmp);
				tmp = '';
			} else {
				tmp = tmp + '\n';
			}
		}
		res.push(tmp);
		core.insertAction(res);
	}
},
    "获取和使用技能": function () {
	this.generateSkill = function (condition, effect) {
		var skill = core.clone(core.plugin.skillList[effect]);
		skill.time = core.getFlag("maxTime");
		skill.max = core.getFlag("maxTime");
		skill.condition = condition;
		return skill;
	}
	this.runSkill = function (x, arg) {
		core.plugin.skillList[x.id].run.call(x, arg);
	}
	this.checkSkill = function (condition, arg) {
		if (core.getFlag("inverted")) return;
		for (var i = 0; i < flags.skills.length; ++i) {
			var x = flags.skills[i];
			if (x == null) continue;
			if (x.condition == condition && x.time > 0) {
				x.time = x.time - 1;
				core.runSkill(x, arg);
				if (condition != 14) core.checkSkill(14);
			}
			if (x.time == 0) {
				delete flags.skills[i];
			}
		}
	}
	this.useSkill = function (x) {
		if (core.getFlag("inverted")) {
			core.drawTip("翻面时不能使用技能");
			return;
		}
		var y = flags.skills[x];
		if (y.condition == 9 && y.time > 0) {
			y.time -= 1;
			core.runSkill(y);
			core.checkSkill(14);
		}
		if (y.time == 0) {
			delete flags.skills[x];
		}
	}
	this.getSkillDescription = function (x) {
		if (x == null) return '[无]';
		var y = core.plugin.skillList[x.id];
		return (`(${x.time}/${x.max})${core.conditionName(x.condition)}，${y.desc.call(x)}`);
	}
	this.getShortDescription = function (x) {
		if (x == null) return '[无]';
		var y = core.plugin.skillList[x.id];
		if (core.getFlag("useShort") && y.short) return (`(${x.time}/${x.max})${core.conditionName(x.condition)}，发动${y.short}`);
		else return (`(${x.time}/${x.max})${core.conditionName(x.condition)}，${y.desc.call(x)}`);
	}
}
}