main.floors.MToutside=
{
    "floorId": "MToutside",
    "title": "塔外",
    "name": "塔外",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "cannotViewMap": false,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "firstArrive": [
        {
            "type": "tip",
            "text": "游戏已重启"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,10": [
            "\t[hero]就是这里了......\n攻进去!",
            {
                "type": "hide",
                "remove": true
            }
        ],
        "10,6": [
            "物品爆率如下：\n红、蓝、黄、绿宝石：各7%\n红、蓝、黄、绿血瓶：各7%\n红、蓝、黄、绿钥匙：各6%\n破墙镐、炸弹、飞行器、上楼器、下楼器、圣水：各2%\n幸运金币、十字架、屠龙匕、大黄门钥匙、地震卷轴：各1%\n铁剑、铁盾、银剑、银盾：各0.5%\n骑士剑、骑士盾、圣剑、圣盾：各0.2%\n神圣剑、神圣盾：各0.1%"
        ],
        "10,5": [
            {
                "type": "function",
                "function": "function(){\ncore.effectFullList();\n}"
            }
        ],
        "10,4": [
            {
                "type": "function",
                "function": "function(){\ncore.conditionFullList();\n}"
            }
        ],
        "10,2": [
            "本改版说明：\n每到达一个新的楼层，你都可以抽取一次技能触发时机和一次技能效果\n你最多可同时持有2个技能，每个技能初始最多使用3次\n当技能数量超出上限时，你必须放弃新技能或替换一个已有技能\n部分技能效果需要参数，必须选择能提供参数的触发时机才能选择\n需要条件的技能，不管是否发动成功，都会扣除使用次数",
            "物品修改：\n绿宝石提供3护盾\n黄宝石=红+蓝+绿\n绿钥匙为万能钥匙，可以开启所有的门(包括机关门)\n十字架、屠龙匕、幸运金币可持有多个，效果加算\n十字架额外提供5%防御，屠龙匕额外提供5%攻击\n圣水削弱为5倍攻防和",
            "战斗机制修改：\n已破防的怪物可以强制战斗，战斗时血可以扣成负值，此时会进入濒死状态\n濒死时只能使用圣水回血\n当你首次进入濒死状态时，你发动觉醒技，技能持有上限+1，并解锁更多触发时机和效果\n如果不想死可以消耗金币觉醒",
            "地图修改：\n为防止技能浪费，21-29楼被隐藏并重新装修\n28楼的商人移到30楼回收各种钥匙\n对骑士剑盾的机关做了修改\n36有暗道、48有警卫",
            "其它改动：\n对话不能穿墙，但可从其他地方获得这个效果\n开门和战斗不再重置穿墙\n时空之门要打败假魔王和大法师才能开启\n有快捷商店，商店倍率取最大值\n2F的小偷要和15F小偷对话之后才会出现",
            "关于结局：\n本塔只有一个结局：击败50F魔王\n根据难度和是否自选技能分为5*2=10个榜单\n最后得分为(生命/100+攻击+防御)，向下取整"
        ],
        "10,3": [
            "名词解释：\n\\d翻面\\d：玩家翻面时，无法使用技能，且战斗回合数*2，战斗后恢复\n怪物翻面时，将被隐藏并触发其战后事件，切换楼层后恢复\n大法师和魔王无法被翻面\n\\d加点\\d：等同于一次不消耗金币的商店加点，不过生命回复固定为200*区域倍率\n\\d该数值\\d：指技能触发时机中击杀怪物时造成的伤害、受到的伤害或消耗的金币",
            "\\d摸牌\\d：获得一个随机物品，包括基本物品和道具，具体概率见第5个木牌\n\\d基本物品\\d：指宝石、血瓶和钥匙，其倍率为当前区域倍率\n\\d道具\\d：指剑盾和道具栏显示的12个道具(不包括手册笔记楼传)\n\\d弃牌\\d：移除一把钥匙，或扣除本区域宝石或蓝血瓶对应的属性;",
            "\\d物品颜色\\d： 基本物品的颜色为它本身的颜色，其它道具的颜色如下：\n红色：炸弹、上楼器\n黄色：破墙镐、十字架、飞行器、幸运金币、地震卷轴、大黄门钥匙、骑士剑、骑士盾\n蓝色：下楼器、圣水、铁剑、铁盾、神圣剑、神圣盾\n绿色：圣剑、圣盾\n无色：屠龙匕、雪花、银剑、银盾"
        ],
        "2,2": [
            {
                "type": "while",
                "condition": "true",
                "data": [
                    {
                        "type": "choices",
                        "text": "\t[神秘人,N332]这里可以修改游戏模式\n注意：进入魔塔之后就无法再次修改",
                        "choices": [
                            {
                                "text": "查看随机种子",
                                "action": [
                                    {
                                        "type": "while",
                                        "condition": "true",
                                        "data": [
                                            {
                                                "type": "choices",
                                                "text": "\t[神秘人,N332]当前随机种子为：${flag:__rand__}",
                                                "choices": [
                                                    {
                                                        "text": "重新随机",
                                                        "condition": "!core.hasVisitedFloor(\"MT1\")",
                                                        "action": [
                                                            {
                                                                "type": "function",
                                                                "function": "function(){\ncore.rand();\n}"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "text": "手动输入",
                                                        "condition": "!core.hasVisitedFloor(\"MT1\")",
                                                        "action": [
                                                            {
                                                                "type": "input",
                                                                "text": "请输入一个正整数，范围在1~2147483646之间"
                                                            },
                                                            {
                                                                "type": "setValue",
                                                                "name": "flag:input",
                                                                "operator": "max=",
                                                                "value": "1"
                                                            },
                                                            {
                                                                "type": "setValue",
                                                                "name": "flag:input",
                                                                "operator": "min=",
                                                                "value": "2147483646"
                                                            },
                                                            {
                                                                "type": "setValue",
                                                                "name": "flag:__rand__",
                                                                "value": "flag:input"
                                                            }
                                                        ]
                                                    },
                                                    {
                                                        "text": "返回",
                                                        "action": [
                                                            {
                                                                "type": "break",
                                                                "n": 1
                                                            }
                                                        ]
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "text": "游戏难度：${core.difficultyText()}",
                                "need": "!core.hasVisitedFloor(\"MT1\")",
                                "action": [
                                    "\t[神秘人,N332]\r[#c0c0c0]乱撞\r：怪物属性1倍\n\r[#add8e6]简单\r：怪物属性1.2倍\n\r[#90ee90]普通\r：怪物属性1.5倍\n\r[#ffc088]较难\r：怪物属性1.5倍，且每层额外+0.02倍\n\r[#ff9999]极难\r：\"较难\"的基础上，血瓶倍率-40%，商店价格+50%，技能使用次数-1",
                                    {
                                        "type": "choices",
                                        "text": "\t[神秘人,N332]难度选择",
                                        "choices": [
                                            {
                                                "text": "乱撞",
                                                "color": [
                                                    192,
                                                    192,
                                                    192
                                                ],
                                                "condition": "!core.hasVisitedFloor(\"MT1\")",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "flag:difficulty",
                                                        "value": "0"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "简单",
                                                "color": [
                                                    173,
                                                    216,
                                                    230
                                                ],
                                                "condition": "!core.hasVisitedFloor(\"MT1\")",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "flag:difficulty",
                                                        "value": "1"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "普通",
                                                "color": [
                                                    144,
                                                    238,
                                                    144
                                                ],
                                                "condition": "!core.hasVisitedFloor(\"MT1\")",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "flag:difficulty",
                                                        "value": "2"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "较难",
                                                "color": [
                                                    255,
                                                    192,
                                                    136
                                                ],
                                                "condition": "!core.hasVisitedFloor(\"MT1\")",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "flag:difficulty",
                                                        "value": "3"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "极难",
                                                "color": [
                                                    255,
                                                    153,
                                                    153
                                                ],
                                                "condition": "!core.hasVisitedFloor(\"MT1\")",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "flag:difficulty",
                                                        "value": "4"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "返回",
                                                "action": []
                                            }
                                        ]
                                    }
                                ]
                            },
                            {
                                "text": "技能选取模式：${flag:ZiXuan?'自选':'抽取'}",
                                "need": "!core.hasVisitedFloor(\"MT1\")",
                                "action": [
                                    {
                                        "type": "setValue",
                                        "name": "flag:ZiXuan",
                                        "value": "(!flag:ZiXuan)"
                                    }
                                ]
                            },
                            {
                                "text": "返回",
                                "action": [
                                    {
                                        "type": "break",
                                        "n": 1
                                    }
                                ]
                            },
                            {
                                "text": "娱乐模式选项",
                                "need": "!core.hasVisitedFloor(\"MT1\")",
                                "action": [
                                    "\t[神秘人,N332]\r[#ded0ff]失衡模式\r：在此模式中，一切限制都被移除，使用特定的技能组合能轻松将分数刷到几万亿甚至更高。玩家承担开启此模式带来的一切后果。",
                                    {
                                        "type": "choices",
                                        "text": "\t[神秘人,N332]",
                                        "choices": [
                                            {
                                                "text": "开启失衡模式",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "flag:overload",
                                                        "value": "true"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "关闭失衡模式",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "flag:overload",
                                                        "value": "false"
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ],
        "3,2": [
            {
                "type": "choices",
                "text": "\t[奸商,fairy]给我${2000*core.shopMult()}金币，我就帮你觉醒技能",
                "choices": [
                    {
                        "text": "我太需要了",
                        "action": [
                            {
                                "type": "if",
                                "condition": "(status:money>=2000*core.shopMult())",
                                "true": [
                                    {
                                        "type": "if",
                                        "condition": "flag:awaken",
                                        "true": [
                                            "\t[奸商,fairy]你已经觉醒过技能了！",
                                            {
                                                "type": "hide",
                                                "remove": true
                                            }
                                        ],
                                        "false": [
                                            {
                                                "type": "setValue",
                                                "name": "status:money",
                                                "operator": "-=",
                                                "value": "2000*core.shopMult()"
                                            },
                                            {
                                                "type": "insert",
                                                "name": "濒死"
                                            },
                                            {
                                                "type": "hide",
                                                "remove": true
                                            }
                                        ]
                                    }
                                ],
                                "false": [
                                    "\t[奸商,fairy]你的金币不足！"
                                ]
                            }
                        ]
                    },
                    {
                        "text": "下次再说",
                        "action": []
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "beforeBattle": {},
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "autoEvent": {},
    "cannotMove": {},
    "cannotMoveIn": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 87,  1,  1,  1,  1,  1,  1],
    [  1,  1,332,124,  1,  1,  0,  1,  1,  0,129,  1,  1],
    [  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,129,  1,  1],
    [  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,129,  1,  1],
    [  1,  1,  0,  0,  0, 45, 73, 46,  0,  0,129,  1,  1],
    [  1,  1,  0,  0,  0,  0,  0,  0,  0,  0,129,  1,  1],
    [  1,  1,  1,  1,  1,  1, 86,  1,  1,  1,  1,  1,  1],
    [  1,  1,  5,  1,  5,  1, 24,  1,  5,  1,  5,  1,  1],
    [  1,  5,  5,  5,  5,  1,  0,  1,  5,  5,  5,  5,  1],
    [  1,  5,  5,  5,  5,  1,  0,  1,  5,  5,  5,  5,  1],
    [  1,  5,  5,  5,  5,  1,  0,  1,  5,  5,  5,  5,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [

],
    "fgmap": [

]
}