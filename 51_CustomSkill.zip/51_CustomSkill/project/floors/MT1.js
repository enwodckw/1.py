main.floors.MT1=
{
    "floorId": "MT1",
    "title": "魔塔 第01层",
    "name": "第 1 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,226,201,202,201,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1, 31,  0,  0, 81,  0,  1, 27, 21,  0,  1,  0,  1],
    [  1,  0,209,  0,  1,  0,  1, 28, 31,  0,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  1,  1,  1, 81,  1,  0,  1],
    [  1, 21,  0,  0,  1,  0, 81,205,217,205,  1,  0,  1],
    [  1,  0,210,  0,  1,  0,  1,  1,  1,  1,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1,  0,  1,  1,  1, 81,  1,  1],
    [  1, 31,  0, 21,  1, 21,  0, 34,  1,  0,205,  0,  1],
    [  1, 31, 32, 21,  1,  0, 88,  0,  1,201, 32,201,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [
        {
            "type": "if",
            "condition": "(flag:difficulty==4)",
            "true": [
                {
                    "type": "setValue",
                    "name": "flag:maxTime",
                    "operator": "-=",
                    "value": "1"
                }
            ]
        },
        {
            "type": "if",
            "condition": "flag:skipAnimate",
            "true": [
                {
                    "type": "setValue",
                    "name": "flag:nowWeapon",
                    "value": "null"
                },
                {
                    "type": "setValue",
                    "name": "flag:nowShield",
                    "value": "null"
                },
                {
                    "type": "setValue",
                    "name": "status:atk",
                    "operator": "-=",
                    "value": "90"
                },
                {
                    "type": "setValue",
                    "name": "status:def",
                    "operator": "-=",
                    "value": "90"
                },
                {
                    "type": "closeDoor",
                    "id": "yellowDoor",
                    "loc": [
                        6,
                        9
                    ]
                }
            ],
            "false": [
                {
                    "type": "show",
                    "loc": [
                        [
                            2,
                            1
                        ]
                    ],
                    "time": 300
                },
                "\t[yellowKnight]你来到了魔塔，这表明你是个勇士，但现在游戏结束了，我将在这里亲手没收你的剑盾",
                {
                    "type": "move",
                    "loc": [
                        2,
                        1
                    ],
                    "time": 100,
                    "keep": true,
                    "steps": [
                        "right:9",
                        "down:7",
                        "left:5",
                        "down:2"
                    ]
                },
                {
                    "type": "setValue",
                    "name": "flag:nowWeapon",
                    "value": "null"
                },
                {
                    "type": "setValue",
                    "name": "flag:nowShield",
                    "value": "null"
                },
                {
                    "type": "setValue",
                    "name": "status:atk",
                    "operator": "-=",
                    "value": "90"
                },
                {
                    "type": "setValue",
                    "name": "status:def",
                    "operator": "-=",
                    "value": "90"
                },
                {
                    "type": "move",
                    "loc": [
                        6,
                        10
                    ],
                    "time": 100,
                    "keep": true,
                    "steps": [
                        "up:2"
                    ]
                },
                {
                    "type": "closeDoor",
                    "id": "yellowDoor",
                    "loc": [
                        6,
                        9
                    ]
                },
                {
                    "type": "move",
                    "loc": [
                        6,
                        8
                    ],
                    "time": 100,
                    "keep": true,
                    "steps": [
                        "right:5",
                        "up:7",
                        "left:9"
                    ]
                },
                "\t[yellowKnight]你以为你已经非常强大了吗？嘿嘿错了，只是我现在不想打你罢了。我走了，有本事到32楼与我再打一次"
            ]
        },
        {
            "type": "hide",
            "loc": [
                [
                    2,
                    1
                ]
            ],
            "remove": true,
            "time": 300
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "2,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        }
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        2,
        1
    ],
    "downFloor": [
        6,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}