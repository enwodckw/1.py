main.floors.MT24=
{
    "floorId": "MT24",
    "title": "魔塔 第24层",
    "name": "第 24 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 22,  0,  0,  0,  4,  0,  4,  0,  0,  0, 34,  1],
    [  1,  0,259,  0,  1,  1,  1,  1,  1,  0,259,  0,  1],
    [  1,  0,  0,  1,  1,  1,  1,  1,  1,  1,  0,  0,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,242,  1,  1,  1,231,  0,231,  1,  1,  1,254,  1],
    [  1, 30, 81, 82, 81,  0,  0,  0, 81, 82, 81, 28,  1],
    [  1,242,  1,  1,  1,  0,  0,  0,  1,  1,  1,254,  1],
    [  1,  0,  1,  1,  1,  1, 83,  1,  1,  1,  1,  0,  1],
    [  1,  0,  0, 81,  1,  1,236,  1,  1,  1,  0,  0,  1],
    [  1,  0, 87,  0,  1,  1,  0,  1,  1,  0,243,  0,  1],
    [  1, 88,  0,  0,  0,241, 27,241,  0,  0,  0, 29,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "section3.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "setCurtain",
                    "color": [
                        0,
                        0,
                        0
                    ],
                    "time": 200,
                    "keep": true
                },
                {
                    "type": "for",
                    "name": "temp:A",
                    "from": "24",
                    "to": "50",
                    "step": "1",
                    "data": [
                        {
                            "type": "function",
                            "function": "function(){\ncore.ui.statusBar._update_props(core.floors[\"MT\" + core.calValue(\"temp:A\")].title)\n}"
                        },
                        {
                            "type": "sleep",
                            "time": 80
                        }
                    ]
                },
                {
                    "type": "changeFloor",
                    "floorId": "MT50",
                    "loc": [
                        6,
                        7
                    ],
                    "direction": "down",
                    "time": 200
                },
                {
                    "type": "setCurtain",
                    "time": 200
                }
            ]
        }
    },
    "changeFloor": {
        "2,10": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        2,
        11
    ],
    "downFloor": [
        2,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}