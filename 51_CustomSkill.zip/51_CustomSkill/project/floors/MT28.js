main.floors.MT28=
{
    "floorId": "MT28",
    "title": "魔塔 第28层",
    "name": "第 28 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,231,  0,231, 81, 21, 30, 21, 81,233,  0,233,  1],
    [  1,  0, 85,  0,  1,  0, 31,  0,  1,  0,124,  0,  1],
    [  1,231,  0,231,  1,333,333,333,  1,233,  0,233,  1],
    [  1,  1, 81,  1,  1,333, 33,333,  1,  1, 82,  1,  1],
    [  1,  0,  0,333,333,333,259,333,333,333,  0,  0,  1],
    [  1,  0,  0,333, 27,236, 23,254, 28,333,  0,  0,  1],
    [  1,  0,  0,333,333,333,241,333,333,333,  0,  0,  1],
    [  1,  0,  0,  0,  0,333,241,333,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,333, 29,333,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,333, 81,333,  0,  0,  0,  0,  1],
    [  1, 87,  0,  0,  0,  0,  0,  0,  0,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "section3.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "10,2": [
            {
                "type": "openShop",
                "id": "shop3",
                "open": true
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "1,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT28_4_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT28_4_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,1": [
            {
                "type": "setValue",
                "name": "flag:door_MT28_4_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT28_4_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {
        "2,2": [
            {
                "type": "setBlock",
                "number": "superPotion"
            }
        ]
    },
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        2,
        11
    ],
    "downFloor": [
        10,
        11
    ],
    "autoEvent": {
        "2,2": {
            "0": {
                "condition": "flag:door_MT28_4_4==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT28_4_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}