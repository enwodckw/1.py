main.floors.MT21=
{
    "floorId": "MT21",
    "title": "魔塔 第21层",
    "name": "第 21 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 27, 28, 31,  1,  0, 88,  0,  1, 22, 21, 21,  1],
    [  1, 27, 28, 31,  1, 21,  0,121,  1, 22, 21, 21,  1],
    [  1,259,242,  1,  1,  1, 81,  1,  1,  1,242,259,  1],
    [  1,  1, 82,  1,  1, 30,  0, 30,  1,  1, 82,  1,  1],
    [  1, 32,  0,  1,  0,  0,  0,  0,  0,  1,  0, 32,  1],
    [  1,  0,241, 81,  0,  0, 33,  0,  0, 81,241,  0,  1],
    [  1, 28,  0,  1,  0,  0,  0,  0,  0,  1,  0, 27,  1],
    [  1, 81,  1,  1,  1,233,  0,233,  1,  1,  1, 81,  1],
    [  1,243,  0,  1,  1,  1, 85,  1,  1,  1,  0,254,  1],
    [  1,  0,  0,  0,  1,231,  0,231,  1,  0,  0,  0,  1],
    [  1, 21,  0,243, 81,  0, 87,  0, 81,254,  0, 21,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 8,
    "defaultGround": "ground",
    "bgm": "section3.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT21_6_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT21_6_9",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        6,
        10
    ],
    "downFloor": [
        6,
        2
    ],
    "autoEvent": {
        "6,9": {
            "0": {
                "condition": "flag:door_MT21_6_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT21_6_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}