main.floors.MT35=
{
    "floorId": "MT35",
    "title": "魔塔 第35层",
    "name": "第 35 层",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,8": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [],
                "false": [
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            6,
                            9
                        ]
                    }
                ]
            },
            {
                "type": "hide",
                "remove": true
            }
        ]
    },
    "changeFloor": {},
    "afterBattle": {
        "6,7": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "snow",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT13"
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "5,7": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "snow",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT13"
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "7,7": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "snow",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT13"
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "5,6": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "snow",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT13"
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "6,6": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "snow",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT13"
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "7,6": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "snow",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT13"
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "5,5": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "snow",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT13"
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "6,5": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "snow",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT13"
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "7,5": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 5],\n\t[6, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n\t[5, 7],\n\t[6, 7],\n\t[7, 7],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "snow",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                6,
                                10
                            ]
                        ],
                        "floorId": "MT13"
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 87,  1],
    [  1,  3,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1,  1],
    [  1,  3,  1,  3,  1, 32, 32, 32,  1,  1,  1,  1,  1],
    [  1,  3,  1,  3,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  3,  1,  3,  1,342,343,344,  1,  1,  1,  1,  1],
    [  1,  3,  1,  3,  1,345,346,347,  1,  1,  1,  1,  1],
    [  1,  3,  1,  3,  1,348,257,349,  1,  1,  1,  1,  1],
    [  1,  3,  1,  3,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  3,  1,  3,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,  3,  1,  3,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  3,  3,  3,  1,  0, 88,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "downFloor": [
        6,
        10
    ],
    "upFloor": [
        10,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}