main.floors.MT10=
{
    "floorId": "MT10",
    "title": "魔塔 第10层",
    "name": "第 10 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,209,209,209,  1,  1,  0,  1,  1,209,209,209,  1],
    [  1,  0,210,  0, 85,  0,211,  0, 85,  0,210,  0,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,209, 28,209,  1,  1,  0,  1,  1,209, 27,209,  1],
    [  1,  0,210,  0,  1,  1,  0,  1,  1,  0,210,  0,  1],
    [  1,  0,  0,  0,  1,  1,  0,  1,  1,  0,  0,  0,  1],
    [  1, 81,  1, 81,  1,  1, 83,  1,  1, 81,  1, 81,  1],
    [  1,  0,  1,  0,  1,  0,  0,  0,  1,  0,  1,  0,  1],
    [  1, 88,  1,  0,217,  0,  0,  0,217,  0,  1, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,5": [
            {
                "type": "if",
                "condition": "(blockCls:6,4===\"enemys\")",
                "true": [
                    {
                        "type": "if",
                        "condition": "(blockCls:6,1===\"enemys\")",
                        "true": [],
                        "false": [
                            {
                                "type": "closeDoor",
                                "id": "specialDoor",
                                "loc": [
                                    6,
                                    7
                                ],
                                "async": true
                            },
                            {
                                "type": "playSound",
                                "name": "10F.mp3"
                            },
                            {
                                "type": "openDoor",
                                "loc": [
                                    4,
                                    4
                                ],
                                "async": true
                            },
                            {
                                "type": "openDoor",
                                "loc": [
                                    8,
                                    4
                                ],
                                "async": true
                            },
                            {
                                "type": "setBlock",
                                "number": "0",
                                "loc": [
                                    [
                                        5,
                                        6
                                    ]
                                ]
                            },
                            {
                                "type": "setBlock",
                                "number": "0",
                                "loc": [
                                    [
                                        7,
                                        6
                                    ]
                                ]
                            },
                            {
                                "type": "waitAsync"
                            },
                            "\t[骷髅队长,skeletonCaptain]哈哈哈 你是如此的幸运能安全到达这里 但现在好运离你而去了 你中埋伏了 弟兄们给我上",
                            {
                                "type": "playBgm",
                                "name": "boss1.mp3"
                            },
                            {
                                "type": "move",
                                "loc": [
                                    6,
                                    4
                                ],
                                "time": 200,
                                "keep": true,
                                "async": true,
                                "steps": [
                                    "up:3"
                                ]
                            },
                            {
                                "type": "move",
                                "loc": [
                                    2,
                                    4
                                ],
                                "time": 200,
                                "keep": true,
                                "async": true,
                                "steps": [
                                    "right:3",
                                    "down:2",
                                    "right:1"
                                ]
                            },
                            {
                                "type": "move",
                                "loc": [
                                    10,
                                    4
                                ],
                                "time": 200,
                                "keep": true,
                                "async": true,
                                "steps": [
                                    "left:4"
                                ]
                            },
                            {
                                "type": "sleep",
                                "time": 600
                            },
                            {
                                "type": "move",
                                "loc": [
                                    3,
                                    3
                                ],
                                "time": 200,
                                "keep": true,
                                "async": true,
                                "steps": [
                                    "down:1",
                                    "right:2",
                                    "down:2"
                                ]
                            },
                            {
                                "type": "move",
                                "loc": [
                                    9,
                                    3
                                ],
                                "time": 200,
                                "keep": true,
                                "async": true,
                                "steps": [
                                    "down:1",
                                    "left:2",
                                    "down:2"
                                ]
                            },
                            {
                                "type": "sleep",
                                "time": 200
                            },
                            {
                                "type": "move",
                                "loc": [
                                    2,
                                    3
                                ],
                                "time": 200,
                                "keep": true,
                                "async": true,
                                "steps": [
                                    "down:1",
                                    "right:3",
                                    "down:1"
                                ]
                            },
                            {
                                "type": "move",
                                "loc": [
                                    10,
                                    3
                                ],
                                "time": 200,
                                "keep": true,
                                "async": true,
                                "steps": [
                                    "down:1",
                                    "left:3",
                                    "down:1"
                                ]
                            },
                            {
                                "type": "sleep",
                                "time": 200
                            },
                            {
                                "type": "move",
                                "loc": [
                                    1,
                                    3
                                ],
                                "time": 200,
                                "keep": true,
                                "async": true,
                                "steps": [
                                    "down:1",
                                    "right:4"
                                ]
                            },
                            {
                                "type": "move",
                                "loc": [
                                    11,
                                    3
                                ],
                                "time": 200,
                                "keep": true,
                                "async": true,
                                "steps": [
                                    "down:1",
                                    "left:4"
                                ]
                            },
                            {
                                "type": "waitAsync"
                            },
                            {
                                "type": "closeDoor",
                                "id": "specialDoor",
                                "loc": [
                                    4,
                                    4
                                ],
                                "async": true
                            },
                            {
                                "type": "closeDoor",
                                "id": "specialDoor",
                                "loc": [
                                    6,
                                    3
                                ],
                                "async": true
                            },
                            {
                                "type": "closeDoor",
                                "id": "specialDoor",
                                "loc": [
                                    8,
                                    4
                                ],
                                "async": true
                            },
                            {
                                "type": "waitAsync"
                            }
                        ]
                    }
                ]
            },
            {
                "type": "hide",
                "remove": true
            }
        ],
        "6,2": [
            {
                "type": "if",
                "condition": "(blockCls:6,1===\"enemys\")",
                "true": [
                    "\t[骷髅队长,skeletonCaptain]你怎能杀出重围 我是绝不会让你通过的 来吧 我要与你决斗"
                ]
            },
            {
                "type": "hide",
                "remove": true
            }
        ],
        "6,9": [
            {
                "type": "if",
                "condition": "(blockCls:6,9===\"enemys\")",
                "true": [],
                "false": [
                    {
                        "type": "if",
                        "condition": "(blockCls:6,4===\"enemys\")",
                        "true": [],
                        "false": [
                            {
                                "type": "setBlock",
                                "number": "thief",
                                "loc": [
                                    [
                                        1,
                                        10
                                    ]
                                ],
                                "time": 500
                            },
                            {
                                "type": "openDoor",
                                "loc": [
                                    1,
                                    9
                                ]
                            },
                            {
                                "type": "move",
                                "loc": [
                                    1,
                                    10
                                ],
                                "time": 200,
                                "keep": true,
                                "steps": [
                                    "up:2",
                                    "right:2"
                                ]
                            },
                            {
                                "type": "openDoor",
                                "loc": [
                                    3,
                                    9
                                ]
                            },
                            {
                                "type": "move",
                                "loc": [
                                    3,
                                    8
                                ],
                                "time": 200,
                                "keep": true,
                                "steps": [
                                    "down:3",
                                    "right:2",
                                    "up:1",
                                    "right:1"
                                ]
                            },
                            "\t[小偷,thief]嘿，虽然我没见过你，但是你竟然打败了这个区域的头目，真是厉害！我之前一直在担心怎么上楼呢。",
                            "\t[小偷,thief]哦，我听说11楼有一把盾，17楼有一把剑。和盾比起来，还是先拿剑比较好，所以得巧妙地避开强敌。\n我先走一步了。",
                            {
                                "type": "move",
                                "loc": [
                                    6,
                                    10
                                ],
                                "time": 200,
                                "steps": [
                                    "down:1"
                                ]
                            },
                            {
                                "type": "waitAsync"
                            },
                            {
                                "type": "hide",
                                "remove": true,
                                "time": 0
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {},
    "afterBattle": {
        "5,4": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 4],\n\t[6, 4],\n\t[7, 4],\n\t[5, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ]
            }
        ],
        "5,5": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 4],\n\t[6, 4],\n\t[7, 4],\n\t[5, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ]
            }
        ],
        "5,6": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 4],\n\t[6, 4],\n\t[7, 4],\n\t[5, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ]
            }
        ],
        "6,6": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 4],\n\t[6, 4],\n\t[7, 4],\n\t[5, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ]
            }
        ],
        "7,6": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 4],\n\t[6, 4],\n\t[7, 4],\n\t[5, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ]
            }
        ],
        "7,4": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 4],\n\t[6, 4],\n\t[7, 4],\n\t[5, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ]
            }
        ],
        "7,5": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 4],\n\t[6, 4],\n\t[7, 4],\n\t[5, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ]
            }
        ],
        "6,4": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 4],\n\t[6, 4],\n\t[7, 4],\n\t[5, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        6,
        10
    ],
    "downFloor": [
        1,
        10
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}