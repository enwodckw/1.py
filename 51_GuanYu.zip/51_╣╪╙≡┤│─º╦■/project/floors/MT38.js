main.floors.MT38=
{
    "floorId": "MT38",
    "title": "魔塔 第38层",
    "name": "第 38 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0, 83,216,  0,  0,  0,216, 81,  0, 87,  1],
    [  1,  0,  0,  1, 21,  0,122,  0,  0,  1,  0,  0,  1],
    [  1,212,  1,  1,  1,225,  1, 81,  1,  1,  1, 81,  1],
    [  1,  0,  0,  0,  1,225,  1,  0,  1, 21,  1,  0,  1],
    [  1,  1,  0,  1,  1, 82,  1,  0,  1, 21,  1,  0,  1],
    [  1,  0,  0,  0, 82, 82,  1,212,  1, 21,  1,212,  1],
    [  1,  0, 40,  0,  1,  1,  1,224,  1,  0,227,  0,  1],
    [  1,  0,  0,  0,  1, 28, 31,  0,  1,  1,  1, 81,  1],
    [  1,  1, 85,  1,  1,  1,  1,  1,  1, 21,  0,212,  1],
    [  1,222,  0,222,  1,  0,  0,  0,  1,  0,227,  0,  1],
    [  1,  0,  0,  0, 81,224,  0,213, 81,225,  0, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "2,6": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[1, 10],\n\t[3, 10],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [],
                "false": [
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            2,
                            5
                        ]
                    }
                ]
            },
            {
                "type": "hide",
                "remove": true
            }
        ]
    },
    "changeFloor": {},
    "afterBattle": {
        "1,10": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[1, 10],\n\t[3, 10],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            5
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ],
                        "remove": true
                    }
                ]
            }
        ],
        "3,10": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[1, 10],\n\t[3, 10],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            5
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ],
                        "remove": true
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        10,
        1
    ],
    "downFloor": [
        2,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}