main.floors.MT32=
{
    "floorId": "MT32",
    "title": "魔塔 第32层",
    "name": "第 32 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 28,  0, 82,  0,  0,  0,  0,  0,  0,  0, 87,  1],
    [  1,  0, 27,  1,  1,  1,  0,  1,  1,  1,  0,  0,  1],
    [  1, 81,  1,  1,  0, 81,  0, 81,  0,  1,  1,  1,  1],
    [  1,225,  0,216,  0,  1,  0,  1,212,  1, 21, 32,  1],
    [  1,  0, 21,  0,216,  1,  0,  1,  0, 81,  0, 21,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,227,  1,  1,  1,  1],
    [  1, 21, 21, 21, 21,  1,  0,  1,  0, 81,  0, 21,  1],
    [  1, 22,  0,  1,  1,  1,  0,  1,  1,  1, 21, 22,  1],
    [  1,  1, 85,  1,  0,  0,  0,  0,  0,  1,  1,  1,  1],
    [  1,222,  0,222,  0,  1,  0,  1,  0,  7,131,  8,  1],
    [  1,  0,  0,  0,  0,  1, 88,  1,212,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,9": [
            {
                "type": "setBlock",
                "number": "yellowKnight",
                "loc": [
                    [
                        10,
                        1
                    ]
                ],
                "time": 500
            },
            {
                "type": "move",
                "loc": [
                    10,
                    1
                ],
                "time": 200,
                "keep": true,
                "steps": [
                    "left:4"
                ]
            },
            "\t[骑士队长,yellowKnight]你打败了前2个区域的头目 这表明你是个勇士 但现在游戏结束了 我将在这里亲手杀死你",
            {
                "type": "move",
                "loc": [
                    6,
                    1
                ],
                "time": 200,
                "keep": true,
                "steps": [
                    "down:7"
                ]
            },
            {
                "type": "function",
                "function": "function(){\nlet floorId = core.status.floorId,\n\tx = 6,\n\ty = 8;\nlet id = core.getBlockId(x, y, floorId),\n\tattribute = 'special';\nlet a = core.getEnemyValue(id, attribute, x, y, floorId) || [];\nif (typeof a === \"number\") a = [a]\nlet b = a.slice();\nb.push(1)\ncore.setEnemyOnPoint(x, y, floorId, attribute, b);\n}"
            },
            {
                "type": "callBook"
            },
            {
                "type": "battle",
                "loc": [
                    6,
                    8
                ]
            },
            {
                "type": "setBlock",
                "number": "yellowKnight",
                "loc": [
                    [
                        6,
                        8
                    ]
                ],
                "time": 0
            },
            {
                "type": "move",
                "loc": [
                    6,
                    8
                ],
                "time": 200,
                "keep": true,
                "steps": [
                    "up:7"
                ]
            },
            "\t[骑士队长,yellowKnight]你以为你已非常强大了吗 嘿嘿错了 只是我今天状态不佳而已 我走了 有本事到40楼与我再打一次",
            {
                "type": "move",
                "loc": [
                    6,
                    1
                ],
                "time": 200,
                "steps": [
                    "right:5"
                ]
            },
            {
                "type": "hide",
                "remove": true,
                "time": 0
            }
        ]
    },
    "changeFloor": {},
    "afterBattle": {
        "1,10": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[1, 10],\n\t[3, 10],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    }
                ]
            }
        ],
        "3,10": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[1, 10],\n\t[3, 10],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "downFloor": [
        6,
        10
    ],
    "upFloor": [
        10,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}