main.floors.MT20=
{
    "floorId": "MT20",
    "title": "魔塔 第20层",
    "name": "第 20 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0, 87,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1,  1],
    [  1, 28, 27,  1,  0,  0,  0,  0,  0,  1, 31, 32,  1],
    [  1, 21,  0,  1,  0,206,206,206,  0,  1,  0, 21,  1],
    [  1,  1, 82,  1,  0,206,208,206,  0,  1, 82,  1,  1],
    [  1,205,  0,  1,  0,206,206,206,  0,  1,  0,205,  1],
    [  1,  0,205,  1,  0,  0,  0,  0,  0,  1,205,  0,  1],
    [  1, 81,  1,  1,  1,  1, 83,  1,  1,  1,  1, 81,  1],
    [  1,  0,215,  0,  1,  0,  0,  0,  1,  0,215,  0,  1],
    [  1, 31,  0,  0,218,  0, 88,  0,218,  0,  0, 31,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "ub.mp3",
    "firstArrive": [
        {
            "type": "setValue",
            "name": "flag:20",
            "value": "0"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,8": [
            {
                "type": "if",
                "condition": "(flag:20==0)",
                "true": [
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            6,
                            9
                        ]
                    },
                    {
                        "type": "playSound",
                        "name": "20F.mp3"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                5,
                                5
                            ],
                            [
                                6,
                                5
                            ],
                            [
                                7,
                                5
                            ],
                            [
                                5,
                                6
                            ],
                            [
                                7,
                                6
                            ],
                            [
                                5,
                                7
                            ],
                            [
                                6,
                                7
                            ],
                            [
                                7,
                                7
                            ]
                        ],
                        "time": 500
                    },
                    {
                        "type": "show",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "time": 500
                    },
                    "\t[吸血鬼,vampire]很好 你打败了骷髅族 但别想象藐视骷髅人那样藐视我",
                    "\t[hero]为什么",
                    "\t[吸血鬼,vampire]因为我的强大足以超越世界！",
                    "\t[吸血鬼,vampire]即使是在另一个没有魔法的平行世界里，我也是令人抓狂、夜不能寐、却又无法消灭的存在！",
                    "\t[hero]你是怎么知道的",
                    "\t[吸血鬼,vampire]因为我们的意识相通，尔等凡夫俗子怎能理解",
                    "\t[hero]所以在那个平行世界里的你究竟是什么样的呢",
                    "\t[吸血鬼,vampire]这我就不知道了，不过那里的人类都叫我“蚊子”",
                    "\t[hero]……",
                    {
                        "type": "setValue",
                        "name": "flag:20",
                        "value": "1"
                    }
                ],
                "false": []
            }
        ],
        "6,6": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "data": []
        }
    },
    "changeFloor": {
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "6,6": [
            {
                "type": "if",
                "condition": "switch:A",
                "true": [],
                "false": [
                    "\t[吸血鬼,vampire]嗡嗡嗡……你牛……嗡嗡嗡……但……嗡嗡嗡……但穞更牛……嗡嗡……嗡……",
                    {
                        "type": "playSound",
                        "name": "door.mp3",
                        "stop": true
                    },
                    {
                        "type": "setBlock",
                        "number": "21",
                        "loc": [
                            [
                                5,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "21",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "21",
                        "loc": [
                            [
                                7,
                                4
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "27",
                        "loc": [
                            [
                                4,
                                5
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "27",
                        "loc": [
                            [
                                4,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "27",
                        "loc": [
                            [
                                4,
                                7
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "28",
                        "loc": [
                            [
                                8,
                                5
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "28",
                        "loc": [
                            [
                                8,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "28",
                        "loc": [
                            [
                                8,
                                7
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "32",
                        "loc": [
                            [
                                5,
                                8
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "32",
                        "loc": [
                            [
                                6,
                                8
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "32",
                        "loc": [
                            [
                                7,
                                8
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    },
                    {
                        "type": "setValue",
                        "name": "switch:A",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "downFloor": [
        6,
        10
    ],
    "upFloor": [
        6,
        2
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}