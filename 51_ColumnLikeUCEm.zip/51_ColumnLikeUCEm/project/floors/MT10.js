main.floors.MT10=
{
    "floorId": "MT10",
    "title": "魔塔 第10层",
    "name": "第 10 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,209,209,209,  1,  1,  0,  1,  1,209,209,209,  1],
    [  1,  0,210,  0, 85,  0,211,  0, 85,  0,210,  0,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,209, 28,209,  1,  1,  0,  1,  1,209, 27,209,  1],
    [  1,  0,210,  0,  1,  1,  0,  1,  1,  0,210,  0,  1],
    [  1,  0,  0,  0,  1,  1,  0,  1,  1,  0,  0,  0,  1],
    [  1, 81,  1, 81,  1,  1, 83,  1,  1, 81,  1, 81,  1],
    [  1,123,  1,  0,  1,  0,  0,  0,  1,  0,  1,  0,  1],
    [  1, 88,  1,  0,217,  0, 87,  0,217,  0,  1, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "ub.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "data": []
        },
        "6,5": [
            {
                "type": "if",
                "condition": "switch:A",
                "true": [],
                "false": [
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            6,
                            7
                        ],
                        "async": true
                    },
                    {
                        "type": "playSound",
                        "name": "10F.mp3"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            4,
                            4
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            4
                        ],
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                5,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                7,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "waitAsync"
                    },
                    "\t[骷髅队长,skeletonCaptain]你好，我很爱讲冷笑话，因为我是一只cool髅",
                    {
                        "type": "setValue",
                        "name": "flag:cool",
                        "value": "1"
                    },
                    {
                        "type": "move",
                        "loc": [
                            6,
                            4
                        ],
                        "time": 200,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "up:3"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            2,
                            4
                        ],
                        "time": 200,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "right:3",
                            "down:2",
                            "right:1"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            10,
                            4
                        ],
                        "time": 200,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "left:4"
                        ]
                    },
                    {
                        "type": "sleep",
                        "time": 600
                    },
                    {
                        "type": "move",
                        "loc": [
                            3,
                            3
                        ],
                        "time": 200,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "right:2",
                            "down:2"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            9,
                            3
                        ],
                        "time": 200,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "left:2",
                            "down:2"
                        ]
                    },
                    {
                        "type": "sleep",
                        "time": 200
                    },
                    {
                        "type": "move",
                        "loc": [
                            2,
                            3
                        ],
                        "time": 200,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "right:3",
                            "down:1"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            10,
                            3
                        ],
                        "time": 200,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "left:3",
                            "down:1"
                        ]
                    },
                    {
                        "type": "sleep",
                        "time": 200
                    },
                    {
                        "type": "move",
                        "loc": [
                            1,
                            3
                        ],
                        "time": 200,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "right:4"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            11,
                            3
                        ],
                        "time": 200,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "left:4"
                        ]
                    },
                    {
                        "type": "waitAsync"
                    },
                    {
                        "type": "if",
                        "condition": "(flag:10>=7)",
                        "true": [],
                        "false": [
                            {
                                "type": "closeDoor",
                                "id": "specialDoor",
                                "loc": [
                                    4,
                                    4
                                ],
                                "async": true
                            },
                            {
                                "type": "closeDoor",
                                "id": "specialDoor",
                                "loc": [
                                    6,
                                    3
                                ],
                                "async": true
                            },
                            {
                                "type": "closeDoor",
                                "id": "specialDoor",
                                "loc": [
                                    8,
                                    4
                                ],
                                "async": true
                            },
                            {
                                "type": "waitAsync"
                            }
                        ]
                    },
                    {
                        "type": "setValue",
                        "name": "switch:A",
                        "value": "1"
                    }
                ]
            }
        ],
        "1,10": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "data": []
        },
        "6,9": [
            {
                "type": "if",
                "condition": "(flag:10==7)",
                "true": [
                    {
                        "type": "show",
                        "loc": [
                            [
                                1,
                                10
                            ]
                        ],
                        "time": 500
                    },
                    {
                        "type": "move",
                        "loc": [
                            1,
                            10
                        ],
                        "time": 200,
                        "keep": true,
                        "steps": [
                            "up:2",
                            "right:2",
                            "down:3",
                            "right:2",
                            "up:1",
                            "right:1"
                        ]
                    },
                    "\t[小偷,thief]哦，你看起来冻坏了……",
                    "\t[小偷,thief]放心，我可不会讲冷笑话",
                    {
                        "type": "move",
                        "loc": [
                            6,
                            10
                        ],
                        "time": 200,
                        "steps": [
                            "down:1"
                        ]
                    },
                    {
                        "type": "hide",
                        "time": 0
                    }
                ],
                "false": []
            }
        ]
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "5,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "5,5": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "5,6": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "6,6": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,6": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,5": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "6,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "1,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "2,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "3,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "2,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "9,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "10,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "10,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "11,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {
        "2,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "2,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "10,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "10,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "11,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "9,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "3,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "1,3": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "5,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "5,5": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,5": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "7,6": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "5,6": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "6,6": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ],
        "6,4": [
            {
                "type": "if",
                "condition": "flag:10==7",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:10",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        6,
        10
    ],
    "downFloor": [
        1,
        10
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}