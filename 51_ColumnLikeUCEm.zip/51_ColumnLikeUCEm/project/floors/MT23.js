main.floors.MT23=
{
    "floorId": "MT23",
    "title": "魔塔 第23层",
    "name": "第 23 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0,  0,  0,  0,  0,  0,  0,  0,  0, 87,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,121,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 3,
    "defaultGround": "ground",
    "bgm": "ub.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "4,3": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "2,2": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "2,3": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "2,5": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "2,4": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "4,5": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "8,3": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "10,3": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "10,4": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "10,5": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "8,5": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "8,4": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "2,7": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "4,7": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "2,8": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "2,9": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "4,10": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "8,7": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "10,7": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "8,9": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "2,6": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "4,6": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "4,9": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "4,8": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "4,4": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "4,2": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "6,2": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "6,3": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "6,4": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "6,5": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "6,6": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "6,7": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "6,8": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "2,10": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "6,9": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "6,10": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "8,10": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "8,8": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "8,6": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "8,2": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "10,9": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "10,8": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "10,6": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "10,2": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        },
        "10,10": {
            "trigger": null,
            "enable": true,
            "noPass": true,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "hide",
                    "remove": true,
                    "time": 0
                },
                {
                    "type": "closeDoor",
                    "id": "yellowWall"
                },
                {
                    "type": "if",
                    "condition": "(flag:23===44)",
                    "true": [
                        "\t[老人,man]你竟然把这里的柱子全部推开了！那么奖励你一个隐藏结局吧",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "23",
                            "norefresh": true
                        },
                        {
                            "type": "win",
                            "reason": "你看，他们像柱子一样",
                            "norank": 1
                        }
                    ],
                    "false": [
                        {
                            "type": "setValue",
                            "name": "flag:23",
                            "operator": "+=",
                            "value": "1"
                        }
                    ]
                }
            ]
        }
    },
    "changeFloor": {
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "downFloor": [
        1,
        2
    ],
    "upFloor": [
        11,
        2
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}