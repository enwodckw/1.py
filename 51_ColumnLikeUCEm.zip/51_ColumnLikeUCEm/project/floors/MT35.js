main.floors.MT35=
{
    "floorId": "MT35",
    "title": "魔塔 第35层",
    "name": "第 35 层",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "ub.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "5,10": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                "\t[小偷,thief]你好 骑士队长实力差又爱吹牛 虽然骑士队长实力差又爱吹牛 而且骑士队长实力差又爱吹牛 但是骑士队长实力差又爱吹牛 总之骑士队长实力差又爱吹牛",
                {
                    "type": "openDoor",
                    "loc": [
                        4,
                        10
                    ]
                },
                {
                    "type": "hide",
                    "time": 500
                }
            ]
        }
    },
    "changeFloor": {
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "6,7": [
            {
                "type": "if",
                "condition": "switch:A",
                "true": [],
                "false": [
                    {
                        "type": "setValue",
                        "name": "item:snow",
                        "operator": "+=",
                        "value": "1"
                    },
                    {
                        "type": "setValue",
                        "name": "switch:A",
                        "value": "1"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            2
                        ]
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  2,  2,  2,  2,  0,  0,  0,  0,  0,  0, 87,  1],
    [  1,  2,  1,  1,  1,  1, 85,  1,  1,  1,  1,  1,  1],
    [  1,  2,  1,  2,  1, 32, 32, 32,  1,  1,  1,  1,  1],
    [  1,  2,  1,  2,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  2,  1,  2,  1,189,190,191,  1,  1,  1,  1,  1],
    [  1,  2,  1,  2,  1,192,193,194,  1,  1,  1,  1,  1],
    [  1,  2,  1,  2,  1,195,257,196,  1,  1,  1,  1,  1],
    [  1,  2,  1,  2,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  2,  1,  2,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  2,  1,  2,  1,123,  0,  0,  1,  1,  1,  1,  1],
    [  1,  2,  2,  2,  1,  0, 88,  0,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "downFloor": [
        6,
        10
    ],
    "upFloor": [
        10,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}