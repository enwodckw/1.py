main.floors.MT50=
{
    "floorId": "MT50",
    "title": "魔塔 第50层",
    "name": "第 50 层",
    "width": 13,
    "height": 13,
    "map": [
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  1,  1,  1,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  0,123,  0,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  0,  0,  0,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  0,  0,  0,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  1,  1,  1,  1,  1,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4],
    [  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4,  4]
],
    "canFlyTo": false,
    "canFlyFrom": false,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": "ub.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,5": [
            "\t[hero]你怎会在这里！你果然是魔王！",
            "\t[小偷,thief]直觉不错，那我们打开天窗说亮话吧",
            {
                "type": "hide",
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "249"
            },
            {
                "type": "show",
                "time": 500
            },
            "\t[hero]所以你的阴谋是什么？统治世界？肉身成圣？",
            "\t[redKing]那太无聊了，其实我本来没有任何打算",
            "\t[hero]你这是什么意思？",
            "\t[redKing]我只是像平时那样，例行清理不知死活前来闯塔的勇者，直到我遇见了你",
            "\t[hero]然后你把我扔到了牢房里",
            "\t[redKing]是的，我本来只想和你干一把，然后就把你扔出去的。谁知道你竟然有复制整列物品的能力",
            "\t[hero]果然……所以你想用我的能力做什么，魔王！",
            "\t[redKing]我看你身上的神圣剑盾挺值钱的，既然你在我的地盘里复制了那么多把，那你总该分我一点吧",
            "\t[hero]啊？",
            "\t[redKing]不懂吗？既然是在魔塔里复制出来的东西，那就是魔塔的财产。",
            "\t[hero]这……呃……",
            "\t[redKing]好啦，我也不贪心，你可以给自己留一套剑盾，身上的其他装备给我，我就放你走。",
            "\t[hero]不是……这太出乎意料了，让我缓缓",
            "\t[hero]咳咳，虽然我完全没猜到你是这种动机，但是不行",
            "\t[redKing]别太过分了，勇者",
            "\t[hero]不行",
            "\t[redKing]那，那我要打你喽",
            "\t[hero]呃，还是不行",
            "\t[redKing]那我要打你喽……"
        ]
    },
    "changeFloor": {},
    "afterBattle": {
        "6,5": [
            {
                "type": "setCurtain",
                "color": [
                    0,
                    0,
                    0,
                    1
                ],
                "time": 0,
                "keep": true
            },
            {
                "type": "setText",
                "align": "center",
                "background": [
                    0,
                    0,
                    0,
                    0
                ]
            },
            {
                "type": "sleep",
                "time": 500
            },
            "在勇者击败魔王的一瞬间，魔塔轰然倒塌",
            "勇者趁乱带着自己收集到的剑盾离开了魔塔，卖了很多钱，成为大富翁",
            "在魔塔的废墟之下，十一个魔王伴随着勇士的能力被复制出来",
            "据说他们最后死于内讧",
            {
                "type": "if",
                "condition": "flag:hell",
                "true": [
                    {
                        "type": "if",
                        "condition": "flag:addhp",
                        "true": [
                            {
                                "type": "win",
                                "reason": "疯狂加血版（困难）"
                            }
                        ],
                        "false": [
                            {
                                "type": "if",
                                "condition": "(flag:end==1)",
                                "true": [
                                    {
                                        "type": "win",
                                        "reason": "【困难难度·穿墙】"
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "choices",
                                        "text": "\t[恭喜通关]请选择计分方式",
                                        "choices": [
                                            {
                                                "text": "生命",
                                                "icon": "hp",
                                                "action": [
                                                    {
                                                        "type": "win",
                                                        "reason": "【困难难度·生命】"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "金币",
                                                "icon": "money",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "status:hp",
                                                        "value": "status:money",
                                                        "norefresh": true
                                                    },
                                                    {
                                                        "type": "win",
                                                        "reason": "【困难难度·金币】"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "蓝钥匙",
                                                "icon": "blueKey",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "status:hp",
                                                        "value": "item:blueKey",
                                                        "norefresh": true
                                                    },
                                                    {
                                                        "type": "win",
                                                        "reason": "【困难难度·蓝钥】"
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "if",
                        "condition": "flag:addhp",
                        "true": [
                            {
                                "type": "win",
                                "reason": "疯狂加血版（简单）"
                            }
                        ],
                        "false": [
                            {
                                "type": "if",
                                "condition": "(flag:end==1)",
                                "true": [
                                    {
                                        "type": "win",
                                        "reason": "【简单难度·穿墙】"
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "choices",
                                        "text": "\t[恭喜通关]请选择计分方式",
                                        "choices": [
                                            {
                                                "text": "生命",
                                                "icon": "hp",
                                                "action": [
                                                    {
                                                        "type": "win",
                                                        "reason": "【简单难度·生命】"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "金币",
                                                "icon": "money",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "status:hp",
                                                        "value": "status:money",
                                                        "norefresh": true
                                                    },
                                                    {
                                                        "type": "win",
                                                        "reason": "【简单难度·金币】"
                                                    }
                                                ]
                                            },
                                            {
                                                "text": "蓝钥匙",
                                                "icon": "blueKey",
                                                "action": [
                                                    {
                                                        "type": "setValue",
                                                        "name": "status:hp",
                                                        "value": "item:blueKey",
                                                        "norefresh": true
                                                    },
                                                    {
                                                        "type": "win",
                                                        "reason": "【简单难度·蓝钥】"
                                                    }
                                                ]
                                            }
                                        ]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}