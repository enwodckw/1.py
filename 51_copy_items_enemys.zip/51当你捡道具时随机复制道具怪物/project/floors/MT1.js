main.floors.MT1=
{
    "floorId": "MT1",
    "title": "魔塔 第01层",
    "name": "第 1 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,201,202,201,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1, 31,  0,  0, 81,  0,  1, 27, 21,  0,  1,  0,  1],
    [  1,  0,209,  0,  1,  0,  1, 28, 31,  0,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  1,  1,  1, 81,  1,  0,  1],
    [  1, 21,  0,  0,  1,  0, 81,205,217,205,  1,  0,  1],
    [  1,  0,210,  0,  1,  0,  1,  1,  1,  1,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1, 81,  1,  1,  1, 81,  1,  1],
    [  1, 31,  0, 21,  1,  0,  0,331,  1,  0,205,  0,  1],
    [  1, 31,  0, 21,  1,  0,  0,  0,  1,201, 32,201,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [
        {
            "type": "tip",
            "text": "游戏已重启"
        },
        {
            "type": "function",
            "function": "function(){\ncore.setFlag(\"numCopyItem\", 2);\ncore.setFlag(\"numCopyMon\", 2);\ncore.setFlag(\"numMon\", 1);\n\ncore.setFlag(\"itemDetail\", ture);\n}"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,10": [
            "是否要开启疯狂加血模式？\n在这个模式下，你的生命仍然要超过怪物伤害才能战斗，但实际战斗中，你将不会受到伤害，而是会回复等量的生命。",
            {
                "type": "choices",
                "choices": [
                    {
                        "text": "是",
                        "action": [
                            {
                                "type": "setValue",
                                "name": "flag:addhp",
                                "value": "1"
                            }
                        ]
                    },
                    {
                        "text": "否",
                        "action": []
                    }
                ]
            },
            {
                "type": "hide",
                "time": 0
            }
        ],
        "7,10": [
            "每当你在同一层捡到两个道具：\n随机复制当前地图上的一个道具和一个怪物在随机空地上。",
            "有三只跳跃靴被抓进了牢房，它们可以帮你度过一些难关。\n可惜它们畏高，一旦你到达11层它们就会逃跑啦！",
            {
                "type": "if",
                "condition": "(flag:rank===1)",
                "true": [
                    {
                        "type": "if",
                        "condition": "(flag:isChange===0)",
                        "true": [
                            "新增了一丢丢可自定义内容：\n1.捡到n个道具时可复制一个道具。(默认每两个复制）\n2.捡到n个道具时可复制一个怪物。(默认每两个复制）\n3.怪物属性倍率。（默认一倍）\n（0<自定义范围<1024）\n(请输入整数，如因输入小数导致bug，懒得修复。）\n(如果因为自定义而导致通关无解，恕我无力负责。）",
                            {
                                "type": "comment",
                                "text": "可以在这里写添加任何注释内容"
                            },
                            {
                                "type": "confirm",
                                "text": "确认要自定义道具复制吗?",
                                "yes": [
                                    {
                                        "type": "input",
                                        "text": "请输入一个数"
                                    },
                                    {
                                        "type": "if",
                                        "condition": "((flag:input<=0)||(flag:input>=1024))",
                                        "true": [
                                            "你自定义的数值${core.getFlag(\"input\",Error)}超出范围，将设为默认数值",
                                            {
                                                "type": "setValue",
                                                "name": "flag:numCopyItem",
                                                "value": "2"
                                            }
                                        ],
                                        "false": [
                                            {
                                                "type": "setValue",
                                                "name": "flag:numCopyItem",
                                                "value": "flag:input"
                                            }
                                        ]
                                    }
                                ],
                                "no": [
                                    {
                                        "type": "setValue",
                                        "name": "flag:numCopyItem",
                                        "value": "2"
                                    }
                                ]
                            },
                            {
                                "type": "comment",
                                "text": "可以在这里写添加任何注释内容"
                            },
                            {
                                "type": "confirm",
                                "text": "确认要自定义怪物复制吗?",
                                "yes": [
                                    {
                                        "type": "input",
                                        "text": "请输入一个数"
                                    },
                                    {
                                        "type": "if",
                                        "condition": "((flag:input<=0)||(flag:input>=1024))",
                                        "true": [
                                            "你自定义的数值${core.getFlag(\"input\",Error)}超出范围，将设为默认数值",
                                            {
                                                "type": "setValue",
                                                "name": "flag:numCopyMon",
                                                "value": "2"
                                            }
                                        ],
                                        "false": [
                                            {
                                                "type": "setValue",
                                                "name": "flag:numCopyMon",
                                                "value": "flag:input"
                                            }
                                        ]
                                    }
                                ],
                                "no": [
                                    {
                                        "type": "setValue",
                                        "name": "flag:numCopyMon",
                                        "value": "2"
                                    }
                                ]
                            },
                            {
                                "type": "comment",
                                "text": "可以在这里写添加任何注释内容"
                            },
                            {
                                "type": "confirm",
                                "text": "确认要自定义怪物属性倍率吗?",
                                "yes": [
                                    {
                                        "type": "input",
                                        "text": "请输入一个数"
                                    },
                                    {
                                        "type": "if",
                                        "condition": "((flag:input<=0)||(flag:input>=1024))",
                                        "true": [
                                            "你自定义的数值${core.getFlag(\"input\",Error)}超出范围，将设为默认数值",
                                            {
                                                "type": "setValue",
                                                "name": "flag:numMon",
                                                "value": "1"
                                            }
                                        ],
                                        "false": [
                                            {
                                                "type": "setValue",
                                                "name": "flag:numMon",
                                                "value": "flag:input"
                                            }
                                        ]
                                    }
                                ],
                                "no": [
                                    {
                                        "type": "setValue",
                                        "name": "flag:numMon",
                                        "value": "1"
                                    }
                                ]
                            },
                            {
                                "type": "comment",
                                "text": "可以在这里写添加任何注释内容"
                            },
                            {
                                "type": "setValue",
                                "name": "flag:isChange",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setBlock",
                                "number": "yellowKey",
                                "loc": [
                                    [
                                        5,
                                        10
                                    ]
                                ]
                            },
                            {
                                "type": "setBlock",
                                "number": "fly",
                                "loc": [
                                    [
                                        5,
                                        11
                                    ]
                                ]
                            }
                        ],
                        "false": []
                    }
                ],
                "false": [
                    {
                        "type": "if",
                        "condition": "(flag:isChange===0)",
                        "true": [
                            {
                                "type": "setValue",
                                "name": "flag:isChange",
                                "operator": "+=",
                                "value": "1"
                            },
                            {
                                "type": "setBlock",
                                "number": "yellowKey",
                                "loc": [
                                    [
                                        5,
                                        10
                                    ]
                                ]
                            },
                            {
                                "type": "setBlock",
                                "number": "fly",
                                "loc": [
                                    [
                                        5,
                                        11
                                    ]
                                ]
                            }
                        ],
                        "false": []
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        2,
        1
    ],
    "downFloor": [
        6,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}