main.floors.MT43=
{
    "floorId": "MT43",
    "title": "魔塔 第43层",
    "name": "第 43 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0, 81,  0,204,  0, 81, 81,246,  0,  0,  1],
    [  1,  0,  0,  1,  1,  1,  0,  1,  1,  0,  1,  0,  1],
    [  1,  0,  0, 81,  0,  1,228,  1,  0,  0,  1,  0,  1],
    [  1, 82,  1,  1,220,  1,  0,228,  0, 42,  1,  0,  1],
    [  1,  0,204,  0,  0,  1,  1,  1,  1,  1,  1, 81,  1],
    [  1,  0,  1, 81,  1,  1, 32,  0, 81,  0,  0,  0,  1],
    [  1,  0,  1,  0,  0,204,  0,  0,  1,219,  0, 31,  1],
    [  1, 81,  1,  1,  1,  1,  1,  1,  1,  0,333,  0,  1],
    [  1,  0,207,  1, 32,  0,228,  0,  1,  1,  1, 81,  1],
    [  1,  0,  0,  1, 32,  1,  1,  0, 81,  0,207,  0,  1],
    [  1, 87,  0,  1, 32,  0, 82,  0,  1,  0,  0,332,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": "section5.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": "MT45",
            "stair": "downFloor",
            "time": 0
        },
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {
        "8,1": [
            {
                "type": "if",
                "condition": "(status:direction=='right' )",
                "true": [
                    {
                        "type": "moveAction"
                    },
                    {
                        "type": "playSound",
                        "name": "开关门"
                    },
                    {
                        "type": "closeDoor",
                        "id": "yellowWall",
                        "loc": [
                            7,
                            1
                        ],
                        "async": true
                    },
                    {
                        "type": "move",
                        "loc": [
                            9,
                            1
                        ],
                        "time": 200,
                        "keep": true,
                        "steps": [
                            "right:2"
                        ]
                    },
                    {
                        "type": "waitAsync"
                    },
                    {
                        "type": "playSound",
                        "name": "开关门"
                    },
                    {
                        "type": "closeDoor",
                        "id": "yellowWall",
                        "loc": [
                            10,
                            1
                        ]
                    },
                    {
                        "type": "hide",
                        "remove": true,
                        "time": 0
                    },
                    {
                        "type": "exit"
                    }
                ],
                "false": []
            }
        ]
    },
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        1,
        10
    ],
    "downFloor": [
        1,
        2
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}