main.floors.MT1=
{
    "floorId": "MT1",
    "title": "魔塔 第01层",
    "name": "第 1 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,201,202,201,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1, 31,  0,  0, 81,  0,  1, 27,333,  0,  1,  0,  1],
    [  1,  0,209,  0,  1,  0,  1, 28, 31,  0,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  1,  1,  1, 81,  1,  0,  1],
    [  1,333,  0,  0,  1,  0, 81,205,217,205,  1,  0,  1],
    [  1,  0,210,  0,  1,  0,  1,  1,  1,  1,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1, 86,  1,  1,  1, 81,  1,  1],
    [  1, 31,  0,333,  1, 25, 73,127,  1,  0,205,  0,  1],
    [  1, 31,  0,333,  1, 46,  0, 45,  1,201, 32,201,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [
        {
            "type": "tip",
            "text": "游戏已重启"
        },
        {
            "type": "loadBgm",
            "name": "Ending.mp3"
        },
        {
            "type": "loadBgm",
            "name": "SkeletonA.mp3"
        },
        {
            "type": "loadBgm",
            "name": "Vampire.mp3"
        },
        {
            "type": "loadBgm",
            "name": "GreatMagicMaster.mp3"
        },
        {
            "type": "loadBgm",
            "name": "Knight.mp3"
        },
        {
            "type": "loadBgm",
            "name": "Zeno.mp3"
        },
        {
            "type": "setValue",
            "name": "flag:调试模式",
            "value": "false"
        },
        {
            "type": "choices",
            "text": "\t[作者,oldMan]选择模式",
            "choices": [
                {
                    "text": "正常（比较简单）",
                    "action": [
                        "\t[作者,oldMan]注意，这个模式开局只有500生命",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "500"
                        },
                        {
                            "type": "setValue",
                            "name": "flag:模式",
                            "value": "0"
                        }
                    ]
                },
                {
                    "text": "（黄蓝）钥匙血瓶互换（相对普通）",
                    "action": [
                        {
                            "type": "setValue",
                            "name": "flag:模式",
                            "value": "1"
                        },
                        {
                            "type": "function",
                            "function": "function(){\nfor (let f of core.floorIds) {\n\tfor (let i = 1; i <= 11; i++) {\n\t\tfor (let j = 1; j <= 11; j++) {\n\t\t\tlet bn = core.getBlockNumber(i, j, f)\n\t\t\tif (bn === 32) {\n\t\t\t\tcore.setBlock(332, i, j, f);\n\t\t\t} else if (bn === 31) {\n\t\t\t\tcore.setBlock(333, i, j, f);\n\t\t\t} else if (bn === 333) {\n\t\t\t\tcore.setBlock(31, i, j, f);\n\t\t\t} else if (bn === 332) {\n\t\t\t\tcore.setBlock(32, i, j, f);\n\t\t\t}\n\t\t}\n\t}\n}\n}"
                        }
                    ]
                },
                {
                    "text": "（黄蓝）钥匙怪物互换（非常简单）",
                    "action": [
                        "\t[hero]……一区哪有黄色怪，这一开始不就卡死了！",
                        "\t[作者,oldMan]没事，绿色史莱姆自愿变成黄色怪物",
                        "\t[greenSlime]……",
                        "\t[作者,oldMan]不说话就是同意了！",
                        "\t[黄色史莱姆,greenSlime]……",
                        "\t[hero]那四区呢？你确定四区能过？",
                        "\t[作者,oldMan]放心，商人都不会走路，没法先攻或者伏击你，触发对应事件就好了",
                        "\t[作者,oldMan]赠你幸运金币一个，不用谢！",
                        "\t[作者,oldMan]0层换成圣水了，记得拿！",
                        {
                            "type": "setBlock",
                            "number": "superPotion",
                            "loc": [
                                [
                                    6,
                                    6
                                ]
                            ],
                            "floorId": "MT0"
                        },
                        {
                            "type": "setValue",
                            "name": "item:coin",
                            "operator": "+=",
                            "value": "1"
                        },
                        {
                            "type": "setValue",
                            "name": "flag:模式",
                            "value": "2"
                        },
                        {
                            "type": "function",
                            "function": "function(){\nlet ye = [\"greenSlime\", \"yellowGuard\", \"skeletonCaptain\", \"zombie\", \"zombieKnight\", \"rock\", \"swordsman\", \"yellowKnight\", \"brownWizard\"];\n\nlet rye = [\"skeletonCaptain\", \"zombieKnight\", \"greenSlime\", \"yellowKnight\", \"brownWizard\"]\n\nlet be = [\"bat\", \"bluePriest\", \"bigBat\", \"ghostSkeleton\", \"blueGuard\", \"soldier\", \"whiteKing\"];\n\nlet rbe = [\"bluePriest\", \"bigBat\", null, \"blueGuard\", \"whiteKing\"];\n\nfor (let f of core.floorIds) {\n\tlet r = core.status.maps[f].ratio - 1;\n\tfor (let i = 1; i <= 11; i++) {\n\t\tfor (let j = 1; j <= 11; j++) {\n\t\t\tlet bid = core.getBlockId(i, j, f)\n\t\t\tif (ye.includes(bid)) {\n\t\t\t\tcore.setBlock(\"N333\", i, j, f);\n\t\t\t} else if (be.includes(bid)) {\n\t\t\t\tcore.setBlock(\"N332\", i, j, f);\n\t\t\t} else if (bid === \"N333\") {\n\t\t\t\tcore.setBlock(rye[r], i, j, f);\n\t\t\t} else if (bid === \"N332\") {\n\t\t\t\tcore.setBlock(rbe[r], i, j, f);\n\t\t\t}\n\t\t}\n\t}\n}\n}"
                        }
                    ]
                },
                {
                    "text": "正常+移除（比较简单）",
                    "condition": "false",
                    "action": [
                        "\t[作者,oldMan]注意，这个模式开局只有500生命",
                        {
                            "type": "setValue",
                            "name": "status:hp",
                            "value": "500"
                        },
                        {
                            "type": "setValue",
                            "name": "flag:模式",
                            "value": "3"
                        },
                        {
                            "type": "setValue",
                            "name": "flag:移除",
                            "value": "true"
                        }
                    ]
                }
            ]
        },
        {
            "type": "choices",
            "text": "\t[作者,oldMan]选择难度",
            "choices": [
                {
                    "text": "简单",
                    "action": [
                        "\t[作者,oldMan]给你一个好玩的魔杖！",
                        "\t[skill1]可以隔着一格跟NPC交流",
                        {
                            "type": "setValue",
                            "name": "item:skill1",
                            "operator": "+=",
                            "value": "1"
                        },
                        {
                            "type": "setValue",
                            "name": "flag:难度",
                            "value": "0"
                        }
                    ]
                },
                {
                    "text": "普通",
                    "action": [
                        "\t[作者,oldMan]没有任何其它变化了",
                        {
                            "type": "setValue",
                            "name": "flag:难度",
                            "value": "1"
                        }
                    ]
                }
            ]
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "7,10": [
            {
                "type": "switch",
                "condition": "flag:模式",
                "caseList": [
                    {
                        "case": "2",
                        "action": [
                            "\t[作者,oldMan]这个模式的具体规则是这样：每区的黄色怪物换为黄钥匙商人，蓝色怪物换为蓝钥匙商人",
                            "\t[作者,oldMan]原本的钥匙商人，则按本区域金币数量最多的对应颜色怪物替换",
                            "\t[作者,oldMan]对话穿墙现在能直接以商人为中心，选择5*5范围内的任意一个墙壁消除。",
                            "\t[作者,oldMan]只有新增的商人有这个功能，原本老人商人是没有对话穿墙的。",
                            "\t[作者,oldMan]再提醒一次，商人都不会走路，没法先攻或者伏击你",
                            "\t[作者,oldMan]也就是说，40层boss战不需要跟商人购买东西就能通过，具体怎么操作你可以想想"
                        ]
                    },
                    {
                        "case": "1",
                        "action": [
                            "\t[作者,oldMan]这个模式大概就是原本的钥匙换成钥匙商人。然后，红血瓶互换黄钥匙商人，蓝血瓶互换蓝钥匙商人",
                            "\t[作者,oldMan]红钥匙以及红钥匙商人保持不变",
                            "\t[作者,oldMan]对话穿墙现在能直接以商人为中心，选择5*5范围内的任意一个墙壁消除。",
                            "\t[作者,oldMan]只有新增的商人有这个功能，原本老人商人是没有对话穿墙的。"
                        ]
                    },
                    {
                        "case": "0",
                        "action": [
                            "\t[作者,oldMan]好消息啊！对话穿墙回归了！而且还是加强版！",
                            "\t[hero]且慢！那些怪模怪样的商人是什么？钥匙呢！",
                            "\t[作者,oldMan]对话穿墙现在能直接以商人为中心，选择5*5范围内的任意一个墙壁消除了！",
                            "\t[hero]我问你！钥匙呢！",
                            "\t[作者,oldMan]不过要注意，需要点击范围外才能取消！",
                            "\t[hero]\\c[30]钥！匙！呢！",
                            "\t[作者,oldMan]你吼那么大声干嘛啊！，钥匙……找商人买不就好了！",
                            "\t[作者,oldMan]速速闯塔，莫要偷懒！",
                            "\t[作者,oldMan]对了，上述福利只有新增的商人有，原本老人商人是没有对话穿墙的！"
                        ]
                    }
                ]
            },
            "\t[作者,oldMan]应测塔员强烈要求，魔王略微加强，目前为5000/1700/200"
        ]
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {
        "6,9": [
            "修改较多，放在样板简介里面了！就是工具栏那个长得像卷轴一样的东西"
        ]
    },
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        2,
        1
    ],
    "downFloor": [
        6,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}