main.floors.MT15=
{
    "floorId": "MT15",
    "title": "魔塔 第15层",
    "name": "第 15 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21,  0, 21,  1,  0, 87,  0,  1,123,  0,122,  1],
    [  1,  0, 37,  0,  1,  0,  0,  0,  1,  0,  0,  0,  1],
    [  1, 22,  0,  0,  1,  1, 85,  1,  1,  0,203,  0,  1],
    [  1,  1, 81,  1,  1,  0,  0,  0,  1,  1, 85,  1,  1],
    [  1,206,  0,206,  1,181,182,183,  1,206,  0,206,  1],
    [  1,218,  0,129,  1,184,185,186,  1,  0,  0,  0,  1],
    [  1,  1, 81,  1,  1,187,258,188,  1,  1, 81,  1,  1],
    [  1,  0,203,  0,  1,  0,  0,  0,  1,205,  0,205,  1],
    [  1,  1,  0,  1,  1,  1,  0,  1,  1,  1, 81,  1,  1],
    [  1,214,  0,203,  1,  0,  0,  0,  1,  0,  0,218,  1],
    [  1, 28,213,  0, 81,  0, 88,  0, 81,  0,218, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "section2.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "9,1": [
            "\t[小偷,thief]阿哈 你还好吗 这大章鱼挡住了我前进的道路 现在暗道终于完工了 你现在最好也躲开它 我要走了 再见",
            {
                "type": "openDoor",
                "loc": [
                    8,
                    1
                ]
            },
            {
                "type": "move",
                "loc": [
                    9,
                    1
                ],
                "time": 200,
                "steps": [
                    "left",
                    "left",
                    "left"
                ]
            }
        ],
        "3,6": [
            "打败这个房间的三个怪开启黄门，当然你可以直接拿钥匙开"
        ],
        "11,1": [
            {
                "type": "if",
                "condition": "switch:A",
                "true": [
                    {
                        "type": "insert",
                        "name": "老人",
                        "args": [
                            0
                        ]
                    }
                ],
                "false": [
                    {
                        "type": "insert",
                        "name": "商人",
                        "args": [
                            0
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "6,7": [
            {
                "type": "openDoor",
                "loc": [
                    6,
                    3
                ]
            },
            {
                "type": "setBlock",
                "number": "pickaxe",
                "loc": [
                    [
                        6,
                        4
                    ]
                ]
            }
        ],
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT15_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT15_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT15_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT15_10_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT15_10_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        6,
        2
    ],
    "downFloor": [
        6,
        10
    ],
    "autoEvent": {
        "2,4": {
            "0": {
                "condition": "flag:door_MT15_2_4==3",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT15_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "10,4": {
            "0": {
                "condition": "flag:door_MT15_10_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT15_10_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}