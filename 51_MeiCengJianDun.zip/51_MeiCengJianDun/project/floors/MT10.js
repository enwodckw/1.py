main.floors.MT10=
{
    "floorId": "MT10",
    "title": "魔塔 第10层",
    "name": "第 10 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 21, 21, 21, 85,123, 88,  0, 81,  0,  0,209,  1],
    [  1, 28, 28, 28,  1,  0,  0,  0,  1,  0,210, 28,  1],
    [  1,  0,  1,  1,  1,  1, 86,  1,  1,  1,  1,209,  1],
    [  1, 27, 27, 27,  1,  0,  0,  0, 81,  0,  0,  0,  1],
    [  1, 32, 32, 32, 85,  0,  0,  0,  1,  1, 81,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,217,  1,  0,217,  0,  1],
    [  1,209,209, 85,209,209,  1,  0,  1, 36,  1,  0,  1],
    [  1,210,210,  1,209,209,  1,  0,  1,  1,  1, 81,  1],
    [  1, 85,  1,  1,  1, 85,  1,  0,  1,209,  0,  0,  1],
    [  1,  0,  0,  1,  0,  0,  1,  0,  1, 27,210,  0,  1],
    [  1, 87,  0,  0,211,  0, 83,  0,  1,209,  0, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "1,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "data": []
        },
        "5,11": [
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    6,
                    11
                ]
            },
            {
                "type": "playSound",
                "name": "10F.mp3"
            },
            {
                "type": "openDoor",
                "loc": [
                    5,
                    9
                ],
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    3,
                    7
                ],
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    1,
                    9
                ],
                "async": true
            },
            {
                "type": "waitAsync"
            },
            "\t[skeletonCaptain]哈哈哈 你是如此的幸运能安全到达这里 但现在好运离你而去了 你中埋伏了 弟兄们给我上",
            {
                "type": "move",
                "loc": [
                    4,
                    11
                ],
                "time": 200,
                "keep": true,
                "async": true,
                "steps": [
                    "left:2"
                ]
            },
            {
                "type": "move",
                "loc": [
                    5,
                    8
                ],
                "time": 200,
                "keep": true,
                "async": true,
                "steps": [
                    "down:2",
                    "left:1",
                    "down:1"
                ]
            },
            {
                "type": "move",
                "loc": [
                    5,
                    7
                ],
                "time": 200,
                "keep": true,
                "async": true,
                "steps": [
                    "down:3"
                ]
            },
            {
                "type": "move",
                "loc": [
                    4,
                    8
                ],
                "time": 200,
                "keep": true,
                "async": true,
                "steps": [
                    "up:1",
                    "right:1"
                ]
            },
            {
                "type": "move",
                "loc": [
                    4,
                    7
                ],
                "time": 200,
                "keep": true,
                "async": true,
                "steps": [
                    "right:1",
                    "down:1"
                ]
            },
            {
                "type": "move",
                "loc": [
                    2,
                    7
                ],
                "time": 200,
                "keep": true,
                "async": true,
                "steps": [
                    "right:2"
                ]
            },
            {
                "type": "move",
                "loc": [
                    2,
                    8
                ],
                "time": 200,
                "keep": true,
                "async": true,
                "steps": [
                    "up:1"
                ]
            },
            {
                "type": "waitAsync"
            },
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    1,
                    9
                ],
                "async": true
            },
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    3,
                    7
                ],
                "async": true
            },
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    5,
                    9
                ],
                "async": true
            },
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    3,
                    11
                ],
                "async": true
            },
            {
                "type": "waitAsync"
            },
            {
                "type": "hide"
            }
        ],
        "1,10": [
            "\t[skeletonCaptain]你怎能杀出重围 我是绝不会让你通过的 来吧 我要与你决斗",
            {
                "type": "hide"
            }
        ],
        "5,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        }
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_5_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_5_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "4,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_3_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_3_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_1_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "1,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_1_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_1_9",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT10_3_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "2,11": [
            "\t[骷髅队长,skeletonCaptain]不 这是不可能的 你怎会打败我 你别太得意 后面还有许多强大的对手和机关存在 你稍有疏忽就必死无疑",
            {
                "type": "playSound",
                "name": "door.mp3",
                "stop": true
            },
            {
                "type": "show",
                "loc": [
                    [
                        1,
                        11
                    ]
                ]
            },
            {
                "type": "openDoor",
                "loc": [
                    3,
                    11
                ],
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    6,
                    11
                ],
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    4,
                    1
                ],
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    4,
                    5
                ]
            },
            {
                "type": "waitAsync"
            },
            {
                "type": "show",
                "loc": [
                    [
                        5,
                        1
                    ]
                ],
                "time": 500
            },
            {
                "type": "move",
                "loc": [
                    5,
                    1
                ],
                "time": 200,
                "keep": true,
                "steps": [
                    "down:1",
                    "right:1"
                ]
            },
            {
                "type": "openDoor",
                "loc": [
                    6,
                    3
                ]
            },
            {
                "type": "move",
                "loc": [
                    6,
                    2
                ],
                "time": 200,
                "keep": true,
                "steps": [
                    "down:2",
                    "right:1",
                    "down:7",
                    "left:5"
                ]
            },
            "\t[小偷,thief]你总算是帮我解决了这麻烦的骷髅队长 我终于可以上去了 我听说银盾在12 14 16 18 20楼 银剑在11 13 15 17 19楼 这消息不知道对你是否有用 下次见",
            {
                "type": "hide",
                "loc": [
                    [
                        2,
                        11
                    ]
                ],
                "time": 200
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        1,
        10
    ],
    "downFloor": [
        6,
        2
    ],
    "autoEvent": {
        "5,9": {
            "0": {
                "condition": "flag:door_MT10_5_9==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT10_5_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "3,7": {
            "0": {
                "condition": "flag:door_MT10_3_7==3",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT10_3_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "1,9": {
            "0": {
                "condition": "flag:door_MT10_1_9==3",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT10_1_9",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}