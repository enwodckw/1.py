main.floors.MT40=
{
    "floorId": "MT40",
    "title": "魔塔 第40层",
    "name": "第 40 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0, 81,  0,  0,  0,  0,  0,  0,  0, 87,  1],
    [  1,  0,  0,  1,  0,216,  0,216,  0,  1,  0,  0,  1],
    [  1,225,  1,  1,  1,  1, 83,  1,  1,  1,  1, 82,  1],
    [  1,  0, 31,224,  1,  0,  0,  0,  1, 32,  1,  0,  1],
    [  1,  1,  0,  1,  1,  0,  1,  0,  1, 21,  1,  0,  1],
    [  1,  0,  0,  0,  1,  0,  1,  0,  1, 27,  1,  0,  1],
    [  1,  0, 40,  0,  1,  1,  1,  0,  1, 28,227,  0,  1],
    [  1,  0,  0,  0,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,  1, 85,  1,  1,  1,  0,  1,  1,  0,  0,  0,  1],
    [  1,225,225,225,  1,  0,  0,  0,  1,212,212,212,  1],
    [  1,227,227,227,  0,  0,226,  0,  0,224,224,224,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "2,6": [
            {
                "type": "closeDoor",
                "id": "yellowWall",
                "loc": [
                    2,
                    5
                ]
            },
            {
                "type": "hide"
            }
        ],
        "11,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "6,4": [
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    6,
                    3
                ]
            },
            {
                "type": "playBgm",
                "name": "boss4.mp3"
            },
            {
                "type": "function",
                "function": "function(){\ncore.material.enemys.ghostSkeleton.special = 1;\ncore.material.enemys.soldier.special = 1;\ncore.material.enemys.swordsman.special = 1;\ncore.material.enemys.redKnight.special = 1;\ncore.material.enemys.yellowKnight.special = 1;\ncore.insertAction([\n\t{ \"type\": \"update\" },\n]);\n}"
            },
            "\t[骑士队长,yellowKnight]我还在担心你不能来了。我确信这次我一定能杀了你。给我上！",
            {
                "type": "callBook"
            },
            {
                "type": "function",
                "function": "function(){\nvar a = new Array([11, 10], [10, 10], [9, 10], [3, 10], [2, 10], [1, 10], [11, 11], [10, 11], [9, 11], [3, 11], [2, 11], [1, 11]);\nfor (var i = 11; i > -1; i--) {\n\tif (core.getBlockId(a[i][0], a[i][1]) == null) {\n\t\tcontinue;\n\t}\n\tcore.insertAction([{ \"type\": \"sleep\", \"time\": 300 }, ]);\n\tcore.insertAction([{\n\t\t\"type\": \"battle\",\n\t\t\"loc\": [\n\t\t\ta[i][0], a[i][1]\n\t\t]\n\t}, ]);\n}\n}"
            },
            "\t[骑士队长,yellowKnight]你怎会击败我所有的手下？我和你誓不两立我决不认输。",
            {
                "type": "battle",
                "loc": [
                    6,
                    11
                ]
            },
            {
                "type": "function",
                "function": "function(){\ncore.material.enemys.ghostSkeleton.special = 0;\ncore.material.enemys.soldier.special = 0;\ncore.material.enemys.swordsman.special = 0;\ncore.material.enemys.redKnight.special = 0;\ncore.material.enemys.yellowKnight.special = 0;\ncore.insertAction([{ \"type\": \"update\" }, ]);\n}"
            },
            {
                "type": "openDoor",
                "loc": [
                    6,
                    3
                ]
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        4
                    ]
                ]
            }
        ]
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "afterBattle": {
        "1,10": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "2,10": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "3,10": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "9,10": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "10,10": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "11,10": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "1,11": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "2,11": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "3,11": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "9,11": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "10,11": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "11,11": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ],
        "6,11": [
            {
                "type": "setValue",
                "name": "flag:40",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:40==13)",
                "true": [
                    "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                    {
                        "type": "show",
                        "loc": [
                            [
                                11,
                                1
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redGem",
                        "loc": [
                            [
                                1,
                                11
                            ],
                            [
                                2,
                                11
                            ],
                            [
                                3,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ],
                            [
                                10,
                                11
                            ],
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "blueGem",
                        "loc": [
                            [
                                1,
                                10
                            ],
                            [
                                2,
                                10
                            ],
                            [
                                3,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "bluePotion",
                        "loc": [
                            [
                                9,
                                10
                            ],
                            [
                                10,
                                10
                            ],
                            [
                                11,
                                10
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                4
                            ]
                        ]
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        10,
        1
    ],
    "downFloor": [
        2,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}