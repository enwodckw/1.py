main.floors.MT30=
{
    "floorId": "MT30",
    "title": "魔塔 第30层",
    "name": "第 30 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  1,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  1,  1,  1,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1,  0,  1,  1,  0,  0,  0,  1],
    [  1,  0,  0,  1,  1,  0,204,  0,  1,  1,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1,  0,  1,  1,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  1,  0,  1,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1, 88,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 3,
    "defaultGround": "ground",
    "bgm": "section3.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "1,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "6,9": [
            "\t[史莱姆王,slimelord]你终于来了 我好想和你干一把 但我的部下们不同意",
            {
                "type": "setBlock",
                "number": "blackSlime",
                "loc": [
                    [
                        6,
                        5
                    ],
                    [
                        5,
                        6
                    ],
                    [
                        7,
                        6
                    ],
                    [
                        6,
                        7
                    ]
                ],
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "redSlime",
                "loc": [
                    [
                        6,
                        4
                    ],
                    [
                        7,
                        5
                    ],
                    [
                        8,
                        6
                    ],
                    [
                        7,
                        7
                    ],
                    [
                        5,
                        7
                    ],
                    [
                        4,
                        6
                    ],
                    [
                        5,
                        5
                    ]
                ],
                "time": 500
            },
            {
                "type": "setBlock",
                "number": "greenSlime",
                "loc": [
                    [
                        6,
                        3
                    ],
                    [
                        7,
                        4
                    ],
                    [
                        8,
                        5
                    ],
                    [
                        9,
                        6
                    ],
                    [
                        8,
                        7
                    ],
                    [
                        7,
                        8
                    ],
                    [
                        5,
                        8
                    ],
                    [
                        4,
                        7
                    ],
                    [
                        3,
                        6
                    ],
                    [
                        4,
                        5
                    ],
                    [
                        5,
                        4
                    ]
                ],
                "time": 500
            },
            {
                "type": "hide"
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "5,5": [
            {
                "type": "setValue",
                "name": "flag:30",
                "value": "-1"
            }
        ],
        "5,7": [
            {
                "type": "setValue",
                "name": "flag:30",
                "value": "-1"
            }
        ],
        "7,7": [
            {
                "type": "setValue",
                "name": "flag:30",
                "value": "-1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:30",
                "value": "-1"
            }
        ],
        "6,5": [
            {
                "type": "setValue",
                "name": "flag:30",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:30==4)",
                "true": [
                    "\t[史莱姆王,slimelord]完蛋了 我被封印了 功力只剩五成",
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "atk",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "def",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "hp",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "money",
                        "operator": "/=",
                        "value": "2"
                    }
                ]
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:30",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:30==4)",
                "true": [
                    "\t[史莱姆王,slimelord]完蛋了 我被封印了 功力只剩五成",
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "atk",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "def",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "hp",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "money",
                        "operator": "/=",
                        "value": "2"
                    }
                ]
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:30",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:30==4)",
                "true": [
                    "\t[史莱姆王,slimelord]完蛋了 我被封印了 功力只剩五成",
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "atk",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "def",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "hp",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "money",
                        "operator": "/=",
                        "value": "2"
                    }
                ]
            }
        ],
        "6,7": [
            {
                "type": "setValue",
                "name": "flag:30",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:30==4)",
                "true": [
                    "\t[史莱姆王,slimelord]完蛋了 我被封印了 功力只剩五成",
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "atk",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "def",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "hp",
                        "operator": "/=",
                        "value": "2"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                6,
                                6
                            ]
                        ],
                        "name": "money",
                        "operator": "/=",
                        "value": "2"
                    }
                ]
            }
        ],
        "6,6": [
            "\t[史莱姆王,slimelord]很好嘛 你通过了我的面试 你是个合格的勇士",
            {
                "type": "setBlock",
                "number": "yellowKey",
                "loc": [
                    [
                        5,
                        5
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "redPotion",
                "loc": [
                    [
                        7,
                        5
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "redGem",
                "loc": [
                    [
                        5,
                        7
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "blueGem",
                "loc": [
                    [
                        7,
                        7
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "0",
                "loc": [
                    [
                        6,
                        5
                    ],
                    [
                        7,
                        6
                    ],
                    [
                        6,
                        7
                    ],
                    [
                        5,
                        6
                    ]
                ]
            },
            {
                "type": "show",
                "loc": [
                    [
                        1,
                        1
                    ]
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "downFloor": [
        1,
        10
    ],
    "upFloor": [
        1,
        2
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}