main.floors.MT3=
{
    "floorId": "MT3",
    "title": "魔塔 第03层",
    "name": "第 3 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  1,  0,  0,  0,  0,  1, 32,  0, 81,  0,  1],
    [  1,  0,  1,  0,  0,  1, 21,  1, 32, 32,  1,205,  1],
    [  1,  0, 81,202,  0,  1,  0,  1, 21, 21,  1,  0,  1],
    [  1,  1,  1,  1, 81,  1,201,  1, 21, 21,  1,  0,  1],
    [  1, 21,  0,217,  0,  1,  0,  1,  1,  1,  1,  0,  1],
    [  1, 27,  0,  0,205,  1,  0, 22,  0,  0,  0,  0,  1],
    [  1,  1,209,  1,  1,  1,  0,  1,  1,  1,  1,205,  1],
    [  1,  0,  0,  0,  0,  1,201,  1,  0,  0,  0,  0,  1],
    [  1, 28, 31, 31, 21,  1,  0,  1, 31,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  0,  1, 21, 31,  1],
    [  1, 88,  0,126,  0,126,245,  1,121, 81,217, 35,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "4,11": [
            {
                "type": "setValue",
                "name": "flag:03",
                "value": "1"
            },
            {
                "type": "playSound",
                "name": "3F.mp3"
            },
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        11
                    ]
                ],
                "time": 500
            },
            "\t[魔王,redKing]欢迎来到魔塔 你是第100位挑战者 你若能打败我所有的手下 我就与你一对一的决斗 现在你必须接受我的安排",
            {
                "type": "show",
                "loc": [
                    [
                        3,
                        11
                    ],
                    [
                        5,
                        11
                    ]
                ],
                "time": 500
            },
            "\t[hero]什么",
            {
                "type": "setCurtain",
                "color": [
                    0,
                    0,
                    0,
                    1
                ],
                "time": 1000,
                "keep": true,
                "async": true
            },
            {
                "type": "playSound",
                "name": "zone.mp3",
                "stop": true
            },
            {
                "type": "sleep",
                "time": 300
            },
            {
                "type": "playSound",
                "name": "zone.mp3"
            },
            {
                "type": "sleep",
                "time": 150
            },
            {
                "type": "playSound",
                "name": "zone.mp3"
            },
            {
                "type": "sleep",
                "time": 300
            },
            {
                "type": "playSound",
                "name": "zone.mp3"
            },
            {
                "type": "sleep",
                "time": 150
            },
            {
                "type": "playSound",
                "name": "zone.mp3"
            },
            {
                "type": "waitAsync"
            },
            {
                "type": "setValue",
                "name": "status:hp",
                "value": "400"
            },
            {
                "type": "setValue",
                "name": "status:atk",
                "value": "10"
            },
            {
                "type": "setValue",
                "name": "status:def",
                "value": "10"
            },
            {
                "type": "setValue",
                "name": "flag:03",
                "value": "1"
            },
            {
                "type": "setValue",
                "name": "flag:nowWeapon",
                "value": "null"
            },
            {
                "type": "setValue",
                "name": "flag:nowShield",
                "value": "null"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        3,
                        11
                    ],
                    [
                        5,
                        11
                    ],
                    [
                        6,
                        11
                    ]
                ],
                "time": 0
            },
            {
                "type": "sleep",
                "time": 1000
            },
            {
                "type": "changeFloor",
                "floorId": "MT2",
                "loc": [
                    2,
                    5
                ],
                "direction": "down",
                "time": 0
            }
        ],
        "3,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": false,
            "data": []
        },
        "6,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": false,
            "data": []
        },
        "5,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": false,
            "data": []
        }
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        1,
        2
    ],
    "downFloor": [
        2,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}