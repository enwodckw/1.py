main.floors.MT35=
{
    "floorId": "MT35",
    "title": "魔塔 第35层",
    "name": "第 35 层",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,1": [
            {
                "type": "battle",
                "loc": [
                    5,
                    3
                ]
            }
        ],
        "10,3": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                "\t[小偷,thief]你好 暗道已挖好 你可用它绕过魔龙 我听说骑士队长实力差又爱吹牛 所以被魔法警卫们讨厌 这魔塔太危险了 我可不想再次被抓 我要离塔回去了 再见",
                {
                    "type": "openDoor",
                    "loc": [
                        10,
                        4
                    ]
                },
                {
                    "type": "hide",
                    "time": 500
                }
            ]
        }
    },
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "afterBattle": {
        "5,3": [
            {
                "type": "openDoor",
                "loc": [
                    3,
                    1
                ]
            },
            {
                "type": "setBlock",
                "number": "snow",
                "loc": [
                    [
                        5,
                        2
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "bluePotion",
                "loc": [
                    [
                        4,
                        1
                    ],
                    [
                        5,
                        1
                    ],
                    [
                        6,
                        1
                    ]
                ]
            }
        ],
        "9,9": [
            {
                "type": "setValue",
                "name": "flag:35",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:35==4)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            10,
                            8
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            10
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "11,9": [
            {
                "type": "setValue",
                "name": "flag:35",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:35==4)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            10,
                            8
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            10
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "9,11": [
            {
                "type": "setValue",
                "name": "flag:35",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:35==4)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            10,
                            8
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            10
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ],
        "11,11": [
            {
                "type": "setValue",
                "name": "flag:35",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:35==4)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            10,
                            8
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            10
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {
        "10,10": [
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    10,
                    8
                ],
                "async": true
            },
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    8,
                    10
                ],
                "async": true
            },
            {
                "type": "waitAsync"
            },
            "\t[yellowKnight]你拿到了骑士剑 这表明你是个勇士 但现在游戏结束了 我将在这里让双手剑士杀死你",
            {
                "type": "setBlock",
                "number": "swordsman",
                "loc": [
                    [
                        9,
                        9
                    ],
                    [
                        11,
                        9
                    ],
                    [
                        9,
                        11
                    ],
                    [
                        11,
                        11
                    ]
                ],
                "time": 200
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0, 85,189,190,191,  2,  0,  0,  0, 88,  1],
    [  1,  0,  0,  1,192,193,194,  1,  0,  1,  1,  1,  1],
    [  1,  2,  1,  1,195,257,196,  1,  0,  0,123,  0,  1],
    [  1,  2,  2,  1,  1,  2,  1,  1,  1,  1,  1,  1,  1],
    [  1,  2,  2,  1,  2,  2,  2,  2,  1,  2,  2,  2,  1],
    [  1,  2,  2,  1,  2,  1,  1,  2,  1,  2,  2,  2,  1],
    [  1,  2,  2,  2,  2,  2,  2,  2,  1,  2,  2,  2,  1],
    [  1,  2,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1,  1],
    [  1,  2,  2,  2,  1,  2,  2,  2,  1,  0,  0,  0,  1],
    [  1,  2,  1,  2,  2,  2,  1,  2,  0,  0, 39,  0,  1],
    [  1,  2,  2,  2,  1,  2,  2,  2,  1,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "downFloor": [
        10,
        1
    ],
    "upFloor": [
        2,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}