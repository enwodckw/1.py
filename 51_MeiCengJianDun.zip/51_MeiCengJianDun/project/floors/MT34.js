main.floors.MT34=
{
    "floorId": "MT34",
    "title": "魔塔 第34层",
    "name": "第 34 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0, 81,216,  0,  0,  0,212, 81,  0, 87,  1],
    [  1,  0, 31,  1,  0,  0,  0,  0,  0,  1,  0,  0,  1],
    [  1,216,  1,  1,  1,  1,  1, 81,  1,  1,  1,  0,  1],
    [  1,  0,  0, 21,  1,205, 81,203,  1,202,  1,  0,  1],
    [  1,  1, 81,  1,  1, 81,  1, 81,  1, 81,  1,  0,  1],
    [  1, 28,227, 31,  1,224,  1,212,  1,201,  1,  0,  1],
    [  1,  0, 40,  0,  1,  1,  1, 81,  1,  0, 81,  0,  1],
    [  1, 21, 21, 21,  1,227, 81,225,  1,  1,  1, 81,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  0,  0,  0,  1],
    [  1,225,  0,  0,  1, 27, 21,  0,  1,  0,  1,  0,  1],
    [  1, 32,224,  0, 81, 31,  0,225, 81,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "afterBattle": {
        "5,4": [
            {
                "type": "setValue",
                "name": "flag:34",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:34==8)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redKey",
                        "loc": [
                            [
                                10,
                                10
                            ]
                        ]
                    }
                ]
            }
        ],
        "7,4": [
            {
                "type": "setValue",
                "name": "flag:34",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:34==8)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redKey",
                        "loc": [
                            [
                                10,
                                10
                            ]
                        ]
                    }
                ]
            }
        ],
        "9,4": [
            {
                "type": "setValue",
                "name": "flag:34",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:34==8)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redKey",
                        "loc": [
                            [
                                10,
                                10
                            ]
                        ]
                    }
                ]
            }
        ],
        "9,6": [
            {
                "type": "setValue",
                "name": "flag:34",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:34==8)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redKey",
                        "loc": [
                            [
                                10,
                                10
                            ]
                        ]
                    }
                ]
            }
        ],
        "7,6": [
            {
                "type": "setValue",
                "name": "flag:34",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:34==8)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redKey",
                        "loc": [
                            [
                                10,
                                10
                            ]
                        ]
                    }
                ]
            }
        ],
        "5,6": [
            {
                "type": "setValue",
                "name": "flag:34",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:34==8)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redKey",
                        "loc": [
                            [
                                10,
                                10
                            ]
                        ]
                    }
                ]
            }
        ],
        "5,8": [
            {
                "type": "setValue",
                "name": "flag:34",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:34==8)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redKey",
                        "loc": [
                            [
                                10,
                                10
                            ]
                        ]
                    }
                ]
            }
        ],
        "7,8": [
            {
                "type": "setValue",
                "name": "flag:34",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "if",
                "condition": "(flag:34==8)",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                11,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "yellowKey",
                        "loc": [
                            [
                                9,
                                11
                            ]
                        ]
                    },
                    {
                        "type": "setBlock",
                        "number": "redKey",
                        "loc": [
                            [
                                10,
                                10
                            ]
                        ]
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        10,
        1
    ],
    "downFloor": [
        2,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}