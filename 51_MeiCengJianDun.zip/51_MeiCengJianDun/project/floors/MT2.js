main.floors.MT2=
{
    "floorId": "MT2",
    "title": "魔塔 第02层",
    "name": "第 2 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0, 32, 86,  0, 88,  0, 86, 21,  0,  0,  1],
    [  1,  0, 32, 32,  1,  0,  0,  0,  1, 21, 21,  0,  1],
    [  1, 86,  1,  1,  1,  1,  0,  1,  1,  1,  1, 86,  1],
    [  1,  0,  0,  0,  1,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,123,  0,  0, 86,  0,  0,  0,  1,  1, 82,  1,  1],
    [  1,  1,  1,  1,  1,  1,  1,  0,  1,222,  0,222,  1],
    [  1,  0,  0,  0,  0,  0,  1,  0,  1, 36,  1,  0,  1],
    [  1,  0,  0,  1,  0,  0,  1,  0,  1,  1,  1, 86,  1],
    [  1,  0,  1,  1,  1,  0,  1,  0,  1,  0,  0,121,  1],
    [  1,  0,  0,  1,  0,  0,  1,  0,  1,  0,124,  0,  1],
    [  1, 87,  0,  1,  0,  0,  0,  0, 86,123,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [],
    "eachArrive": [
        {
            "type": "if",
            "condition": "flag:03",
            "true": [
                {
                    "type": "sleep",
                    "time": 500
                },
                "\t[小偷,thief]喂",
                "\t[小偷,thief]喂 醒醒",
                {
                    "type": "setCurtain",
                    "time": 1000
                },
                {
                    "type": "hide",
                    "loc": [
                        [
                            4,
                            11
                        ]
                    ],
                    "floorId": "MT3",
                    "time": 0
                },
                {
                    "type": "setValue",
                    "name": "flag:03",
                    "value": "0"
                }
            ],
            "false": []
        }
    ],
    "parallelDo": "",
    "events": {
        "1,5": [
            "\t[小偷,thief]你清醒了吗 你到监狱时还处在昏迷中 魔法警卫把你扔到我这个房间 但你很幸运 我刚完成逃跑的暗道你就醒了 我们一起越狱吧",
            {
                "type": "openDoor",
                "loc": [
                    1,
                    6
                ]
            },
            {
                "type": "show",
                "loc": [
                    [
                        1,
                        8
                    ]
                ],
                "time": 0
            },
            {
                "type": "move",
                "time": 200,
                "keep": true,
                "steps": [
                    "down:3"
                ]
            },
            {
                "type": "hide",
                "time": 0
            }
        ],
        "1,8": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                "\t[小偷,thief]我们终于逃出来了 你的剑盾被警卫拿走了 你必须先找到武器 我知道铁剑在1 3 5 7 9楼 铁盾在2 4 6 8 10楼 你最好先取到他们 我现在有事要做没法帮你 再见",
                {
                    "type": "move",
                    "time": 200,
                    "steps": [
                        "down:2"
                    ]
                },
                {
                    "type": "hide",
                    "time": 0
                }
            ]
        },
        "9,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                "\t[小偷,thief]你终于来了 我以为再也出不去了呢 35层有个魔龙挡路 我帮你挖一条暗道吧",
                {
                    "type": "show",
                    "loc": [
                        [
                            10,
                            3
                        ]
                    ],
                    "floorId": "MT35",
                    "time": 0
                },
                {
                    "type": "function",
                    "function": "function(){\ncore.extractBlocks('MT35');\nvar a = core.status.maps.MT35.blocks;\nvar indexes = [];\nfor (var i = 0; i < a.length; ++i) {\n\tif (a[i] && a[i].id == 2) {\n\t\tindexes.push(i);\n\t}\n}\ncore.removeBlockByIndexes(indexes, \"MT35\");\n}"
                },
                {
                    "type": "hide",
                    "time": 500
                }
            ]
        },
        "10,10": [
            {
                "type": "choices",
                "text": "\t[商人,woman]谢谢你救了我 我可以帮你提升3%的攻击和防御",
                "choices": [
                    {
                        "text": "现在提升",
                        "action": [
                            {
                                "type": "playSound",
                                "name": "item.mp3"
                            },
                            {
                                "type": "addValue",
                                "name": "status:atk",
                                "value": "Math.round(status:atk*0.03)"
                            },
                            {
                                "type": "addValue",
                                "name": "status:def",
                                "value": "Math.round(status:def*0.03)"
                            },
                            {
                                "type": "setValue",
                                "name": "flag:talking",
                                "value": "2"
                            },
                            {
                                "type": "hide",
                                "time": 500
                            }
                        ]
                    },
                    {
                        "text": "等会再说",
                        "action": []
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "9,6": [
            {
                "type": "if",
                "condition": "flag:2",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            1
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            11,
                            3
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            4,
                            1
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            1,
                            3
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            4,
                            5
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            11,
                            8
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            11
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:2",
                        "value": "1"
                    }
                ]
            }
        ],
        "11,6": [
            {
                "type": "if",
                "condition": "flag:2",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            1
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            11,
                            3
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            4,
                            1
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            1,
                            3
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            4,
                            5
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            11,
                            8
                        ],
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            11
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:2",
                        "value": "1"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        1,
        10
    ],
    "downFloor": [
        6,
        2
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}