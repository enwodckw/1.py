main.floors.MT19=
{
    "floorId": "MT19",
    "title": "魔塔 第19层",
    "name": "第 19 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 31,218, 22,  1,  0, 87,  0,  1, 21,  0, 27,  1],
    [  1,214, 37,214,  1, 21,  0, 21,  1,  0,  0,  0,  1],
    [  1,  0,  2,  0,  1, 81,  1,  0,  1,  0,206,  0,  1],
    [  1,  1,320,  1,  1,206,  1,214,  1,  1, 81,  1,  1],
    [  1,  0,  2,  0,  1,  0,  1,  0,  1,  0,203,  0,  1],
    [  1, 21,  0, 21,  1,203,  1,205,  1,203,  0,203,  1],
    [  1,  1, 85,  1,  1, 81,  1, 81,  1,  1, 81,  1,  1],
    [  1,215,  0,215,  1,  0,  0,  0,  0,214,  0, 21,  1],
    [  1,  0,  0,  0,  1,  1,206,  1,  1,  0,213,  0,  1],
    [  1,  1, 82,  1,  1,  0,  0,  0,  1,  1, 81,  1,  1],
    [  1,  0,203,206, 81,  0, 88,  0,205,  0,206, 31,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "section2.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "2,4": [
            {
                "type": "playSound",
                "name": "door.mp3"
            },
            {
                "type": "setBlock",
                "number": "cross",
                "loc": [
                    [
                        2,
                        4
                    ]
                ]
            }
        ]
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        },
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "1,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT19_2_7",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,8": [
            {
                "type": "setValue",
                "name": "flag:door_MT19_2_7",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "downFloor": [
        6,
        10
    ],
    "upFloor": [
        6,
        2
    ],
    "autoEvent": {
        "2,7": {
            "0": {
                "condition": "flag:door_MT19_2_7==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT19_2_7",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}