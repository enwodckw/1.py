main.floors.MT43=
{
    "floorId": "MT43",
    "title": "魔塔 第43层",
    "name": "第 43 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 22,  0,228, 81, 32, 32, 32,339,335,339,  0,  1],
    [  1,  0,207,  0,  1, 82,331,331,331,331,331, 82,  1],
    [  1,  1, 81,  1,  1,  0,331,  0,331,  0,331,  0,  1],
    [  1,  0,  0,  0, 82,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,207,  1,  1,  1, 81,  1,  0,  1,  0,  1,  0,  1],
    [  1,  0,  0,204,  0,220,  1,  1,  1,  1,  1,  0,  1],
    [  1, 81,  1,  1, 81,  1,  1,  0,  0,204, 81,  0,  1],
    [  1,  0,  1, 32,204,  0,  1, 81,  1,228,  1,  0,  1],
    [  1,  0,  1,  1, 81,  1,  1, 81,  0,228,  1,  0,  1],
    [  1,  0,  1,219,  0,  0, 81,246, 41,  0,  1,  0,  1],
    [  1, 87,  1,  0, 21, 31,  1,  0,  0,  0,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": "section5.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": "MT45",
            "stair": "downFloor",
            "time": 0
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:43",
                "value": "1"
            }
        ],
        "9,9": [
            {
                "type": "setValue",
                "name": "flag:43",
                "value": "1"
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:43",
                "value": "1"
            }
        ],
        "9,1": [
            {
                "type": "setBlock",
                "number": "sword5"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {
        "7,9": [
            {
                "type": "if",
                "condition": "(!flag:43)",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            10
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            7,
                            10
                        ],
                        "time": 200,
                        "keep": true,
                        "steps": [
                            "left:2"
                        ]
                    },
                    {
                        "type": "closeDoor",
                        "id": "yellowWall",
                        "loc": [
                            6,
                            10
                        ],
                        "async": true
                    },
                    {
                        "type": "closeDoor",
                        "id": "yellowWall",
                        "loc": [
                            8,
                            7
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    },
                    {
                        "type": "hide"
                    }
                ]
            }
        ]
    },
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        1,
        10
    ],
    "downFloor": [
        11,
        10
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}