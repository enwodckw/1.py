main.floors.MT45=
{
    "floorId": "MT45",
    "title": "魔塔 第45层",
    "name": "第 45 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 27, 82, 28,  1,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1, 27,  1, 28,  1,  0,  1,  1,  1,  1,  1,  0,  1],
    [  1,228,  0,228,  1,  0,  1,219,  1,220,  1,  0,  1],
    [  1,  1, 81,  1,  1,  0, 81,  0,  0,  0, 81,  0,  1],
    [  1,  0,  0,  0,  0,  0,  1,220,  0,219,  1,  0,  1],
    [  1,  0,  1,  1,  1,  1,  1,  1, 81,  1,  1,  0,  1],
    [  1,  0,  1,  0, 21,  0, 81,207,  0,  0,  1,  0,  1],
    [  1,  0,  1, 32,  0,220,  1,  1, 83,  1,  1,  0,  1],
    [  1,  0,  1,  1, 81,  1,  1,204,  0, 51,  1,  0,  1],
    [  1,  0,  1,246,  0,246, 85,  0, 41,  0,  1,  0,  1],
    [  1, 87,  1,228,  0,228,  1,121,  0,122,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": "section5.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,11": {
            "floorId": "MT43",
            "stair": "upFloor",
            "time": 0
        },
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "3,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT45_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,10": [
            {
                "type": "setValue",
                "name": "flag:door_MT45_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT45_6_10",
                "operator": "+=",
                "value": "1"
            }
        ],
        "5,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT45_6_10",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        1,
        10
    ],
    "downFloor": [
        11,
        10
    ],
    "autoEvent": {
        "6,10": {
            "0": {
                "condition": "flag:door_MT45_6_10==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT45_6_10",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}