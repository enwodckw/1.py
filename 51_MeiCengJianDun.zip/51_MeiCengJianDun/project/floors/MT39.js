main.floors.MT39=
{
    "floorId": "MT39",
    "title": "魔塔 第39层",
    "name": "第 39 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,227, 81,  0,216,  0, 81,  0,  0,  0, 88,  1],
    [  1,  0,  0,  1,  0,  1,  0,  1,  0,  1,  1,  1,  1],
    [  1, 81,  1,  1,212, 27,225,  1, 21,  0,  0,122,  1],
    [  1,  0,224,  1,  1,  1,  1,  1,  1,  1,  0,  1,  1],
    [  1,216, 28,  1, 21,  0,  0,212,  1, 81, 81, 81,  1],
    [  1,  0,227,  1,  0,  1,  1,  0, 82, 81, 81, 81,  1],
    [  1,  0,  0, 81,  0,121,  0,212,  1, 81, 81, 81,  1],
    [331,331,331,331,331,  1,  1,  1,  1,  1,  0,  1,  1],
    [331,  0,  0,  0,331,  0,  0,  0,  1,  0,227,  0,  1],
    [331,  0,338,  0,331,  0,  1,  0,  1,  0, 39,  0,  1],
    [331,  0,  0,  0,331,  0,  0,  0,  1,  0,  0,  0,  1],
    [331,331,331,331,331,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "10,6": {
            "trigger": "action",
            "enable": true,
            "noPass": null,
            "displayDamage": true,
            "data": [
                {
                    "type": "if",
                    "condition": "flag:centerFly",
                    "true": [
                        {
                            "type": "addValue",
                            "name": "item:centerFly",
                            "value": "3"
                        },
                        {
                            "type": "hide",
                            "time": 0
                        }
                    ],
                    "false": [
                        {
                            "type": "openDoor",
                            "needKey": true
                        }
                    ]
                }
            ]
        }
    },
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "afterBattle": {
        "2,10": [
            {
                "type": "setBlock",
                "number": "sword5"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {
        "10,5": [
            {
                "type": "if",
                "condition": "(flag:39 == 1)",
                "true": [
                    {
                        "type": "playSound",
                        "name": "door.mp3"
                    },
                    {
                        "type": "setBlock",
                        "number": "50",
                        "loc": [
                            [
                                10,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "setValue",
                        "name": "flag:centerFly",
                        "value": "1"
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:39",
                        "value": "1"
                    }
                ]
            }
        ],
        "9,6": [
            {
                "type": "if",
                "condition": "(flag:39 == 1)",
                "true": [
                    {
                        "type": "playSound",
                        "name": "door.mp3"
                    },
                    {
                        "type": "setBlock",
                        "number": "50",
                        "loc": [
                            [
                                10,
                                6
                            ]
                        ]
                    },
                    {
                        "type": "setValue",
                        "name": "flag:centerFly",
                        "value": "1"
                    }
                ],
                "false": [
                    {
                        "type": "addValue",
                        "name": "flag:39",
                        "value": "1"
                    }
                ]
            }
        ],
        "10,6": [
            {
                "type": "addValue",
                "name": "flag:39",
                "value": "-1"
            }
        ],
        "11,5": [
            {
                "type": "addValue",
                "name": "flag:39",
                "value": "-1"
            }
        ],
        "11,6": [
            {
                "type": "addValue",
                "name": "flag:39",
                "value": "-1"
            }
        ],
        "11,7": [
            {
                "type": "addValue",
                "name": "flag:39",
                "value": "-1"
            }
        ],
        "10,7": [
            {
                "type": "addValue",
                "name": "flag:39",
                "value": "-1"
            }
        ],
        "9,7": [
            {
                "type": "addValue",
                "name": "flag:39",
                "value": "-1"
            }
        ],
        "9,5": [
            {
                "type": "addValue",
                "name": "flag:39",
                "value": "-1"
            }
        ]
    },
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        1,
        2
    ],
    "downFloor": [
        10,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}