main.floors.MT32=
{
    "floorId": "MT32",
    "title": "魔塔 第32层",
    "name": "第 32 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 88,  0,  0,212,  0,  0,  0,  0,  0,226, 87,  1],
    [  1,  0,  0,  1,  0,  7,131,  8,  0,  1,  0,  0,  1],
    [  1,  1,  0,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,222,  0,222,  1,216,  0,216, 81,  0,  1,  0,  1],
    [  1,  1, 85,  1,  1,  0, 21,  0,  1,  0,  1,  0,  1],
    [  1, 21,  0, 21,  1,225,  1,  1,  1,  0,  1,  0,  1],
    [  1,  0, 40,  0,  1, 81,  1,  0, 82,  0,  0,  0,  1],
    [  1, 21, 22, 21,  1, 28,  0, 27,  1,  1,  1, 81,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1, 21,  0,212,  1],
    [  1, 21,  0, 21,  1,  0,  0,  0,  1,  0,  0,  0,  1],
    [  1,  0, 22,  0, 81,227,  0,  0, 81, 21,  0, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "10,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "data": []
        },
        "6,2": [
            {
                "type": "setValue",
                "name": "flag:ratio",
                "value": "4"
            },
            {
                "type": "setValue",
                "name": "flag:shopratio",
                "value": "Math.max(core.getFlag('shopratio', 1), core.getFlag('ratio', 1))"
            },
            {
                "type": "openShop",
                "id": "shop1"
            },
            {
                "type": "insert",
                "name": "商店"
            }
        ],
        "3,1": [
            {
                "type": "show",
                "loc": [
                    [
                        10,
                        1
                    ]
                ],
                "time": 500
            },
            "\t[骑士队长,yellowKnight]你打败了前两个区域的头目 这表明你是个勇士 但现在游戏结束了 我将在这里亲手杀死你",
            {
                "type": "callBook"
            },
            {
                "type": "move",
                "loc": [
                    4,
                    1
                ],
                "time": 200,
                "keep": true,
                "steps": [
                    "down:1"
                ]
            },
            {
                "type": "move",
                "loc": [
                    10,
                    1
                ],
                "time": 200,
                "keep": true,
                "steps": [
                    "left:6"
                ]
            },
            {
                "type": "battle",
                "id": "yellowKnight"
            },
            {
                "type": "move",
                "loc": [
                    4,
                    1
                ],
                "time": 200,
                "keep": true,
                "steps": [
                    "right:6"
                ]
            },
            {
                "type": "move",
                "loc": [
                    4,
                    2
                ],
                "time": 200,
                "keep": true,
                "steps": [
                    "up:1"
                ]
            },
            "\t[骑士队长,yellowKnight]你以为你已非常强大了吗 嘿嘿错了 只是我今天状态不佳而已 我走了 有本事到40楼与我再打一次",
            {
                "type": "hide",
                "loc": [
                    [
                        10,
                        1
                    ]
                ],
                "time": 500
            },
            {
                "type": "hide",
                "loc": [
                    [
                        3,
                        1
                    ]
                ],
                "time": 500
            }
        ]
    },
    "changeFloor": {
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "1,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "1,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT32_2_5",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,4": [
            {
                "type": "setValue",
                "name": "flag:door_MT32_2_5",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "downFloor": [
        2,
        1
    ],
    "upFloor": [
        10,
        1
    ],
    "autoEvent": {
        "2,5": {
            "0": {
                "condition": "flag:door_MT32_2_5==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT32_2_5",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}