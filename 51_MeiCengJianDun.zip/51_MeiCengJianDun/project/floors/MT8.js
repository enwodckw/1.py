main.floors.MT8=
{
    "floorId": "MT8",
    "title": "魔塔 第08层",
    "name": "第 8 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,201, 27, 21,  1,  0, 88,  0,  1, 21,  0, 31,  1],
    [  1,205, 21, 28,  1,  0,  0,  0,  1,  0, 22,210,  1],
    [  1, 82,  1,  1,  1,  1, 81,  1,  1,  1,  1, 81,  1],
    [  1,  0,205,  0,  1,  0,  0,  0,  0,217,  0,209,  1],
    [  1,205,  0,209, 81,  0,  0,  0,  1,  1, 81,  1,  1],
    [  1, 81,  1,  1,  1, 81,  1,205,  1,  0,221,  0,  1],
    [  1,  0,202,201,202,  0,  1,  0,  1, 36,  1,221,  1],
    [  1,  0, 31,  1,  0,  0,  1,  0,  1,  1,  1, 85,  1],
    [  1, 81,  1,  1,  1, 81,  1,  0,  1, 21,  0, 21,  1],
    [  1,  0,201,  1,  0, 21,  1,217,  1,  0, 23,  0,  1],
    [  1, 87,  0, 81, 21, 21, 81,  0,  1, 32,  0, 31,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "afterBattle": {
        "11,7": [
            {
                "type": "setValue",
                "name": "flag:door_MT8_11_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "10,6": [
            {
                "type": "setValue",
                "name": "flag:door_MT8_11_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        1,
        10
    ],
    "downFloor": [
        6,
        2
    ],
    "autoEvent": {
        "11,8": {
            "0": {
                "condition": "flag:door_MT8_11_8==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT8_11_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}