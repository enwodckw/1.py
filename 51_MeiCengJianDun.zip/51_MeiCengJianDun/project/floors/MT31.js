main.floors.MT31=
{
    "floorId": "MT31",
    "title": "魔塔 第31层",
    "name": "第 31 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0, 81,214,  0,214, 81,  0,  0,  0, 88,  1],
    [  1,  0,  0,  1,  0,  0,  0,  1,  0,  1,  1,  1,  1],
    [  1, 81,  1,  1,  0,  0,  0,  1,  0,  0,  0,  0,  1],
    [  1,212,  0,  1,  1,  1,  1,  1,  1,  1, 81,  1,  1],
    [  1,  0,  0,  1, 31, 21, 21, 31,  1,  0,212,  0,  1],
    [  1,  0,  0, 81,216,  1,  1,216, 81,  0,  0,  0,  1],
    [  1,212,  0,  1, 31, 21, 21, 31,  1, 31,  0,121,  1],
    [  1, 81,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1,  1],
    [  1,  0,224, 21,  1,  0, 31,  0,  1,212,  0,212,  1],
    [  1,225,  1, 21,  1,212,122,227,  1,  0, 39,  0,  1],
    [  1, 21, 21, 22, 81,  0,  1, 28,  1,225, 27,225,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {},
    "changeFloor": {
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor"
        },
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor"
        }
    },
    "afterBattle": {
        "9,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT31_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,9": [
            {
                "type": "setValue",
                "name": "flag:door_MT31_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT31_10_8",
                "operator": "+=",
                "value": "1"
            }
        ],
        "11,11": [
            {
                "type": "setValue",
                "name": "flag:door_MT31_10_8",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {
        "10,10": [
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    10,
                    8
                ]
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        2,
        1
    ],
    "downFloor": [
        10,
        1
    ],
    "autoEvent": {
        "10,8": {
            "0": {
                "condition": "flag:door_MT31_10_8==4",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT31_10_8",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            },
            "1": null
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}