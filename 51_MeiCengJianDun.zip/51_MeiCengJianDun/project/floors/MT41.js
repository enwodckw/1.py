main.floors.MT41=
{
    "floorId": "MT41",
    "title": "魔塔 第41层",
    "name": "第 41 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,229,207,  0,  1, 81,333, 32,  1, 32,333, 81,  1],
    [  1, 22,  0,207,  1, 31,  1,  1,  1,  1,  1, 31,  1],
    [  1,  0,219,  0,  1, 81,  1,246,  1,246,  1, 81,  1],
    [  1,  1, 82,  1,  1,  0,  0,245,  0,  0,  0,  0,  1],
    [  1,  0,  0, 81,  0,  0,  1,246,  1,246,  1,  0,  1],
    [  1,  0,  1,  1, 81,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1, 81,  1, 31,204, 28,  1,  0,  0,  0,  0,  0,  1],
    [  1,  0,  1, 21,  0, 21,  1,  1, 82,  1,  1,  0,  1],
    [  1, 81,  1,  1, 81,  1,  1,  0,219,  0,  1,226,  1],
    [  1,  0,  1, 31,204, 27,  1,207, 41, 22,  1,  0,  1],
    [  1, 87,  1, 21,  0, 21,  1,  0,207,  1,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": "section5.mp3",
    "firstArrive": [
        {
            "type": "show",
            "loc": [
                [
                    6,
                    10
                ]
            ],
            "floorId": "MT42",
            "time": 0
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "11,9": {
            "trigger": "action",
            "enable": true,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "if",
                    "condition": "(status:direction=='down')",
                    "true": [
                        {
                            "type": "battle",
                            "loc": [
                                11,
                                9
                            ]
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    11,
                                    4
                                ]
                            ]
                        },
                        {
                            "type": "hide"
                        }
                    ],
                    "false": [
                        "\t[骑士队长,yellowKnight]啊！又是你！！",
                        {
                            "type": "move",
                            "loc": [
                                11,
                                9
                            ],
                            "time": 200,
                            "keep": true,
                            "steps": [
                                "up:5",
                                "left:2"
                            ]
                        },
                        {
                            "type": "show",
                            "loc": [
                                [
                                    7,
                                    4
                                ]
                            ],
                            "time": 500
                        },
                        "\t[魔王,redKing]你敢临阵脱逃！",
                        "\t[骑士队长,yellowKnight]哦，大王，我打不过这个勇士，不得不逃，饶了我吧",
                        "\t[redKing]你说什么？你敢再说一次！你像个胆小鬼一样逃离你负责的区域,并说出那样的话。魔塔不需要像你这样的败类，来人给我杀了。",
                        {
                            "type": "jump",
                            "from": [
                                7,
                                3
                            ],
                            "to": [
                                8,
                                4
                            ],
                            "time": 500,
                            "keep": true,
                            "async": true
                        },
                        {
                            "type": "jump",
                            "from": [
                                7,
                                5
                            ],
                            "to": [
                                10,
                                4
                            ],
                            "time": 500,
                            "keep": true,
                            "async": true
                        },
                        {
                            "type": "waitAsync"
                        },
                        "\t[骑士队长,yellowKnight]饶命啊",
                        {
                            "type": "playSound",
                            "name": "attack.mp3"
                        },
                        {
                            "type": "function",
                            "function": "function(){\ncore.drawImage(\"animate\", core.statusBar.icons.battle, 0, 0, 32, 32, (9 - 1) * 32, (4 - 1) * 32, 32, 32);\nsetTimeout(function () { core.clearMap(\"animate\", (9 - 1) * 32, (4 - 1) * 32, 32, 32); }, 100);\n}"
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    9,
                                    4
                                ]
                            ],
                            "time": 500
                        },
                        "\t[魔王,redKing]虽然我刚才态度异常，但别担心, 在决斗时，我不会像刚才这个无用的家伙一样让手下一拥而上。我期待着与你决斗。",
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    7,
                                    4
                                ],
                                [
                                    8,
                                    4
                                ],
                                [
                                    10,
                                    4
                                ]
                            ],
                            "time": 500
                        },
                        "\t[hero]不是 怎么还给我留一个夹击啊",
                        {
                            "type": "setValue",
                            "name": "flag:41_1",
                            "value": "1"
                        },
                        {
                            "type": "hide",
                            "loc": [
                                [
                                    11,
                                    4
                                ]
                            ]
                        },
                        {
                            "type": "hide"
                        }
                    ]
                }
            ]
        },
        "7,4": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "11,4": [
            {
                "type": "if",
                "condition": "(!flag:41_1)",
                "true": [
                    "\t[骑士队长,yellowKnight]偷袭！",
                    {
                        "type": "move",
                        "loc": [
                            11,
                            9
                        ],
                        "time": 200,
                        "keep": true,
                        "steps": [
                            "up:4"
                        ]
                    },
                    {
                        "type": "battle",
                        "loc": [
                            11,
                            5
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                11,
                                9
                            ]
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                11,
                                4
                            ]
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor"
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor"
        }
    },
    "afterBattle": {
        "1,1": [
            {
                "type": "openDoor",
                "loc": [
                    9,
                    11
                ]
            },
            {
                "type": "setBlock",
                "number": "redWizard",
                "loc": [
                    [
                        9,
                        11
                    ]
                ]
            }
        ],
        "9,11": [
            {
                "type": "closeDoor",
                "id": "yellowWall",
                "loc": [
                    6,
                    4
                ]
            },
            {
                "type": "setBlock",
                "number": "downFly",
                "loc": [
                    [
                        8,
                        4
                    ]
                ]
            },
            {
                "type": "show",
                "loc": [
                    [
                        8,
                        4
                    ]
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        1,
        10
    ],
    "downFloor": [
        11,
        10
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}