main.floors.MT49=
{
    "floorId": "MT49",
    "title": "魔塔 第49层",
    "name": "第 49 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,126,126,126,  1,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,126,245,126,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,126,126,126,  1,  0,  1,228,  1,229,  1,  0,  1],
    [  1,  1, 85,  1,  1,  0, 85,  0, 85,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  1,228,  1,229,  1,  0,  1],
    [  1,  0,  1,  1,  0,  1,  1,  1,  1,  1,  1,  0,  1],
    [  1,  0,  1,  0,  0,  0,  1,  0,  0,  0,  0,  0,  1],
    [  1,  0,  1,  0,  0,  0,  1,  1, 85,  1,  1, 83,  1],
    [  1,  0,  1,  1,  0,  1,  1,246,246,246,  1,  0,  1],
    [  1,  0,  1,  0,  0,  0,  1,246, 41,246,  1,  0,  1],
    [  1,  0,  1,  0,  0,  0,  1,246,246,246,  1, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": "section5.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "2,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 0.5,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "1,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 0.5,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "3,1": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 0.5,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "3,2": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 0.5,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "3,3": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 0.5,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "2,3": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 0.5,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "1,3": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 0.5,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "1,2": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 0.5,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "2,2": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "2,5": [
            {
                "type": "closeDoor",
                "id": "specialDoor",
                "loc": [
                    11,
                    8
                ],
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    8,
                    8
                ],
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    2,
                    4
                ],
                "async": true
            },
            {
                "type": "waitAsync"
            },
            {
                "type": "show",
                "loc": [
                    [
                        2,
                        2
                    ]
                ],
                "time": 500
            },
            "\t[魔王,redKing]你终于来啦 我好想和你干一把 但是我的部下不同意",
            {
                "type": "playBgm",
                "name": "boss5.mp3"
            },
            {
                "type": "show",
                "loc": [
                    [
                        1,
                        1
                    ],
                    [
                        2,
                        1
                    ],
                    [
                        3,
                        1
                    ],
                    [
                        3,
                        2
                    ],
                    [
                        3,
                        3
                    ],
                    [
                        2,
                        3
                    ],
                    [
                        1,
                        3
                    ],
                    [
                        1,
                        2
                    ]
                ],
                "time": 500,
                "async": true
            },
            {
                "type": "show",
                "loc": [
                    [
                        7,
                        9
                    ],
                    [
                        8,
                        9
                    ],
                    [
                        9,
                        9
                    ],
                    [
                        9,
                        10
                    ],
                    [
                        9,
                        11
                    ],
                    [
                        8,
                        11
                    ],
                    [
                        7,
                        11
                    ],
                    [
                        7,
                        10
                    ]
                ],
                "time": 500,
                "async": true
            },
            {
                "type": "waitAsync"
            },
            {
                "type": "hide",
                "time": 0
            }
        ],
        "7,9": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "8,9": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "9,9": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "9,10": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "9,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "8,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "7,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "7,10": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        }
    },
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "9,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT49_8_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "9,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT49_8_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,3": [
            {
                "type": "setValue",
                "name": "flag:door_MT49_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT49_6_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "7,9": [
            {
                "type": "setValue",
                "name": "flag:494",
                "operator": "-=",
                "value": "1"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        3,
                        3
                    ]
                ]
            }
        ],
        "9,9": [
            {
                "type": "setValue",
                "name": "flag:494",
                "operator": "-=",
                "value": "1"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        1,
                        3
                    ]
                ]
            }
        ],
        "7,11": [
            {
                "type": "setValue",
                "name": "flag:494",
                "operator": "-=",
                "value": "1"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        3,
                        1
                    ]
                ]
            }
        ],
        "9,11": [
            {
                "type": "setValue",
                "name": "flag:494",
                "operator": "-=",
                "value": "1"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        1,
                        1
                    ]
                ]
            }
        ],
        "8,9": [
            {
                "type": "setValue",
                "name": "flag:494",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        2,
                        3
                    ]
                ]
            },
            {
                "type": "if",
                "condition": "(flag:494==4)",
                "true": [
                    "\t[魔王,redKing]完蛋了 我被封印了 功力只剩一成",
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "atk",
                        "operator": "/=",
                        "value": "10"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "def",
                        "operator": "/=",
                        "value": "10"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "hp",
                        "operator": "/=",
                        "value": "10"
                    }
                ]
            }
        ],
        "7,10": [
            {
                "type": "setValue",
                "name": "flag:494",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        3,
                        2
                    ]
                ]
            },
            {
                "type": "if",
                "condition": "(flag:494==4)",
                "true": [
                    "\t[魔王,redKing]完蛋了 我被封印了 功力只剩一成",
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "atk",
                        "operator": "/=",
                        "value": "10"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "def",
                        "operator": "/=",
                        "value": "10"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "hp",
                        "operator": "/=",
                        "value": "10"
                    }
                ]
            }
        ],
        "9,10": [
            {
                "type": "setValue",
                "name": "flag:494",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        1,
                        2
                    ]
                ]
            },
            {
                "type": "if",
                "condition": "(flag:494==4)",
                "true": [
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "atk",
                        "operator": "/=",
                        "value": "10"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "def",
                        "operator": "/=",
                        "value": "10"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "hp",
                        "operator": "/=",
                        "value": "10"
                    }
                ]
            }
        ],
        "8,11": [
            {
                "type": "setValue",
                "name": "flag:494",
                "operator": "+=",
                "value": "1"
            },
            {
                "type": "hide",
                "loc": [
                    [
                        2,
                        1
                    ]
                ]
            },
            {
                "type": "if",
                "condition": "(flag:494==4)",
                "true": [
                    "\t[魔王,redKing]完蛋了 我被封印了 功力只剩一成",
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "atk",
                        "operator": "/=",
                        "value": "10"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "def",
                        "operator": "/=",
                        "value": "10"
                    },
                    {
                        "type": "setEnemyOnPoint",
                        "loc": [
                            [
                                2,
                                2
                            ]
                        ],
                        "name": "hp",
                        "operator": "/=",
                        "value": "10"
                    }
                ]
            }
        ],
        "2,2": [
            "\t[redKing]很好嘛 你通过了我的面试 你是个合格的勇士",
            {
                "type": "hide",
                "loc": [
                    [
                        1,
                        1
                    ],
                    [
                        2,
                        1
                    ],
                    [
                        3,
                        1
                    ],
                    [
                        3,
                        2
                    ],
                    [
                        3,
                        3
                    ],
                    [
                        2,
                        3
                    ],
                    [
                        1,
                        3
                    ],
                    [
                        1,
                        2
                    ],
                    [
                        7,
                        9
                    ],
                    [
                        8,
                        9
                    ],
                    [
                        9,
                        9
                    ],
                    [
                        9,
                        10
                    ],
                    [
                        9,
                        11
                    ],
                    [
                        8,
                        11
                    ],
                    [
                        7,
                        11
                    ],
                    [
                        7,
                        10
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "redGem",
                "loc": [
                    [
                        3,
                        7
                    ],
                    [
                        4,
                        7
                    ],
                    [
                        5,
                        7
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "blueGem",
                "loc": [
                    [
                        3,
                        8
                    ],
                    [
                        4,
                        8
                    ],
                    [
                        5,
                        8
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "bluePotion",
                "loc": [
                    [
                        3,
                        11
                    ],
                    [
                        4,
                        11
                    ],
                    [
                        5,
                        11
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "redKey",
                "loc": [
                    [
                        3,
                        10
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "knife",
                "loc": [
                    [
                        5,
                        10
                    ]
                ]
            },
            {
                "type": "openDoor",
                "loc": [
                    11,
                    8
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "downFloor": [
        11,
        10
    ],
    "autoEvent": {
        "8,4": {
            "0": {
                "condition": "flag:door_MT49_8_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT49_8_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        },
        "6,4": {
            "0": {
                "condition": "flag:door_MT49_6_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT49_6_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}