main.floors.MT20=
{
    "floorId": "MT20",
    "title": "魔塔 第20层",
    "name": "第 20 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  1, 32,  0, 82,  0,  1,  0, 31,  1],
    [  1,  0, 38,  0,  1, 31, 21,  1,205,  1,215,  0,  1],
    [  1,  0,  0,  0,  1,  1,  1,  1,  0, 81,  0,  0,  1],
    [  1,  1, 85,  1,  1, 27, 21,  1,  1,  1,  1,218,  1],
    [  1,206,206,206,  1, 28,  0, 82,  0,205,  1,  0,  1],
    [  1,206,208,206,  1,  1,  1,  1,205,  0,  1,  0,  1],
    [  1,206,206,206,  1, 31,218, 81,  0,205,  1,  0,  1],
    [  1,  1, 83,  1,  1,  1,  0,  1,  1,  1,  1,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  1,  0,  1,  1,  0,  1,  0,  1],
    [  1,  0,  0,  0,  0,  1, 88,  1,215,  0,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "section2.mp3",
    "firstArrive": [
        {
            "type": "setValue",
            "name": "flag:20",
            "value": "0"
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "11,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "2,6": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        }
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "2,6": [
            "\t[吸血鬼,vampire]上帝啊 我做梦也没想到我会被别人打败 毫无疑问你是比我强 但以你现在的状态对于大法师来说又太弱了 你仅仅取得了一个暂时的胜利",
            {
                "type": "playSound",
                "name": "door.mp3",
                "stop": true
            },
            {
                "type": "setBlock",
                "number": "21",
                "loc": [
                    [
                        1,
                        9
                    ],
                    [
                        1,
                        10
                    ],
                    [
                        1,
                        11
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "27",
                "loc": [
                    [
                        2,
                        9
                    ],
                    [
                        2,
                        10
                    ],
                    [
                        2,
                        11
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "28",
                "loc": [
                    [
                        3,
                        9
                    ],
                    [
                        3,
                        10
                    ],
                    [
                        3,
                        11
                    ]
                ]
            },
            {
                "type": "setBlock",
                "number": "32",
                "loc": [
                    [
                        4,
                        9
                    ],
                    [
                        4,
                        10
                    ],
                    [
                        4,
                        11
                    ]
                ]
            },
            {
                "type": "openDoor",
                "loc": [
                    2,
                    4
                ],
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    5,
                    9
                ],
                "async": true
            },
            {
                "type": "show",
                "loc": [
                    [
                        11,
                        11
                    ]
                ]
            },
            {
                "type": "waitAsync"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {
        "2,8": [
            {
                "type": "if",
                "condition": "(flag:20==0)",
                "true": [
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            5,
                            9
                        ]
                    },
                    {
                        "type": "playSound",
                        "name": "20F.mp3"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                1,
                                5
                            ],
                            [
                                2,
                                5
                            ],
                            [
                                3,
                                5
                            ],
                            [
                                3,
                                6
                            ],
                            [
                                3,
                                7
                            ],
                            [
                                2,
                                7
                            ],
                            [
                                1,
                                7
                            ],
                            [
                                1,
                                6
                            ]
                        ],
                        "time": 500
                    },
                    {
                        "type": "show",
                        "loc": [
                            [
                                2,
                                6
                            ]
                        ],
                        "time": 500
                    },
                    "\t[吸血鬼,vampire]很好 你打败了骷髅族 但别想象藐视骷髅人那样藐视我 我对于你就像是神一样 是不可战胜的 来吧",
                    {
                        "type": "setValue",
                        "name": "flag:20",
                        "value": "1"
                    }
                ],
                "false": []
            }
        ]
    },
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "downFloor": [
        6,
        10
    ],
    "upFloor": [
        11,
        10
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}