main.floors.MT16=
{
    "floorId": "MT16",
    "title": "魔塔 第16层",
    "name": "第 16 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  1, 21,  0, 81,  0,  1,  1,320,  1],
    [  1,  0, 38,  0,  1,  0, 22,  1,218,  1,  0,216,  1],
    [  1,  0,  0,  0,  1, 81,  1,  1,  0, 81,  0,  0,  1],
    [  1,  1, 85,  1,  1,  0,206,  1,  1,  1,  1,  0,  1],
    [  1,206,  0,206,  1,213,  0,  1, 27, 28,  2,203,  1],
    [  1,  0,  0,  0,  1, 81,  1,  1, 21, 31,  1,  0,  1],
    [  1,121, 31,  0,  0,203,  0,  1, 21,215,  1,  0,  1],
    [  1,  1,  1,  1,  1,  1, 81,  1,  1, 81,  1,206,  1],
    [  1, 21,  0,206,  0, 81, 21, 82,  0,  0, 81,  0,  1],
    [  1, 21,  0,218,  0,  1,  0,  1,  1,214,  1,  0,  1],
    [  1, 21,  0,206,213,  1, 88,  1, 21, 31,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "section2.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "11,1": [
            {
                "type": "playSound",
                "name": "door.mp3"
            },
            "\t[man]很好，你居然找到了我。作为奖励我将给你一瓶圣水。用<T>可以查看它。喝了它将按你的攻击和防御力增加你的生命点数，你越晚用它效果越好。",
            {
                "type": "function",
                "function": "function(){\ncore.addItem(\"superPotion\")\n}"
            },
            {
                "type": "hide",
                "time": 500
            }
        ]
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        },
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "1,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT16_2_4",
                "operator": "+=",
                "value": "1"
            }
        ],
        "3,5": [
            {
                "type": "setValue",
                "name": "flag:door_MT16_2_4",
                "operator": "+=",
                "value": "1"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        11,
        10
    ],
    "downFloor": [
        6,
        10
    ],
    "autoEvent": {
        "2,4": {
            "0": {
                "condition": "flag:door_MT16_2_4==2",
                "currentFloor": true,
                "priority": 0,
                "delayExecute": false,
                "multiExecute": false,
                "data": [
                    {
                        "type": "openDoor"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:door_MT16_2_4",
                        "operator": "=",
                        "value": "null"
                    }
                ]
            }
        }
    },
    "beforeBattle": {},
    "cannotMoveIn": {}
}