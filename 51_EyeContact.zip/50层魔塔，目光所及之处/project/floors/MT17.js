main.floors.MT17=
{
    "floorId": "MT17",
    "title": "魔塔 第17层",
    "name": "第 17 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  1,  0, 87,  0,  1, 27,  0, 28,  1],
    [  1,  0, 37,  0,  1,  0,  0,  0,  1,  0, 32,  0,  1],
    [  1,  0,  0,  0,  1,214,  1,206,  1, 21,  0, 21,  1],
    [  1,  1, 85,  1,  1,  0,  1,  0,  1,  1, 85,  1,  1],
    [  1,221,  0,221,  1, 81,  1, 82,  1,214,  0,214,  1],
    [  1,  0,  0,  0,  1,  0,  1,  0,  1,  0,  0,  0,  1],
    [  1,  1, 85,  1,  1,213,  1,203,  1,  1, 85,  1,  1],
    [  1,221,  0,221,  1,  0,  0,  0,  1,213,  0,213,  1],
    [  1,  0,  0,  0,  1,  1,218,  1,  1,  0,  0,  0,  1],
    [  1,  1, 81,  1,  1,  0,  0,  0,  1,  1, 81,  1,  1],
    [  1, 31,  0,  0,206,  0, 88,  0,206,  0,  0, 31,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "section2.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "0,8": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[1, 8],\n\t[3, 8],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1],'MT17') == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            7
                        ],
                        "floorId": "MT17"
                    }
                ]
            }
        ],
        "0,5": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[1, 5],\n\t[3, 5],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1],'MT17') == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            4
                        ],
                        "floorId": "MT17"
                    }
                ]
            }
        ],
        "12,5": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[9, 5],\n\t[11, 5],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1],'MT17') == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            10,
                            4
                        ],
                        "floorId": "MT17"
                    }
                ]
            }
        ],
        "12,8": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[9, 8],\n\t[11, 8],\n]\nloc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1],'MT17') == \"enemys\") {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            10,
                            7
                        ],
                        "floorId": "MT17"
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "6,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "1,8": [
            {
                "type": "insert",
                "loc": [
                    0,
                    8
                ],
                "floorId": "MT17"
            }
        ],
        "3,8": [
            {
                "type": "insert",
                "loc": [
                    0,
                    8
                ],
                "floorId": "MT17"
            }
        ],
        "1,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    5
                ],
                "floorId": "MT17"
            }
        ],
        "3,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    5
                ],
                "floorId": "MT17"
            }
        ],
        "9,8": [
            {
                "type": "insert",
                "loc": [
                    12,
                    8
                ],
                "floorId": "MT17"
            }
        ],
        "11,8": [
            {
                "type": "insert",
                "loc": [
                    12,
                    8
                ],
                "floorId": "MT17"
            }
        ],
        "9,5": [
            {
                "type": "insert",
                "loc": [
                    12,
                    5
                ],
                "floorId": "MT17"
            }
        ],
        "11,5": [
            {
                "type": "insert",
                "loc": [
                    12,
                    5
                ],
                "floorId": "MT17"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "downFloor": [
        6,
        10
    ],
    "upFloor": [
        6,
        2
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}