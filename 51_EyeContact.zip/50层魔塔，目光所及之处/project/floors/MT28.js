main.floors.MT28=
{
    "floorId": "MT28",
    "title": "魔塔 第28层",
    "name": "第 28 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  1,  1,  1,  1,  1,  0,  1],
    [  1,  0,  0,  0,  0,  0,  1,  0,  0,  0,  1,  0,  1],
    [  1,  0,  0,  0,  0,  0,  1,  0,124,  0,  1,  0,  1],
    [  1,  0,  0,  0,  0,  0,  1,  0,  0,  0,  1,  0,  1],
    [  1,  0,  0,  0,  0,  0,  1,  1,  0,  1,  1,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1, 87,  0,  0,  0,  0,  0,  0,  0,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 3,
    "defaultGround": "ground",
    "bgm": "section3.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "8,4": [
            {
                "type": "choices",
                "text": "\t[商人,woman]我能回收钥匙！你现在拥有钥匙：\n黄钥匙：${core.itemCount(\"yellowKey\")} 蓝钥匙：${core.itemCount(\"blueKey\")}\n红钥匙：${core.itemCount(\"redKey\")}",
                "choices": [
                    {
                        "text": "回收黄钥匙（100金币/1把）",
                        "action": [
                            {
                                "type": "if",
                                "condition": "(item:yellowKey>0)",
                                "true": [
                                    {
                                        "type": "playSound",
                                        "name": "item.mp3"
                                    },
                                    {
                                        "type": "setValue",
                                        "name": "item:yellowKey",
                                        "operator": "-=",
                                        "value": "1"
                                    },
                                    {
                                        "type": "setValue",
                                        "name": "status:money",
                                        "operator": "+=",
                                        "value": "100"
                                    },
                                    {
                                        "type": "insert",
                                        "loc": [
                                            8,
                                            4
                                        ]
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "tip",
                                        "text": "你没有黄钥匙"
                                    },
                                    {
                                        "type": "insert",
                                        "loc": [
                                            8,
                                            4
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "text": "批量回收黄钥匙（100金币/1把）",
                        "action": [
                            {
                                "type": "if",
                                "condition": "(item:yellowKey>0)",
                                "true": [
                                    {
                                        "type": "input",
                                        "text": "请输入一个数"
                                    },
                                    {
                                        "type": "if",
                                        "condition": "(flag:input>core.itemCount(\"yellowKey\"))",
                                        "true": [
                                            {
                                                "type": "tip",
                                                "text": "你没有足够黄钥匙"
                                            },
                                            {
                                                "type": "insert",
                                                "loc": [
                                                    8,
                                                    4
                                                ]
                                            }
                                        ],
                                        "false": [
                                            {
                                                "type": "playSound",
                                                "name": "item.mp3"
                                            },
                                            {
                                                "type": "setValue",
                                                "name": "item:yellowKey",
                                                "operator": "-=",
                                                "value": "flag:input"
                                            },
                                            {
                                                "type": "setValue",
                                                "name": "status:money",
                                                "operator": "+=",
                                                "value": "(flag:input*100)"
                                            },
                                            {
                                                "type": "insert",
                                                "loc": [
                                                    8,
                                                    4
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "tip",
                                        "text": "你没有黄钥匙"
                                    },
                                    {
                                        "type": "insert",
                                        "loc": [
                                            8,
                                            4
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "text": "回收蓝钥匙（250金币/1把）",
                        "action": [
                            {
                                "type": "if",
                                "condition": "(item:blueKey>0)",
                                "true": [
                                    {
                                        "type": "playSound",
                                        "name": "item.mp3"
                                    },
                                    {
                                        "type": "setValue",
                                        "name": "item:blueKey",
                                        "operator": "-=",
                                        "value": "1"
                                    },
                                    {
                                        "type": "setValue",
                                        "name": "status:money",
                                        "operator": "+=",
                                        "value": "250"
                                    },
                                    {
                                        "type": "insert",
                                        "loc": [
                                            8,
                                            4
                                        ]
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "tip",
                                        "text": "你没有蓝钥匙"
                                    },
                                    {
                                        "type": "insert",
                                        "loc": [
                                            8,
                                            4
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "text": "批量回收蓝钥匙（250金币/1把）",
                        "action": [
                            {
                                "type": "if",
                                "condition": "(item:blueKey>0)",
                                "true": [
                                    {
                                        "type": "input",
                                        "text": "请输入一个数"
                                    },
                                    {
                                        "type": "if",
                                        "condition": "(flag:input>core.itemCount(\"blueKey\"))",
                                        "true": [
                                            {
                                                "type": "tip",
                                                "text": "你没有足够蓝钥匙"
                                            },
                                            {
                                                "type": "insert",
                                                "loc": [
                                                    8,
                                                    4
                                                ]
                                            }
                                        ],
                                        "false": [
                                            {
                                                "type": "playSound",
                                                "name": "item.mp3"
                                            },
                                            {
                                                "type": "setValue",
                                                "name": "item:blueKey",
                                                "operator": "-=",
                                                "value": "flag:input"
                                            },
                                            {
                                                "type": "setValue",
                                                "name": "status:money",
                                                "operator": "+=",
                                                "value": "(flag:input*250)"
                                            },
                                            {
                                                "type": "insert",
                                                "loc": [
                                                    8,
                                                    4
                                                ]
                                            }
                                        ]
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "tip",
                                        "text": "你没有蓝钥匙"
                                    },
                                    {
                                        "type": "insert",
                                        "loc": [
                                            8,
                                            4
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "text": "回收红钥匙（500金币/1把）",
                        "action": [
                            {
                                "type": "if",
                                "condition": "(item:redKey>0)",
                                "true": [
                                    {
                                        "type": "playSound",
                                        "name": "item.mp3"
                                    },
                                    {
                                        "type": "setValue",
                                        "name": "item:redKey",
                                        "operator": "-=",
                                        "value": "1"
                                    },
                                    {
                                        "type": "setValue",
                                        "name": "status:money",
                                        "operator": "+=",
                                        "value": "500"
                                    },
                                    {
                                        "type": "insert",
                                        "loc": [
                                            8,
                                            4
                                        ]
                                    }
                                ],
                                "false": [
                                    {
                                        "type": "tip",
                                        "text": "你没有红钥匙"
                                    },
                                    {
                                        "type": "insert",
                                        "loc": [
                                            8,
                                            4
                                        ]
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "text": "下次再说",
                        "action": [
                            {
                                "type": "exit"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {},
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        2,
        11
    ],
    "downFloor": [
        10,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}