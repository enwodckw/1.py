main.floors.MT41=
{
    "floorId": "MT41",
    "title": "魔塔 第41层",
    "name": "第 41 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 31,  1,  0, 22,  1, 88,  1, 22,  0,  1, 31,  1],
    [  1, 81,220,  0,  0,  1,  0,  1,  0,  0,  1, 81,  1],
    [  1, 81,  1,  0,  1,  1,  0,  1,  1,  0,  1, 81,  1],
    [  1, 81,  1, 81,  1,246,  0,246,  1, 81,  1, 81,  1],
    [  1,  0,  0,219,  1,  1,  0,  1,  1,219,  0,  0,  1],
    [  1,207,  0,  0,  0, 82,  0, 82,  0,  0,  0,207,  1],
    [  1,  0,207,  0,204,  1, 81,  1,204,  0,207,  0,  1],
    [  1, 81,  1,  1, 81,  1, 81,  1, 81,  1,  1, 81,  1],
    [  1, 81,  1, 31,  0,  1, 81,  1,  0, 31,  1, 81,  1],
    [  1, 81,  1, 21, 21,  1,  0,  1, 21, 21,  1, 81,  1],
    [  1, 32,  1, 21, 27,  1, 87,  1, 28, 21,  1, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": "section5.mp3",
    "firstArrive": [
        {
            "type": "show",
            "loc": [
                [
                    6,
                    10
                ]
            ],
            "floorId": "MT42",
            "time": 0
        }
    ],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "10,2": {
            "trigger": "action",
            "enable": true,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "if",
                    "condition": "(flag:41===1)",
                    "true": [
                        {
                            "type": "playSound",
                            "name": "door.mp3"
                        },
                        {
                            "type": "sleep",
                            "time": 200
                        },
                        {
                            "type": "setBlock",
                            "number": "220"
                        },
                        {
                            "type": "setValue",
                            "name": "flag:41",
                            "value": "2"
                        },
                        {
                            "type": "sleep",
                            "time": 200
                        },
                        {
                            "type": "function",
                            "function": "function(){\ncore.refreshItemLevelUp(null, null, null,true);\n}"
                        }
                    ],
                    "false": [
                        {
                            "type": "if",
                            "condition": "(flag:41===2)",
                            "true": [
                                {
                                    "type": "battle",
                                    "loc": [
                                        10,
                                        2
                                    ]
                                }
                            ],
                            "false": []
                        }
                    ]
                }
            ]
        }
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "2,2": [
            {
                "type": "setValue",
                "name": "flag:41",
                "value": "1"
            }
        ],
        "10,2": [
            {
                "type": "playSound",
                "name": "door.mp3"
            },
            {
                "type": "setBlock",
                "number": "none",
                "loc": [
                    [
                        5,
                        6
                    ]
                ],
                "floorId": "MT41"
            },
            {
                "type": "setBlock",
                "number": "none",
                "loc": [
                    [
                        7,
                        6
                    ]
                ],
                "floorId": "MT41"
            },
            {
                "type": "setBlock",
                "number": "blueWall",
                "loc": [
                    [
                        5,
                        6
                    ],
                    [
                        6,
                        6
                    ],
                    [
                        7,
                        6
                    ]
                ],
                "floorId": "MT41"
            },
            {
                "type": "openDoor",
                "loc": [
                    5,
                    7
                ],
                "floorId": "MT41",
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    7,
                    7
                ],
                "floorId": "MT41",
                "async": true
            },
            {
                "type": "waitAsync"
            },
            {
                "type": "setBlock",
                "number": "52",
                "loc": [
                    [
                        6,
                        5
                    ]
                ],
                "floorId": "MT41",
                "time": 0
            },
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        5
                    ]
                ],
                "floorId": "MT41",
                "time": 0
            },
            {
                "type": "tip",
                "text": "降临之翼出现了"
            },
            {
                "type": "hide",
                "time": 0
            },
            {
                "type": "function",
                "function": "function(){\ncore.refreshItemLevelUp(null, null, null,true);\n}"
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        6,
        10
    ],
    "downFloor": [
        6,
        2
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}