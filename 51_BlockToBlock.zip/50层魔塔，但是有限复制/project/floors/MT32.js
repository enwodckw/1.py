main.floors.MT32=
{
    "floorId": "MT32",
    "title": "魔塔 第32层",
    "name": "第 32 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 28,  0, 82,  0,  0,  0,  0,  0,  0,226, 87,  1],
    [  1,  0, 27,  1,  1,  1,  0,  1,  1,  1,  0,  0,  1],
    [  1, 81,  1,  1,  0, 81,  0, 81,  0,  1,  1,  1,  1],
    [  1,225,  0,216,  0,  1,  0,  1,212,  1, 21, 32,  1],
    [  1,  0, 21,  0,216,  1,  0,  1,  0, 81,  0, 21,  1],
    [  1,  1,  1,  1,  1,  1,  0,  1,  0,  1,  1,  1,  1],
    [  1, 21, 21, 21, 21,  1,  0,  1,227,  1, 21, 22,  1],
    [  1,  0,  0,  0, 22,  1,  0,  1,  0, 81,  0, 21,  1],
    [  1,  1, 85,  1,  1,  1,  0,  1,  1,  1,  1,  1,  1],
    [  1,222,  0,222,  0,  0,  0,  0,  0,  7,131,  8,  1],
    [  1,  0,  0,  0,  0, 88,  0,  1,212,  0,168,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "10,10": [
            {
                "type": "setValue",
                "name": "flag:ratio",
                "value": "4"
            },
            {
                "type": "setValue",
                "name": "flag:shopratio",
                "value": "Math.max(core.getFlag('shopratio', 1), core.getFlag('ratio', 1))"
            },
            {
                "type": "insert",
                "name": "商店"
            }
        ],
        "10,1": {
            "trigger": null,
            "enable": true,
            "noPass": null,
            "displayDamage": true,
            "opacity": 0.5,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": []
        },
        "6,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT32"
            }
        ],
        "0,0": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[1, 10],\n\t[3, 10],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1],'MT32') == \"enemys\") {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT32');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            9
                        ],
                        "floorId": "MT32"
                    }
                ]
            }
        ],
        "0,1": [
            {
                "type": "function",
                "function": "function(){\ncore.material.enemys.yellowKnight.special = 1;\n}"
            },
            {
                "type": "show",
                "loc": [
                    [
                        10,
                        1
                    ]
                ],
                "floorId": "MT32",
                "time": 50
            },
            {
                "type": "move",
                "loc": [
                    10,
                    1
                ],
                "time": 50,
                "keep": true,
                "steps": [
                    "left:4"
                ]
            },
            "\t[骑士队长,yellowKnight]你打败了前2个区域的头目 这表明你是个勇士 但现在游戏结束了 我将在这里亲手杀死你",
            {
                "type": "move",
                "loc": [
                    6,
                    1
                ],
                "time": 50,
                "keep": true,
                "steps": [
                    "down:8"
                ]
            },
            {
                "type": "setValue",
                "name": "flag:32TrapBlock",
                "value": "blockId:6,9"
            },
            {
                "type": "function",
                "function": "function(){\n//console.log('1');\n}"
            },
            {
                "type": "function",
                "function": "function(){\ncore.setFlag('32TrapBlock',null);\n}"
            },
            {
                "type": "function",
                "function": "function(){\n//console.log('2');\n}"
            },
            {
                "type": "if",
                "condition": "(blockCls:6,9==='enemys')",
                "true": [
                    {
                        "type": "setValue",
                        "name": "flag:32TrapBlock",
                        "value": "blockId:6,9"
                    },
                    {
                        "type": "battle",
                        "loc": [
                            6,
                            9
                        ]
                    }
                ]
            },
            {
                "type": "if",
                "condition": "(blockCls:6,9==='items')",
                "true": [
                    {
                        "type": "setValue",
                        "name": "flag:32TrapBlock",
                        "value": "blockId:6,9"
                    },
                    {
                        "type": "function",
                        "function": "function(){\n//console.log('3');\n}"
                    },
                    {
                        "type": "function",
                        "function": "function(){\ncore.getItem(core.getBlockId(6,9,'MT32'),1,6,9);\n}"
                    },
                    {
                        "type": "function",
                        "function": "function(){\n//console.log('4');\n}"
                    }
                ]
            },
            {
                "type": "function",
                "function": "function(){\ncore.setBlock(core.getFlag('32TrapBlock',null),6,9,'MT32');\n}"
            },
            {
                "type": "function",
                "function": "function(){\n//console.log('5');\n}"
            },
            {
                "type": "move",
                "loc": [
                    6,
                    9
                ],
                "time": 50,
                "keep": true,
                "steps": [
                    "up:8"
                ]
            },
            "\t[骑士队长,yellowKnight]你以为你已非常强大了吗 嘿嘿错了 只是我今天状态不佳而已 我走了 有本事到40楼与我再打一次",
            {
                "type": "move",
                "loc": [
                    6,
                    1
                ],
                "time": 50,
                "steps": [
                    "right:5"
                ]
            },
            {
                "type": "function",
                "function": "function(){\ncore.material.enemys.yellowKnight.special = 0;\n}"
            },
            {
                "type": "hide",
                "time": 0
            }
        ]
    },
    "changeFloor": {
        "11,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "5,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "1,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT32"
            }
        ],
        "3,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT32"
            }
        ]
    },
    "afterGetItem": {
        "6,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT32"
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "downFloor": [
        6,
        11
    ],
    "upFloor": [
        10,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {
        "6,10": [
            {
                "type": "setValue",
                "name": "flag:战后保留图块",
                "value": "true"
            }
        ]
    },
    "cannotMoveIn": {}
}