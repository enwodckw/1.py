main.floors.MT49=
{
    "floorId": "MT49",
    "title": "魔塔 第49层",
    "name": "第 49 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  1,  1,  1,  0,  0,  0,  0,  0,  1,  1,  1,  1],
    [  1,  1,  1,  0,  0,  0,  0,  0,  0,  0,  1,  1,  1],
    [  1,  1,  0,  0,  0,  0,245,  0,  0,  0,  0,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  1,  0,  0,  0,168,  0,  0,  0,  1,  0,  1],
    [  1,  0,  1,  0,  0,168,  0,168,  0,  0,  1,  0,  1],
    [  1,  0,  1,  0,  1,  1, 85,  1,  1,  0,  1,  0,  1],
    [  1,  0,  1,  0,  1,228,  0,228,  1,  0,  1,  0,  1],
    [  1,  0,  0,  0,  1,  1, 85,  1,  1,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,220,  0,220,  1,  1,  1,  1,  1],
    [  1, 88,  0, 83,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": "section5.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,6": [
            {
                "type": "if",
                "condition": "(core.getBlockId(6,7)==='specialDoor')",
                "true": [],
                "false": [
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            6,
                            7
                        ]
                    }
                ]
            },
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        3
                    ]
                ],
                "floorId": "MT49",
                "time": 100
            },
            "\t[魔王,redKing]你终于来啦 我好想和你干一把 但是我的部下不同意",
            {
                "type": "playBgm",
                "name": "boss5.mp3"
            },
            {
                "type": "setBlock",
                "number": "whiteKing",
                "loc": [
                    [
                        5,
                        2
                    ],
                    [
                        6,
                        2
                    ],
                    [
                        7,
                        2
                    ],
                    [
                        5,
                        3
                    ],
                    [
                        7,
                        3
                    ],
                    [
                        5,
                        4
                    ],
                    [
                        6,
                        4
                    ],
                    [
                        7,
                        4
                    ]
                ],
                "floorId": "MT49",
                "time": 50
            },
            {
                "type": "hide",
                "time": 0
            }
        ],
        "6,3": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "data": []
        },
        "0,10": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 10],\n\t[7, 10],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1], 'MT49') !== null) {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT49');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "hide",
                        "time": 0
                    }
                ]
            }
        ],
        "0,8": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 8],\n\t[7, 8],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1], 'MT49') !== null) {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT49');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            7
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "hide",
                        "time": 0
                    }
                ]
            }
        ],
        "0,0": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[6, 2],\n\t[6, 4],\n\t[5, 3],\n\t[7, 3],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1], 'MT49') !== null) {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT49');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\nvar loc_arr = [\n\t[5, 2],\n\t[7, 2],\n\t[5, 4],\n\t[7, 4],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1], 'MT49') === null) {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT49');\n\tif (BlockId === null || BlockId === 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "function",
                        "function": "function(){\nconst HardScale = core.getFlag('HardScaleS', 1);\ncore.setEnemy('redKing', 'hp', Math.floor(800 * HardScale), '=', null, true);\ncore.setEnemy('redKing', 'atk', Math.floor(500 * HardScale), '=', null, true);\ncore.setEnemy('redKing', 'def', Math.floor(100 * HardScale), '=', null, true);\ncore.updateStatusBar();\n}"
                    },
                    {
                        "type": "update"
                    },
                    "\t[魔王,redKing]完蛋了 我被封印了 功力只剩一成"
                ]
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "5,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    10
                ],
                "floorId": "MT49"
            }
        ],
        "7,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    10
                ],
                "floorId": "MT49"
            }
        ],
        "5,8": [
            {
                "type": "insert",
                "loc": [
                    0,
                    8
                ],
                "floorId": "MT49"
            }
        ],
        "7,8": [
            {
                "type": "insert",
                "loc": [
                    0,
                    8
                ],
                "floorId": "MT49"
            }
        ],
        "6,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT49"
            }
        ],
        "5,3": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT49"
            }
        ],
        "6,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT49"
            }
        ],
        "7,3": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT49"
            }
        ],
        "6,3": [
            {
                "type": "if",
                "condition": "(!flag:49)",
                "true": [
                    {
                        "type": "setValue",
                        "name": "flag:49",
                        "value": "true"
                    },
                    "\t[魔王,redKing]很好嘛 你通过了我的面试 你是个合格的勇士",
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                2
                            ],
                            [
                                5,
                                3
                            ],
                            [
                                7,
                                3
                            ],
                            [
                                5,
                                4
                            ],
                            [
                                6,
                                4
                            ],
                            [
                                7,
                                4
                            ]
                        ],
                        "floorId": "MT49",
                        "time": 0
                    },
                    {
                        "type": "setBlock",
                        "number": "23",
                        "loc": [
                            [
                                5,
                                2
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "setBlock",
                        "number": "62",
                        "loc": [
                            [
                                7,
                                2
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "setBlock",
                        "number": "27",
                        "loc": [
                            [
                                2,
                                4
                            ],
                            [
                                3,
                                4
                            ],
                            [
                                4,
                                4
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "setBlock",
                        "number": "28",
                        "loc": [
                            [
                                8,
                                4
                            ],
                            [
                                9,
                                4
                            ],
                            [
                                10,
                                4
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "setBlock",
                        "number": "32",
                        "loc": [
                            [
                                5,
                                5
                            ],
                            [
                                6,
                                5
                            ],
                            [
                                7,
                                5
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "show",
                        "loc": [
                            [
                                5,
                                2
                            ],
                            [
                                7,
                                2
                            ]
                        ],
                        "floorId": "MT49",
                        "time": 0
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            7
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "floorId": "MT49"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {
        "5,8": [
            {
                "type": "insert",
                "loc": [
                    0,
                    8
                ],
                "floorId": "MT49"
            }
        ],
        "7,8": [
            {
                "type": "insert",
                "loc": [
                    0,
                    8
                ],
                "floorId": "MT49"
            }
        ],
        "5,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    10
                ],
                "floorId": "MT49"
            }
        ],
        "7,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    10
                ],
                "floorId": "MT49"
            }
        ],
        "5,3": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT49"
            }
        ],
        "6,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT49"
            }
        ],
        "7,3": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT49"
            }
        ],
        "6,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT49"
            }
        ],
        "6,3": [
            {
                "type": "if",
                "condition": "(!flag:49)",
                "true": [
                    {
                        "type": "setValue",
                        "name": "flag:49",
                        "value": "true"
                    },
                    "\t[魔王,redKing]很好嘛 你通过了我的面试 你是个合格的勇士",
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                2
                            ],
                            [
                                5,
                                3
                            ],
                            [
                                7,
                                3
                            ],
                            [
                                5,
                                4
                            ],
                            [
                                6,
                                4
                            ],
                            [
                                7,
                                4
                            ]
                        ],
                        "floorId": "MT49",
                        "time": 0
                    },
                    {
                        "type": "setBlock",
                        "number": "23",
                        "loc": [
                            [
                                5,
                                2
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "setBlock",
                        "number": "62",
                        "loc": [
                            [
                                7,
                                2
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "setBlock",
                        "number": "27",
                        "loc": [
                            [
                                2,
                                4
                            ],
                            [
                                3,
                                4
                            ],
                            [
                                4,
                                4
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "setBlock",
                        "number": "28",
                        "loc": [
                            [
                                8,
                                4
                            ],
                            [
                                9,
                                4
                            ],
                            [
                                10,
                                4
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "setBlock",
                        "number": "32",
                        "loc": [
                            [
                                5,
                                5
                            ],
                            [
                                6,
                                5
                            ],
                            [
                                7,
                                5
                            ]
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "show",
                        "loc": [
                            [
                                5,
                                2
                            ],
                            [
                                7,
                                2
                            ]
                        ],
                        "floorId": "MT49",
                        "time": 0
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            7
                        ],
                        "floorId": "MT49"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            9
                        ],
                        "floorId": "MT49"
                    }
                ]
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "downFloor": [
        2,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}