main.floors.MT25=
{
    "floorId": "MT25",
    "title": "魔塔 第25层",
    "name": "第 25 层",
    "width": 13,
    "height": 13,
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 3,
    "defaultGround": "ground",
    "bgm": "section3.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,9": [
            {
                "type": "if",
                "condition": "(blockCls:6,6===\"enemys\")",
                "true": [
                    "\t[大法师,blackMagician]杀死入侵者",
                    {
                        "type": "playBgm",
                        "name": "boss3.mp3"
                    }
                ],
                "false": []
            },
            {
                "type": "hide",
                "remove": true,
                "time": 0
            }
        ]
    },
    "changeFloor": {
        "1,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "2,10": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "6,6": [
            {
                "type": "if",
                "condition": "(!flag:25)",
                "true": [
                    {
                        "type": "setValue",
                        "name": "flag:25",
                        "value": "true"
                    },
                    {
                        "type": "setBlock",
                        "number": "23",
                        "loc": [
                            [
                                4,
                                8
                            ],
                            [
                                5,
                                8
                            ],
                            [
                                7,
                                8
                            ],
                            [
                                8,
                                8
                            ]
                        ],
                        "floorId": "MT25"
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                9
                            ]
                        ],
                        "floorId": "MT25",
                        "time": 0
                    },
                    {
                        "type": "playSound",
                        "name": "door.mp3"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {},
    "afterOpenDoor": {},
    "cannotMove": {},
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1,  1,  1,  1,  0,  0,  0,  1],
    [  1,  0,  0,  1,  1,  0,  0,  0,  1,  1,  0,  0,  1],
    [  1,  0,  1,  1,  0,  0,  0,  0,  0,  1,  1,  0,  1],
    [  1,  0,  1,  0,  0,  1,  0,  1,  0,  0,  1,  0,  1],
    [  1,  0,  1,  0,  0,  0,247,  0,  0,  0,  1,  0,  1],
    [  1,  0,  1,  0,  0,  1,  0,  1,  0,  0,  1,  0,  1],
    [  1,  0,  1,  1,  0,  0,  0,  0,  0,  1,  1,  0,  1],
    [  1,  0,  0,  1,  1,  0,  0,  0,  1,  1,  0,  0,  1],
    [  1,  0, 88,  0,  1,  1, 83,  1,  1,  0,  0,  0,  1],
    [  1, 87,  0,  0,  0,  0,168,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        2,
        11
    ],
    "downFloor": [
        2,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {
        "6,9": [
            {
                "type": "setValue",
                "name": "flag:战后保留图块",
                "value": "true"
            }
        ]
    },
    "cannotMoveIn": {}
}