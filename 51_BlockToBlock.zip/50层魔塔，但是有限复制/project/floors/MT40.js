main.floors.MT40=
{
    "floorId": "MT40",
    "title": "魔塔 第40层",
    "name": "第 40 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,168,226,168,  0,  0,  0,  0,  1],
    [  1,  0,224,224,224,  0,168,  0,227,227,227,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,212,212,212,  0,225,225,225,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  0,  0,  0,  0,  0,  1,  1,  1,  1],
    [  1,  1,  1,  1,  0,  0,  0,  0,  0,  1,  1,  1,  1],
    [  1,  1,  1,  1,  1,  1, 83,  1,  1,  1,  1,  1,  1],
    [  1, 28, 21,  0,  1,216,  0,216,  1, 31,224,  0,  1],
    [  1, 32,  0,  0,  1,  0,  0,  0,  1,225,  0,  0,  1],
    [  1, 27,  0,227, 82,  0,  0,  0, 81,  0,  0, 88,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,7": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT40"
            }
        ],
        "6,1": [
            {
                "type": "if",
                "condition": "flag:40",
                "true": [
                    {
                        "type": "changeFloor",
                        "floorId": "MT41",
                        "loc": [
                            6,
                            2
                        ],
                        "direction": "down",
                        "time": 0
                    }
                ],
                "false": []
            }
        ],
        "0,0": [
            {
                "type": "if",
                "condition": "(!flag:40)",
                "true": [
                    {
                        "type": "function",
                        "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[3, 4],\n\t[4, 4],\n\t[5, 4],\n\t[7, 4],\n\t[8, 4],\n\t[9, 4],\n\t[2, 2],\n\t[3, 2],\n\t[4, 2],\n\t[8, 2],\n\t[9, 2],\n\t[10, 2],\n\t[6, 1]\n]\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT40');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t\t//console.log(`(${loc[0]},${loc[1]})`);\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
                    },
                    {
                        "type": "if",
                        "condition": "flag:open_yes",
                        "true": [
                            {
                                "type": "setValue",
                                "name": "flag:40",
                                "value": "true"
                            },
                            "\t[骑士队长,yellowKnight]这次先饶了你，下次碰到我会和你正式的决斗，你最好投降。",
                            {
                                "type": "playSound",
                                "name": "door.mp3"
                            },
                            {
                                "type": "setBlock",
                                "number": "21",
                                "loc": [
                                    [
                                        2,
                                        2
                                    ],
                                    [
                                        3,
                                        2
                                    ],
                                    [
                                        4,
                                        2
                                    ]
                                ],
                                "floorId": "MT40"
                            },
                            {
                                "type": "setBlock",
                                "number": "27",
                                "loc": [
                                    [
                                        8,
                                        2
                                    ],
                                    [
                                        9,
                                        2
                                    ],
                                    [
                                        10,
                                        2
                                    ]
                                ],
                                "floorId": "MT40"
                            },
                            {
                                "type": "setBlock",
                                "number": "32",
                                "loc": [
                                    [
                                        3,
                                        4
                                    ],
                                    [
                                        4,
                                        4
                                    ],
                                    [
                                        5,
                                        4
                                    ]
                                ],
                                "floorId": "MT40"
                            },
                            {
                                "type": "setBlock",
                                "number": "28",
                                "loc": [
                                    [
                                        7,
                                        4
                                    ],
                                    [
                                        8,
                                        4
                                    ],
                                    [
                                        9,
                                        4
                                    ]
                                ],
                                "floorId": "MT40"
                            },
                            {
                                "type": "show",
                                "loc": [
                                    [
                                        2,
                                        2
                                    ],
                                    [
                                        3,
                                        2
                                    ],
                                    [
                                        4,
                                        2
                                    ],
                                    [
                                        8,
                                        2
                                    ],
                                    [
                                        9,
                                        2
                                    ],
                                    [
                                        10,
                                        2
                                    ],
                                    [
                                        3,
                                        4
                                    ],
                                    [
                                        4,
                                        4
                                    ],
                                    [
                                        5,
                                        4
                                    ],
                                    [
                                        7,
                                        4
                                    ],
                                    [
                                        8,
                                        4
                                    ],
                                    [
                                        9,
                                        4
                                    ]
                                ],
                                "floorId": "MT40"
                            },
                            {
                                "type": "show",
                                "loc": [
                                    [
                                        6,
                                        1
                                    ]
                                ],
                                "floorId": "MT40"
                            },
                            {
                                "type": "setBlock",
                                "number": "87",
                                "loc": [
                                    [
                                        6,
                                        1
                                    ]
                                ],
                                "floorId": "MT40"
                            },
                            {
                                "type": "hide",
                                "loc": [
                                    [
                                        6,
                                        7
                                    ]
                                ],
                                "floorId": "MT40",
                                "remove": true,
                                "time": 0
                            },
                            {
                                "type": "openDoor",
                                "loc": [
                                    6,
                                    8
                                ],
                                "floorId": "MT40"
                            },
                            {
                                "type": "show",
                                "loc": [
                                    [
                                        6,
                                        10
                                    ]
                                ],
                                "floorId": "MT42",
                                "time": 0
                            }
                        ]
                    }
                ]
            }
        ],
        "0,1": [
            {
                "type": "if",
                "condition": "(!flag:40)",
                "true": [
                    {
                        "type": "if",
                        "condition": "(core.getBlockId(6,8)==='redDoor')",
                        "true": [],
                        "false": [
                            {
                                "type": "closeDoor",
                                "id": "specialDoor",
                                "loc": [
                                    6,
                                    8
                                ]
                            }
                        ]
                    },
                    {
                        "type": "playBgm",
                        "name": "boss4.mp3"
                    },
                    "\t[骑士队长,yellowKnight]我还在担心你不能来了。我确信这次我一定能杀了你。给我上！",
                    {
                        "type": "function",
                        "function": "function(){\nlet arr = [\n\t[3, 4],\n\t[4, 4],\n\t[5, 4],\n\t[7, 4],\n\t[8, 4],\n\t[9, 4],\n\t[2, 2],\n\t[3, 2],\n\t[4, 2],\n\t[8, 2],\n\t[9, 2],\n\t[10, 2],\n\t[6, 1]\n];\nlet floorId = core.status.floorId,\n\tattribute = 'special';\narr.forEach(([x, y]) => {\n\tlet cls = core.getBlockCls(x, y, floorId);\n\tif (cls === 'enemys') {\n\t\tlet id = core.getBlockId(x, y, floorId);\n\t\tlet a = core.getEnemyValue(id, attribute, x, y, floorId) || [];\n\t\tif (typeof a === \"number\") a = [a];\n\t\tlet b = a.slice();\n\t\tb.push(1);\n\t\tcore.setEnemyOnPoint(x, y, floorId, attribute, b);\n\t}\n\n})\n}"
                    },
                    {
                        "type": "callBook"
                    },
                    {
                        "type": "function",
                        "function": "function(){\nlet arr = [\n\t[10, 2],\n\t[9, 2],\n\t[8, 2],\n\t[4, 2],\n\t[3, 2],\n\t[2, 2],\n\t[9, 4],\n\t[8, 4],\n\t[7, 4],\n\t[5, 4],\n\t[4, 4],\n\t[3, 4],\n];\narr.forEach(([x, y]) => {\n\tcore.insertAction([{ \"type\": \"sleep\", \"time\": 300 }, ]);\n\tif (core.getBlockCls(x, y) === \"enemys\") {\n\t\tcore.insertAction([{\n\t\t\t\"type\": \"battle\",\n\t\t\t\"loc\": [\n\t\t\t\tx, y\n\t\t\t]\n\t\t}, ]);\n\t}\n})\n}"
                    },
                    {
                        "type": "if",
                        "condition": "(blockCls:6,1 ==='enemys')",
                        "true": [
                            "\t[骑士队长,yellowKnight]你怎会击败我所有的手下？我和你誓不两立我决不认输。",
                            {
                                "type": "battle",
                                "loc": [
                                    6,
                                    1
                                ]
                            }
                        ]
                    },
                    {
                        "type": "hide",
                        "loc": [
                            [
                                6,
                                7
                            ]
                        ],
                        "remove": true,
                        "time": 0
                    }
                ],
                "false": []
            }
        ]
    },
    "changeFloor": {
        "11,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "2,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "3,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "4,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "8,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "9,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "10,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "3,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "4,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "5,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "7,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "8,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "9,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "6,1": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ]
    },
    "afterGetItem": {
        "2,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "3,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "4,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "8,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "9,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "10,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "3,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "4,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "5,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "7,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "8,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "9,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ],
        "6,7": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT40"
            }
        ],
        "6,1": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT40"
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        6,
        2
    ],
    "downFloor": [
        10,
        11
    ],
    "autoEvent": {},
    "beforeBattle": {
        "6,7": [
            {
                "type": "setValue",
                "name": "flag:战后保留图块",
                "value": "true"
            }
        ]
    },
    "cannotMoveIn": {}
}