main.floors.MT11=
{
    "floorId": "MT11",
    "title": "魔塔 第11层",
    "name": "第 11 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,168,  0,  1, 27,  0, 81,  0,  1, 31, 21,  1],
    [  1,168, 38,168,  1,  0,205,  1,213,  1,  0,  0,  1],
    [  1,  0,168,  0,  1, 81,  1,  1,  0, 81,  0,  0,  1],
    [  1,  1, 85,  1,  1,  0,206,  1,  1,  1,  1,203,  1],
    [  1,218,  0,218,  1,213,  0, 81,218,  0,  1,  0,  1],
    [  1,  0,  0,  0,  1,  1,  1,  1,  0, 31,  1,  0,  1],
    [  1, 32,  0,  0,206,  0,  0, 81,203,  0,  1,  0,  1],
    [  1,  1, 82,  1,  1,  1,  1,  1,  1,  1,  1,206,  1],
    [  1,  0,206,  0,203, 81,  0,  0,  0,  0,205,  0,  1],
    [  1, 21,  0,  0,  0,  1,  0,  1,  1, 81,  1,  0,  1],
    [  1, 21, 21, 21, 21,  1, 88,  1, 32,206,  1, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 2,
    "defaultGround": "ground",
    "bgm": "section2.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "0,0": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[1, 5],\n\t[3, 5],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1],'MT11') !==null) {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT11');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            2,
                            4
                        ],
                        "floorId": "MT11"
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "6,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "1,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT11"
            }
        ],
        "3,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT11"
            }
        ]
    },
    "afterGetItem": {
        "1,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT11"
            }
        ],
        "3,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT11"
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        11,
        10
    ],
    "downFloor": [
        6,
        10
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}