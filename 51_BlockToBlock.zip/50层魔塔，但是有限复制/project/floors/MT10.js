main.floors.MT10=
{
    "floorId": "MT10",
    "title": "魔塔 第10层",
    "name": "第 10 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,209,209,209,  1,  1,  0,  1,  1,209,209,209,  1],
    [  1,  0,210,  0, 85,  0,211,  0, 85,  0,210,  0,  1],
    [  1,  1,  1,  1,  1,  0,  0,  0,  1,  1,  1,  1,  1],
    [  1,209, 28,209,  1,  1,  0,  1,  1,209, 27,209,  1],
    [  1,  0,210,  0,  1,  1,  0,  1,  1,  0,210,  0,  1],
    [  1,  0,  0,  0,  1,  1,168,  1,  1,  0,  0,  0,  1],
    [  1, 81,  1, 81,  1,  1, 83,  1,  1, 81,  1, 81,  1],
    [  1,123,  1,  0,  1,  0,  0,  0,  1,  0,  1,  0,  1],
    [  1, 88,  1,  0,217,  0, 87,  0,217,  0,  1, 32,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 1,
    "defaultGround": "ground",
    "bgm": "section1.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "6,11": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "data": []
        },
        "6,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    2
                ],
                "floorId": "MT10"
            }
        ],
        "1,10": {
            "trigger": null,
            "enable": false,
            "noPass": null,
            "displayDamage": true,
            "data": []
        },
        "6,2": [
            "\t[骷髅队长,skeletonCaptain]你怎能杀出重围 我是绝不会让你通过的 来吧 我要与你决斗",
            {
                "type": "hide",
                "time": 0
            }
        ],
        "6,9": [
            {
                "type": "if",
                "condition": "flag:10",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "thief",
                        "loc": [
                            [
                                1,
                                10
                            ]
                        ],
                        "floorId": "MT10",
                        "time": 0
                    },
                    {
                        "type": "show",
                        "loc": [
                            [
                                1,
                                10
                            ]
                        ],
                        "floorId": "MT10",
                        "time": 50
                    },
                    {
                        "type": "move",
                        "loc": [
                            1,
                            10
                        ],
                        "time": 50,
                        "keep": true,
                        "steps": [
                            "up:2",
                            "right:2",
                            "down:3",
                            "right:2",
                            "up:1",
                            "right:1"
                        ]
                    },
                    "\t[小偷,thief]你总算是帮我解决了这麻烦的骷髅队长 我终于可以上去了 我听说银盾在11楼 银剑在17楼 这消息不知道对你是否有用 下次见",
                    {
                        "type": "move",
                        "loc": [
                            6,
                            10
                        ],
                        "time": 50,
                        "steps": [
                            "down:1"
                        ]
                    },
                    {
                        "type": "hide",
                        "remove": true,
                        "time": 0
                    }
                ],
                "false": []
            }
        ],
        "0,0": [
            {
                "type": "setValue",
                "name": "flag:10",
                "value": "true"
            },
            "\t[骷髅队长,skeletonCaptain]不 这是不可能的 你怎会打败我 你别太得意 后面还有许多强大的对手和机关存在 你稍有疏忽就必死无疑",
            {
                "type": "playSound",
                "name": "door.mp3",
                "stop": true
            },
            {
                "type": "setBlock",
                "number": "27",
                "loc": [
                    [
                        1,
                        3
                    ],
                    [
                        2,
                        3
                    ],
                    [
                        3,
                        3
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "28",
                "loc": [
                    [
                        9,
                        3
                    ],
                    [
                        10,
                        3
                    ],
                    [
                        11,
                        3
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "32",
                "loc": [
                    [
                        1,
                        4
                    ],
                    [
                        2,
                        4
                    ],
                    [
                        3,
                        4
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "21",
                "loc": [
                    [
                        9,
                        4
                    ],
                    [
                        10,
                        4
                    ],
                    [
                        11,
                        4
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "setBlock",
                "number": "0",
                "loc": [
                    [
                        6,
                        9
                    ]
                ],
                "floorId": "MT10"
            },
            {
                "type": "show",
                "loc": [
                    [
                        1,
                        3
                    ],
                    [
                        2,
                        3
                    ],
                    [
                        3,
                        3
                    ],
                    [
                        1,
                        4
                    ],
                    [
                        2,
                        4
                    ],
                    [
                        3,
                        4
                    ],
                    [
                        9,
                        3
                    ],
                    [
                        10,
                        3
                    ],
                    [
                        11,
                        3
                    ],
                    [
                        9,
                        4
                    ],
                    [
                        10,
                        4
                    ],
                    [
                        11,
                        4
                    ]
                ],
                "floorId": "MT10",
                "time": 0
            },
            {
                "type": "hide",
                "loc": [
                    [
                        6,
                        2
                    ],
                    [
                        6,
                        5
                    ]
                ],
                "floorId": "MT10",
                "remove": true
            },
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        9
                    ]
                ],
                "floorId": "MT10",
                "time": 0
            },
            {
                "type": "show",
                "loc": [
                    [
                        6,
                        11
                    ]
                ],
                "floorId": "MT10",
                "time": 0
            },
            {
                "type": "openDoor",
                "loc": [
                    4,
                    4
                ],
                "floorId": "MT10",
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    6,
                    7
                ],
                "floorId": "MT10",
                "async": true
            },
            {
                "type": "openDoor",
                "loc": [
                    8,
                    4
                ],
                "floorId": "MT10",
                "async": true
            },
            {
                "type": "waitAsync"
            }
        ],
        "0,1": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 4],\n\t[6, 4],\n\t[7, 4],\n\t[5, 5],\n\t[7, 5],\n\t[5, 6],\n\t[6, 6],\n\t[7, 6],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1],'MT10') !== null) {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT10');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            3
                        ],
                        "floorId": "MT10"
                    }
                ]
            }
        ],
        "0,2": [
            {
                "type": "if",
                "condition": "flag:10陷阱已触发",
                "true": [],
                "false": [
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            6,
                            7
                        ],
                        "async": true
                    },
                    {
                        "type": "playSound",
                        "name": "10F.mp3"
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            4,
                            4
                        ],
                        "floorId": "MT10",
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            8,
                            4
                        ],
                        "floorId": "MT10",
                        "async": true
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                5,
                                6
                            ]
                        ],
                        "floorId": "MT10"
                    },
                    {
                        "type": "setBlock",
                        "number": "0",
                        "loc": [
                            [
                                7,
                                6
                            ]
                        ],
                        "floorId": "MT10"
                    },
                    {
                        "type": "waitAsync"
                    },
                    "\t[骷髅队长,skeletonCaptain]哈哈哈 你是如此的幸运能安全到达这里 但现在好运离你而去了 你中埋伏了 弟兄们给我上",
                    {
                        "type": "move",
                        "loc": [
                            6,
                            4
                        ],
                        "time": 50,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "up:3"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            2,
                            4
                        ],
                        "time": 50,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "right:3",
                            "down:2",
                            "right:1"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            10,
                            4
                        ],
                        "time": 50,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "left:4"
                        ]
                    },
                    {
                        "type": "sleep",
                        "time": 150
                    },
                    {
                        "type": "move",
                        "loc": [
                            3,
                            3
                        ],
                        "time": 50,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "right:2",
                            "down:2"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            9,
                            3
                        ],
                        "time": 50,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "left:2",
                            "down:2"
                        ]
                    },
                    {
                        "type": "sleep",
                        "time": 50
                    },
                    {
                        "type": "move",
                        "loc": [
                            2,
                            3
                        ],
                        "time": 50,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "right:3",
                            "down:1"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            10,
                            3
                        ],
                        "time": 50,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "left:3",
                            "down:1"
                        ]
                    },
                    {
                        "type": "sleep",
                        "time": 50
                    },
                    {
                        "type": "move",
                        "loc": [
                            1,
                            3
                        ],
                        "time": 50,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "right:4"
                        ]
                    },
                    {
                        "type": "move",
                        "loc": [
                            11,
                            3
                        ],
                        "time": 50,
                        "keep": true,
                        "async": true,
                        "steps": [
                            "down:1",
                            "left:4"
                        ]
                    },
                    {
                        "type": "waitAsync"
                    },
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            4,
                            4
                        ],
                        "async": true
                    },
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            6,
                            3
                        ],
                        "async": true
                    },
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            8,
                            4
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:10陷阱已触发",
                        "value": "true"
                    },
                    {
                        "type": "hide",
                        "remove": true
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "6,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "1,11": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "5,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "5,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "5,6": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "6,6": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "7,6": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "7,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "7,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "6,4": [
            {
                "type": "if",
                "condition": "((!flag:10)&&(core.getBlockId(6, 1, 'MT10')===null))",
                "true": [
                    {
                        "type": "comment",
                        "text": "表明骷髅队长没有被击败且没有后退"
                    },
                    {
                        "type": "insert",
                        "loc": [
                            0,
                            0
                        ],
                        "floorId": "MT10"
                    }
                ],
                "false": [
                    {
                        "type": "insert",
                        "loc": [
                            0,
                            1
                        ],
                        "floorId": "MT10"
                    }
                ]
            }
        ],
        "6,1": [
            {
                "type": "if",
                "condition": "(!flag:10)",
                "true": [
                    {
                        "type": "insert",
                        "loc": [
                            0,
                            0
                        ],
                        "floorId": "MT10"
                    }
                ]
            }
        ]
    },
    "afterGetItem": {
        "5,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "5,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "5,6": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "6,6": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "7,6": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "7,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "7,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT10"
            }
        ],
        "6,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    2
                ],
                "floorId": "MT10"
            }
        ],
        "6,4": [
            {
                "type": "if",
                "condition": "((!flag:10)&&(core.getBlockId(6, 1, 'MT10')===null))",
                "true": [
                    {
                        "type": "comment",
                        "text": "表明骷髅队长没有被击败且没有后退"
                    },
                    {
                        "type": "insert",
                        "loc": [
                            0,
                            0
                        ],
                        "floorId": "MT10"
                    }
                ],
                "false": [
                    {
                        "type": "insert",
                        "loc": [
                            0,
                            1
                        ],
                        "floorId": "MT10"
                    }
                ]
            }
        ],
        "6,1": [
            {
                "type": "if",
                "condition": "(!flag:10)",
                "true": [
                    {
                        "type": "insert",
                        "loc": [
                            0,
                            0
                        ],
                        "floorId": "MT10"
                    }
                ]
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        6,
        10
    ],
    "downFloor": [
        1,
        10
    ],
    "autoEvent": {},
    "beforeBattle": {
        "6,5": [
            {
                "type": "setValue",
                "name": "flag:战后保留图块",
                "value": "true"
            }
        ]
    },
    "cannotMoveIn": {}
}