main.floors.MT44=
{
    "floorId": "MT44",
    "title": "魔塔 第44层",
    "name": "第 44 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  1,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  1,  1,  1,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1, 31,  1,  1,  0,  0,  0,  1],
    [  1,  0,  0,  1,  1, 31, 44, 31,  1,  1,  0,  0,  1],
    [  1,  0,  0,  0,  1,  1, 31,  1,  1,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  1, 85,  1,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,223,168,223,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": false,
    "canFlyFrom": false,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 5,
    "defaultGround": "ground",
    "bgm": "section5.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "0,0": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[5, 9],\n\t[7, 9],\n]\n/*loc_arr.forEach(loc => {\n\tif (core.getBlockCls(loc[0], loc[1],'MT44') !== null) {\n\t\tbool = false;\n\t}\n});*/\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT44');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool);\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            6,
                            8
                        ],
                        "floorId": "MT44"
                    },
                    {
                        "type": "hide",
                        "time": 0
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "5,9": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT44"
            }
        ],
        "7,9": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT44"
            }
        ]
    },
    "afterGetItem": {
        "5,9": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT44"
            }
        ],
        "7,9": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT44"
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}