main.floors.MT33=
{
    "floorId": "MT33",
    "title": "魔塔 第33层",
    "name": "第 33 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1, 87,  0, 81,214,  0,216, 81,  0,  0,  0, 88,  1],
    [  1,  0,  0,  1,  0, 31,  0,  1, 81,  1,  1,  1,  1],
    [  1, 82,  1,  1,121,  0, 21,  1,  0,  0,  0, 32,  1],
    [  1,  0, 31,  1,  1, 81,  1,  1,  1,  1,  0,  1,  1],
    [  1,216,  0,  1,  0,  0,214,  0,  1,212,  0,212,  1],
    [  1,  0,  0,  1,224,  1,  1, 81,  1,  0,  0,  0,  1],
    [  1,  0,216, 81,  0,  0,212,  0,  1,225,  0,225,  1],
    [  1, 81,  1,  1,  1,  1,  1,  1,  1,  1,  0,  1,  1],
    [  1,  0,  0,214,  1,  0,225,  0,  1,  0,168,  0,  1],
    [  1,224,  1,  0,  1, 21,  1,216,  0,168, 39,168,  1],
    [  1, 21,225,  0, 82,  0, 81,  0,  1,  0,168,  0,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "10,5": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[9, 5],\n\t[11, 5],\n\t[9, 7],\n\t[11, 7],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT33');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool);\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [],
                "false": [
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            10,
                            4
                        ],
                        "async": true
                    },
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            10,
                            8
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            },
            {
                "type": "hide",
                "remove": true,
                "time": 0
            }
        ],
        "0,0": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[9, 5],\n\t[11, 5],\n\t[9, 7],\n\t[11, 7],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1],'MT33') == \"enemys\") {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT33');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "openDoor",
                        "loc": [
                            10,
                            4
                        ],
                        "floorId": "MT33",
                        "async": true
                    },
                    {
                        "type": "openDoor",
                        "loc": [
                            10,
                            8
                        ],
                        "floorId": "MT33",
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    },
                    {
                        "type": "setValue",
                        "name": "flag:33陷阱已触发",
                        "value": "true"
                    }
                ]
            }
        ],
        "9,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT33"
            }
        ],
        "0,1": [
            {
                "type": "if",
                "condition": "(!flag:33陷阱已触发)",
                "true": [
                    {
                        "type": "closeDoor",
                        "id": "yellowWall",
                        "loc": [
                            8,
                            10
                        ]
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "1,1": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "9,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT33"
            }
        ],
        "9,7": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT33"
            }
        ],
        "11,7": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT33"
            }
        ],
        "11,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT33"
            }
        ]
    },
    "afterGetItem": {
        "9,10": [
            {
                "type": "insert",
                "loc": [
                    0,
                    1
                ],
                "floorId": "MT33"
            }
        ],
        "9,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT33"
            }
        ],
        "9,7": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT33"
            }
        ],
        "11,7": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT33"
            }
        ],
        "11,5": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT33"
            }
        ],
        "10,5": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[9, 5],\n\t[11, 5],\n\t[9, 7],\n\t[11, 7],\n]\n// loc_arr.forEach(loc => {\n// \tif (core.getBlockCls(loc[0], loc[1]) == \"enemys\") {\n// \t\tbool = false;\n// \t}\n// });\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT33');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool);\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [],
                "false": [
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            10,
                            4
                        ],
                        "async": true
                    },
                    {
                        "type": "closeDoor",
                        "id": "specialDoor",
                        "loc": [
                            10,
                            8
                        ],
                        "async": true
                    },
                    {
                        "type": "waitAsync"
                    }
                ]
            },
            {
                "type": "hide",
                "remove": true,
                "time": 0
            }
        ]
    },
    "afterOpenDoor": {},
    "cannotMove": {},
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "fgmap": [

],
    "upFloor": [
        2,
        1
    ],
    "downFloor": [
        10,
        1
    ],
    "autoEvent": {},
    "beforeBattle": {
        "9,10": [
            {
                "type": "setValue",
                "name": "flag:战后保留图块",
                "value": "true"
            }
        ],
        "10,5": [
            {
                "type": "setValue",
                "name": "flag:战后保留图块",
                "value": "true"
            }
        ]
    },
    "cannotMoveIn": {}
}