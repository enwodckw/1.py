main.floors.MT39=
{
    "floorId": "MT39",
    "title": "魔塔 第39层",
    "name": "第 39 层",
    "width": 13,
    "height": 13,
    "map": [
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  1,  0,  0, 88,  1],
    [  1,  0, 81,  0, 81,  0, 81,  0,  1,122,  0,  0,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  1,  0,  0, 21,  1],
    [  1,  0, 81,  0, 81,  0, 81,  0,  1,  1, 81,  1,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  1,  0,  0,225,  1],
    [  1,  0, 81,  0, 81,  0, 81,  0,  1,216,  1, 27,  1],
    [  1,  0,  0,  0,  0,  0,  0,  0,  1,  0,  0,212,  1],
    [  1,  1, 82,  1,  1,  1,  1,  1,  1,  1, 81,  1,  1],
    [  1,  0,  0,212,  1,224, 28,227,  1,  0,227,  0,  1],
    [  1,  1,212,  0, 81,  0,  1,  0, 81,  0,  0,168,  1],
    [  1,121,  0, 21,  1,  0,216,  0,  1, 31,168, 87,  1],
    [  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1]
],
    "canFlyTo": true,
    "canFlyFrom": true,
    "canUseQuickShop": true,
    "images": [],
    "ratio": 4,
    "defaultGround": "ground",
    "bgm": "section4.mp3",
    "firstArrive": [],
    "eachArrive": [],
    "parallelDo": "",
    "events": {
        "4,4": {
            "trigger": "action",
            "enable": true,
            "noPass": null,
            "displayDamage": true,
            "opacity": 1,
            "filter": {
                "blur": 0,
                "hue": 0,
                "grayscale": 0,
                "invert": false,
                "shadow": 0
            },
            "data": [
                {
                    "type": "if",
                    "condition": "(blockId:4,4==='centerFly')",
                    "true": [
                        {
                            "type": "addValue",
                            "name": "item:centerFly",
                            "value": "3"
                        },
                        {
                            "type": "hide",
                            "remove": true,
                            "time": 0
                        }
                    ],
                    "false": [
                        {
                            "type": "openDoor",
                            "needKey": true
                        }
                    ]
                }
            ]
        },
        "0,0": [
            {
                "type": "function",
                "function": "function(){\nvar bool = true;\nvar loc_arr = [\n\t[4, 2],\n\t[6, 4],\n]\n/*loc_arr.forEach(loc => {\n\tif (core.getBlockId(loc[0], loc[1], 'MT39') == \"yellowDoor\") {\n\t\tbool = false;\n\t}\n});*/\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT39');\n\tif (BlockId !== null && BlockId !== 'none') {\n\t\tbool = false;\n\t}\n});\nvar loc_arr = [\n\t[2, 2],\n\t[2, 4],\n\t[2, 6],\n\t[4, 4],\n\t[4, 6],\n\t[6, 2],\n\t[6, 6],\n]\n/*loc_arr.forEach(loc => {\n\tif (core.getBlockId(loc[0], loc[1], 'MT39') != \"yellowDoor\") {\n\t\tbool = false;\n\t}\n});*/\nloc_arr.forEach(loc => {\n\tconst BlockId = core.getBlockId(loc[0], loc[1], 'MT39');\n\tif (BlockId === null || BlockId === 'none') {\n\t\tbool = false;\n\t}\n});\ncore.setFlag(\"open_yes\", bool)\n}"
            },
            {
                "type": "if",
                "condition": "flag:open_yes",
                "true": [
                    {
                        "type": "setBlock",
                        "number": "centerFly",
                        "loc": [
                            [
                                4,
                                4
                            ]
                        ],
                        "floorId": "MT39",
                        "time": 50
                    }
                ]
            }
        ]
    },
    "changeFloor": {
        "11,11": {
            "floorId": ":next",
            "stair": "downFloor",
            "time": 0
        },
        "11,1": {
            "floorId": ":before",
            "stair": "upFloor",
            "time": 0
        }
    },
    "afterBattle": {
        "4,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT39"
            }
        ],
        "6,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT39"
            }
        ]
    },
    "afterGetItem": {
        "4,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT39"
            }
        ],
        "6,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT39"
            }
        ]
    },
    "afterOpenDoor": {
        "4,2": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT39"
            }
        ],
        "6,4": [
            {
                "type": "insert",
                "loc": [
                    0,
                    0
                ],
                "floorId": "MT39"
            }
        ]
    },
    "cannotMove": {},
    "fgmap": [

],
    "bgmap": [
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 17],
    [ 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17]
],
    "upFloor": [
        11,
        10
    ],
    "downFloor": [
        11,
        2
    ],
    "autoEvent": {},
    "beforeBattle": {},
    "cannotMoveIn": {}
}