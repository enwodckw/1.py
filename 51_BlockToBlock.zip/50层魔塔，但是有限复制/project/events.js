var events_c12a15a8_c380_4b28_8144_256cba95f760 = 
{
	"commonEvent": {
		"加点事件": [
			{
				"type": "comment",
				"text": "通过传参，flag:arg1 表示当前应该的加点数值"
			},
			{
				"type": "choices",
				"choices": [
					{
						"text": "攻击+${1*flag:arg1}",
						"action": [
							{
								"type": "setValue",
								"name": "status:atk",
								"operator": "+=",
								"value": "1*flag:arg1"
							}
						]
					},
					{
						"text": "防御+${2*flag:arg1}",
						"action": [
							{
								"type": "setValue",
								"name": "status:def",
								"operator": "+=",
								"value": "2*flag:arg1"
							}
						]
					},
					{
						"text": "生命+${200*flag:arg1}",
						"action": [
							{
								"type": "setValue",
								"name": "status:hp",
								"operator": "+=",
								"value": "200*flag:arg1"
							}
						]
					}
				]
			}
		],
		"回收钥匙商店": [
			{
				"type": "comment",
				"text": "此事件在全局商店中被引用了(全局商店keyShop)"
			},
			{
				"type": "comment",
				"text": "解除引用前勿删除此事件"
			},
			{
				"type": "comment",
				"text": "玩家在快捷列表（V键）中可以使用本公共事件"
			},
			{
				"type": "while",
				"condition": "1",
				"data": [
					{
						"type": "choices",
						"text": "\t[商人,trader]你有多余的钥匙想要出售吗？",
						"choices": [
							{
								"text": "黄钥匙（10金币）",
								"color": [
									255,
									255,
									0,
									1
								],
								"action": [
									{
										"type": "if",
										"condition": "item:yellowKey >= 1",
										"true": [
											{
												"type": "setValue",
												"name": "item:yellowKey",
												"operator": "-=",
												"value": "1"
											},
											{
												"type": "setValue",
												"name": "status:money",
												"operator": "+=",
												"value": "10"
											}
										],
										"false": [
											"\t[商人,trader]你没有黄钥匙！"
										]
									}
								]
							},
							{
								"text": "蓝钥匙（50金币）",
								"color": [
									0,
									0,
									255,
									1
								],
								"action": [
									{
										"type": "if",
										"condition": "item:blueKey >= 1",
										"true": [
											{
												"type": "setValue",
												"name": "item:blueKey",
												"operator": "-=",
												"value": "1"
											},
											{
												"type": "setValue",
												"name": "status:money",
												"operator": "+=",
												"value": "50"
											}
										],
										"false": [
											"\t[商人,trader]你没有蓝钥匙！"
										]
									}
								]
							},
							{
								"text": "离开",
								"action": [
									{
										"type": "exit"
									}
								]
							}
						]
					}
				]
			}
		],
		"游戏说明": [
			{
				"type": "choices",
				"choices": [
					{
						"text": "游戏简介",
						"action": [
							"h5版本是按照flash版复刻，其中部分对话使用的魔塔盛宴的版本。",
							"地图复制：数码宝贝51、641\n部分事件复制：小艾\n默认背景音乐：无；可在切换音乐处设置\n游戏音乐、怪物显伤等开关可以在系统设置里打开和关闭",
							"想要获得更详细的介绍，可以在菜单——游戏信息——游戏主页中进入本塔的评论区，查看置顶评论。",
							{
								"type": "insert",
								"name": "游戏说明"
							}
						]
					},
					{
						"text": "游戏结局",
						"action": [
							{
								"type": "if",
								"condition": "flag:addhp",
								"true": [
									"疯狂加血模式下，本塔有且仅有一个专属结局。",
									{
										"type": "insert",
										"name": "游戏说明"
									}
								],
								"false": [
									"本塔共有四个结局。\n在原版魔塔中，使用下楼器和破墙镐（或下楼器和地震卷轴）可以封印魔王，因此，这个版本如保留下楼器和破墙镐（或下楼器和地震卷轴）击败魔王，即可打出True End，否则为Normal End。",
									"不论是Normal End还是True End，都分为穿墙结局和不穿墙结局，如果从未使用对话穿墙，可以打出不穿墙结局。",
									{
										"type": "insert",
										"name": "游戏说明"
									}
								]
							}
						]
					},
					{
						"text": "对话穿墙",
						"action": [
							"在与老人对话后，或购买商人的物品并再次对话后，可以立即清除，或走一步再清除身边的某一堵墙（不必是暗墙）。",
							"这期间不能瞬移、打怪、开门和使用道具，否则穿墙会失败。",
							{
								"type": "insert",
								"name": "游戏说明"
							}
						]
					},
					{
						"text": "切换音乐",
						"action": [
							{
								"type": "choices",
								"choices": [
									{
										"text": "精灵石 3个小萝莉在一起",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "1"
											},
											{
												"type": "playBgm",
												"name": "xiaoluoli.mp3"
											}
										]
									},
									{
										"text": "精灵石 晚上家里和镇子",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "2"
											},
											{
												"type": "playBgm",
												"name": "wan.mp3"
											}
										]
									},
									{
										"text": "精灵石 黄昏的镇子",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "3"
											},
											{
												"type": "playBgm",
												"name": "huang.mp3"
											}
										]
									},
									{
										"text": "仙境传说-守候永恒的爱",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "4"
											},
											{
												"type": "playBgm",
												"name": "xian.mp3"
											}
										]
									},
									{
										"text": "精灵石 精灵石传说",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "5"
											},
											{
												"type": "playBgm",
												"name": "chuanshuo.mp3"
											}
										]
									},
									{
										"text": "精灵石 ed【神曲】",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "6"
											},
											{
												"type": "playBgm",
												"name": "ed.mp3"
											}
										]
									},
									{
										"text": "精灵石 幸福之花",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "7"
											},
											{
												"type": "playBgm",
												"name": "hua.mp3"
											}
										]
									},
									{
										"text": "精灵石 迷宫",
										"action": [
											{
												"type": "setValue",
												"name": "flag:bgm",
												"value": "8"
											},
											{
												"type": "playBgm",
												"name": "migong.mp3"
											}
										]
									},
									{
										"text": "离开",
										"action": []
									}
								]
							},
							{
								"type": "insert",
								"name": "游戏说明"
							}
						]
					},
					{
						"text": "返回游戏",
						"action": []
					}
				]
			}
		],
		"对话": [
			{
				"type": "switch",
				"condition": "flag:arg1",
				"caseList": [
					{
						"case": "2",
						"action": [
							{
								"type": "if",
								"condition": "(!flag:arg4)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'谢谢你救了我，为了感谢你的帮助请收下这些礼物。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话2",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "choices",
										"text": "\t[商人,woman]谢谢你救了我 我可以帮你提升3%的攻击和防御",
										"choices": [
											{
												"text": "现在提升",
												"action": [
													{
														"type": "playSound",
														"name": "item.mp3"
													},
													{
														"type": "addValue",
														"name": "status:atk",
														"value": "Math.round(status:atk*0.03)"
													},
													{
														"type": "addValue",
														"name": "status:def",
														"value": "Math.round(status:def*0.03)"
													},
													{
														"type": "setValue",
														"name": "flag:talking",
														"value": "0"
													},
													{
														"type": "hide",
														"time": 50
													}
												]
											},
											{
												"text": "等会再说",
												"action": []
											}
										]
									}
								]
							}
						]
					},
					{
						"case": "3",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'众所周知，乌冬的塔都是爽塔。如果某些时候觉得很牢，思考一下是不是大方向的思路出了偏差。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话3",
								"value": "1"
							}
						]
					},
					{
						"case": "4",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你是否发现每次对话之后你都没有神秘的能力'"
							},
							{
								"type": "setValue",
								"name": "flag:对话4",
								"value": "1"
							}
						]
					},
					{
						"case": "6",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 4)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'购买物品之后再与商人对话，他会告诉你一些重要的消息。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话6",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'魔塔共有50层，每10层为一个区域。如果不打败此区域的头目就不能到更高的地方，但有时候也可以临阵脱逃。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话602",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "7",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你的攻击比敌人防御高时就能对他造成伤害，你防御比敌人攻击高或一样时就能无伤。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话7",
								"value": "1"
							}
						]
					},
					{
						"case": "12",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'本塔有很多暗墙，比如5 9 12 14 16 18 35 36层，你都找到了吗？'"
							},
							{
								"type": "setValue",
								"name": "flag:对话12",
								"value": "1"
							}
						]
					},
					{
						"case": "15",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'十字架对兽人和吸血鬼是神器，它被藏在这之上的某层中。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话15",
								"value": "1"
							}
						]
					},
					{
						"case": "16",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'整个魔塔有2把藏在墙里的红钥匙。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话16",
								"value": "1"
							}
						]
					},
					{
						"case": "18",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'在这区域不多次提升攻击力，就不能打败石头人，切记前人教训。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话18",
								"value": "1"
							}
						]
					},
					{
						"case": "21",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'大法师住在25楼，他是魔塔的主人，以你现在的状态去攻击他简直就是自杀，你应当在取得更高级别的道具后再去打败他，当然你也可以不打。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话21",
								"value": "1"
							}
						]
					},
					{
						"case": "23",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'我没有什么可说的，但有一个确切的消息藏在这个楼层。虽然很多人可能看不到，但我敢打赌你一定看到了这段话。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话23",
								"value": "1"
							}
						]
					},
					{
						"case": "27",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'如果你没有使用过4层的祭坛，在12层供奉不超过4次。那么祝贺你，你的前期是比较成功的。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话27",
								"value": "1"
							}
						]
					},
					{
						"case": "31",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'你居然买了我的钥匙，那我就告诉你一个秘密，魔塔里有个幸运金币，拥有它在打败敌人后能获得2倍的金币。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话3102",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'双手剑士的攻击力太高了，你最好到能对他一击必杀时再与他战斗，但是如果他主动攻击你，你仍然会受到一次伤害。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话31",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "33",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'别匆忙，放慢速度，反正你也不会听。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话33",
								"value": "1"
							}
						]
					},
					{
						"case": "36",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'本层有暗道，但是如果你能用好地震卷轴，可以省更多血。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话36",
								"value": "1"
							}
						]
					},
					{
						"case": "37",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你需要用地震卷轴才能取走这里的所有宝物，当然你也可以不取，51层魔塔最好玩的地方就是道具有多种用法。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话37",
								"value": "1"
							}
						]
					},
					{
						"case": "38",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'存放圣剑的房间的门没坏，你可以想想怎么进去。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话38",
								"value": "1"
							}
						]
					},
					{
						"case": "39",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg2 == 1)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'谜题：在3点，拥有传送功能的密宝，就会出现。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话39",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'你怎么连我的钥匙都买，那我就告诉你一个秘密，神圣剑有3种方法可以得到，不同的方法路线也会不同。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话3902",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "42",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'巫师会用魔法攻击路过的人，在2个魔法警卫间通过会使你的生命减少一半。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话42",
								"value": "1"
							}
						]
					},
					{
						"case": "45",
						"action": [
							{
								"type": "if",
								"condition": "(flag:arg3 == 3)",
								"true": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'神圣盾能防御魔法攻击，但它被藏在异空间的楼层内。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话45",
										"value": "1"
									}
								],
								"false": [
									{
										"type": "setValue",
										"name": "flag:content",
										"value": "'44楼被藏在异空间，你只能用移动宝物才能到达。'"
									},
									{
										"type": "setValue",
										"name": "flag:对话4502",
										"value": "1"
									}
								]
							}
						]
					},
					{
						"case": "46",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'41层其实是左右对称的。你应该能发现，打怪时如果不和怪物重叠，可以规避一些魔法攻击。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话46",
								"value": "1"
							}
						]
					},
					{
						"case": "47",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'如果要打败魔龙你需要 圣剑 圣盾 屠龙匕 或更高等级的装备。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话47",
								"value": "1"
							}
						]
					},
					{
						"case": "48",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'像骰子上5一样的形状是一种封印魔法，你最好记住，它在与魔王战斗时可能有用。'"
							},
							{
								"type": "setValue",
								"name": "flag:对话48",
								"value": "1"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "if",
				"condition": "flag:arg4",
				"true": [
					{
						"type": "if",
						"condition": "(flag:arg1!=2)",
						"true": [
							"\t[商人,woman]${flag:content}"
						],
						"false": []
					}
				],
				"false": [
					"\t[老人,man]${flag:content}"
				]
			},
			{
				"type": "switch",
				"condition": "flag:arg1",
				"caseList": [
					{
						"case": "2",
						"action": [
							{
								"type": "if",
								"condition": "(!flag:arg4)",
								"true": [
									{
										"type": "comment",
										"text": "如果不是商人"
									},
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "+=",
										"value": "1000"
									},
									{
										"type": "tip",
										"text": "获得1000金币"
									}
								],
								"false": []
							}
						]
					},
					{
						"case": "3",
						"action": []
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:talking",
				"value": "0"
			},
			{
				"type": "hide",
				"loc": [
					"core.nextX()",
					"core.nextY()"
				],
				"remove": true,
				"time": 500
			}
		],
		"商人": [
			{
				"type": "switch",
				"condition": "parseInt(core.status.floorId.substring(2))",
				"caseList": [
					{
						"case": "6",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "50"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把蓝钥匙'"
							}
						]
					},
					{
						"case": "7",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "50"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'五把黄钥匙'"
							}
						]
					},
					{
						"case": "12",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "800"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把红钥匙'"
							}
						]
					},
					{
						"case": "15",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "200"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把蓝钥匙'"
							}
						]
					},
					{
						"case": "31",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "1000"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'一把蓝钥匙, 四把黄钥匙'"
							}
						]
					},
					{
						"case": "38",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "200"
							},
							{
								"type": "setValue",
								"name": "flag:alt",
								"value": "1"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'大甩卖! 三把黄钥匙只要200金币, 先到先得!'"
							}
						]
					},
					{
						"case": "39",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "2000"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'三把蓝钥匙'"
							}
						]
					},
					{
						"case": "45",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "1000"
							},
							{
								"type": "setValue",
								"name": "flag:alt",
								"value": "1"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'你出1000金币, 我就帮你回复2000点生命值'"
							}
						]
					},
					{
						"case": "47",
						"action": [
							{
								"type": "setValue",
								"name": "flag:money",
								"value": "4000"
							},
							{
								"type": "setValue",
								"name": "flag:item",
								"value": "'地震卷轴'"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "choices",
				"text": "\t[商人,woman]${flag:alt ? flag:item : '我有'+flag:item+', 你出'+flag:money+'金币就卖给你'}",
				"choices": [
					{
						"text": "我太需要了",
						"action": [
							{
								"type": "if",
								"condition": "(status:money >= flag:money)",
								"true": [
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money"
									},
									{
										"type": "switch",
										"condition": "parseInt(core.status.floorId.substring(2))",
										"caseList": [
											{
												"case": "6",
												"action": [
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "7",
												"action": [
													{
														"type": "setValue",
														"name": "item:yellowKey",
														"operator": "+=",
														"value": "5"
													}
												]
											},
											{
												"case": "12",
												"action": [
													{
														"type": "setValue",
														"name": "item:redKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "15",
												"action": [
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "31",
												"action": [
													{
														"type": "setValue",
														"name": "item:yellowKey",
														"operator": "+=",
														"value": "4"
													},
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "38",
												"action": [
													{
														"type": "setValue",
														"name": "item:yellowKey",
														"operator": "+=",
														"value": "3"
													}
												]
											},
											{
												"case": "39",
												"action": [
													{
														"type": "setValue",
														"name": "item:blueKey",
														"operator": "+=",
														"value": "3"
													}
												]
											},
											{
												"case": "45",
												"action": [
													{
														"type": "playSound",
														"name": "item.mp3"
													},
													{
														"type": "setValue",
														"name": "status:hp",
														"operator": "+=",
														"value": "2000"
													}
												]
											},
											{
												"case": "47",
												"action": [
													{
														"type": "setValue",
														"name": "item:earthquake",
														"operator": "+=",
														"value": "1"
													}
												]
											},
											{
												"case": "default",
												"action": []
											}
										]
									},
									{
										"type": "function",
										"function": "function(){\nvar name = core.status.floorId + '@' + core.nextX() + '@' + core.nextY() + '@' + 'A';\ncore.setFlag(name, 1);\n}"
									}
								],
								"false": [
									"\t[商人,woman]你的金币不够${flag:money}枚，无法交易！"
								]
							}
						]
					},
					{
						"text": "下次再说",
						"action": []
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:alt",
				"value": "0"
			}
		],
		"商店": [
			{
				"type": "if",
				"condition": "(flag:times1===0)",
				"true": [
					{
						"type": "setValue",
						"name": "flag:times1",
						"value": "1"
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:money1",
				"value": "20+10*flag:times1*(flag:times1-1)"
			},
			{
				"type": "choices",
				"text": "\t[祭坛,blueShop]如果供奉${flag:money1}金币, 便可以增加你的力量, 你想要什么呢…",
				"choices": [
					{
						"text": "生命+${100*flag:times1}",
						"action": [
							{
								"type": "if",
								"condition": "(status:money>=flag:money1)",
								"true": [
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:hp",
										"operator": "+=",
										"value": "100*flag:times1"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money1"
									},
									{
										"type": "setValue",
										"name": "flag:times1",
										"operator": "+=",
										"value": "1"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "你的金币不足${flag:money1}枚，无法供奉！"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								]
							}
						]
					},
					{
						"text": "攻击+${2*flag:ratio}",
						"action": [
							{
								"type": "if",
								"condition": "(status:money>=flag:money1)",
								"true": [
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:atk",
										"operator": "+=",
										"value": "2*flag:ratio"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money1"
									},
									{
										"type": "setValue",
										"name": "flag:times1",
										"operator": "+=",
										"value": "1"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "你的金币不足${flag:money1}枚，无法供奉！"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								]
							}
						]
					},
					{
						"text": "防御+${4*flag:ratio}",
						"action": [
							{
								"type": "if",
								"condition": "(status:money>=flag:money1)",
								"true": [
									{
										"type": "playSound",
										"name": "item.mp3"
									},
									{
										"type": "setValue",
										"name": "status:def",
										"operator": "+=",
										"value": "4*flag:ratio"
									},
									{
										"type": "setValue",
										"name": "status:money",
										"operator": "-=",
										"value": "flag:money1"
									},
									{
										"type": "setValue",
										"name": "flag:times1",
										"operator": "+=",
										"value": "1"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "你的金币不足${flag:money1}枚，无法供奉！"
									},
									{
										"type": "insert",
										"name": "商店"
									}
								]
							}
						]
					},
					{
						"text": "离开",
						"action": []
					}
				]
			}
		],
		"记事本": [
			{
				"type": "if",
				"condition": "(flag:翻页===0)",
				"true": [
					{
						"type": "setValue",
						"name": "flag:翻页",
						"value": "1"
					}
				]
			},
			{
				"type": "if",
				"condition": "(flag:翻页===1)",
				"true": [
					{
						"type": "while",
						"condition": "true",
						"data": [
							{
								"type": "choices",
								"text": "记事本（只显示对话过的）",
								"choices": [
									{
										"text": "2层老人",
										"condition": "flag:对话2==1",
										"action": [
											"谢谢你救了我，为了感谢你的帮助请收下这些礼物。"
										]
									},
									{
										"text": "3层老人",
										"condition": "flag:对话3==1",
										"action": [
											"我可以给你怪物手册<快捷键x> 它能预测出当前楼层各类怪物对你的伤害"
										]
									},
									{
										"text": "4层老人",
										"condition": "flag:对话4==1",
										"action": [
											"你是否发现每次对话之后你都有一种神秘的能力"
										]
									},
									{
										"text": "6层老人",
										"condition": "flag:对话6==1",
										"action": [
											"购买物品之后再与商人对话，他会告诉你一些重要的消息。"
										]
									},
									{
										"text": "6层商人",
										"condition": "flag:对话602==1",
										"action": [
											"魔塔共有50层，每10层为一个区域。如果不打败此区域的头目就不能到更高的地方。"
										]
									},
									{
										"text": "7层商人",
										"condition": "flag:对话7==1",
										"action": [
											"你的攻击比敌人防御高时就能对他造成伤害 你防御比敌人攻击高或一样时就能无伤"
										]
									},
									{
										"text": "12层商人",
										"condition": "flag:对话12==1",
										"action": [
											"本塔有很多暗墙 比如5 9 12 14 16 18层 你都找到了吗"
										]
									},
									{
										"text": "15层商人",
										"condition": "flag:对话15==1",
										"action": [
											"十字架对兽人和吸血鬼是神器 它被藏在这之上的某层中"
										]
									},
									{
										"text": "16层老人",
										"condition": "flag:对话16==1",
										"action": [
											"整座魔塔中有2把藏在墙里的红钥匙"
										]
									},
									{
										"text": "跳到尾页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "3"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "下一页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "2"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "离开",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "exit"
											}
										]
									}
								]
							}
						]
					}
				],
				"false": []
			},
			{
				"type": "if",
				"condition": "(flag:翻页===2)",
				"true": [
					{
						"type": "while",
						"condition": "true",
						"data": [
							{
								"type": "choices",
								"text": "记事本（只显示对话过的）",
								"choices": [
									{
										"text": "18层老人",
										"condition": "flag:对话18==1",
										"action": [
											"在这区域不多次提升攻击力 就不能打败石头人 切记前人教训"
										]
									},
									{
										"text": "21层老人",
										"condition": "flag:对话21==1",
										"action": [
											"大法师住在25楼 他是魔塔的主人 以你现在的状态去攻击他简直就是自杀 你应当在取得更高级别的道具后再去打败他"
										]
									},
									{
										"text": "23层老人",
										"condition": "flag:对话23==1",
										"action": [
											"我没有什么可说的，但有一个确切的消息藏在这个楼层"
										]
									},
									{
										"text": "27层老人",
										"condition": "flag:对话27==1",
										"action": [
											"如果你没有使用过4层的祭坛 在12层供奉不超过4次 那么祝贺你 你的前期是比较成功的"
										]
									},
									{
										"text": "31层商人",
										"condition": "flag:对话3102==1",
										"action": [
											"你居然买了我的钥匙 那我就告诉你一个秘密 魔塔里有个幸运金币 拥有它在打败敌人后能获得2倍的金币"
										]
									},
									{
										"text": "31层老人",
										"condition": "flag:对话31==1",
										"action": [
											"双手剑士的攻击力太高了 你最好到能对他一击必杀时再与他战斗 但是如果他主动攻击你, 你仍然会受到一次伤害"
										]
									},
									{
										"text": "33层老人",
										"condition": "flag:对话33==1",
										"action": [
											"别匆忙, 放慢速度"
										]
									},
									{
										"text": "36层老人",
										"condition": "flag:对话36==1",
										"action": [
											"不用找了 本层没有暗道, 如果你能用好移动宝物 就可以省很多血"
										]
									},
									{
										"text": "37层老人",
										"condition": "flag:对话37==1",
										"action": [
											"你需要用地震卷轴才能取走这里的所有宝物 当然你也可以不取 51层魔塔最好玩的地方就是道具有多种用法"
										]
									},
									{
										"text": "上一页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "下一页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "3"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "离开",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "exit"
											}
										]
									}
								]
							}
						]
					}
				],
				"false": []
			},
			{
				"type": "if",
				"condition": "(flag:翻页===3)",
				"true": [
					{
						"type": "while",
						"condition": "true",
						"data": [
							{
								"type": "choices",
								"text": "记事本（只显示对话过的）",
								"choices": [
									{
										"text": "38层商人",
										"condition": "flag:对话38==1",
										"action": [
											"存放圣剑的房间的门坏了 你只能用其他方法进去"
										]
									},
									{
										"text": "39层老人",
										"condition": "flag:对话39==1",
										"action": [
											"谜题 在3点 拥有传送功能的密宝 就会出现"
										]
									},
									{
										"text": "39层商人",
										"condition": "flag:对话3902==1",
										"action": [
											"你居然买了我的钥匙 那我就告诉你一个秘密 神圣剑有3种方法可以得到 不同的方法路线也会不同"
										]
									},
									{
										"text": "42层老人",
										"condition": "flag:对话42==1",
										"action": [
											"巫师会用魔法攻击路过的人 在2个魔法警卫间通过会使你的生命减少一半"
										]
									},
									{
										"text": "45层老人",
										"condition": "flag:对话45==1",
										"action": [
											"神圣盾能防御魔法攻击 但它被藏在异空间的楼层内"
										]
									},
									{
										"text": "45层商人",
										"condition": "flag:对话4502==1",
										"action": [
											"44层被藏在异空间 你只能用移动宝物才能到达"
										]
									},
									{
										"text": "46层老人",
										"condition": "flag:对话46==1",
										"action": [
											"41层其实是左右对称的\n还有, 打怪时如果不和怪物重叠 可以规避一些魔法攻击"
										]
									},
									{
										"text": "47层商人",
										"condition": "flag:对话47==1",
										"action": [
											"如果要打败魔龙你需要 圣剑 圣盾 屠龙匕 或更高等级的装备"
										]
									},
									{
										"text": "48层老人",
										"condition": "flag:对话48==1",
										"action": [
											"像骰子上5一样的形状是一种封印魔法 你最好记住 它在与魔王战斗时可能有用 什么 别说胡话了 这房间没有魔法警卫"
										]
									},
									{
										"text": "上一页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "2"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "跳到首页",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "insert",
												"name": "记事本"
											}
										]
									},
									{
										"text": "离开",
										"action": [
											{
												"type": "setValue",
												"name": "flag:翻页",
												"value": "1"
											},
											{
												"type": "exit"
											}
										]
									}
								]
							}
						]
					}
				],
				"false": []
			}
		],
		"选择复制": [
			{
				"type": "comment",
				"text": "判断本层地图是否可以复制，如果不能则直接退出"
			},
			{
				"type": "function",
				"function": "function(){\nlet floorId = core.status.floorId;\n//console.log(floorId);\nlet floorIdNum = parseInt(floorId.slice(2));\n//console.log(floorIdNum);\nlet CanCopy = core.getFlag('CanCopyS');\n//console.log(CanCopy);\n//console.log(CanCopy[floorIdNum]);\ncore.setFlag('可以复制', CanCopy[floorIdNum]);\n}"
			},
			{
				"type": "if",
				"condition": "flag:可以复制",
				"true": [
					{
						"type": "setValue",
						"name": "flag:复制敌人",
						"value": "false"
					},
					{
						"type": "setValue",
						"name": "temp:X",
						"value": "-1+status:x"
					},
					{
						"type": "setValue",
						"name": "temp:Y",
						"value": "-1+status:y"
					},
					{
						"type": "tip",
						"text": "请选择要复制的敌人"
					},
					{
						"type": "while",
						"condition": "true",
						"data": [
							{
								"type": "showImage",
								"code": 1,
								"image": "range.png",
								"loc": [
									"32*(temp:X-2)",
									"32*(temp:Y-2)"
								],
								"opacity": 1,
								"time": 0
							},
							{
								"type": "wait",
								"forceChild": true,
								"data": [
									{
										"case": "mouse",
										"px": [
											0,
											512
										],
										"py": [
											0,
											512
										],
										"action": [
											{
												"type": "if",
												"condition": "(core.getBlockCls(1+flags.x,1+flags.y)==='enemys')",
												"true": [
													{
														"type": "setValue",
														"name": "flag:MonX",
														"value": "1+flags.x"
													},
													{
														"type": "setValue",
														"name": "flag:MonY",
														"value": "1+flags.y"
													},
													{
														"type": "setValue",
														"name": "temp:X",
														"value": "-1+status:x"
													},
													{
														"type": "setValue",
														"name": "temp:Y",
														"value": "-1+status:y"
													},
													{
														"type": "if",
														"condition": "(core.status.hero.flags.hard===3)",
														"true": [
															{
																"type": "comment",
																"text": "困难难度直接复制，同时设置变量MonX2,MonY2"
															},
															{
																"type": "function",
																"function": "function(){\nlet floorId = core.status.floorId;\nconst PasteEnemyList = [];\nfor (let j = 1; j < 12; j++) {\n\tfor (let k = 1; k < 12; k++) {\n\t\tif (core.getBlockId(j, k, floorId) === 'flower') {\n\t\t\tcore.setBlock(core.getBlockId(flags.MonX, flags.MonY, floorId), j, k, floorId);\n\t\t\tPasteEnemyList.push([j, k]);\n\t\t\tflags.MonX2 = j;\n\t\t\tflags.MonY2 = k;\n\t\t}\n\t}\n}\n//console.log(PasteEnemyList);\ncore.setFlag('PasteEnemyListS', PasteEnemyList);\n}"
															},
															{
																"type": "playSound",
																"name": "bomb.mp3"
															},
															{
																"type": "tip",
																"text": "复制成功"
															},
															{
																"type": "setValue",
																"name": "flag:复制敌人",
																"value": "true"
															},
															{
																"type": "comment",
																"text": "令本层的可复制为假"
															},
															{
																"type": "function",
																"function": "function(){\nlet floorId = core.status.floorId;\nlet floorIdNum = parseInt(floorId.slice(2));\nlet CanCopy = core.getFlag('CanCopyS');\nCanCopy[floorIdNum] = false;\ncore.setFlag('CanCopyS', CanCopy);\n}"
															}
														],
														"false": [
															{
																"type": "setValue",
																"name": "temp:X",
																"value": "flags.x"
															},
															{
																"type": "setValue",
																"name": "temp:Y",
																"value": "flags.y"
															},
															{
																"type": "tip",
																"text": "请选择敌人要复制到的位置"
															},
															{
																"type": "while",
																"condition": "true",
																"data": [
																	{
																		"type": "showImage",
																		"code": 1,
																		"image": "range.png",
																		"loc": [
																			"32*(temp:X-2)",
																			"32*(temp:Y-2)"
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "wait",
																		"forceChild": true,
																		"data": [
																			{
																				"case": "mouse",
																				"px": [
																					0,
																					512
																				],
																				"py": [
																					0,
																					512
																				],
																				"action": [
																					{
																						"type": "function",
																						"function": "function(){\n//console.log(1+flags.x,1+flags.y);\n}"
																					},
																					{
																						"type": "comment",
																						"text": "判断能否粘贴怪物到该位置"
																					},
																					{
																						"type": "function",
																						"function": "function(){\nlet CanPasteEnemy = true;\n//if (core.status.hero.flags.hard === 3 && core.getBlockId(1 + flags.x, 1 + flags.y) === 'flower') CanPasteEnemy = false;\n\nif (flags.MonX === 1 + flags.x && flags.MonY === 1 + flags.y) CanPasteEnemy = false;\ncore.setFlag('允许粘贴怪物', CanPasteEnemy);\n}"
																					},
																					{
																						"type": "if",
																						"condition": "(!flag:允许粘贴怪物)",
																						"true": [
																							{
																								"type": "tip",
																								"text": "该位置不符合条件，已退出选择"
																							}
																						],
																						"false": [
																							{
																								"type": "comment",
																								"text": "用于判断图块能否粘贴的变量"
																							},
																							{
																								"type": "setValue",
																								"name": "flag:MonX2",
																								"value": "1+flags.x"
																							},
																							{
																								"type": "setValue",
																								"name": "flag:MonY2",
																								"value": "1+flags.y"
																							},
																							{
																								"type": "function",
																								"function": "function(){\n//console.log(flags.MonX,flags.MonY);\n}"
																							},
																							{
																								"type": "function",
																								"function": "function(){\n//console.log(core.getBlockId(flags.MonX,flags.MonY));\n}"
																							},
																							{
																								"type": "function",
																								"function": "function(){\ncore.setBlock(core.getBlockId(flags.MonX, flags.MonY), 1 + flags.x, 1 + flags.y);\n}"
																							},
																							{
																								"type": "playSound",
																								"name": "bomb.mp3"
																							},
																							{
																								"type": "tip",
																								"text": "复制成功"
																							},
																							{
																								"type": "setValue",
																								"name": "flag:复制敌人",
																								"value": "true"
																							},
																							{
																								"type": "comment",
																								"text": "令本层的可复制为假"
																							},
																							{
																								"type": "function",
																								"function": "function(){\nlet floorId = core.status.floorId;\nlet floorIdNum = parseInt(floorId.slice(2));\nlet CanCopy = core.getFlag('CanCopyS');\n//console.log(CanCopy);\n//console.log(CanCopy[floorIdNum]);\nCanCopy[floorIdNum] = false;\ncore.setFlag('CanCopyS', CanCopy);\n}"
																							}
																						]
																					},
																					{
																						"type": "break",
																						"n": 1
																					}
																				]
																			}
																		]
																	},
																	{
																		"type": "hideImage",
																		"code": 1,
																		"time": 0
																	}
																]
															}
														]
													}
												],
												"false": [
													{
														"type": "tip",
														"text": "该位置不符合条件，已退出选择"
													}
												]
											},
											{
												"type": "break",
												"n": 1
											}
										]
									}
								]
							},
							{
								"type": "hideImage",
								"code": 1,
								"time": 0
							}
						]
					},
					{
						"type": "hideImage",
						"code": 1,
						"time": 0
					},
					{
						"type": "if",
						"condition": "flag:复制敌人",
						"true": [
							{
								"type": "comment",
								"text": "判断本层地图是否还存在道具，如果不存在则直接退出"
							},
							{
								"type": "function",
								"function": "function(){\nlet floorId = core.status.floorId;\nouter:\n\tfor (let j = 1; j < 12; j++) {\n\t\tfor (let k = 1; k < 12; k++) {\n\t\t\tif (core.getBlockCls(j, k, floorId) === 'items') {\n\t\t\t\tcore.setFlag('存在道具', true);\n\t\t\t\tbreak outer;\n\t\t\t}\n\t\t}\n\t}\n}"
							},
							{
								"type": "if",
								"condition": "flag:存在道具",
								"true": [
									{
										"type": "tip",
										"text": "请选择要复制的图块"
									},
									{
										"type": "while",
										"condition": "true",
										"data": [
											{
												"type": "setValue",
												"name": "temp:X",
												"value": "flags.x"
											},
											{
												"type": "setValue",
												"name": "temp:Y",
												"value": "flags.y"
											},
											{
												"type": "showImage",
												"code": 1,
												"image": "range.png",
												"loc": [
													"32*(temp:X-2)",
													"32*(temp:Y-2)"
												],
												"opacity": 1,
												"time": 0
											},
											{
												"type": "wait",
												"forceChild": true,
												"data": [
													{
														"case": "mouse",
														"px": [
															0,
															512
														],
														"py": [
															0,
															512
														],
														"action": [
															{
																"type": "setValue",
																"name": "flag:BlockX",
																"value": "1+flags.x"
															},
															{
																"type": "setValue",
																"name": "flag:BlockY",
																"value": "1+flags.y"
															},
															{
																"type": "tip",
																"text": "请选择图块要复制到的位置"
															},
															{
																"type": "while",
																"condition": "true",
																"data": [
																	{
																		"type": "setValue",
																		"name": "temp:X",
																		"value": "flags.x"
																	},
																	{
																		"type": "setValue",
																		"name": "temp:Y",
																		"value": "flags.y"
																	},
																	{
																		"type": "showImage",
																		"code": 1,
																		"image": "range.png",
																		"loc": [
																			"32*(temp:X-2)",
																			"32*(temp:Y-2)"
																		],
																		"opacity": 1,
																		"time": 0
																	},
																	{
																		"type": "wait",
																		"forceChild": true,
																		"data": [
																			{
																				"case": "mouse",
																				"px": [
																					0,
																					512
																				],
																				"py": [
																					0,
																					512
																				],
																				"action": [
																					{
																						"type": "function",
																						"function": "function(){\n//console.log(1+flags.x,1+flags.y);\n}"
																					},
																					{
																						"type": "comment",
																						"text": "判断能否将图块粘贴到这里"
																					},
																					{
																						"type": "function",
																						"function": "function(){\nlet CanPasteItem = true;\nif (flags.MonX === 1 + flags.x && flags.MonY === 1 + flags.y) CanPasteItem = false;\nif (flags.MonX2 === 1 + flags.x && flags.MonY2 === 1 + flags.y) CanPasteItem = false;\nconst PasteEnemyList = core.getFlag('PasteEnemyListS', []);\nconst nx = 1 + flags.x,\n\tny = 1 + flags.y;\n//console.log(PasteEnemyList);\nif (PasteEnemyList.find(item => item[0] === nx && item[1] === ny)) {\n\tCanPasteItem = false;\n}\n\ncore.setFlag('允许粘贴图块', CanPasteItem);\n}"
																					},
																					{
																						"type": "if",
																						"condition": "(!flag:允许粘贴图块)",
																						"true": [
																							{
																								"type": "tip",
																								"text": "该位置不符合条件，请重新选择"
																							}
																						],
																						"false": [
																							{
																								"type": "function",
																								"function": "function(){\n//console.log(flags.BlockX,flags.BlockY);\n}"
																							},
																							{
																								"type": "function",
																								"function": "function(){\n//console.log(core.getBlockId(flags.BlockX,flags.BlockY));\n}"
																							},
																							{
																								"type": "function",
																								"function": "function(){\n//console.log(1 + flags.x, 1 + flags.y);\n}"
																							},
																							{
																								"type": "function",
																								"function": "function(){\n//core.setBlock(core.getBlockId(flags.BlockX, flags.BlockY), 1 + flags.x, 1 + flags.y);\nconst floorId = core.status.floorId;\nconst CopyBlockId = core.getBlockId(flags.BlockX, flags.BlockY, floorId);\nif (CopyBlockId !== null) {\n\tcore.setBlock(CopyBlockId, 1 + flags.x, 1 + flags.y, floorId);\n} else {\n\tcore.setBlock('none', 1 + flags.x, 1 + flags.y, floorId);\n}\n}"
																							},
																							{
																								"type": "playSound",
																								"name": "bomb.mp3"
																							},
																							{
																								"type": "tip",
																								"text": "复制成功"
																							},
																							{
																								"type": "setValue",
																								"name": "flag:复制敌人",
																								"value": "false"
																							},
																							{
																								"type": "break",
																								"n": 1
																							}
																						]
																					}
																				]
																			}
																		]
																	},
																	{
																		"type": "hideImage",
																		"code": 1,
																		"time": 0
																	}
																]
															},
															{
																"type": "break",
																"n": 1
															}
														]
													}
												]
											},
											{
												"type": "hideImage",
												"code": 1,
												"time": 0
											}
										]
									}
								],
								"false": [
									{
										"type": "tip",
										"text": "当前地图不存在道具，已退出选择"
									},
									{
										"type": "break",
										"n": 1
									}
								]
							}
						]
					},
					{
						"type": "hideImage",
						"code": 1,
						"time": 0
					}
				],
				"false": [
					{
						"type": "tip",
						"text": "本层已使用复制"
					}
				]
			}
		],
		"小偷": [
			{
				"type": "switch",
				"condition": "flag:arg1",
				"caseList": [
					{
						"case": "2",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你终于来了 我以为再也出不去了呢 35层有个魔龙挡路 我帮你挖一条暗道吧'"
							}
						]
					},
					{
						"case": "15",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'阿哈 你还好吗 这大章鱼挡住了我前进的道路 现在暗道终于完工了 你现在最好也躲开它 我要走了 再见'"
							}
						]
					},
					{
						"case": "29",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你来的正好 我这边暗道完工了 一起走吧'"
							}
						]
					},
					{
						"case": "35",
						"action": [
							{
								"type": "setValue",
								"name": "flag:content",
								"value": "'你好 暗道已挖好 你可用它绕过魔龙 我听说骑士队长实力差又爱吹牛 所以被魔法警卫们讨厌 这魔塔太危险了 我可不想再次被抓 我要离塔回去了 再见'"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			"\t[小偷,thief]${flag:content}",
			{
				"type": "switch",
				"condition": "flag:arg1",
				"caseList": [
					{
						"case": "2",
						"action": [
							{
								"type": "show",
								"loc": [
									[
										5,
										10
									]
								],
								"floorId": "MT35",
								"time": 0
							}
						]
					},
					{
						"case": "15",
						"action": [
							{
								"type": "openDoor",
								"loc": [
									"core.nextX()-1",
									"core.nextY()"
								],
								"floorId": "MT15"
							},
							{
								"type": "move",
								"loc": [
									"core.nextX()",
									"core.nextY()"
								],
								"time": 50,
								"steps": [
									"left:3"
								]
							}
						]
					},
					{
						"case": "29",
						"action": [
							{
								"type": "openDoor",
								"loc": [
									"core.nextX()",
									"core.nextY()+1"
								],
								"floorId": "MT29"
							},
							{
								"type": "move",
								"loc": [
									"core.nextX()",
									"core.nextY()"
								],
								"time": 20,
								"steps": [
									"down:9"
								]
							},
							{
								"type": "setBlock",
								"number": "thief",
								"loc": [
									[
										11,
										11
									]
								],
								"floorId": "MT2"
							},
							{
								"type": "show",
								"loc": [
									[
										11,
										11
									]
								],
								"floorId": "MT2",
								"time": 0
							}
						]
					},
					{
						"case": "35",
						"action": [
							{
								"type": "openDoor",
								"loc": [
									"core.nextX()-1",
									"core.nextY()"
								],
								"floorId": "MT35"
							}
						]
					},
					{
						"case": "default",
						"action": []
					}
				]
			},
			{
				"type": "setValue",
				"name": "flag:talking",
				"value": "0"
			},
			{
				"type": "hide",
				"loc": [
					"core.nextX()",
					"core.nextY()"
				],
				"remove": true,
				"time": 50
			}
		]
	}
}